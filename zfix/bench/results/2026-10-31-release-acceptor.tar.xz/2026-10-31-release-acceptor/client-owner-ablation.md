# FIX measured baseline

Build label: `release-server-io-owners-client-app-owners`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 3 | 58835.9 | 59046.1 | 5.309 | 5.344 |
| native-native / tls / scalar | 4 | 3 | 56088.1 | 56143.1 | 5.457 | 5.496 |
| native-quickfix / tcp / scalar | 4 | 3 | 46032.7 | 46113.1 | 6.702 | 6.716 |
| native-quickfix / tls / scalar | 4 | 3 | 43380.0 | 43402.2 | 7.257 | 7.275 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 1.832 | 1.325 | 39.594 | 43.203 |
| native-native / tls / scalar | 4 | 1.953 | 1.339 | 47.426 | 49.992 |
| native-quickfix / tcp / scalar | 4 | 2.077 | 1.622 | 39.375 | 37.012 |
| native-quickfix / tls / scalar | 4 | 2.258 | 1.800 | 45.859 | 41.168 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 4 / 1 | 3 | 14736.3 | 4142169 | 5278825 | 5316820 | 5316820 | 6646025 |
| native-native / tcp / scalar / 4 / 2 | 3 | 14746.4 | 4140913 | 5290776 | 5330216 | 5330216 | 6662770 |
| native-native / tcp / scalar / 4 / 3 | 3 | 14772.8 | 4129969 | 5269541 | 5314545 | 5314545 | 6643182 |
| native-native / tcp / scalar / 4 / 4 | 3 | 14790.5 | 4131355 | 5308694 | 5343914 | 5343914 | 6679893 |
| native-native / tls / scalar / 4 / 1 | 3 | 14032.5 | 4311258 | 5457171 | 5496189 | 5496189 | 6870237 |
| native-native / tls / scalar / 4 / 2 | 3 | 14034.7 | 4310344 | 5441971 | 5487965 | 5487965 | 6859957 |
| native-native / tls / scalar / 4 / 3 | 3 | 14036.6 | 4312065 | 5443197 | 5488645 | 5488645 | 6860807 |
| native-native / tls / scalar / 4 / 4 | 3 | 14039.3 | 4309389 | 5438144 | 5478628 | 5478628 | 6848285 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 11518.5 | 5567649 | 6649466 | 6662658 | 6662658 | 8328323 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 11523.3 | 5554940 | 6646390 | 6659391 | 6659391 | 8324239 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 11533.2 | 5562454 | 6701616 | 6715747 | 6715747 | 8394684 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 11538.1 | 5563780 | 6670181 | 6684880 | 6684880 | 8356100 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 10849.7 | 6219172 | 7254271 | 7272580 | 7272580 | 9090725 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 10851.3 | 6219838 | 7252650 | 7270734 | 7270734 | 9088418 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 10850.1 | 6219029 | 7256078 | 7272741 | 7272741 | 9090927 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 10851.2 | 6219653 | 7256656 | 7274662 | 7274662 | 9093328 |

Raw artifacts: `/tmp/zfix-acceptor-investigation/client-owner-ablation`.
