#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <exception>
#include <string>
#include <quickfix/Message.h>
#include <quickfix/DataDictionary.h>

static uint64_t now(clockid_t clock) {
  timespec t; clock_gettime(clock, &t);
  return uint64_t(t.tv_sec) * 1000000000 + t.tv_nsec;
}

int main(int argc, char **argv) {
  if (argc < 3 || argc > 4) return 2;
  unsigned long count = argc == 4 ? strtoul(argv[3], nullptr, 10) : 100000;
  if (!count) return 2;
  auto f = fopen(argv[2], "rb"); if (!f) return 2;
  fseek(f, 0, SEEK_END); auto n = ftell(f); rewind(f);
  if (n <= 0) { fclose(f); return 2; }
  std::string wire; wire.resize(n);
  bool read = fread(&wire[0], 1, n, f) == unsigned(n); fclose(f);
  if (!read) return 2;
  try {
    FIX::DataDictionary dictionary{argv[1]};
    uint64_t sink = 0, cpu = now(CLOCK_PROCESS_CPUTIME_ID), wall = now(CLOCK_MONOTONIC);
    for (unsigned long i = 0; i < count; ++i) {
      FIX::Message message{wire, dictionary, true}; dictionary.validate(message);
      sink += message.calculateLength();
      auto get = [&message, &sink](int tag, bool required = true) {
	if (!required && !message.isSetField(tag)) return;
	sink += message.getField(tag).length();
      };
      get(37); get(11); get(17); get(41, false);
      get(150); get(39); get(55); get(54);
      get(38, false); get(44, false); get(151); get(14); get(6);
      get(32, false); get(31, false); get(60, false);
      get(58, false); get(355, false);
    }
    wall = now(CLOCK_MONOTONIC) - wall; cpu = now(CLOCK_PROCESS_CPUTIME_ID) - cpu;
    printf("{\"count\":%lu,\"cpuNs\":%llu,\"wallNs\":%llu,\"sink\":%llu}\n", count,
      (unsigned long long)cpu, (unsigned long long)wall, (unsigned long long)sink);
  } catch (const std::exception &e) {
    fprintf(stderr, "%s\n", e.what()); return 1;
  }
  return 0;
}
