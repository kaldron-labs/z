import bisect
import collections
import functools
import json
from pathlib import Path
import re
import struct
import subprocess
import sys


@functools.cache
def symbols(path):
    with open(path, 'rb') as f:
        h = f.read(64)
        assert h[:6] == b'\x7fELF\x02\x01', path
        phoff = struct.unpack_from('<Q', h, 32)[0]
        size, count = struct.unpack_from('<HH', h, 54)
        f.seek(phoff); ph = f.read(size * count)
    loads = []
    for i in range(count):
        kind, flags, offset, addr, _, length, _, _ = struct.unpack_from('<IIQQQQQQ', ph, i * size)
        if kind == 1:
            loads.append((offset, addr, length))
    result = subprocess.run(['nm', '-n', '-S', '--defined-only', path],
                            capture_output=True, text=True)
    if not result.stdout.strip():
        result = subprocess.run(['nm', '-D', '-n', '-S', '--defined-only', path],
                                capture_output=True, text=True)
    found = {}
    for line in result.stdout.splitlines():
        p = line.split(None, 3)
        if len(p) == 4 and p[2] in ('t', 'T', 'w', 'W', 'i', 'I'):
            found[int(p[0], 16)] = (int(p[1], 16), p[3])
    addrs = sorted(found)
    return loads, addrs, found


def profile(path):
    data = path.read_bytes()
    h = struct.unpack_from('<5Q', data)
    assert h[0] == h[2] == 0 and h[1] >= 3
    offset = (h[1] + 2) * 8
    records = []
    while True:
        count, depth = struct.unpack_from('<2Q', data, offset); offset += 16
        pcs = struct.unpack_from('<' + str(depth) + 'Q', data, offset); offset += depth * 8
        if (count, depth, pcs) == (0, 1, (0,)):
            break
        records.append((count, pcs))
    maps = []
    for line in data[offset:].decode().splitlines():
        p = line.split(None, 5)
        if len(p) == 6 and p[5].startswith('/'):
            lo, hi = (int(n, 16) for n in p[0].split('-'))
            maps.append((lo, hi, int(p[2], 16), p[5]))
    maps.sort(); starts = [m[0] for m in maps]

    @functools.cache
    def resolve(pc):
        i = bisect.bisect_right(starts, pc) - 1
        if i < 0 or pc >= maps[i][1]:
            return ('unknown', hex(pc))
        lo, hi, pos, name = maps[i]
        loads, addrs, syms = symbols(name)
        file_pos = pc - lo + pos
        for start, addr, size in loads:
            if start <= file_pos < start + size:
                address = addr + file_pos - start
                j = bisect.bisect_right(addrs, address) - 1
                if j >= 0:
                    size, symbol = syms[addrs[j]]
                    if address < addrs[j] + size:
                        return (name, symbol)
                return (name, '+' + hex(address))
        return (name, '+' + hex(file_pos))

    flat = collections.Counter(); inclusive = collections.Counter(); modules = collections.Counter()
    total = sum(count for count, pcs in records)
    for count, pcs in records:
        stack = [resolve(pc if i == 0 else pc - 1) for i, pc in enumerate(pcs) if pc]
        flat[stack[0]] += count; modules[stack[0][0]] += count
        for key in set(stack):
            inclusive[key] += count
    keys = set(key for counter in (flat, inclusive) for key, _ in counter.most_common(100))
    names = sorted({key[1] for key in keys})
    demangled = subprocess.run(['c++filt'], input='\n'.join(names) + '\n',
                              capture_output=True, text=True, check=True).stdout.splitlines()
    names = dict(zip(names, demangled))
    def rows(counter):
        return [dict(module=key[0], function=names.get(key[1], key[1]),
                     mangled=key[1], samples=n, percent=100*n/total)
                for key, n in counter.most_common(100)]
    result = dict(samples=total, periodUs=h[3], flat=rows(flat), inclusive=rows(inclusive),
                  modules=[dict(module=key, samples=n, percent=100*n/total)
                           for key, n in modules.most_common()])
    path.with_suffix('.json').write_text(json.dumps(result, indent=2) + '\n')
    print(path.name, total, 'samples')
    for row in result['flat'][:18]:
        text = row['function']
        if len(text) > 190:
            text = text[:85] + ' ... ' + text[-100:]
        print(f"{row['percent']:5.1f}% {Path(row['module']).name}: {text}")


for name in sys.argv[1:]:
    profile(Path(name))
