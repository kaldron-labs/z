# FIX measured baseline

Build label: `release-original-owners-report-layout`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 3 | 78999.9 | 79166.4 | 4.423 | 4.427 |
| native-native / tls / scalar | 4 | 3 | 72872.6 | 73057.3 | 4.113 | 4.124 |
| quickfix-native / tcp / scalar | 4 | 3 | 57218.0 | 59574.3 | 5.978 | 5.989 |
| quickfix-native / tls / scalar | 4 | 3 | 42880.9 | 43045.5 | 7.327 | 7.385 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 1.596 | 1.620 | 43.363 | 49.426 |
| native-native / tls / scalar | 4 | 1.785 | 1.815 | 47.641 | 63.531 |
| quickfix-native / tcp / scalar | 4 | 1.443 | 1.839 | 32.949 | 44.402 |
| quickfix-native / tls / scalar | 4 | 1.884 | 2.027 | 37.246 | 55.059 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 4 / 1 | 3 | 19771.5 | 3245488 | 4137152 | 4153959 | 4153959 | 5192449 |
| native-native / tcp / scalar / 4 / 2 | 3 | 19788.5 | 3253987 | 4422598 | 4426859 | 4426859 | 5533574 |
| native-native / tcp / scalar / 4 / 3 | 3 | 19802.1 | 3246011 | 3928984 | 3932742 | 3932742 | 4915928 |
| native-native / tcp / scalar / 4 / 4 | 3 | 19804.4 | 3244912 | 4372944 | 4376232 | 4376232 | 5470290 |
| native-native / tls / scalar / 4 / 1 | 3 | 18277.1 | 3502021 | 4088639 | 4097473 | 4097473 | 5121842 |
| native-native / tls / scalar / 4 / 2 | 3 | 18278.5 | 3499585 | 4083236 | 4094035 | 4094035 | 5117544 |
| native-native / tls / scalar / 4 / 3 | 3 | 18250.3 | 3502340 | 4113240 | 4124210 | 4124210 | 5155263 |
| native-native / tls / scalar / 4 / 4 | 3 | 18251.5 | 3503641 | 4108605 | 4115004 | 4115004 | 5143755 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 15928.7 | 4035302 | 5699691 | 5717870 | 5717870 | 7147338 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 14550.0 | 4337329 | 5958687 | 5969842 | 5969842 | 7462303 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 14546.5 | 4334232 | 5958426 | 5971800 | 5971800 | 7464750 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 14549.1 | 4337616 | 5977594 | 5988725 | 5988725 | 7485907 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 10745.1 | 6111602 | 7320745 | 7384842 | 7384842 | 9231053 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 10756.6 | 6110558 | 7326160 | 7382599 | 7382599 | 9228249 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 10767.8 | 6109405 | 7326928 | 7381158 | 7381158 | 9226448 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 10776.0 | 6106442 | 7325319 | 7381791 | 7381791 | 9227239 |

Raw artifacts: `/tmp/zfix-acceptor-investigation/wire-only-ablation`.
