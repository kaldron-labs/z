# FIX measured baseline

Build label: `clang21-O3-release-before-acceptor-investigation`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 3 | 70414.7 | 70414.7 | 1.070 | 1.074 |
| native-native / tcp / scalar | 4 | 3 | 80588.0 | 80743.4 | 4.079 | 4.087 |
| native-native / tls / scalar | 1 | 3 | 63132.6 | 63132.6 | 1.222 | 1.227 |
| native-native / tls / scalar | 4 | 3 | 73689.2 | 73798.0 | 4.004 | 4.015 |
| native-quickfix / tcp / scalar | 1 | 3 | 45076.7 | 45076.7 | 1.655 | 1.666 |
| native-quickfix / tcp / scalar | 4 | 3 | 45079.6 | 45193.1 | 6.676 | 6.687 |
| native-quickfix / tls / scalar | 1 | 3 | 37819.1 | 37819.1 | 2.097 | 2.114 |
| native-quickfix / tls / scalar | 4 | 3 | 42870.8 | 42922.6 | 7.247 | 7.265 |
| quickfix-native / tcp / scalar | 1 | 3 | 48710.6 | 48710.6 | 1.577 | 1.588 |
| quickfix-native / tcp / scalar | 4 | 3 | 49121.4 | 51122.6 | 6.224 | 6.262 |
| quickfix-native / tls / scalar | 1 | 3 | 33371.5 | 33371.5 | 2.290 | 2.308 |
| quickfix-native / tls / scalar | 4 | 3 | 38447.0 | 38549.6 | 7.742 | 7.802 |
| quickfix-quickfix / tcp / scalar | 1 | 3 | 54670.4 | 54670.4 | 1.588 | 1.600 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 60086.3 | 62610.5 | 6.288 | 6.302 |
| quickfix-quickfix / tls / scalar | 1 | 3 | 41207.3 | 41207.3 | 2.071 | 2.088 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 49281.0 | 49415.2 | 7.829 | 7.888 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 0.412 | 0.428 | 23.895 | 23.895 |
| native-native / tcp / scalar | 4 | 1.591 | 1.634 | 42.848 | 49.215 |
| native-native / tls / scalar | 1 | 0.457 | 0.478 | 24.539 | 27.805 |
| native-native / tls / scalar | 4 | 1.759 | 1.806 | 51.215 | 63.660 |
| native-quickfix / tcp / scalar | 1 | 0.529 | 0.431 | 23.895 | 23.895 |
| native-quickfix / tcp / scalar | 4 | 2.111 | 1.653 | 39.496 | 37.387 |
| native-quickfix / tls / scalar | 1 | 0.605 | 0.493 | 24.465 | 24.922 |
| native-quickfix / tls / scalar | 4 | 2.244 | 1.780 | 45.664 | 41.562 |
| quickfix-native / tcp / scalar | 1 | 0.451 | 0.537 | 23.895 | 23.895 |
| quickfix-native / tcp / scalar | 4 | 1.618 | 1.989 | 32.785 | 43.969 |
| quickfix-native / tls / scalar | 1 | 0.591 | 0.666 | 24.020 | 26.637 |
| quickfix-native / tls / scalar | 4 | 2.024 | 2.231 | 37.562 | 54.953 |
| quickfix-quickfix / tcp / scalar | 1 | 0.419 | 0.388 | 24.020 | 24.020 |
| quickfix-quickfix / tcp / scalar | 4 | 1.372 | 1.325 | 32.906 | 37.023 |
| quickfix-quickfix / tls / scalar | 1 | 0.509 | 0.460 | 24.020 | 24.887 |
| quickfix-quickfix / tls / scalar | 4 | 1.656 | 1.507 | 37.578 | 41.035 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 1 / 1 | 3 | 70414.7 | 898330 | 1070139 | 1074388 | 1074388 | 1342985 |
| native-native / tcp / scalar / 4 / 1 | 3 | 20161.5 | 3205267 | 4078543 | 4086792 | 4086792 | 5108490 |
| native-native / tcp / scalar / 4 / 2 | 3 | 20177.3 | 3194695 | 4029412 | 4034414 | 4034414 | 5043018 |
| native-native / tcp / scalar / 4 / 3 | 3 | 20199.9 | 3191818 | 3904681 | 3911190 | 3911190 | 4888988 |
| native-native / tcp / scalar / 4 / 4 | 3 | 20194.5 | 3202877 | 3926655 | 3933098 | 3933098 | 4916373 |
| native-native / tls / scalar / 1 / 1 | 3 | 63132.6 | 1010212 | 1222097 | 1227194 | 1227194 | 1533993 |
| native-native / tls / scalar / 4 / 1 | 3 | 18466.2 | 3470792 | 4001202 | 4008258 | 4008258 | 5010323 |
| native-native / tls / scalar / 4 / 2 | 3 | 18448.0 | 3474404 | 4001389 | 4014708 | 4014708 | 5018385 |
| native-native / tls / scalar / 4 / 3 | 3 | 18439.5 | 3469941 | 4001275 | 4014019 | 4014019 | 5017524 |
| native-native / tls / scalar / 4 / 4 | 3 | 18444.2 | 3471575 | 4003709 | 4014018 | 4014018 | 5017523 |
| native-quickfix / tcp / scalar / 1 / 1 | 3 | 45076.7 | 1432481 | 1655127 | 1665629 | 1665629 | 2082037 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 11289.0 | 5971540 | 6618192 | 6628531 | 6628531 | 8285664 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 11297.7 | 5973269 | 6587473 | 6601406 | 6601406 | 8251758 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 11302.1 | 5963473 | 6676249 | 6687471 | 6687471 | 8359339 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 11304.2 | 5963619 | 6652372 | 6668273 | 6668273 | 8335342 |
| native-quickfix / tls / scalar / 1 / 1 | 3 | 37819.1 | 1572642 | 2097279 | 2113796 | 2113796 | 2642245 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 10745.7 | 6331453 | 7225283 | 7241485 | 7241485 | 9051857 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 10728.3 | 6332639 | 7226117 | 7242568 | 7242568 | 9053210 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 10724.2 | 6332487 | 7239940 | 7257445 | 7257445 | 9071807 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 10724.3 | 6333258 | 7246654 | 7264718 | 7264718 | 9080898 |
| quickfix-native / tcp / scalar / 1 / 1 | 3 | 48710.6 | 1260553 | 1577297 | 1588463 | 1588463 | 1985579 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 13734.9 | 4567440 | 5958075 | 5976247 | 5976247 | 7470309 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 12452.3 | 5410799 | 6200186 | 6215796 | 6215796 | 7769745 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 12462.1 | 5402903 | 6216843 | 6237480 | 6237480 | 7796850 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 12473.4 | 5415073 | 6223557 | 6262486 | 6262486 | 7828108 |
| quickfix-native / tls / scalar / 1 / 1 | 3 | 33371.5 | 2011030 | 2290050 | 2307666 | 2307666 | 2884583 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 9624.9 | 6448370 | 7741624 | 7802188 | 7802188 | 9752735 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 9630.2 | 6448775 | 7719699 | 7778165 | 7778165 | 9722707 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 9637.2 | 6441236 | 7698403 | 7756209 | 7756209 | 9695262 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 9657.2 | 6435959 | 7696588 | 7757660 | 7757660 | 9697075 |
| quickfix-quickfix / tcp / scalar / 1 / 1 | 3 | 54670.4 | 1073697 | 1588259 | 1600431 | 1600431 | 2000539 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 16742.1 | 3643960 | 6193625 | 6205323 | 6205323 | 7756654 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 15288.6 | 4159451 | 6282295 | 6296584 | 6296584 | 7870730 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 15287.5 | 4160186 | 6287792 | 6302078 | 6302078 | 7877598 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 15292.4 | 4159165 | 6276373 | 6287969 | 6287969 | 7859962 |
| quickfix-quickfix / tls / scalar / 1 / 1 | 3 | 41207.3 | 1529722 | 2071184 | 2088344 | 2088344 | 2610430 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 12356.8 | 5021589 | 7826354 | 7882464 | 7882464 | 9853080 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 12357.5 | 5022006 | 7828599 | 7887087 | 7887087 | 9858859 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 12348.7 | 5025383 | 7826058 | 7887279 | 7887279 | 9859099 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 12352.2 | 5029511 | 7827250 | 7887580 | 7887580 | 9859475 |

Raw artifacts: `/tmp/zfix-acceptor-investigation/release-before-s1`, `/tmp/zfix-acceptor-investigation/release-before-s4`.
