# FIX process load measurements

Build label: clang21-O3-release-original-owners-report-layout. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 71673.848 | 71673.848 | 0.407345 / 25018368 | 0.420841 / 25018368 |
| native-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 71139.878 | 71139.878 | 0.410445 / 25018368 | 0.425779 / 25018368 |
| native-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 68320.162 | 68320.162 | 0.421339 / 25018368 | 0.434551 / 25018368 |
| native-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 62599.044 | 62599.044 | 0.471315 / 25649152 | 0.489812 / 30261248 |
| native-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 63770.122 | 63770.122 | 0.455360 / 25124864 | 0.475581 / 29462528 |
| native-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 60036.628 | 60036.628 | 0.471753 / 25059328 | 0.498493 / 29597696 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 45464.833 | 45464.833 | 0.550581 / 25018368 | 0.441059 / 25018368 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 49795.274 | 49795.274 | 0.511380 / 25018368 | 0.420058 / 25018368 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 45822.564 | 45822.564 | 0.532681 / 25018368 | 0.444583 / 25018368 |
| native-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 35028.118 | 35028.118 | 0.613234 / 25636864 | 0.531633 / 25853952 |
| native-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 39301.066 | 39301.066 | 0.603779 / 25546752 | 0.493529 / 26226688 |
| native-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 40085.173 | 40085.173 | 0.593628 / 25100288 | 0.479617 / 25939968 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 58730.342 | 58730.342 | 0.411279 / 25149440 | 0.485868 / 25149440 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 49526.233 | 49526.233 | 0.455805 / 25149440 | 0.519506 / 25149440 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 55267.865 | 55267.865 | 0.415115 / 25149440 | 0.508420 / 25149440 |
| quickfix-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 31900.943 | 31900.943 | 0.605887 / 25149440 | 0.674145 / 27602944 |
| quickfix-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 34247.138 | 34247.138 | 0.578883 / 25149440 | 0.653041 / 28000256 |
| quickfix-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 33092.608 | 33092.608 | 0.592246 / 25149440 | 0.646966 / 27848704 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 56874.650 | 56874.650 | 0.405935 / 25149440 | 0.390788 / 25149440 |
| quickfix-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 61154.041 | 61154.041 | 0.381661 / 25149440 | 0.358651 / 25149440 |
| quickfix-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 53801.651 | 53801.651 | 0.425925 / 25149440 | 0.387476 / 25149440 |
| quickfix-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 38669.714 | 38669.714 | 0.523313 / 25149440 | 0.464801 / 26247168 |
| quickfix-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 35587.752 | 35587.752 | 0.558605 / 25280512 | 0.477287 / 25952256 |
| quickfix-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 35976.176 | 35976.176 | 0.561318 / 25280512 | 0.491534 / 25968640 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806016 / 1910220 | 5505024 |
| native-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910220 / 4806016 | 5505024 |
| native-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805812 / 1910141 | 5505024 |
| native-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910141 / 4805812 | 5505024 |
| native-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805854 / 1910068 | 5505024 |
| native-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910068 / 4805854 | 5505024 |
| native-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805931 / 1910145 | 5505024 |
| native-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910145 / 4805931 | 5505024 |
| native-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805996 / 1910159 | 5505024 |
| native-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910159 / 4805996 | 5505024 |
| native-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805926 / 1910172 | 5505024 |
| native-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910172 / 4805926 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910178 | 5505024 |
| native-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910178 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910175 | 5505024 |
| native-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910175 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910132 | 5505024 |
| native-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910132 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910146 | 5505024 |
| native-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910146 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910220 | 5505024 |
| native-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910220 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910195 | 5505024 |
| native-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910195 / 4810790 | 1428169 |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806015 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4806015 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805721 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805721 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805888 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805888 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805954 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805954 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805847 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805847 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806016 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4806016 | 5505024 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 880663 / 973144 / 1007204 / 1043088 / 1058284 | 886465 / 979195 / 1013400 / 1047248 / 1060672 | 0 / 0 / 0 / 0 / 0 | 880663 / 973144 / 1007204 / 1043088 / 1058284 | 886465 / 979195 / 1013400 / 1047248 / 1060672 | 5505024 | 33803086.268 |
| native-native/scalar/tcp/2 / 1 | 887449 / 1006429 / 1062141 / 1119377 / 1165587 | 893237 / 1014879 / 1069234 / 1131122 / 1167432 | 0 / 0 / 0 / 0 / 0 | 887449 / 1006429 / 1062141 / 1119377 / 1165587 | 893237 / 1014879 / 1069234 / 1131122 / 1167432 | 5505024 | 33627032.331 |
| native-native/scalar/tcp/3 / 1 | 921129 / 1044365 / 1242911 / 1548460 / 1652161 | 927137 / 1050380 / 1247123 / 1551236 / 1654419 | 0 / 0 / 0 / 0 / 0 | 921129 / 1044365 / 1242911 / 1548460 / 1652161 | 927137 / 1050380 / 1247123 / 1551236 / 1654419 | 5505024 | 32955939.935 |
| native-native/scalar/tls/1 / 1 | 1010911 / 1166227 / 1236824 / 1668223 / 1740217 | 1017612 / 1173532 / 1240218 / 1670214 / 1745798 | 0 / 0 / 0 / 0 / 0 | 1010911 / 1166227 / 1236824 / 1668223 / 1740217 | 1017612 / 1173532 / 1240218 / 1670214 / 1745798 | 5505024 | 28881520.753 |
| native-native/scalar/tls/2 / 1 | 1002314 / 1126620 / 1181381 / 1212706 / 1243528 | 1009202 / 1134248 / 1187912 / 1219161 / 1254206 | 0 / 0 / 0 / 0 / 0 | 1002314 / 1126620 / 1181381 / 1212706 / 1243528 | 1009202 / 1134248 / 1187912 / 1219161 / 1254206 | 5505024 | 29853889.872 |
| native-native/scalar/tls/3 / 1 | 1056888 / 1178624 / 1213695 / 1239244 / 1284659 | 1064492 / 1187447 / 1221211 / 1246378 / 1288753 | 0 / 0 / 0 / 0 / 0 | 1056888 / 1178624 / 1213695 / 1239244 / 1284659 | 1064492 / 1187447 / 1221211 / 1246378 / 1288753 | 5505024 | 28702907.970 |
| native-quickfix/scalar/tcp/1 / 1 | 1428986 / 1533813 / 1573675 / 1621719 / 1639419 | 1441215 / 1546675 / 1587378 / 1638182 / 1652570 | 0 / 0 / 0 / 0 / 0 | 1428986 / 1533813 / 1573675 / 1621719 / 1639419 | 1441215 / 1546675 / 1587378 / 1638182 / 1652570 | 5505024 | 7356009.803 |
| native-quickfix/scalar/tcp/2 / 1 | 1287609 / 1396860 / 1436264 / 1591802 / 1642459 | 1297801 / 1406834 / 1447386 / 1602535 / 1668335 | 0 / 0 / 0 / 0 / 0 | 1287609 / 1396860 / 1436264 / 1591802 / 1642459 | 1297801 / 1406834 / 1447386 / 1602535 / 1668335 | 5505024 | 7341310.879 |
| native-quickfix/scalar/tcp/3 / 1 | 1426945 / 1537890 / 1569901 / 1594358 / 1645608 | 1439782 / 1551251 / 1582474 / 1607090 / 1658221 | 0 / 0 / 0 / 0 / 0 | 1426945 / 1537890 / 1569901 / 1594358 / 1645608 | 1439782 / 1551251 / 1582474 / 1607090 / 1658221 | 5505024 | 7410999.085 |
| native-quickfix/scalar/tls/1 / 1 | 1865536 / 2028401 / 2081250 / 2131745 / 2151712 | 1879142 / 2044379 / 2098039 / 2150837 / 2169207 | 0 / 0 / 0 / 0 / 0 | 1865536 / 2028401 / 2081250 / 2131745 / 2151712 | 1879142 / 2044379 / 2098039 / 2150837 / 2169207 | 5505024 | 16449729.801 |
| native-quickfix/scalar/tls/2 / 1 | 1564370 / 1863198 / 1945020 / 2007712 / 2020135 | 1576771 / 1877378 / 1958008 / 2023007 / 2042912 | 0 / 0 / 0 / 0 / 0 | 1564370 / 1863198 / 1945020 / 2007712 / 2020135 | 1576771 / 1877378 / 1958008 / 2023007 / 2042912 | 5505024 | 17621767.447 |
| native-quickfix/scalar/tls/3 / 1 | 1525251 / 1887534 / 1991150 / 2040199 / 2095849 | 1537035 / 1901804 / 2004833 / 2050699 / 2110488 | 0 / 0 / 0 / 0 / 0 | 1525251 / 1887534 / 1991150 / 2040199 / 2095849 | 1537035 / 1901804 / 2004833 / 2050699 / 2110488 | 5505024 | 17993289.333 |
| quickfix-native/scalar/tcp/1 / 1 | 1076769 / 1169068 / 1292286 / 1375038 / 1405483 | 1081035 / 1174381 / 1298600 / 1382880 / 1407938 | 0 / 0 / 0 / 0 / 0 | 1076769 / 1169068 / 1292286 / 1375038 / 1405483 | 1081035 / 1174381 / 1298600 / 1382880 / 1407938 | 1238429 | 4293616.470 |
| quickfix-native/scalar/tcp/2 / 1 | 1299421 / 1384125 / 1421484 / 1446224 / 1456622 | 1306951 / 1391880 / 1429441 / 1453648 / 1465445 | 0 / 0 / 0 / 0 / 0 | 1299421 / 1384125 / 1421484 / 1446224 / 1456622 | 1306951 / 1391880 / 1429441 / 1453648 / 1465445 | 1238429 | 4465917.517 |
| quickfix-native/scalar/tcp/3 / 1 | 1112417 / 1403064 / 1454147 / 1484754 / 1500101 | 1117949 / 1412053 / 1462964 / 1491897 / 1500823 | 0 / 0 / 0 / 0 / 0 | 1112417 / 1403064 / 1454147 / 1484754 / 1500101 | 1117949 / 1412053 / 1462964 / 1491897 / 1500823 | 1238429 | 4274300.709 |
| quickfix-native/scalar/tls/1 / 1 | 2011904 / 2178375 / 2252489 / 2309328 / 2334757 | 2028093 / 2195170 / 2269594 / 2327943 / 2344626 | 0 / 0 / 0 / 0 / 0 | 2011904 / 2178375 / 2252489 / 2309328 / 2334757 | 2028093 / 2195170 / 2269594 / 2327943 / 2344626 | 1238429 | 7825302.381 |
| quickfix-native/scalar/tls/2 / 1 | 1839363 / 2031859 / 2072284 / 2096988 / 2114087 | 1853759 / 2049339 / 2088863 / 2115242 / 2131377 | 0 / 0 / 0 / 0 / 0 | 1839363 / 2031859 / 2072284 / 2096988 / 2114087 | 1853759 / 2049339 / 2088863 / 2115242 / 2131377 | 1238429 | 7738852.314 |
| quickfix-native/scalar/tls/3 / 1 | 1900267 / 2097050 / 2172067 / 2210456 / 2220059 | 1916804 / 2114075 / 2190033 / 2227510 / 2239883 | 0 / 0 / 0 / 0 / 0 | 1900267 / 2097050 / 2172067 / 2210456 / 2220059 | 1916804 / 2114075 / 2190033 / 2227510 / 2239883 | 1238429 | 5034761.609 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 1062798 / 1420643 / 1586312 / 1643230 / 1654631 | 1067831 / 1429167 / 1597425 / 1653316 / 1668118 | 0 / 0 / 0 / 0 / 0 | 1062798 / 1420643 / 1586312 / 1643230 / 1654631 | 1067831 / 1429167 / 1597425 / 1653316 / 1668118 | 1238429 | 4252442.588 |
| quickfix-quickfix/scalar/tcp/2 / 1 | 1033421 / 1099782 / 1142772 / 1176840 / 1192450 | 1039484 / 1105893 / 1148019 / 1182007 / 1194718 | 0 / 0 / 0 / 0 / 0 | 1033421 / 1099782 / 1142772 / 1176840 / 1192450 | 1039484 / 1105893 / 1148019 / 1182007 / 1194718 | 1238429 | 4148315.386 |
| quickfix-quickfix/scalar/tcp/3 / 1 | 1204943 / 1516692 / 1582073 / 1621228 / 1635240 | 1212734 / 1528765 / 1594652 / 1630136 / 1647585 | 0 / 0 / 0 / 0 / 0 | 1204943 / 1516692 / 1582073 / 1621228 / 1635240 | 1212734 / 1528765 / 1594652 / 1630136 / 1647585 | 1238429 | 4250146.732 |
| quickfix-quickfix/scalar/tls/1 / 1 | 1594741 / 1831897 / 1983690 / 2070309 / 2084981 | 1607620 / 1845737 / 1999322 / 2084256 / 2099950 | 0 / 0 / 0 / 0 / 0 | 1594741 / 1831897 / 1983690 / 2070309 / 2084981 | 1607620 / 1845737 / 1999322 / 2084256 / 2099950 | 1238429 | 7328393.276 |
| quickfix-quickfix/scalar/tls/2 / 1 | 1588376 / 2207460 / 2275270 / 2332604 / 2344946 | 1600815 / 2224814 / 2292776 / 2350108 / 2362269 | 0 / 0 / 0 / 0 / 0 | 1588376 / 2207460 / 2275270 / 2332604 / 2344946 | 1600815 / 2224814 / 2292776 / 2350108 / 2362269 | 1238429 | 4722603.232 |
| quickfix-quickfix/scalar/tls/3 / 1 | 1605338 / 2237959 / 2292375 / 2780375 / 2853912 | 1618622 / 2255304 / 2311119 / 2802390 / 2861397 | 0 / 0 / 0 / 0 / 0 | 1605338 / 2237959 / 2292375 / 2780375 / 2853912 | 1618622 / 2255304 / 2311119 / 2802390 / 2861397 | 1238429 | 7396830.742 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
