# FIX process load measurements

Build label: release-server-io-owners-client-app-owners. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 55775.271 | 55908.495 | 1.872629 / 41517056 | 1.365554 / 44900352 |
| native-native / scalar / tcp / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 58835.881 | 59046.062 | 1.829849 / 41492480 | 1.325173 / 45121536 |
| native-native / scalar / tcp / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 59962.721 | 60187.439 | 1.832403 / 41377792 | 1.318189 / 45301760 |
| native-native / scalar / tls / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 56088.089 | 56143.050 | 1.934382 / 46460928 | 1.339026 / 51781632 |
| native-native / scalar / tls / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 53292.605 | 53370.770 | 1.976655 / 46010368 | 1.383811 / 51740672 |
| native-native / scalar / tls / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 56591.690 | 56672.759 | 1.953151 / 49729536 | 1.337340 / 52420608 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 48086.568 | 48168.947 | 2.011967 / 41287680 | 1.585702 / 38809600 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 45388.342 | 45486.017 | 2.116187 / 41005056 | 1.647834 / 38645760 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 46032.696 | 46113.064 | 2.077170 / 40812544 | 1.621924 / 38727680 |
| native-quickfix / scalar / tls / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 43380.019 | 43402.201 | 2.257642 / 47149056 | 1.800102 / 42967040 |
| native-quickfix / scalar / tls / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 44738.094 | 44813.270 | 2.229799 / 48087040 | 1.711466 / 43167744 |
| native-quickfix / scalar / tls / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 41004.586 | 41062.634 | 2.301734 / 46977024 | 1.847653 / 43012096 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805929 / 1910127 | 5505024 |
| native-native/scalar/tcp/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521283 / 2031294 | 5505024 |
| native-native/scalar/tcp/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521021 / 2031163 | 5505024 |
| native-native/scalar/tcp/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521544 / 2031270 | 5505024 |
| native-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910127 / 4805929 | 5505024 |
| native-native/scalar/tcp/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031294 / 5521283 | 5505024 |
| native-native/scalar/tcp/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031163 / 5521021 | 5505024 |
| native-native/scalar/tcp/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031270 / 5521544 | 5505024 |
| native-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806030 / 1910182 | 5505024 |
| native-native/scalar/tcp/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521093 / 2031071 | 5505024 |
| native-native/scalar/tcp/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520957 / 2031186 | 5505024 |
| native-native/scalar/tcp/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521519 / 2031260 | 5505024 |
| native-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910182 / 4806030 | 5505024 |
| native-native/scalar/tcp/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031071 / 5521093 | 5505024 |
| native-native/scalar/tcp/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031186 / 5520957 | 5505024 |
| native-native/scalar/tcp/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031260 / 5521519 | 5505024 |
| native-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805954 / 1910133 | 5505024 |
| native-native/scalar/tcp/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521103 / 2031172 | 5505024 |
| native-native/scalar/tcp/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521159 / 2031221 | 5505024 |
| native-native/scalar/tcp/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521488 / 2031257 | 5505024 |
| native-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910133 / 4805954 | 5505024 |
| native-native/scalar/tcp/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031172 / 5521103 | 5505024 |
| native-native/scalar/tcp/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031221 / 5521159 | 5505024 |
| native-native/scalar/tcp/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031257 / 5521488 | 5505024 |
| native-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805814 / 1910097 | 5505024 |
| native-native/scalar/tls/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521035 / 2031150 | 5505024 |
| native-native/scalar/tls/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521023 / 2031195 | 5505024 |
| native-native/scalar/tls/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521423 / 2031183 | 5505024 |
| native-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910097 / 4805814 | 5505024 |
| native-native/scalar/tls/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031150 / 5521035 | 5505024 |
| native-native/scalar/tls/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031195 / 5521023 | 5505024 |
| native-native/scalar/tls/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031183 / 5521423 | 5505024 |
| native-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805913 / 1910150 | 5505024 |
| native-native/scalar/tls/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521081 / 2031104 | 5505024 |
| native-native/scalar/tls/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521070 / 2031142 | 5505024 |
| native-native/scalar/tls/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521570 / 2031242 | 5505024 |
| native-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910150 / 4805913 | 5505024 |
| native-native/scalar/tls/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031104 / 5521081 | 5505024 |
| native-native/scalar/tls/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031142 / 5521070 | 5505024 |
| native-native/scalar/tls/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031242 / 5521570 | 5505024 |
| native-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805893 / 1910224 | 5505024 |
| native-native/scalar/tls/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521141 / 2031226 | 5505024 |
| native-native/scalar/tls/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520835 / 2031050 | 5505024 |
| native-native/scalar/tls/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521523 / 2031245 | 5505024 |
| native-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910224 / 4805893 | 5505024 |
| native-native/scalar/tls/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031226 / 5521141 | 5505024 |
| native-native/scalar/tls/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031050 / 5520835 | 5505024 |
| native-native/scalar/tls/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031245 / 5521523 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910156 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526026 / 2031209 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5525868 / 2031054 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526414 / 2031322 | 5505024 |
| native-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910156 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031209 / 5526026 | 1555267 |
| native-quickfix/scalar/tcp/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031054 / 5525868 | 1555457 |
| native-quickfix/scalar/tcp/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031322 / 5526414 | 1555459 |
| native-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910091 | 5505024 |
| native-quickfix/scalar/tcp/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526026 / 2031166 | 5505024 |
| native-quickfix/scalar/tcp/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5525868 / 2031171 | 5505024 |
| native-quickfix/scalar/tcp/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526414 / 2031305 | 5505024 |
| native-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910091 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031166 / 5526026 | 1555267 |
| native-quickfix/scalar/tcp/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031171 / 5525868 | 1555457 |
| native-quickfix/scalar/tcp/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031305 / 5526414 | 1555459 |
| native-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910209 | 5505024 |
| native-quickfix/scalar/tcp/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526026 / 2031192 | 5505024 |
| native-quickfix/scalar/tcp/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5525868 / 2031152 | 5505024 |
| native-quickfix/scalar/tcp/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526414 / 2031365 | 5505024 |
| native-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910209 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031192 / 5526026 | 1555267 |
| native-quickfix/scalar/tcp/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031152 / 5525868 | 1555457 |
| native-quickfix/scalar/tcp/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031365 / 5526414 | 1555459 |
| native-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910055 | 5505024 |
| native-quickfix/scalar/tls/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526026 / 2031120 | 5505024 |
| native-quickfix/scalar/tls/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5525868 / 2031217 | 5505024 |
| native-quickfix/scalar/tls/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526414 / 2031328 | 5505024 |
| native-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910055 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031120 / 5526026 | 1555267 |
| native-quickfix/scalar/tls/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031217 / 5525868 | 1555457 |
| native-quickfix/scalar/tls/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031328 / 5526414 | 1555459 |
| native-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910200 | 5505024 |
| native-quickfix/scalar/tls/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526026 / 2031176 | 5505024 |
| native-quickfix/scalar/tls/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5525868 / 2031073 | 5505024 |
| native-quickfix/scalar/tls/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526414 / 2031348 | 5505024 |
| native-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910200 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031176 / 5526026 | 1555267 |
| native-quickfix/scalar/tls/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031073 / 5525868 | 1555457 |
| native-quickfix/scalar/tls/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031348 / 5526414 | 1555459 |
| native-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910068 | 5505024 |
| native-quickfix/scalar/tls/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526026 / 2031230 | 5505024 |
| native-quickfix/scalar/tls/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5525868 / 2031090 | 5505024 |
| native-quickfix/scalar/tls/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5526414 / 2031307 | 5505024 |
| native-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910068 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031230 / 5526026 | 1555267 |
| native-quickfix/scalar/tls/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031090 / 5525868 | 1555457 |
| native-quickfix/scalar/tls/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031307 / 5526414 | 1555459 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 4722409 / 5143777 / 5278825 / 7242182 / 7790266 | 4758775 / 5184000 / 5316820 / 7252874 / 7798460 | 0 / 0 / 0 / 0 / 0 | 4722409 / 5143777 / 5278825 / 7242182 / 7790266 | 4758775 / 5184000 / 5316820 / 7252874 / 7798460 | 5505024 | 7931072.788 |
| native-native/scalar/tcp/1 / 2 | 4723353 / 5145835 / 5290776 / 7238935 / 7787370 | 4760878 / 5185547 / 5330216 / 7250964 / 7797599 | 0 / 0 / 0 / 0 / 0 | 4723353 / 5145835 / 5290776 / 7238935 / 7787370 | 4760878 / 5185547 / 5330216 / 7250964 / 7797599 | 5505024 | 8918930.683 |
| native-native/scalar/tcp/1 / 3 | 4720066 / 5139269 / 5269541 / 7246820 / 7793166 | 4759085 / 5185165 / 5314545 / 7255279 / 7800708 | 0 / 0 / 0 / 0 / 0 | 4720066 / 5139269 / 5269541 / 7246820 / 7793166 | 4759085 / 5185165 / 5314545 / 7255279 / 7800708 | 5505024 | 8918466.584 |
| native-native/scalar/tcp/1 / 4 | 4723169 / 5149190 / 5308694 / 7227129 / 7774136 | 4760587 / 5189266 / 5343914 / 7310209 / 7824608 | 0 / 0 / 0 / 0 / 0 | 4723169 / 5149190 / 5308694 / 7227129 / 7774136 | 4760587 / 5189266 / 5343914 / 7310209 / 7824608 | 5505024 | 8919210.559 |
| native-native/scalar/tcp/2 / 1 | 4142169 / 5110113 / 5150894 / 5193760 / 5212009 | 4176109 / 5149542 / 5190792 / 5233430 / 5252628 | 0 / 0 / 0 / 0 / 0 | 4142169 / 5110113 / 5150894 / 5193760 / 5212009 | 4176109 / 5149542 / 5190792 / 5233430 / 5252628 | 5505024 | 8385934.359 |
| native-native/scalar/tcp/2 / 2 | 4140913 / 5110180 / 5151787 / 5193206 / 5211553 | 4172653 / 5149601 / 5191761 / 5231665 / 5254390 | 0 / 0 / 0 / 0 / 0 | 4140913 / 5110180 / 5151787 / 5193206 / 5211553 | 4172653 / 5149601 / 5191761 / 5231665 / 5254390 | 5505024 | 9429712.994 |
| native-native/scalar/tcp/2 / 3 | 4129969 / 5105915 / 5146786 / 5187450 / 5207456 | 4164569 / 5149530 / 5191219 / 5232456 / 5247578 | 0 / 0 / 0 / 0 / 0 | 4129969 / 5105915 / 5146786 / 5187450 / 5207456 | 4164569 / 5149530 / 5191219 / 5232456 / 5247578 | 5505024 | 9429686.774 |
| native-native/scalar/tcp/2 / 4 | 4131355 / 5109257 / 5151375 / 5193012 / 5216273 | 4160385 / 5149418 / 5191922 / 5234155 / 5253412 | 0 / 0 / 0 / 0 / 0 | 4131355 / 5109257 / 5151375 / 5193012 / 5216273 | 4160385 / 5149418 / 5191922 / 5234155 / 5253412 | 5505024 | 9430480.890 |
| native-native/scalar/tcp/3 / 1 | 3926412 / 4858185 / 5002798 / 5089470 / 5125277 | 3959845 / 4899080 / 5044366 / 5125442 / 5163148 | 0 / 0 / 0 / 0 / 0 | 3926412 / 4858185 / 5002798 / 5089470 / 5125277 | 3959845 / 4899080 / 5044366 / 5125442 / 5163148 | 5505024 | 8472683.550 |
| native-native/scalar/tcp/3 / 2 | 3924829 / 4854169 / 4992924 / 5069383 / 5110056 | 3957917 / 4897505 / 5037392 / 5113428 / 5147823 | 0 / 0 / 0 / 0 / 0 | 3924829 / 4854169 / 4992924 / 5069383 / 5110056 | 3957917 / 4897505 / 5037392 / 5113428 / 5147823 | 5505024 | 9527577.019 |
| native-native/scalar/tcp/3 / 3 | 3922088 / 4853634 / 4984592 / 5059327 / 5084823 | 3953873 / 4895410 / 5024865 / 5102953 / 5132162 | 0 / 0 / 0 / 0 / 0 | 3922088 / 4853634 / 4984592 / 5059327 / 5084823 | 3953873 / 4895410 / 5024865 / 5102953 / 5132162 | 5505024 | 9527709.482 |
| native-native/scalar/tcp/3 / 4 | 3919563 / 4855689 / 4978924 / 5066512 / 5087903 | 3953011 / 4894404 / 5018039 / 5106001 / 5126601 | 0 / 0 / 0 / 0 / 0 | 3919563 / 4855689 / 4978924 / 5066512 / 5087903 | 3953011 / 4894404 / 5018039 / 5106001 / 5126601 | 5505024 | 9528169.948 |
| native-native/scalar/tls/1 / 1 | 4311258 / 5233068 / 5341805 / 5443726 / 5848382 | 4347467 / 5275860 / 5386443 / 5484740 / 5851473 | 0 / 0 / 0 / 0 / 0 | 4311258 / 5233068 / 5341805 / 5443726 / 5848382 | 4347467 / 5275860 / 5386443 / 5484740 / 5851473 | 5505024 | 7959980.566 |
| native-native/scalar/tls/1 / 2 | 4310344 / 5232985 / 5341347 / 5437518 / 5656536 | 4346787 / 5277001 / 5385447 / 5480891 / 5716826 | 0 / 0 / 0 / 0 / 0 | 4310344 / 5232985 / 5341347 / 5437518 / 5656536 | 4346787 / 5277001 / 5385447 / 5480891 / 5716826 | 5505024 | 8951167.731 |
| native-native/scalar/tls/1 / 3 | 4312065 / 5232545 / 5339371 / 5429834 / 5487236 | 4347281 / 5275588 / 5382195 / 5473608 / 5498012 | 0 / 0 / 0 / 0 / 0 | 4312065 / 5232545 / 5339371 / 5429834 / 5487236 | 4347281 / 5275588 / 5382195 / 5473608 / 5498012 | 5505024 | 8951206.844 |
| native-native/scalar/tls/1 / 4 | 4309389 / 5233309 / 5343657 / 5447299 / 5966576 | 4345921 / 5277143 / 5388420 / 5493157 / 6033878 | 0 / 0 / 0 / 0 / 0 | 4309389 / 5233309 / 5343657 / 5447299 / 5966576 | 4345921 / 5277143 / 5388420 / 5493157 / 6033878 | 5505024 | 8951666.718 |
| native-native/scalar/tls/2 / 1 | 4933941 / 5361114 / 5438003 / 5619141 / 6355944 | 4973961 / 5404139 / 5482768 / 5622162 / 6359269 | 0 / 0 / 0 / 0 / 0 | 4933941 / 5361114 / 5438003 / 5619141 / 6355944 | 4973961 / 5404139 / 5482768 / 5622162 / 6359269 | 5505024 | 7679485.576 |
| native-native/scalar/tls/2 / 2 | 4932929 / 5357908 / 5436534 / 5840990 / 6573388 | 4974739 / 5403557 / 5486120 / 5904890 / 6644214 | 0 / 0 / 0 / 0 / 0 | 4932929 / 5357908 / 5436534 / 5840990 / 6573388 | 4974739 / 5403557 / 5486120 / 5904890 / 6644214 | 5505024 | 8635549.692 |
| native-native/scalar/tls/2 / 3 | 4936115 / 5362442 / 5443197 / 6063121 / 6808803 | 4974990 / 5404516 / 5488645 / 6158995 / 6886090 | 0 / 0 / 0 / 0 / 0 | 4936115 / 5362442 / 5443197 / 6063121 / 6808803 | 4974990 / 5404516 / 5488645 / 6158995 / 6886090 | 5505024 | 8635580.565 |
| native-native/scalar/tls/2 / 4 | 4936252 / 5361295 / 5438144 / 5519671 / 5983079 | 4974412 / 5403343 / 5478628 / 5563526 / 5986081 | 0 / 0 / 0 / 0 / 0 | 4936252 / 5361295 / 5438144 / 5519671 / 5983079 | 4974412 / 5403343 / 5478628 / 5563526 / 5986081 | 5505024 | 8636266.636 |
| native-native/scalar/tls/3 / 1 | 4228580 / 5340580 / 5457171 / 7776207 / 8330208 | 4261770 / 5382250 / 5496189 / 7778918 / 8334202 | 0 / 0 / 0 / 0 / 0 | 4228580 / 5340580 / 5457171 / 7776207 / 8330208 | 4261770 / 5382250 / 5496189 / 7778918 / 8334202 | 5505024 | 7993373.433 |
| native-native/scalar/tls/3 / 2 | 4225498 / 5335457 / 5441971 / 7174685 / 7743152 | 4260641 / 5380582 / 5487965 / 7227781 / 7792311 | 0 / 0 / 0 / 0 / 0 | 4225498 / 5335457 / 5441971 / 7174685 / 7743152 | 4260641 / 5380582 / 5487965 / 7227781 / 7792311 | 5505024 | 8988659.628 |
| native-native/scalar/tls/3 / 3 | 4226204 / 5334507 / 5437053 / 6590012 / 7059155 | 4259625 / 5379133 / 5479517 / 6592834 / 7087351 | 0 / 0 / 0 / 0 / 0 | 4226204 / 5334507 / 5437053 / 6590012 / 7059155 | 4259625 / 5379133 / 5479517 / 6592834 / 7087351 | 5505024 | 8988085.962 |
| native-native/scalar/tls/3 / 4 | 4227028 / 5331304 / 5425085 / 5528354 / 6111466 | 4260094 / 5377068 / 5469984 / 5576511 / 6113661 | 0 / 0 / 0 / 0 / 0 | 4227028 / 5331304 / 5425085 / 5528354 / 6111466 | 4260094 / 5377068 / 5469984 / 5576511 / 6113661 | 5505024 | 8989136.889 |
| native-quickfix/scalar/tcp/1 / 1 | 4949750 / 6200175 / 6289532 / 6442771 / 6531415 | 4959926 / 6212761 / 6300839 / 6453778 / 6549043 | 0 / 0 / 0 / 0 / 0 | 4949750 / 6200175 / 6289532 / 6442771 / 6531415 | 4959926 / 6212761 / 6300839 / 6453778 / 6549043 | 5505024 | 4606859.460 |
| native-quickfix/scalar/tcp/1 / 2 | 4945741 / 6184861 / 6307930 / 6380945 / 6402037 | 4953175 / 6196503 / 6318572 / 6393209 / 6412665 | 0 / 0 / 0 / 0 / 0 | 4945741 / 6184861 / 6307930 / 6380945 / 6402037 | 4953175 / 6196503 / 6318572 / 6393209 / 6412665 | 5505024 | 5180092.141 |
| native-quickfix/scalar/tcp/1 / 3 | 4920941 / 6185828 / 6287391 / 6421083 / 6449415 | 4930665 / 6196034 / 6299613 / 6437565 / 6470562 | 0 / 0 / 0 / 0 / 0 | 4920941 / 6185828 / 6287391 / 6421083 / 6449415 | 4930665 / 6196034 / 6299613 / 6437565 / 6470562 | 5505024 | 5179877.596 |
| native-quickfix/scalar/tcp/1 / 4 | 4935234 / 6182665 / 6292658 / 6521302 / 6553897 | 4944656 / 6195576 / 6306895 / 6537364 / 6556965 | 0 / 0 / 0 / 0 / 0 | 4935234 / 6182665 / 6292658 / 6521302 / 6553897 | 4944656 / 6195576 / 6306895 / 6537364 / 6556965 | 5505024 | 5180435.551 |
| native-quickfix/scalar/tcp/2 / 1 | 5831827 / 6466257 / 6649466 / 6710852 / 6809469 | 5842506 / 6477564 / 6662658 / 6725348 / 6811739 | 0 / 0 / 0 / 0 / 0 | 5831827 / 6466257 / 6649466 / 6710852 / 6809469 | 5842506 / 6477564 / 6662658 / 6725348 / 6811739 | 5505024 | 4631050.443 |
| native-quickfix/scalar/tcp/2 / 2 | 5808102 / 6472910 / 6646390 / 6693131 / 6703950 | 5819614 / 6485187 / 6659391 / 6706113 / 6725987 | 0 / 0 / 0 / 0 / 0 | 5808102 / 6472910 / 6646390 / 6693131 / 6703950 | 5819614 / 6485187 / 6659391 / 6706113 / 6725987 | 5505024 | 5207313.946 |
| native-quickfix/scalar/tcp/2 / 3 | 5800905 / 6458779 / 6701616 / 6751891 / 6761762 | 5813569 / 6472279 / 6715747 / 6764576 / 6779019 | 0 / 0 / 0 / 0 / 0 | 5800905 / 6458779 / 6701616 / 6751891 / 6761762 | 5813569 / 6472279 / 6715747 / 6764576 / 6779019 | 5505024 | 5207208.521 |
| native-quickfix/scalar/tcp/2 / 4 | 5819482 / 6463252 / 6670181 / 6777703 / 6801341 | 5832097 / 6476525 / 6684880 / 6796065 / 6819657 | 0 / 0 / 0 / 0 / 0 | 5819482 / 6463252 / 6670181 / 6777703 / 6801341 | 5832097 / 6476525 / 6684880 / 6796065 / 6819657 | 5505024 | 5207677.078 |
| native-quickfix/scalar/tcp/3 / 1 | 5567649 / 6141644 / 6373175 / 6563246 / 6604419 | 5578051 / 6153499 / 6384452 / 6583719 / 6605790 | 0 / 0 / 0 / 0 / 0 | 5567649 / 6141644 / 6373175 / 6563246 / 6604419 | 5578051 / 6153499 / 6384452 / 6583719 / 6605790 | 5505024 | 4611215.705 |
| native-quickfix/scalar/tcp/3 / 2 | 5554940 / 6168373 / 6339848 / 6423405 / 6441788 | 5566363 / 6180300 / 6356316 / 6434784 / 6459626 | 0 / 0 / 0 / 0 / 0 | 5554940 / 6168373 / 6339848 / 6423405 / 6441788 | 5566363 / 6180300 / 6356316 / 6434784 / 6459626 | 5505024 | 5184937.883 |
| native-quickfix/scalar/tcp/3 / 3 | 5562454 / 6145206 / 6334116 / 6505333 / 6531196 | 5574444 / 6156741 / 6347048 / 6518864 / 6541212 | 0 / 0 / 0 / 0 / 0 | 5562454 / 6145206 / 6334116 / 6505333 / 6531196 | 5574444 / 6156741 / 6347048 / 6518864 / 6541212 | 5505024 | 5184802.037 |
| native-quickfix/scalar/tcp/3 / 4 | 5563780 / 6143575 / 6354923 / 6572710 / 6592010 | 5574970 / 6157736 / 6369634 / 6585398 / 6599803 | 0 / 0 / 0 / 0 / 0 | 5563780 / 6143575 / 6354923 / 6572710 / 6592010 | 5574970 / 6157736 / 6369634 / 6585398 / 6599803 | 5505024 | 5185322.780 |
| native-quickfix/scalar/tls/1 / 1 | 6219172 / 6733285 / 6942348 / 7162858 / 7206407 | 6234198 / 6750165 / 6957646 / 7183298 / 7218792 | 0 / 0 / 0 / 0 / 0 | 6219172 / 6733285 / 6942348 / 7162858 / 7206407 | 6234198 / 6750165 / 6957646 / 7183298 / 7218792 | 5505024 | 5626950.751 |
| native-quickfix/scalar/tls/1 / 2 | 6219838 / 6732431 / 6944812 / 7172749 / 7217027 | 6234754 / 6750351 / 6960817 / 7193047 / 7219945 | 0 / 0 / 0 / 0 / 0 | 6219838 / 6732431 / 6944812 / 7172749 / 7217027 | 6234754 / 6750351 / 6960817 / 7193047 / 7219945 | 5505024 | 6327134.216 |
| native-quickfix/scalar/tls/1 / 3 | 6219029 / 6734394 / 6942876 / 7166790 / 7199997 | 6234525 / 6750252 / 6959511 / 7177632 / 7226691 | 0 / 0 / 0 / 0 / 0 | 6219029 / 6734394 / 6942876 / 7166790 / 7199997 | 6234525 / 6750252 / 6959511 / 7177632 / 7226691 | 5505024 | 6327083.144 |
| native-quickfix/scalar/tls/1 / 4 | 6219653 / 6734736 / 6941748 / 7175266 / 7199077 | 6235176 / 6752023 / 6958108 / 7190201 / 7216441 | 0 / 0 / 0 / 0 / 0 | 6219653 / 6734736 / 6941748 / 7175266 / 7199077 | 6235176 / 6752023 / 6958108 / 7190201 / 7216441 | 5505024 | 6327633.210 |
| native-quickfix/scalar/tls/2 / 1 | 5204997 / 6940648 / 7157273 / 7217078 / 7243681 | 5217912 / 6959250 / 7176412 / 7233144 / 7270193 | 0 / 0 / 0 / 0 / 0 | 5204997 / 6940648 / 7157273 / 7217078 / 7243681 | 5217912 / 6959250 / 7176412 / 7233144 / 7270193 | 5505024 | 4477796.348 |
| native-quickfix/scalar/tls/2 / 2 | 5208111 / 6940575 / 7158734 / 7213360 / 7245063 | 5221176 / 6958711 / 7175575 / 7230649 / 7270049 | 0 / 0 / 0 / 0 / 0 | 5208111 / 6940575 / 7158734 / 7213360 / 7245063 | 5221176 / 6958711 / 7175575 / 7230649 / 7270049 | 5505024 | 5034914.725 |
| native-quickfix/scalar/tls/2 / 3 | 5208159 / 6941833 / 7158796 / 7224851 / 7250740 | 5221327 / 6960798 / 7176393 / 7230632 / 7269382 | 0 / 0 / 0 / 0 / 0 | 5208159 / 6941833 / 7158796 / 7224851 / 7250740 | 5221327 / 6960798 / 7176393 / 7230632 / 7269382 | 5505024 | 5034740.836 |
| native-quickfix/scalar/tls/2 / 4 | 5208090 / 6945031 / 7159260 / 7218318 / 7273410 | 5220609 / 6961060 / 7174925 / 7236479 / 7290144 | 0 / 0 / 0 / 0 / 0 | 5208090 / 6945031 / 7159260 / 7218318 / 7273410 | 5220609 / 6961060 / 7174925 / 7236479 / 7290144 | 5505024 | 5035287.819 |
| native-quickfix/scalar/tls/3 / 1 | 6524536 / 7117375 / 7254271 / 7391952 / 7436566 | 6540766 / 7132142 / 7272580 / 7411059 / 7458030 | 0 / 0 / 0 / 0 / 0 | 6524536 / 7117375 / 7254271 / 7391952 / 7436566 | 6540766 / 7132142 / 7272580 / 7411059 / 7458030 | 5505024 | 4607392.231 |
| native-quickfix/scalar/tls/3 / 2 | 6524822 / 7119701 / 7252650 / 7396020 / 7757091 | 6541865 / 7137003 / 7270734 / 7414583 / 7773735 | 0 / 0 / 0 / 0 / 0 | 6524822 / 7119701 / 7252650 / 7396020 / 7757091 | 6541865 / 7137003 / 7270734 / 7414583 / 7773735 | 5505024 | 5180773.435 |
| native-quickfix/scalar/tls/3 / 3 | 6525589 / 7125258 / 7256078 / 7421639 / 8208186 | 6542007 / 7141367 / 7272741 / 7443479 / 8218481 | 0 / 0 / 0 / 0 / 0 | 6525589 / 7125258 / 7256078 / 7421639 / 8208186 | 6542007 / 7141367 / 7272741 / 7443479 / 8218481 | 5505024 | 5180569.145 |
| native-quickfix/scalar/tls/3 / 4 | 6528463 / 7120969 / 7256656 / 7431203 / 8407419 | 6543716 / 7140006 / 7274662 / 7453416 / 8419569 | 0 / 0 / 0 / 0 / 0 | 6528463 / 7120969 / 7256656 / 7431203 / 8407419 | 6543716 / 7140006 / 7274662 / 7453416 / 8419569 | 5505024 | 5181092.209 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
