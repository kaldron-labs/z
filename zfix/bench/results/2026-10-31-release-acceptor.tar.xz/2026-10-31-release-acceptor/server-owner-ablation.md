# FIX measured baseline

Build label: `release-server-io-owners-only`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| quickfix-native / tcp / scalar | 4 | 3 | 57227.2 | 59416.6 | 6.092 | 6.106 |
| quickfix-native / tls / scalar | 4 | 3 | 43808.1 | 43907.5 | 7.829 | 7.890 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| quickfix-native / tcp / scalar | 4 | 1.423 | 1.292 | 32.785 | 43.426 |
| quickfix-native / tls / scalar | 4 | 1.823 | 1.252 | 37.324 | 47.840 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 15858.4 | 3983666 | 5860687 | 5873147 | 5873147 | 7341434 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 14508.8 | 4242322 | 6091991 | 6106207 | 6106207 | 7632759 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 14518.5 | 4243735 | 6087489 | 6101718 | 6101718 | 7627148 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 14530.8 | 4245964 | 6087807 | 6103158 | 6103158 | 7628948 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 10968.6 | 5511013 | 7828939 | 7890257 | 7890257 | 9862822 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 10974.2 | 5504405 | 7826460 | 7881355 | 7881355 | 9851694 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 10979.3 | 5503520 | 7821578 | 7877119 | 7877119 | 9846399 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 10985.5 | 5503619 | 7805214 | 7870087 | 7870087 | 9837609 |

Raw artifacts: `/tmp/zfix-acceptor-investigation/server-owner-ablation`.
