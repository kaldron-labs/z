# FIX measured baseline

Build label: `clang21-O3-release-io-owners-report-layout`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 3 | 57676.4 | 57676.4 | 1.490 | 1.495 |
| native-native / tcp / scalar | 4 | 3 | 63346.4 | 63377.7 | 5.642 | 5.700 |
| native-native / tls / scalar | 1 | 3 | 60263.2 | 60263.2 | 1.261 | 1.266 |
| native-native / tls / scalar | 4 | 3 | 64136.4 | 64171.5 | 4.851 | 4.892 |
| native-quickfix / tcp / scalar | 1 | 3 | 53033.8 | 53033.8 | 1.587 | 1.596 |
| native-quickfix / tcp / scalar | 4 | 3 | 54870.7 | 54940.6 | 6.474 | 6.485 |
| native-quickfix / tls / scalar | 1 | 3 | 41928.3 | 41928.3 | 2.047 | 2.061 |
| native-quickfix / tls / scalar | 4 | 3 | 49877.8 | 49901.8 | 6.890 | 6.905 |
| quickfix-native / tcp / scalar | 1 | 3 | 62746.7 | 62746.7 | 1.555 | 1.567 |
| quickfix-native / tcp / scalar | 4 | 3 | 62008.9 | 64415.7 | 6.046 | 6.060 |
| quickfix-native / tls / scalar | 1 | 3 | 35231.4 | 35231.4 | 2.190 | 2.208 |
| quickfix-native / tls / scalar | 4 | 3 | 47479.4 | 47678.9 | 6.995 | 7.046 |
| quickfix-quickfix / tcp / scalar | 1 | 3 | 56596.1 | 56596.1 | 1.513 | 1.524 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 60476.7 | 62969.4 | 6.137 | 6.147 |
| quickfix-quickfix / tls / scalar | 1 | 3 | 36619.7 | 36619.7 | 2.286 | 2.304 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 48044.2 | 48180.9 | 7.035 | 7.087 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 0.319 | 0.328 | 24.062 | 24.062 |
| native-native / tcp / scalar | 4 | 1.187 | 1.205 | 48.062 | 44.805 |
| native-native / tls / scalar | 1 | 0.286 | 0.321 | 25.992 | 24.484 |
| native-native / tls / scalar | 4 | 1.122 | 1.188 | 51.375 | 48.777 |
| native-quickfix / tcp / scalar | 1 | 0.330 | 0.391 | 24.062 | 24.062 |
| native-quickfix / tcp / scalar | 4 | 1.279 | 1.438 | 48.043 | 36.957 |
| native-quickfix / tls / scalar | 1 | 0.354 | 0.453 | 25.000 | 24.836 |
| native-quickfix / tls / scalar | 4 | 1.282 | 1.585 | 51.059 | 41.570 |
| quickfix-native / tcp / scalar | 1 | 0.377 | 0.324 | 24.062 | 24.062 |
| quickfix-native / tcp / scalar | 4 | 1.364 | 1.225 | 32.789 | 44.043 |
| quickfix-native / tls / scalar | 1 | 0.569 | 0.408 | 24.062 | 25.340 |
| quickfix-native / tls / scalar | 4 | 1.724 | 1.217 | 37.949 | 47.715 |
| quickfix-quickfix / tcp / scalar | 1 | 0.405 | 0.387 | 24.188 | 24.188 |
| quickfix-quickfix / tcp / scalar | 4 | 1.359 | 1.319 | 32.996 | 37.023 |
| quickfix-quickfix / tls / scalar | 1 | 0.564 | 0.485 | 24.188 | 25.133 |
| quickfix-quickfix / tls / scalar | 4 | 1.703 | 1.482 | 37.680 | 40.941 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 1 / 1 | 3 | 57676.4 | 1082757 | 1489741 | 1495423 | 1495423 | 1869279 |
| native-native / tcp / scalar / 4 / 1 | 3 | 15846.8 | 3988961 | 5634237 | 5687144 | 5687144 | 7108930 |
| native-native / tcp / scalar / 4 / 2 | 3 | 15842.7 | 3992288 | 5642187 | 5692380 | 5692380 | 7115475 |
| native-native / tcp / scalar / 4 / 3 | 3 | 15843.5 | 3993420 | 5625046 | 5681772 | 5681772 | 7102215 |
| native-native / tcp / scalar / 4 / 4 | 3 | 15844.7 | 3991558 | 5633117 | 5699880 | 5699880 | 7124850 |
| native-native / tls / scalar / 1 / 1 | 3 | 60263.2 | 1055994 | 1260555 | 1266466 | 1266466 | 1583083 |
| native-native / tls / scalar / 4 / 1 | 3 | 16042.6 | 3978425 | 4847542 | 4888823 | 4888823 | 6111029 |
| native-native / tls / scalar / 4 / 2 | 3 | 16042.8 | 3974859 | 4851136 | 4890415 | 4890415 | 6113019 |
| native-native / tls / scalar / 4 / 3 | 3 | 16042.0 | 3974333 | 4849710 | 4891735 | 4891735 | 6114669 |
| native-native / tls / scalar / 4 / 4 | 3 | 16044.2 | 3975401 | 4848843 | 4891010 | 4891010 | 6113763 |
| native-quickfix / tcp / scalar / 1 / 1 | 3 | 53033.8 | 1136545 | 1587453 | 1596402 | 1596402 | 1995503 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 13739.3 | 4532974 | 6436401 | 6446411 | 6446411 | 8058014 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 13732.2 | 4533061 | 6421960 | 6431238 | 6431238 | 8039048 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 13733.0 | 4535105 | 6473840 | 6484662 | 6484662 | 8105828 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 13736.0 | 4534545 | 6443918 | 6455445 | 6455445 | 8069307 |
| native-quickfix / tls / scalar / 1 / 1 | 3 | 41928.3 | 1518686 | 2047262 | 2060616 | 2060616 | 2575770 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 12478.6 | 4990042 | 6889084 | 6903591 | 6903591 | 8629489 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 12474.8 | 4990134 | 6889316 | 6903270 | 6903270 | 8629088 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 12473.8 | 4989740 | 6889893 | 6904984 | 6904984 | 8631230 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 12474.5 | 4990508 | 6890494 | 6903565 | 6903565 | 8629457 |
| quickfix-native / tcp / scalar / 1 / 1 | 3 | 62746.7 | 1009787 | 1555086 | 1566978 | 1566978 | 1958723 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 17289.6 | 3492833 | 5545149 | 5597001 | 5597001 | 6996252 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 15710.4 | 4145206 | 6036527 | 6050981 | 6050981 | 7563727 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 15705.2 | 4144185 | 6043598 | 6054584 | 6054584 | 7568230 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 15710.5 | 4145913 | 6046198 | 6060049 | 6060049 | 7575062 |
| quickfix-native / tls / scalar / 1 / 1 | 3 | 35231.4 | 1785625 | 2190086 | 2208026 | 2208026 | 2760033 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 11905.9 | 5103970 | 6995207 | 7046200 | 7046200 | 8807750 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 11915.4 | 5102719 | 6992110 | 7039894 | 7039894 | 8799868 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 11923.4 | 5109527 | 6977526 | 7037601 | 7037601 | 8797002 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 11934.2 | 5100695 | 6980952 | 7031253 | 7031253 | 8789067 |
| quickfix-quickfix / tcp / scalar / 1 / 1 | 3 | 56596.1 | 1066043 | 1512860 | 1524117 | 1524117 | 1905147 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 16922.0 | 3519839 | 6132816 | 6143352 | 6143352 | 7679190 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 15351.1 | 4356580 | 6137495 | 6147259 | 6147259 | 7684074 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 15348.3 | 4357158 | 6135870 | 6146154 | 6146154 | 7682693 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 15348.0 | 4358125 | 6129075 | 6140256 | 6140256 | 7675320 |
| quickfix-quickfix / tls / scalar / 1 / 1 | 3 | 36619.7 | 1650412 | 2286480 | 2304368 | 2304368 | 2880460 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 12043.5 | 5094909 | 7034651 | 7085626 | 7085626 | 8857033 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 12046.2 | 5095635 | 7027990 | 7086728 | 7086728 | 8858410 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 12043.2 | 5099048 | 7029728 | 7085056 | 7085056 | 8856320 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 12048.0 | 5093411 | 7031637 | 7085801 | 7085801 | 8857252 |

Raw artifacts: `/tmp/zfix-acceptor-investigation/release-after-s1`, `/tmp/zfix-acceptor-investigation/release-after-s4`.
