# FIX process load measurements

Build label: release-original-owners-report-layout. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 79782.050 | 80035.718 | 1.596185 / 44089344 | 1.619756 / 50561024 |
| native-native / scalar / tcp / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 78799.408 | 79068.225 | 1.569640 / 45469696 | 1.603343 / 48832512 |
| native-native / scalar / tcp / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 78999.879 | 79166.388 | 1.604616 / 44244992 | 1.644956 / 51826688 |
| native-native / scalar / tls / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 71349.722 | 71493.199 | 1.785635 / 48656384 | 1.841468 / 65601536 |
| native-native / scalar / tls / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 74073.371 | 74208.670 | 1.749784 / 49741824 | 1.796251 / 66392064 |
| native-native / scalar / tls / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 72872.591 | 73057.315 | 1.784582 / 49954816 | 1.815358 / 66617344 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 48992.896 | 51260.572 | 1.597175 / 34426880 | 2.016964 / 44695552 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 57809.211 | 60139.607 | 1.408697 / 34480128 | 1.838935 / 46559232 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 57217.983 | 59574.314 | 1.442545 / 34549760 | 1.795952 / 46264320 |
| quickfix-native / scalar / tls / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 42880.945 | 43045.529 | 1.918055 / 39055360 | 2.169066 / 56340480 |
| quickfix-native / scalar / tls / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 43314.378 | 43501.413 | 1.839546 / 39043072 | 1.962348 / 56676352 |
| quickfix-native / scalar / tls / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 42068.407 | 42189.950 | 1.884014 / 39034880 | 2.027065 / 57733120 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805794 / 1910120 | 5505024 |
| native-native/scalar/tcp/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521235 / 2031252 | 5505024 |
| native-native/scalar/tcp/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521001 / 2031218 | 5505024 |
| native-native/scalar/tcp/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521487 / 2031270 | 5505024 |
| native-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910120 / 4805794 | 5505024 |
| native-native/scalar/tcp/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031252 / 5521235 | 5505024 |
| native-native/scalar/tcp/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031218 / 5521001 | 5505024 |
| native-native/scalar/tcp/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031270 / 5521487 | 5505024 |
| native-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805804 / 1910071 | 5505024 |
| native-native/scalar/tcp/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521190 / 2031195 | 5505024 |
| native-native/scalar/tcp/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520871 / 2031116 | 5505024 |
| native-native/scalar/tcp/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521491 / 2031271 | 5505024 |
| native-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910071 / 4805804 | 5505024 |
| native-native/scalar/tcp/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031195 / 5521190 | 5505024 |
| native-native/scalar/tcp/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031116 / 5520871 | 5505024 |
| native-native/scalar/tcp/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031271 / 5521491 | 5505024 |
| native-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805970 / 1910178 | 5505024 |
| native-native/scalar/tcp/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521129 / 2031171 | 5505024 |
| native-native/scalar/tcp/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521029 / 2031146 | 5505024 |
| native-native/scalar/tcp/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521640 / 2031351 | 5505024 |
| native-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910178 / 4805970 | 5505024 |
| native-native/scalar/tcp/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031171 / 5521129 | 5505024 |
| native-native/scalar/tcp/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031146 / 5521029 | 5505024 |
| native-native/scalar/tcp/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031351 / 5521640 | 5505024 |
| native-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805974 / 1910216 | 5505024 |
| native-native/scalar/tls/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520966 / 2031073 | 5505024 |
| native-native/scalar/tls/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520992 / 2031158 | 5505024 |
| native-native/scalar/tls/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521538 / 2031284 | 5505024 |
| native-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910216 / 4805974 | 5505024 |
| native-native/scalar/tls/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031073 / 5520966 | 5505024 |
| native-native/scalar/tls/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031158 / 5520992 | 5505024 |
| native-native/scalar/tls/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031284 / 5521538 | 5505024 |
| native-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805874 / 1910192 | 5505024 |
| native-native/scalar/tls/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521112 / 2031133 | 5505024 |
| native-native/scalar/tls/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521241 / 2031291 | 5505024 |
| native-native/scalar/tls/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521605 / 2031273 | 5505024 |
| native-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910192 / 4805874 | 5505024 |
| native-native/scalar/tls/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031133 / 5521112 | 5505024 |
| native-native/scalar/tls/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031291 / 5521241 | 5505024 |
| native-native/scalar/tls/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031273 / 5521605 | 5505024 |
| native-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805860 / 1910118 | 5505024 |
| native-native/scalar/tls/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521116 / 2031190 | 5505024 |
| native-native/scalar/tls/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520929 / 2031156 | 5505024 |
| native-native/scalar/tls/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521695 / 2031292 | 5505024 |
| native-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910118 / 4805860 | 5505024 |
| native-native/scalar/tls/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031190 / 5521116 | 5505024 |
| native-native/scalar/tls/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031156 / 5520929 | 5505024 |
| native-native/scalar/tls/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031292 / 5521695 | 5505024 |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806079 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520956 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520939 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521544 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4806079 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5520956 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520939 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521544 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805796 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520942 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520902 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521501 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805796 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5520942 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520902 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521501 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805971 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521016 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521124 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521656 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805971 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521016 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5521124 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521656 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805719 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521104 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520943 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521484 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805719 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521104 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520943 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521484 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805893 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521106 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520950 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521616 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805893 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521106 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520950 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521616 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805847 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521245 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520950 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521506 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805847 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521245 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520950 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521506 | 5505024 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 3202015 / 3707003 / 4137152 / 4743784 / 5007162 | 3209341 / 3712499 / 4153959 / 4747801 / 5024144 | 0 / 0 / 0 / 0 / 0 | 3202015 / 3707003 / 4137152 / 4743784 / 5007162 | 3209341 / 3712499 / 4153959 / 4747801 / 5024144 | 5505024 | 10951412.277 |
| native-native/scalar/tcp/1 / 2 | 3205217 / 3689824 / 4422598 / 4786061 / 4819035 | 3212292 / 3696616 / 4426859 / 4801499 / 4848268 | 0 / 0 / 0 / 0 / 0 | 3205217 / 3689824 / 4422598 / 4786061 / 4819035 | 3212292 / 3696616 / 4426859 / 4801499 / 4848268 | 5505024 | 12315583.382 |
| native-native/scalar/tcp/1 / 3 | 3208291 / 3688099 / 3920717 / 4372782 / 4812594 | 3214883 / 3699033 / 3929815 / 4375074 / 4815053 | 0 / 0 / 0 / 0 / 0 | 3208291 / 3688099 / 3920717 / 4372782 / 4812594 | 3214883 / 3699033 / 3929815 / 4375074 / 4815053 | 5505024 | 12315146.364 |
| native-native/scalar/tcp/1 / 4 | 3206141 / 3726991 / 4372944 / 4715322 / 4906090 | 3213185 / 3738486 / 4376232 / 4717697 / 4908296 | 0 / 0 / 0 / 0 / 0 | 3206141 / 3726991 / 4372944 / 4715322 / 4906090 | 3213185 / 3738486 / 4376232 / 4717697 / 4908296 | 5505024 | 12316023.662 |
| native-native/scalar/tcp/2 / 1 | 3245488 / 3621070 / 3996902 / 4293752 / 4581316 | 3252427 / 3626779 / 4001602 / 4296806 / 4583150 | 0 / 0 / 0 / 0 / 0 | 3245488 / 3621070 / 3996902 / 4293752 / 4581316 | 3252427 / 3626779 / 4001602 / 4296806 / 4583150 | 5505024 | 10886220.650 |
| native-native/scalar/tcp/2 / 2 | 3253987 / 3582471 / 3914029 / 4251545 / 4433226 | 3260084 / 3590481 / 3921814 / 4268330 / 4446681 | 0 / 0 / 0 / 0 / 0 | 3253987 / 3582471 / 3914029 / 4251545 / 4433226 | 3260084 / 3590481 / 3921814 / 4268330 / 4446681 | 5505024 | 12242176.864 |
| native-native/scalar/tcp/2 / 3 | 3246011 / 3607281 / 3928984 / 4450812 / 4919145 | 3252339 / 3612642 / 3932742 / 4453170 / 4921897 | 0 / 0 / 0 / 0 / 0 | 3246011 / 3607281 / 3928984 / 4450812 / 4919145 | 3252339 / 3612642 / 3932742 / 4453170 / 4921897 | 5505024 | 12241531.718 |
| native-native/scalar/tcp/2 / 4 | 3244912 / 3605373 / 3805062 / 4014686 / 4031502 | 3251954 / 3612508 / 3816180 / 4023728 / 4033441 | 0 / 0 / 0 / 0 / 0 | 3244912 / 3605373 / 3805062 / 4014686 / 4031502 | 3251954 / 3612508 / 3816180 / 4023728 / 4033441 | 5505024 | 12242787.969 |
| native-native/scalar/tcp/3 / 1 | 3272488 / 3545462 / 3691917 / 4488937 / 4936195 | 3279571 / 3552321 / 3702514 / 4491085 / 4937986 | 0 / 0 / 0 / 0 / 0 | 3272488 / 3545462 / 3691917 / 4488937 / 4936195 | 3279571 / 3552321 / 3702514 / 4491085 / 4937986 | 5505024 | 10984203.721 |
| native-native/scalar/tcp/3 / 2 | 3270586 / 3569245 / 3709084 / 3993079 / 4399993 | 3277762 / 3574950 / 3718447 / 3995565 / 4401876 | 0 / 0 / 0 / 0 / 0 | 3270586 / 3569245 / 3709084 / 3993079 / 4399993 | 3277762 / 3574950 / 3718447 / 3995565 / 4401876 | 5505024 | 12351723.303 |
| native-native/scalar/tcp/3 / 3 | 3270262 / 3535794 / 3662335 / 3865321 / 4024499 | 3277373 / 3544383 / 3670362 / 3877744 / 4094791 | 0 / 0 / 0 / 0 / 0 | 3270262 / 3535794 / 3662335 / 3865321 / 4024499 | 3277373 / 3544383 / 3670362 / 3877744 / 4094791 | 5505024 | 12351518.867 |
| native-native/scalar/tcp/3 / 4 | 3271118 / 3539630 / 3671506 / 4140087 / 4693997 | 3278937 / 3545895 / 3679315 / 4142432 / 4696006 | 0 / 0 / 0 / 0 / 0 | 3271118 / 3539630 / 3671506 / 4140087 / 4693997 | 3278937 / 3545895 / 3679315 / 4142432 / 4696006 | 5505024 | 12352853.428 |
| native-native/scalar/tls/1 / 1 | 3590096 / 3898013 / 4088639 / 4490841 / 4839430 | 3601616 / 3911292 / 4097473 / 4519971 / 4881236 | 0 / 0 / 0 / 0 / 0 | 3590096 / 3898013 / 4088639 / 4490841 / 4839430 | 3601616 / 3911292 / 4097473 / 4519971 / 4881236 | 5505024 | 9770161.761 |
| native-native/scalar/tls/1 / 2 | 3587243 / 3897959 / 4083236 / 4445380 / 4516712 | 3599648 / 3910721 / 4094035 / 4485780 / 4542885 | 0 / 0 / 0 / 0 / 0 | 3587243 / 3897959 / 4083236 / 4445380 / 4516712 | 3599648 / 3910721 / 4094035 / 4485780 / 4542885 | 5505024 | 10986086.256 |
| native-native/scalar/tls/1 / 3 | 3592730 / 3908106 / 4113240 / 4585927 / 5282002 | 3604701 / 3919411 / 4124210 / 4644138 / 5319081 | 0 / 0 / 0 / 0 / 0 | 3592730 / 3908106 / 4113240 / 4585927 / 5282002 | 3604701 / 3919411 / 4124210 / 4644138 / 5319081 | 5505024 | 10986247.730 |
| native-native/scalar/tls/1 / 4 | 3588798 / 3900614 / 4108605 / 4852301 / 5605454 | 3600703 / 3912220 / 4115004 / 4882122 / 5648734 | 0 / 0 / 0 / 0 / 0 | 3588798 / 3900614 / 4108605 / 4852301 / 5605454 | 3600703 / 3912220 / 4115004 / 4882122 / 5648734 | 5505024 | 10987225.300 |
| native-native/scalar/tls/2 / 1 | 3465077 / 3818108 / 3920181 / 4615727 / 4853999 | 3476129 / 3828329 / 3935229 / 4657601 / 4887443 | 0 / 0 / 0 / 0 / 0 | 3465077 / 3818108 / 3920181 / 4615727 / 4853999 | 3476129 / 3828329 / 3935229 / 4657601 / 4887443 | 5505024 | 10095281.142 |
| native-native/scalar/tls/2 / 2 | 3465565 / 3815924 / 3930395 / 4523620 / 4572805 | 3478093 / 3825098 / 3942525 / 4561635 / 4600449 | 0 / 0 / 0 / 0 / 0 | 3465565 / 3815924 / 3930395 / 4523620 / 4572805 | 3478093 / 3825098 / 3942525 / 4561635 / 4600449 | 5505024 | 11352186.910 |
| native-native/scalar/tls/2 / 3 | 3466883 / 3814472 / 3920559 / 4314446 / 4611577 | 3477409 / 3821895 / 3931262 / 4316976 / 4628640 | 0 / 0 / 0 / 0 / 0 | 3466883 / 3814472 / 3920559 / 4314446 / 4611577 | 3477409 / 3821895 / 3931262 / 4316976 / 4628640 | 5505024 | 11352618.315 |
| native-native/scalar/tls/2 / 4 | 3463823 / 3812397 / 3915413 / 4903630 / 5468470 | 3474272 / 3822622 / 3927444 / 4943831 / 5489029 | 0 / 0 / 0 / 0 / 0 | 3463823 / 3812397 / 3915413 / 4903630 / 5468470 | 3474272 / 3822622 / 3927444 / 4943831 / 5489029 | 5505024 | 11353138.406 |
| native-native/scalar/tls/3 / 1 | 3502021 / 3786505 / 3929854 / 4144316 / 4306951 | 3512019 / 3795982 / 3938514 / 4153567 / 4332426 | 0 / 0 / 0 / 0 / 0 | 3502021 / 3786505 / 3929854 / 4144316 / 4306951 | 3512019 / 3795982 / 3938514 / 4153567 / 4332426 | 5505024 | 9953293.956 |
| native-native/scalar/tls/3 / 2 | 3499585 / 3786833 / 3932131 / 4051806 / 4517029 | 3510102 / 3795729 / 3939129 / 4066091 / 4520002 | 0 / 0 / 0 / 0 / 0 | 3499585 / 3786833 / 3932131 / 4051806 / 4517029 | 3510102 / 3795729 / 3939129 / 4066091 / 4520002 | 5505024 | 11192758.771 |
| native-native/scalar/tls/3 / 3 | 3502340 / 3792832 / 3948185 / 4202733 / 4713362 | 3512188 / 3802966 / 3966092 / 4210795 / 4716656 | 0 / 0 / 0 / 0 / 0 | 3502340 / 3792832 / 3948185 / 4202733 / 4713362 | 3512188 / 3802966 / 3966092 / 4210795 / 4716656 | 5505024 | 11192431.242 |
| native-native/scalar/tls/3 / 4 | 3503641 / 3793884 / 3929935 / 4286578 / 4726834 | 3513387 / 3805967 / 3941057 / 4300868 / 4729921 | 0 / 0 / 0 / 0 / 0 | 3503641 / 3793884 / 3929935 / 4286578 / 4726834 | 3513387 / 3805967 / 3941057 / 4300868 / 4729921 | 5505024 | 11193768.035 |
| quickfix-native/scalar/tcp/1 / 1 | 4428702 / 5564411 / 5699691 / 5843549 / 5924680 | 4452707 / 5579658 / 5717870 / 5857510 / 5930025 | 0 / 0 / 0 / 0 / 0 | 4428702 / 5564411 / 5699691 / 5843549 / 5924680 | 4452707 / 5579658 / 5717870 / 5857510 / 5930025 | 1238429 | 3445017.862 |
| quickfix-native/scalar/tcp/1 / 2 | 5496695 / 5816920 / 5958687 / 6094323 / 6115569 | 5519290 / 5828952 / 5969842 / 6101234 / 6121184 | 0 / 0 / 0 / 0 / 0 | 5496695 / 5816920 / 5958687 / 6094323 / 6115569 | 5519290 / 5828952 / 5969842 / 6101234 / 6121184 | 1282453 | 3873646.571 |
| quickfix-native/scalar/tcp/1 / 3 | 5492309 / 5815934 / 5958426 / 6091525 / 6117161 | 5516366 / 5830627 / 5971800 / 6101985 / 6122133 | 0 / 0 / 0 / 0 / 0 | 5492309 / 5815934 / 5958426 / 6091525 / 6117161 | 5516366 / 5830627 / 5971800 / 6101985 / 6122133 | 1282517 | 3873612.217 |
| quickfix-native/scalar/tcp/1 / 4 | 5495442 / 5820014 / 5977594 / 6102833 / 6175038 | 5522648 / 5831798 / 5988725 / 6111228 / 6181588 | 0 / 0 / 0 / 0 / 0 | 5495442 / 5820014 / 5977594 / 6102833 / 6175038 | 5522648 / 5831798 / 5988725 / 6111228 / 6181588 | 1282508 | 3873987.040 |
| quickfix-native/scalar/tcp/2 / 1 | 4034976 / 5331147 / 5574006 / 5797847 / 5869086 | 4066730 / 5370752 / 5587801 / 5804676 / 5873195 | 0 / 0 / 0 / 0 / 0 | 4034976 / 5331147 / 5574006 / 5797847 / 5869086 | 4066730 / 5370752 / 5587801 / 5804676 / 5873195 | 1238429 | 3042051.061 |
| quickfix-native/scalar/tcp/2 / 2 | 4337329 / 5678727 / 5848457 / 6059724 / 6075121 | 4347508 / 5690219 / 5860421 / 6069068 / 6079782 | 0 / 0 / 0 / 0 / 0 | 4337329 / 5678727 / 5848457 / 6059724 / 6075121 | 4347508 / 5690219 / 5860421 / 6069068 / 6079782 | 1282453 | 3420680.435 |
| quickfix-native/scalar/tcp/2 / 3 | 4334232 / 5679802 / 5852329 / 6058404 / 6083396 | 4347510 / 5692330 / 5864193 / 6066561 / 6092181 | 0 / 0 / 0 / 0 / 0 | 4334232 / 5679802 / 5852329 / 6058404 / 6083396 | 4347510 / 5692330 / 5864193 / 6066561 / 6092181 | 1282517 | 3420639.683 |
| quickfix-native/scalar/tcp/2 / 4 | 4337616 / 5674304 / 5853940 / 6066596 / 6077435 | 4352062 / 5687443 / 5864036 / 6074049 / 6085552 | 0 / 0 / 0 / 0 / 0 | 4337616 / 5674304 / 5853940 / 6066596 / 6077435 | 4352062 / 5687443 / 5864036 / 6074049 / 6085552 | 1282508 | 3420967.960 |
| quickfix-native/scalar/tcp/3 / 1 | 4035302 / 5452811 / 5644455 / 5822766 / 5841684 | 4061127 / 5469215 / 5663157 / 5828184 / 5851891 | 0 / 0 / 0 / 0 / 0 | 4035302 / 5452811 / 5644455 / 5822766 / 5841684 | 4061127 / 5469215 / 5663157 / 5828184 / 5851891 | 1238429 | 3149355.927 |
| quickfix-native/scalar/tcp/3 / 2 | 4307837 / 5764607 / 5911301 / 6010800 / 6029428 | 4321709 / 5776694 / 5923546 / 6020265 / 6034826 | 0 / 0 / 0 / 0 / 0 | 4307837 / 5764607 / 5911301 / 6010800 / 6029428 | 4321709 / 5776694 / 5923546 / 6020265 / 6034826 | 1282453 | 3541283.463 |
| quickfix-native/scalar/tcp/3 / 3 | 4312331 / 5761687 / 5903276 / 6013663 / 6042360 | 4323100 / 5776424 / 5913979 / 6023453 / 6052987 | 0 / 0 / 0 / 0 / 0 | 4312331 / 5761687 / 5903276 / 6013663 / 6042360 | 4323100 / 5776424 / 5913979 / 6023453 / 6052987 | 1282517 | 3541310.651 |
| quickfix-native/scalar/tcp/3 / 4 | 4308686 / 5763758 / 5899221 / 6059671 / 6074620 | 4320397 / 5775529 / 5912040 / 6069738 / 6079389 | 0 / 0 / 0 / 0 / 0 | 4308686 / 5763758 / 5899221 / 6059671 / 6074620 | 4320397 / 5775529 / 5912040 / 6069738 / 6079389 | 1282508 | 3541619.092 |
| quickfix-native/scalar/tls/1 / 1 | 6069009 / 7070259 / 7320745 / 7712087 / 7760837 | 6113997 / 7125284 / 7384842 / 7771697 / 7816325 | 0 / 0 / 0 / 0 / 0 | 6069009 / 7070259 / 7320745 / 7712087 / 7760837 | 6113997 / 7125284 / 7384842 / 7771697 / 7816325 | 1238429 | 5226045.066 |
| quickfix-native/scalar/tls/1 / 2 | 6058920 / 7071272 / 7326160 / 7710019 / 7756966 | 6106526 / 7125739 / 7382599 / 7770703 / 7809764 | 0 / 0 / 0 / 0 / 0 | 6058920 / 7071272 / 7326160 / 7710019 / 7756966 | 6106526 / 7125739 / 7382599 / 7770703 / 7809764 | 1282453 | 5876698.973 |
| quickfix-native/scalar/tls/1 / 3 | 6055580 / 7071045 / 7326928 / 7715438 / 7754396 | 6101161 / 7125708 / 7381158 / 7769576 / 7815313 | 0 / 0 / 0 / 0 / 0 | 6055580 / 7071045 / 7326928 / 7715438 / 7754396 | 6101161 / 7125708 / 7381158 / 7769576 / 7815313 | 1282517 | 5876534.839 |
| quickfix-native/scalar/tls/1 / 4 | 6052239 / 7071104 / 7325319 / 7714481 / 7764729 | 6093451 / 7125197 / 7381791 / 7769980 / 7817274 | 0 / 0 / 0 / 0 / 0 | 6052239 / 7071104 / 7325319 / 7714481 / 7764729 | 6093451 / 7125197 / 7381791 / 7769980 / 7817274 | 1282508 | 5877053.687 |
| quickfix-native/scalar/tls/2 / 1 | 6111602 / 6710577 / 6825676 / 6970718 / 6986610 | 6158111 / 6765464 / 6878754 / 7026032 / 7038553 | 0 / 0 / 0 / 0 / 0 | 6111602 / 6710577 / 6825676 / 6970718 / 6986610 | 6158111 / 6765464 / 6878754 / 7026032 / 7038553 | 1238429 | 5039865.222 |
| quickfix-native/scalar/tls/2 / 2 | 6110558 / 6708036 / 6817260 / 6966598 / 6977404 | 6156170 / 6765171 / 6879492 / 7024585 / 7038097 | 0 / 0 / 0 / 0 / 0 | 6110558 / 6708036 / 6817260 / 6966598 / 6977404 | 6156170 / 6765171 / 6879492 / 7024585 / 7038097 | 1282453 | 5667194.059 |
| quickfix-native/scalar/tls/2 / 3 | 6109405 / 6708911 / 6820724 / 6969611 / 6981879 | 6154917 / 6765168 / 6879608 / 7025511 / 7038165 | 0 / 0 / 0 / 0 / 0 | 6109405 / 6708911 / 6820724 / 6969611 / 6981879 | 6154917 / 6765168 / 6879608 / 7025511 / 7038165 | 1282517 | 5667039.528 |
| quickfix-native/scalar/tls/2 / 4 | 6106442 / 6711142 / 6825164 / 6971785 / 6988514 | 6154669 / 6765582 / 6881232 / 7025724 / 7037435 | 0 / 0 / 0 / 0 / 0 | 6106442 / 6711142 / 6825164 / 6971785 / 6988514 | 6154669 / 6765582 / 6881232 / 7025724 / 7037435 | 1282508 | 5667633.648 |
| quickfix-native/scalar/tls/3 / 1 | 6240265 / 6557677 / 6696838 / 6790282 / 6816354 | 6290615 / 6609354 / 6747731 / 6837802 / 6867854 | 0 / 0 / 0 / 0 / 0 | 6240265 / 6557677 / 6696838 / 6790282 / 6816354 | 6290615 / 6609354 / 6747731 / 6837802 / 6867854 | 1238429 | 4439938.293 |
| quickfix-native/scalar/tls/3 / 2 | 6242287 / 6560377 / 6699297 / 6791597 / 6820371 | 6290940 / 6610135 / 6747075 / 6836473 / 6868429 | 0 / 0 / 0 / 0 / 0 | 6242287 / 6560377 / 6699297 / 6791597 / 6820371 | 6290940 / 6610135 / 6747075 / 6836473 / 6868429 | 1282453 | 4992718.267 |
| quickfix-native/scalar/tls/3 / 3 | 6241074 / 6560211 / 6698197 / 6790586 / 6817276 | 6290461 / 6610359 / 6745987 / 6835492 / 6870309 | 0 / 0 / 0 / 0 / 0 | 6241074 / 6560211 / 6698197 / 6790586 / 6817276 | 6290461 / 6610359 / 6745987 / 6835492 / 6870309 | 1282517 | 4992490.270 |
| quickfix-native/scalar/tls/3 / 4 | 6244776 / 6561105 / 6700797 / 6784072 / 6809806 | 6290602 / 6608886 / 6747613 / 6837021 / 6864014 | 0 / 0 / 0 / 0 / 0 | 6244776 / 6561105 / 6700797 / 6784072 / 6809806 | 6290602 / 6608886 / 6747613 / 6837021 / 6864014 | 1282508 | 4992940.977 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
