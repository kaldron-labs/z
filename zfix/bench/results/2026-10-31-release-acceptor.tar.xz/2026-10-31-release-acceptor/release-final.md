# FIX measured baseline

Build label: `clang21-O3-release-original-owners-report-layout`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 3 | 71139.9 | 71139.9 | 1.243 | 1.247 |
| native-native / tcp / scalar | 4 | 3 | 80873.8 | 81368.0 | 4.528 | 4.539 |
| native-native / tls / scalar | 1 | 3 | 62599.0 | 62599.0 | 1.237 | 1.240 |
| native-native / tls / scalar | 4 | 3 | 73326.6 | 73520.5 | 4.318 | 4.332 |
| native-quickfix / tcp / scalar | 1 | 3 | 45822.6 | 45822.6 | 1.574 | 1.587 |
| native-quickfix / tcp / scalar | 4 | 3 | 45579.2 | 45699.3 | 6.467 | 6.482 |
| native-quickfix / tls / scalar | 1 | 3 | 39301.1 | 39301.1 | 2.081 | 2.098 |
| native-quickfix / tls / scalar | 4 | 3 | 45926.3 | 45948.6 | 7.237 | 7.250 |
| quickfix-native / tcp / scalar | 1 | 3 | 55267.9 | 55267.9 | 1.454 | 1.463 |
| quickfix-native / tcp / scalar | 4 | 3 | 55998.8 | 58912.1 | 6.006 | 6.023 |
| quickfix-native / tls / scalar | 1 | 3 | 33092.6 | 33092.6 | 2.252 | 2.270 |
| quickfix-native / tls / scalar | 4 | 3 | 46262.2 | 46402.4 | 7.322 | 7.379 |
| quickfix-quickfix / tcp / scalar | 1 | 3 | 56874.6 | 56874.6 | 1.586 | 1.597 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 59036.2 | 61479.4 | 5.969 | 5.980 |
| quickfix-quickfix / tls / scalar | 1 | 3 | 35976.2 | 35976.2 | 2.292 | 2.311 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 50110.1 | 50351.8 | 6.832 | 6.879 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 0.410 | 0.426 | 23.859 | 23.859 |
| native-native / tcp / scalar | 4 | 1.591 | 1.618 | 42.883 | 48.652 |
| native-native / tls / scalar | 1 | 0.471 | 0.490 | 24.461 | 28.859 |
| native-native / tls / scalar | 4 | 1.761 | 1.825 | 48.137 | 63.664 |
| native-quickfix / tcp / scalar | 1 | 0.533 | 0.441 | 23.859 | 23.859 |
| native-quickfix / tcp / scalar | 4 | 2.067 | 1.635 | 40.367 | 36.965 |
| native-quickfix / tls / scalar | 1 | 0.604 | 0.494 | 24.449 | 25.012 |
| native-quickfix / tls / scalar | 4 | 2.225 | 1.737 | 44.965 | 41.191 |
| quickfix-native / tcp / scalar | 1 | 0.415 | 0.508 | 23.984 | 23.984 |
| quickfix-native / tcp / scalar | 4 | 1.487 | 1.886 | 32.918 | 45.098 |
| quickfix-native / tls / scalar | 1 | 0.592 | 0.653 | 23.984 | 26.703 |
| quickfix-native / tls / scalar | 4 | 1.802 | 2.072 | 37.652 | 55.336 |
| quickfix-quickfix / tcp / scalar | 1 | 0.406 | 0.387 | 23.984 | 23.984 |
| quickfix-quickfix / tcp / scalar | 4 | 1.390 | 1.334 | 32.875 | 36.887 |
| quickfix-quickfix / tls / scalar | 1 | 0.559 | 0.477 | 24.109 | 25.031 |
| quickfix-quickfix / tls / scalar | 4 | 1.631 | 1.436 | 37.543 | 40.988 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 1 / 1 | 3 | 71139.9 | 887449 | 1242911 | 1247123 | 1247123 | 1558904 |
| native-native / tcp / scalar / 4 / 1 | 3 | 20321.7 | 3148938 | 4528293 | 4538819 | 4538819 | 5673524 |
| native-native / tcp / scalar / 4 / 2 | 3 | 20331.6 | 3139055 | 3836724 | 3847331 | 3847331 | 4809164 |
| native-native / tcp / scalar / 4 / 3 | 3 | 20352.7 | 3139197 | 4005202 | 4007801 | 4007801 | 5009752 |
| native-native / tcp / scalar / 4 / 4 | 3 | 20362.0 | 3138288 | 3857002 | 3862686 | 3862686 | 4828358 |
| native-native / tls / scalar / 1 / 1 | 3 | 62599.0 | 1010911 | 1236824 | 1240218 | 1240218 | 1550273 |
| native-native / tls / scalar / 4 / 1 | 3 | 18375.1 | 3466359 | 4274304 | 4284562 | 4284562 | 5355703 |
| native-native / tls / scalar / 4 / 2 | 3 | 18378.3 | 3455493 | 4260764 | 4268010 | 4268010 | 5335013 |
| native-native / tls / scalar / 4 / 3 | 3 | 18381.9 | 3468415 | 4317744 | 4331546 | 4331546 | 5414433 |
| native-native / tls / scalar / 4 / 4 | 3 | 18385.2 | 3465547 | 4159247 | 4167496 | 4167496 | 5209370 |
| native-quickfix / tcp / scalar / 1 / 1 | 3 | 45822.6 | 1426945 | 1573675 | 1587378 | 1587378 | 1984223 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 11462.6 | 5677473 | 6445062 | 6457188 | 6457188 | 8071485 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 11406.1 | 5679807 | 6417026 | 6428985 | 6428985 | 8036232 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 11413.5 | 5674541 | 6438266 | 6452322 | 6452322 | 8065403 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 11417.2 | 5673727 | 6466838 | 6481802 | 6481802 | 8102253 |
| native-quickfix / tls / scalar / 1 / 1 | 3 | 39301.1 | 1564370 | 2081250 | 2098039 | 2098039 | 2622549 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 11489.3 | 5186663 | 7221300 | 7236565 | 7236565 | 9045707 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 11486.8 | 5186170 | 7225261 | 7242937 | 7242937 | 9053672 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 11486.0 | 5186370 | 7236344 | 7250279 | 7250279 | 9062849 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 11486.5 | 5186929 | 7237149 | 7250480 | 7250480 | 9063100 |
| quickfix-native / tcp / scalar / 1 / 1 | 3 | 55267.9 | 1112417 | 1454147 | 1462964 | 1462964 | 1828705 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 15780.1 | 4082175 | 5758455 | 5770957 | 5770957 | 7213697 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 14301.6 | 4469455 | 6005519 | 6018849 | 6018849 | 7523562 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 14316.2 | 4466074 | 5996621 | 6009854 | 6009854 | 7512318 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 14329.3 | 4460728 | 6004147 | 6022560 | 6022560 | 7528200 |
| quickfix-native / tls / scalar / 1 / 1 | 3 | 33092.6 | 1900267 | 2252489 | 2269594 | 2269594 | 2836993 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 11593.3 | 5096027 | 7317789 | 7378613 | 7378613 | 9223267 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 11594.1 | 5084418 | 7320857 | 7378964 | 7378964 | 9223705 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 11597.4 | 5081575 | 7319967 | 7376825 | 7376825 | 9221032 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 11617.5 | 5106195 | 7321610 | 7377543 | 7377543 | 9221929 |
| quickfix-quickfix / tcp / scalar / 1 / 1 | 3 | 56874.6 | 1062798 | 1586312 | 1597425 | 1597425 | 1996782 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 16409.2 | 3589029 | 5967786 | 5977324 | 5977324 | 7471655 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 14967.8 | 4270893 | 5959834 | 5969194 | 5969194 | 7461493 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 14960.8 | 4272325 | 5961923 | 5969608 | 5969608 | 7462010 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 14975.0 | 4275044 | 5968929 | 5980090 | 5980090 | 7475113 |
| quickfix-quickfix / tls / scalar / 1 / 1 | 3 | 35976.2 | 1594741 | 2292375 | 2311119 | 2311119 | 2888899 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 12581.3 | 4992878 | 6830213 | 6878354 | 6878354 | 8597943 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 12586.8 | 4993694 | 6831513 | 6876452 | 6876452 | 8595565 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 12589.6 | 4999013 | 6829280 | 6877807 | 6877807 | 8597259 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 12594.1 | 4990979 | 6823772 | 6878546 | 6878546 | 8598183 |

Raw artifacts: `/tmp/zfix-acceptor-investigation/release-final-s1`, `/tmp/zfix-acceptor-investigation/release-final-s4`.
