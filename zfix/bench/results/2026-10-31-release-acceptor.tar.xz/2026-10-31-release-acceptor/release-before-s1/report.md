# FIX process load measurements

Build label: clang21-O3-release-before-acceptor-investigation. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 70414.724 | 70414.724 | 0.411894 / 25055232 | 0.428366 / 25055232 |
| native-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 67707.315 | 67707.315 | 0.423211 / 25055232 | 0.434070 / 25055232 |
| native-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 70741.968 | 70741.968 | 0.411774 / 25055232 | 0.423762 / 25055232 |
| native-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 64403.187 | 64403.187 | 0.456190 / 25309184 | 0.477825 / 29061120 |
| native-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 61114.765 | 61114.765 | 0.468988 / 25415680 | 0.489692 / 29155328 |
| native-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 63132.607 | 63132.607 | 0.456820 / 25731072 | 0.475162 / 29061120 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 44337.073 | 44337.073 | 0.555194 / 25055232 | 0.443245 / 25055232 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 46553.650 | 46553.650 | 0.529380 / 25055232 | 0.420615 / 25055232 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 45076.716 | 45076.716 | 0.525934 / 25055232 | 0.430889 / 25055232 |
| native-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 36240.238 | 36240.238 | 0.620709 / 25251840 | 0.516990 / 26083328 |
| native-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 37819.101 | 37819.101 | 0.605107 / 25403392 | 0.493484 / 25964544 |
| native-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 40697.249 | 40697.249 | 0.572963 / 25653248 | 0.475870 / 26132480 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 54984.645 | 54984.645 | 0.432385 / 25055232 | 0.517030 / 25055232 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 48710.597 | 48710.597 | 0.450694 / 25055232 | 0.536859 / 25055232 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 45963.128 | 45963.128 | 0.462560 / 25055232 | 0.557836 / 25055232 |
| quickfix-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 33629.860 | 33629.860 | 0.586680 / 25186304 | 0.661959 / 27615232 |
| quickfix-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 31567.532 | 31567.532 | 0.629438 / 25186304 | 0.675982 / 27631616 |
| quickfix-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 33371.519 | 33371.519 | 0.590506 / 25186304 | 0.666161 / 27930624 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 58703.549 | 58703.549 | 0.400021 / 25186304 | 0.387857 / 25186304 |
| quickfix-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 54670.435 | 54670.435 | 0.418929 / 25186304 | 0.388400 / 25186304 |
| quickfix-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 53678.904 | 53678.904 | 0.421331 / 25186304 | 0.397573 / 25186304 |
| quickfix-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 40759.104 | 40759.104 | 0.511209 / 25186304 | 0.460492 / 25964544 |
| quickfix-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 41207.253 | 41207.253 | 0.508872 / 25186304 | 0.469201 / 25931776 |
| quickfix-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 41241.362 | 41241.362 | 0.504753 / 25186304 | 0.458441 / 26095616 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4916050 / 1910206 | 5505024 |
| native-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910206 / 4916050 | 5505024 |
| native-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915888 / 1910135 | 5505024 |
| native-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910135 / 4915888 | 5505024 |
| native-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4916159 / 1910233 | 5505024 |
| native-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910233 / 4916159 | 5505024 |
| native-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915985 / 1910192 | 5505024 |
| native-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910192 / 4915985 | 5505024 |
| native-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915918 / 1910170 | 5505024 |
| native-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910170 / 4915918 | 5505024 |
| native-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4916008 / 1910143 | 5505024 |
| native-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910143 / 4916008 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910126 | 5505024 |
| native-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910126 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910149 | 5505024 |
| native-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910149 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910089 | 5505024 |
| native-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910089 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910080 | 5505024 |
| native-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910080 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910137 | 5505024 |
| native-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910137 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910127 | 5505024 |
| native-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910127 / 4810790 | 1428169 |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915969 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915969 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915996 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915996 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915866 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915866 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915972 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915972 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4916019 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4916019 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915926 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915926 | 5505024 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 892181 / 1009250 / 1056925 / 1122804 / 1159492 | 898114 / 1015314 / 1064699 / 1126287 / 1161704 | 0 / 0 / 0 / 0 / 0 | 892181 / 1009250 / 1056925 / 1122804 / 1159492 | 898114 / 1015314 / 1064699 / 1126287 / 1161704 | 5505024 | 33620731.535 |
| native-native/scalar/tcp/2 / 1 | 942765 / 1025324 / 1070139 / 1118573 / 1151486 | 948869 / 1032541 / 1074388 / 1131151 / 1154084 | 0 / 0 / 0 / 0 / 0 | 942765 / 1025324 / 1070139 / 1118573 / 1151486 | 948869 / 1032541 / 1074388 / 1131151 / 1154084 | 5505024 | 33045427.428 |
| native-native/scalar/tcp/3 / 1 | 898330 / 990597 / 1025973 / 1061908 / 1097067 | 904372 / 996260 / 1033183 / 1064627 / 1099462 | 0 / 0 / 0 / 0 / 0 | 898330 / 990597 / 1025973 / 1061908 / 1097067 | 904372 / 996260 / 1033183 / 1064627 / 1099462 | 5505024 | 34405300.466 |
| native-native/scalar/tls/1 / 1 | 989529 / 1099903 / 1146801 / 1206418 / 1241075 | 996173 / 1107320 / 1154231 / 1209135 / 1256667 | 0 / 0 / 0 / 0 / 0 | 989529 / 1099903 / 1146801 / 1206418 / 1241075 | 996173 / 1107320 / 1154231 / 1209135 / 1256667 | 5505024 | 30370644.216 |
| native-native/scalar/tls/2 / 1 | 1048226 / 1143370 / 1190551 / 1581217 / 1683922 | 1055175 / 1150752 / 1198649 / 1608681 / 1685950 | 0 / 0 / 0 / 0 / 0 | 1048226 / 1143370 / 1190551 / 1581217 / 1683922 | 1055175 / 1150752 / 1198649 / 1608681 / 1685950 | 5505024 | 29637779.037 |
| native-native/scalar/tls/3 / 1 | 1010212 / 1165547 / 1222097 / 1441767 / 1485727 | 1017159 / 1172773 / 1227194 / 1449273 / 1488670 | 0 / 0 / 0 / 0 / 0 | 1010212 / 1165547 / 1222097 / 1441767 / 1485727 | 1017159 / 1172773 / 1227194 / 1449273 / 1488670 | 5505024 | 30306782.607 |
| native-quickfix/scalar/tcp/1 / 1 | 1433074 / 1528738 / 1603923 / 1670700 / 1681521 | 1445197 / 1541000 / 1616401 / 1685223 / 1695943 | 0 / 0 / 0 / 0 / 0 | 1433074 / 1528738 / 1603923 / 1670700 / 1681521 | 1445197 / 1541000 / 1616401 / 1685223 / 1695943 | 5505024 | 7414972.902 |
| native-quickfix/scalar/tcp/2 / 1 | 1432481 / 1550045 / 1605850 / 1654209 / 1689197 | 1443681 / 1561787 / 1617990 / 1660019 / 1700032 | 0 / 0 / 0 / 0 / 0 | 1432481 / 1550045 / 1605850 / 1654209 / 1689197 | 1443681 / 1561787 / 1617990 / 1660019 / 1700032 | 5505024 | 7280564.363 |
| native-quickfix/scalar/tcp/3 / 1 | 1403623 / 1554121 / 1655127 / 1775783 / 1812751 | 1414988 / 1567136 / 1665629 / 1785585 / 1814385 | 0 / 0 / 0 / 0 / 0 | 1403623 / 1554121 / 1655127 / 1775783 / 1812751 | 1414988 / 1567136 / 1665629 / 1785585 / 1814385 | 5505024 | 7262569.944 |
| native-quickfix/scalar/tls/1 / 1 | 1817132 / 1982827 / 2097279 / 2161315 / 2289922 | 1831805 / 1998902 / 2113796 / 2173352 / 2291756 | 0 / 0 / 0 / 0 / 0 | 1817132 / 1982827 / 2097279 / 2161315 / 2289922 | 1831805 / 1998902 / 2113796 / 2173352 / 2291756 | 5505024 | 16606103.497 |
| native-quickfix/scalar/tls/2 / 1 | 1572642 / 2026877 / 2080495 / 2106546 / 2142201 | 1586601 / 2042997 / 2093554 / 2121259 / 2145287 | 0 / 0 / 0 / 0 / 0 | 1572642 / 2026877 / 2080495 / 2106546 / 2142201 | 1586601 / 2042997 / 2093554 / 2121259 / 2145287 | 5505024 | 17410590.473 |
| native-quickfix/scalar/tls/3 / 1 | 1538058 / 1719137 / 1825827 / 2013691 / 2074872 | 1549584 / 1733184 / 1841415 / 2033701 / 2082545 | 0 / 0 / 0 / 0 / 0 | 1538058 / 1719137 / 1825827 / 2013691 / 2074872 | 1549584 / 1733184 / 1841415 / 2033701 / 2082545 | 5505024 | 18137499.386 |
| quickfix-native/scalar/tcp/1 / 1 | 1129636 / 1464745 / 1531123 / 1599225 / 1604429 | 1134745 / 1476653 / 1542492 / 1610575 / 1616884 | 0 / 0 / 0 / 0 / 0 | 1129636 / 1464745 / 1531123 / 1599225 / 1604429 | 1134745 / 1476653 / 1542492 / 1610575 / 1616884 | 1238429 | 4378561.954 |
| quickfix-native/scalar/tcp/2 / 1 | 1260553 / 1538978 / 1577297 / 1603843 / 1633496 | 1267701 / 1551760 / 1588463 / 1615168 / 1643736 | 0 / 0 / 0 / 0 / 0 | 1260553 / 1538978 / 1577297 / 1603843 / 1633496 | 1267701 / 1551760 / 1588463 / 1615168 / 1643736 | 1238429 | 4527552.814 |
| quickfix-native/scalar/tcp/3 / 1 | 1381854 / 1495058 / 1527101 / 1560470 / 1593627 | 1392858 / 1506256 / 1539298 / 1572545 / 1594481 | 0 / 0 / 0 / 0 / 0 | 1381854 / 1495058 / 1527101 / 1560470 / 1593627 | 1392858 / 1506256 / 1539298 / 1572545 / 1594481 | 1238429 | 4512351.144 |
| quickfix-native/scalar/tls/1 / 1 | 2011030 / 2159825 / 2220066 / 2289913 / 2304193 | 2027788 / 2177148 / 2237898 / 2308438 / 2322585 | 0 / 0 / 0 / 0 / 0 | 2011030 / 2159825 / 2220066 / 2289913 / 2304193 | 2027788 / 2177148 / 2237898 / 2308438 / 2322585 | 1238429 | 7929052.258 |
| quickfix-native/scalar/tls/2 / 1 | 2015156 / 2227470 / 2290050 / 2360493 / 2390489 | 2031622 / 2244584 / 2307666 / 2383484 / 2410277 | 0 / 0 / 0 / 0 / 0 | 2015156 / 2227470 / 2290050 / 2360493 / 2390489 | 2031622 / 2244584 / 2307666 / 2383484 / 2410277 | 1238429 | 8093217.674 |
| quickfix-native/scalar/tls/3 / 1 | 1908916 / 2016681 / 2056251 / 2078443 / 2092846 | 1923930 / 2032514 / 2072336 / 2092779 / 2108401 | 0 / 0 / 0 / 0 / 0 | 1908916 / 2016681 / 2056251 / 2078443 / 2092846 | 1923930 / 2032514 / 2072336 / 2092779 / 2108401 | 1238429 | 7984192.260 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 1073697 / 1201721 / 1262406 / 1289091 / 1295054 | 1078928 / 1206212 / 1267013 / 1293422 / 1298566 | 0 / 0 / 0 / 0 / 0 | 1073697 / 1201721 / 1262406 / 1289091 / 1295054 | 1078928 / 1206212 / 1267013 / 1293422 / 1298566 | 1238429 | 4249994.888 |
| quickfix-quickfix/scalar/tcp/2 / 1 | 1096621 / 1527649 / 1588259 / 1630572 / 1667502 | 1103364 / 1540128 / 1600431 / 1642961 / 1682695 | 0 / 0 / 0 / 0 / 0 | 1096621 / 1527649 / 1588259 / 1630572 / 1667502 | 1103364 / 1540128 / 1600431 / 1642961 / 1682695 | 1238429 | 4244518.201 |
| quickfix-quickfix/scalar/tcp/3 / 1 | 1058384 / 1528291 / 1568840 / 1600031 / 1617995 | 1064760 / 1539957 / 1581197 / 1613174 / 1627829 | 0 / 0 / 0 / 0 / 0 | 1058384 / 1528291 / 1568840 / 1600031 / 1617995 | 1064760 / 1539957 / 1581197 / 1613174 / 1627829 | 1238429 | 4251553.923 |
| quickfix-quickfix/scalar/tls/1 / 1 | 1529722 / 1665472 / 2071184 / 2120571 / 2131491 | 1542384 / 1679310 / 2088344 / 2138564 / 2145700 | 0 / 0 / 0 / 0 / 0 | 1529722 / 1665472 / 2071184 / 2120571 / 2131491 | 1542384 / 1679310 / 2088344 / 2138564 / 2145700 | 1238429 | 4437632.004 |
| quickfix-quickfix/scalar/tls/2 / 1 | 1518117 / 1676178 / 1891489 / 2014049 / 2073362 | 1530772 / 1691086 / 1903936 / 2029020 / 2088717 | 0 / 0 / 0 / 0 / 0 | 1518117 / 1676178 / 1891489 / 2014049 / 2073362 | 1530772 / 1691086 / 1903936 / 2029020 / 2088717 | 1238429 | 4465406.664 |
| quickfix-quickfix/scalar/tls/3 / 1 | 1533119 / 1619645 / 1688930 / 1729120 / 1746998 | 1545747 / 1632504 / 1702179 / 1741982 / 1760814 | 0 / 0 / 0 / 0 / 0 | 1533119 / 1619645 / 1688930 / 1729120 / 1746998 | 1545747 / 1632504 / 1702179 / 1741982 / 1760814 | 1238429 | 4418914.536 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
