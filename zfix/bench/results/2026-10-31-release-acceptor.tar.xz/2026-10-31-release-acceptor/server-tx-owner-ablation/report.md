# FIX process load measurements

Build label: release-server-shared-tx-separate-rx. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 57310.680 | 57420.972 | 1.875630 / 44040192 | 1.474383 / 53919744 |
| native-native / scalar / tcp / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 57119.059 | 57333.752 | 1.861130 / 41254912 | 1.452950 / 51273728 |
| native-native / scalar / tcp / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 59766.002 | 59863.763 | 1.859073 / 41222144 | 1.437047 / 52162560 |
| native-native / scalar / tls / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 55486.206 | 55568.632 | 1.968523 / 50122752 | 1.521334 / 59285504 |
| native-native / scalar / tls / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 53749.727 | 53830.125 | 2.010551 / 50769920 | 1.560691 / 59142144 |
| native-native / scalar / tls / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 55937.338 | 55982.455 | 1.971967 / 46039040 | 1.539704 / 57131008 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 56539.177 | 58687.615 | 1.480729 / 34471936 | 1.465534 / 50524160 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 62274.422 | 64644.771 | 1.347404 / 34586624 | 1.402083 / 50774016 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 53791.404 | 55411.580 | 1.538700 / 34299904 | 1.488066 / 50606080 |
| quickfix-native / scalar / tls / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 48259.813 | 48484.676 | 1.719377 / 39448576 | 1.487327 / 55623680 |
| quickfix-native / scalar / tls / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 44002.215 | 44141.495 | 1.859223 / 39219200 | 1.569709 / 55631872 |
| quickfix-native / scalar / tls / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 46802.232 | 47003.492 | 1.735683 / 39530496 | 1.431759 / 55111680 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805961 / 1910236 | 5505024 |
| native-native/scalar/tcp/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521129 / 2031222 | 5505024 |
| native-native/scalar/tcp/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521149 / 2031211 | 5505024 |
| native-native/scalar/tcp/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521688 / 2031323 | 5505024 |
| native-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910236 / 4805961 | 5505024 |
| native-native/scalar/tcp/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031222 / 5521129 | 5505024 |
| native-native/scalar/tcp/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031211 / 5521149 | 5505024 |
| native-native/scalar/tcp/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031323 / 5521688 | 5505024 |
| native-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805880 / 1910166 | 5505024 |
| native-native/scalar/tcp/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521222 / 2031223 | 5505024 |
| native-native/scalar/tcp/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520980 / 2031146 | 5505024 |
| native-native/scalar/tcp/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521613 / 2031306 | 5505024 |
| native-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910166 / 4805880 | 5505024 |
| native-native/scalar/tcp/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031223 / 5521222 | 5505024 |
| native-native/scalar/tcp/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031146 / 5520980 | 5505024 |
| native-native/scalar/tcp/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031306 / 5521613 | 5505024 |
| native-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805939 / 1910111 | 5505024 |
| native-native/scalar/tcp/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521089 / 2031241 | 5505024 |
| native-native/scalar/tcp/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520809 / 2031100 | 5505024 |
| native-native/scalar/tcp/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521670 / 2031295 | 5505024 |
| native-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910111 / 4805939 | 5505024 |
| native-native/scalar/tcp/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031241 / 5521089 | 5505024 |
| native-native/scalar/tcp/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031100 / 5520809 | 5505024 |
| native-native/scalar/tcp/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031295 / 5521670 | 5505024 |
| native-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805953 / 1910164 | 5505024 |
| native-native/scalar/tls/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521292 / 2031177 | 5505024 |
| native-native/scalar/tls/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521055 / 2031227 | 5505024 |
| native-native/scalar/tls/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521562 / 2031328 | 5505024 |
| native-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910164 / 4805953 | 5505024 |
| native-native/scalar/tls/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031177 / 5521292 | 5505024 |
| native-native/scalar/tls/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031227 / 5521055 | 5505024 |
| native-native/scalar/tls/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031328 / 5521562 | 5505024 |
| native-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805900 / 1910064 | 5505024 |
| native-native/scalar/tls/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521056 / 2031240 | 5505024 |
| native-native/scalar/tls/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521060 / 2031160 | 5505024 |
| native-native/scalar/tls/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521389 / 2031266 | 5505024 |
| native-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910064 / 4805900 | 5505024 |
| native-native/scalar/tls/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031240 / 5521056 | 5505024 |
| native-native/scalar/tls/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031160 / 5521060 | 5505024 |
| native-native/scalar/tls/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031266 / 5521389 | 5505024 |
| native-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806053 / 1910201 | 5505024 |
| native-native/scalar/tls/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521204 / 2031210 | 5505024 |
| native-native/scalar/tls/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520907 / 2031087 | 5505024 |
| native-native/scalar/tls/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521681 / 2031293 | 5505024 |
| native-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910201 / 4806053 | 5505024 |
| native-native/scalar/tls/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031210 / 5521204 | 5505024 |
| native-native/scalar/tls/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031087 / 5520907 | 5505024 |
| native-native/scalar/tls/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2031293 / 5521681 | 5505024 |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805768 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521250 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521071 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521726 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805768 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521250 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5521071 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521726 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805916 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521216 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521008 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521467 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805916 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521216 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5521008 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521467 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805977 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521127 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521129 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521494 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805977 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521127 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5521129 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521494 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805955 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521283 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520923 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521378 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805955 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521283 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520923 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521378 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805974 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521143 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520989 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521596 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805974 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521143 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520989 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521596 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806074 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521275 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520913 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521511 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4806074 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521275 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520913 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521511 | 5505024 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 4489342 / 4900663 / 5061708 / 5907630 / 6280802 | 4524817 / 4939732 / 5102940 / 5909762 / 6282981 | 0 / 0 / 0 / 0 / 0 | 4489342 / 4900663 / 5061708 / 5907630 / 6280802 | 4524817 / 4939732 / 5102940 / 5909762 / 6282981 | 5505024 | 8100671.215 |
| native-native/scalar/tcp/1 / 2 | 4490044 / 4899713 / 5053976 / 5963879 / 6595777 | 4525133 / 4937453 / 5098569 / 6025399 / 6636195 | 0 / 0 / 0 / 0 / 0 | 4490044 / 4899713 / 5053976 / 5963879 / 6595777 | 4525133 / 4937453 / 5098569 / 6025399 / 6636195 | 5505024 | 9109189.673 |
| native-native/scalar/tcp/1 / 3 | 4487047 / 4897178 / 5054325 / 6008345 / 6618314 | 4523294 / 4935881 / 5095888 / 6010668 / 6620676 | 0 / 0 / 0 / 0 / 0 | 4487047 / 4897178 / 5054325 / 6008345 / 6618314 | 4523294 / 4935881 / 5095888 / 6010668 / 6620676 | 5505024 | 9109200.528 |
| native-native/scalar/tcp/1 / 4 | 4483458 / 4889846 / 5028024 / 5313768 / 5939715 | 4520605 / 4930283 / 5070121 / 5316115 / 5941946 | 0 / 0 / 0 / 0 / 0 | 4483458 / 4889846 / 5028024 / 5313768 / 5939715 | 4520605 / 4930283 / 5070121 / 5316115 / 5941946 | 5505024 | 9109985.725 |
| native-native/scalar/tcp/2 / 1 | 4495343 / 5062593 / 5196662 / 5276959 / 5776188 | 4530541 / 5102254 / 5239098 / 5315328 / 5778389 | 0 / 0 / 0 / 0 / 0 | 4495343 / 5062593 / 5196662 / 5276959 / 5776188 | 4530541 / 5102254 / 5239098 / 5315328 / 5778389 | 5505024 | 8140825.829 |
| native-native/scalar/tcp/2 / 2 | 4491679 / 5057752 / 5193208 / 5252603 / 5284560 | 4526809 / 5100211 / 5235078 / 5293268 / 5331291 | 0 / 0 / 0 / 0 / 0 | 4491679 / 5057752 / 5193208 / 5252603 / 5284560 | 4526809 / 5100211 / 5235078 / 5293268 / 5331291 | 5505024 | 9154663.224 |
| native-native/scalar/tcp/2 / 3 | 4496130 / 5058554 / 5196498 / 5267431 / 5514740 | 4531048 / 5100251 / 5236601 / 5308720 / 5516945 | 0 / 0 / 0 / 0 / 0 | 4496130 / 5058554 / 5196498 / 5267431 / 5514740 | 4531048 / 5100251 / 5236601 / 5308720 / 5516945 | 5505024 | 9154276.549 |
| native-native/scalar/tcp/2 / 4 | 4490925 / 5061347 / 5196908 / 5363577 / 6003237 | 4528629 / 5103515 / 5239698 / 5426608 / 6067703 | 0 / 0 / 0 / 0 / 0 | 4490925 / 5061347 / 5196908 / 5363577 / 6003237 | 4528629 / 5103515 / 5239698 / 5426608 / 6067703 | 5505024 | 9155237.781 |
| native-native/scalar/tcp/3 / 1 | 4306689 / 4802019 / 5377157 / 5451038 / 5477757 | 4339599 / 4837443 / 5422465 / 5494083 / 5515994 | 0 / 0 / 0 / 0 / 0 | 4306689 / 4802019 / 5377157 / 5451038 / 5477757 | 4339599 / 4837443 / 5422465 / 5494083 / 5515994 | 5505024 | 8415963.566 |
| native-native/scalar/tcp/3 / 2 | 4305461 / 4802429 / 5378032 / 5451298 / 5469938 | 4339511 / 4840142 / 5421121 / 5494674 / 5516256 | 0 / 0 / 0 / 0 / 0 | 4305461 / 4802429 / 5378032 / 5451298 / 5469938 | 4339511 / 4840142 / 5421121 / 5494674 / 5516256 | 5505024 | 9463916.159 |
| native-native/scalar/tcp/3 / 3 | 4301851 / 4800988 / 5373669 / 5448031 / 5468752 | 4340111 / 4841738 / 5419461 / 5494996 / 5516989 | 0 / 0 / 0 / 0 / 0 | 4301851 / 4800988 / 5373669 / 5448031 / 5468752 | 4340111 / 4841738 / 5419461 / 5494996 / 5516989 | 5505024 | 9463388.598 |
| native-native/scalar/tcp/3 / 4 | 4305910 / 4805787 / 5379249 / 5454989 / 5479297 | 4340520 / 4845997 / 5421035 / 5496139 / 5516136 | 0 / 0 / 0 / 0 / 0 | 4305910 / 4805787 / 5379249 / 5454989 / 5479297 | 4340520 / 4845997 / 5421035 / 5496139 / 5516136 | 5505024 | 9464711.885 |
| native-native/scalar/tls/1 / 1 | 4644700 / 5087363 / 5392566 / 7215216 / 7655131 | 4681506 / 5125864 / 5435169 / 7281243 / 7718891 | 0 / 0 / 0 / 0 / 0 | 4644700 / 5087363 / 5392566 / 7215216 / 7655131 | 4681506 / 5125864 / 5435169 / 7281243 / 7718891 | 5505024 | 7835063.659 |
| native-native/scalar/tls/1 / 2 | 4640676 / 5076056 / 5358722 / 6163245 / 6641867 | 4679544 / 5117160 / 5402313 / 6166052 / 6652980 | 0 / 0 / 0 / 0 / 0 | 4640676 / 5076056 / 5358722 / 6163245 / 6641867 | 4679544 / 5117160 / 5402313 / 6166052 / 6652980 | 5505024 | 8810757.078 |
| native-native/scalar/tls/1 / 3 | 4638011 / 5073743 / 5353617 / 6303033 / 7011677 | 4676892 / 5116755 / 5397351 / 6372861 / 7093039 | 0 / 0 / 0 / 0 / 0 | 4638011 / 5073743 / 5353617 / 6303033 / 7011677 | 4676892 / 5116755 / 5397351 / 6372861 / 7093039 | 5505024 | 8810538.923 |
| native-native/scalar/tls/1 / 4 | 4641017 / 5077773 / 5372150 / 6574415 / 7175917 | 4678777 / 5119769 / 5419162 / 6650781 / 7239674 | 0 / 0 / 0 / 0 / 0 | 4641017 / 5077773 / 5372150 / 6574415 / 7175917 | 4678777 / 5119769 / 5419162 / 6650781 / 7239674 | 5505024 | 8811248.219 |
| native-native/scalar/tls/2 / 1 | 4770253 / 5453017 / 5727075 / 6760063 / 7328101 | 4807350 / 5493314 / 5773632 / 6798176 / 7383930 | 0 / 0 / 0 / 0 / 0 | 4770253 / 5453017 / 5727075 / 6760063 / 7328101 | 4807350 / 5493314 / 5773632 / 6798176 / 7383930 | 5505024 | 7559992.345 |
| native-native/scalar/tls/2 / 2 | 4767612 / 5427165 / 5715711 / 5754281 / 5778635 | 4803086 / 5470019 / 5763397 / 5800427 / 5818232 | 0 / 0 / 0 / 0 / 0 | 4767612 / 5427165 / 5715711 / 5754281 / 5778635 | 4803086 / 5470019 / 5763397 / 5800427 / 5818232 | 5505024 | 8501430.315 |
| native-native/scalar/tls/2 / 3 | 4768242 / 5443813 / 5720688 / 5781848 / 6276299 | 4804987 / 5485528 / 5768017 / 5832014 / 6332157 | 0 / 0 / 0 / 0 / 0 | 4768242 / 5443813 / 5720688 / 5781848 / 6276299 | 4804987 / 5485528 / 5768017 / 5832014 / 6332157 | 5505024 | 8501344.764 |
| native-native/scalar/tls/2 / 4 | 4764261 / 5447373 / 5725654 / 6244199 / 6810571 | 4805051 / 5489607 / 5773435 / 6279088 / 6867749 | 0 / 0 / 0 / 0 / 0 | 4764261 / 5447373 / 5725654 / 6244199 / 6810571 | 4805051 / 5489607 / 5773435 / 6279088 / 6867749 | 5505024 | 8501834.432 |
| native-native/scalar/tls/3 / 1 | 4586652 / 5408756 / 5579415 / 5736434 / 5914768 | 4624390 / 5451828 / 5624225 / 5776347 / 5959661 | 0 / 0 / 0 / 0 / 0 | 4586652 / 5408756 / 5579415 / 5736434 / 5914768 | 4624390 / 5451828 / 5624225 / 5776347 / 5959661 | 5505024 | 7850989.148 |
| native-native/scalar/tls/3 / 2 | 4589272 / 5409570 / 5580965 / 5738864 / 5918443 | 4622578 / 5452425 / 5623038 / 5786073 / 5969439 | 0 / 0 / 0 / 0 / 0 | 4589272 / 5409570 / 5580965 / 5738864 / 5918443 | 4622578 / 5452425 / 5623038 / 5786073 / 5969439 | 5505024 | 8828421.372 |
| native-native/scalar/tls/3 / 3 | 4584149 / 5405460 / 5576647 / 5728452 / 5881644 | 4623220 / 5451720 / 5623362 / 5778991 / 5965798 | 0 / 0 / 0 / 0 / 0 | 4584149 / 5405460 / 5576647 / 5728452 / 5881644 | 4623220 / 5451720 / 5623362 / 5778991 / 5965798 | 5505024 | 8827930.411 |
| native-native/scalar/tls/3 / 4 | 4587698 / 5408126 / 5578205 / 5735801 / 5926585 | 4623110 / 5451531 / 5624149 / 5781668 / 5965886 | 0 / 0 / 0 / 0 / 0 | 4587698 / 5408126 / 5578205 / 5735801 / 5926585 | 4623110 / 5451531 / 5624149 / 5781668 / 5965886 | 5505024 | 8829075.986 |
| quickfix-native/scalar/tcp/1 / 1 | 4076080 / 5137406 / 5459427 / 5569861 / 5732200 | 4093968 / 5156646 / 5471957 / 5582167 / 5737630 | 0 / 0 / 0 / 0 / 0 | 4076080 / 5137406 / 5459427 / 5569861 / 5732200 | 4093968 / 5156646 / 5471957 / 5582167 / 5737630 | 1238429 | 3257625.400 |
| quickfix-native/scalar/tcp/1 / 2 | 4381977 / 5470615 / 5707580 / 5899279 / 5908603 | 4403750 / 5485050 / 5718996 / 5906870 / 5918071 | 0 / 0 / 0 / 0 / 0 | 4381977 / 5470615 / 5707580 / 5899279 / 5908603 | 4403750 / 5485050 / 5718996 / 5906870 / 5918071 | 1282453 | 3663250.880 |
| quickfix-native/scalar/tcp/1 / 3 | 4388316 / 5451947 / 5721441 / 5887933 / 5903307 | 4409897 / 5471336 / 5731630 / 5894058 / 5909657 | 0 / 0 / 0 / 0 / 0 | 4388316 / 5451947 / 5721441 / 5887933 / 5903307 | 4409897 / 5471336 / 5731630 / 5894058 / 5909657 | 1282517 | 3663139.841 |
| quickfix-native/scalar/tcp/1 / 4 | 4382090 / 5461477 / 5703367 / 5859603 / 5890826 | 4406177 / 5478545 / 5714898 / 5869360 / 5898426 | 0 / 0 / 0 / 0 / 0 | 4382090 / 5461477 / 5703367 / 5859603 / 5890826 | 4406177 / 5478545 / 5714898 / 5869360 / 5898426 | 1282508 | 3663518.537 |
| quickfix-native/scalar/tcp/2 / 1 | 3451250 / 4280223 / 4426212 / 4711213 / 4753890 | 3481706 / 4291654 / 4446593 / 4719224 / 4761292 | 0 / 0 / 0 / 0 / 0 | 3451250 / 4280223 / 4426212 / 4711213 / 4753890 | 3481706 / 4291654 / 4446593 / 4719224 / 4761292 | 1238429 | 2948170.961 |
| quickfix-native/scalar/tcp/2 / 2 | 4194697 / 4489056 / 4633993 / 4881980 / 4900218 | 4207027 / 4499064 / 4639636 / 4887134 / 4907744 | 0 / 0 / 0 / 0 / 0 | 4194697 / 4489056 / 4633993 / 4881980 / 4900218 | 4207027 / 4499064 / 4639636 / 4887134 / 4907744 | 1282453 | 3315176.556 |
| quickfix-native/scalar/tcp/2 / 3 | 4192206 / 4491165 / 4623507 / 4899074 / 4909660 | 4206023 / 4499196 / 4631461 / 4902496 / 4917740 | 0 / 0 / 0 / 0 / 0 | 4192206 / 4491165 / 4623507 / 4899074 / 4909660 | 4206023 / 4499196 / 4631461 / 4902496 / 4917740 | 1282517 | 3315063.342 |
| quickfix-native/scalar/tcp/2 / 4 | 4190714 / 4487141 / 4620570 / 4892452 / 4903447 | 4204727 / 4494741 / 4631037 / 4898280 / 4910225 | 0 / 0 / 0 / 0 / 0 | 4190714 / 4487141 / 4620570 / 4892452 / 4903447 | 4204727 / 4494741 / 4631037 / 4898280 / 4910225 | 1282508 | 3315320.048 |
| quickfix-native/scalar/tcp/3 / 1 | 4157895 / 5218336 / 5331741 / 5403881 / 5434271 | 4170885 / 5231532 / 5347909 / 5411846 / 5443264 | 0 / 0 / 0 / 0 / 0 | 4157895 / 5218336 / 5331741 / 5403881 / 5434271 | 4170885 / 5231532 / 5347909 / 5411846 / 5443264 | 1238429 | 3382537.202 |
| quickfix-native/scalar/tcp/3 / 2 | 5094718 / 5449401 / 5538378 / 5624679 / 5636256 | 5174830 / 5459559 / 5547999 / 5633393 / 5643014 | 0 / 0 / 0 / 0 / 0 | 5094718 / 5449401 / 5538378 / 5624679 / 5636256 | 5174830 / 5459559 / 5547999 / 5633393 / 5643014 | 1282453 | 3803535.909 |
| quickfix-native/scalar/tcp/3 / 3 | 5106084 / 5444414 / 5544940 / 5619608 / 5627017 | 5168401 / 5454028 / 5552406 / 5627206 / 5633258 | 0 / 0 / 0 / 0 / 0 | 5106084 / 5444414 / 5544940 / 5619608 / 5627017 | 5168401 / 5454028 / 5552406 / 5627206 / 5633258 | 1282517 | 3803511.743 |
| quickfix-native/scalar/tcp/3 / 4 | 5113011 / 5442625 / 5551567 / 5614246 / 5620076 | 5173400 / 5454760 / 5559210 / 5621792 / 5627704 | 0 / 0 / 0 / 0 / 0 | 5113011 / 5442625 / 5551567 / 5614246 / 5620076 | 5173400 / 5454760 / 5559210 / 5621792 / 5627704 | 1282508 | 3803758.943 |
| quickfix-native/scalar/tls/1 / 1 | 5085123 / 6052847 / 6356695 / 6441788 / 6484850 | 5124836 / 6093766 / 6402333 / 6498081 / 6547106 | 0 / 0 / 0 / 0 / 0 | 5085123 / 6052847 / 6356695 / 6441788 / 6484850 | 5124836 / 6093766 / 6402333 / 6498081 / 6547106 | 1238429 | 4921108.262 |
| quickfix-native/scalar/tls/1 / 2 | 5077835 / 6046716 / 6358756 / 6453016 / 6490690 | 5123597 / 6091300 / 6402031 / 6494594 / 6548522 | 0 / 0 / 0 / 0 / 0 | 5077835 / 6046716 / 6358756 / 6453016 / 6490690 | 5123597 / 6091300 / 6402031 / 6494594 / 6548522 | 1282453 | 5533733.605 |
| quickfix-native/scalar/tls/1 / 3 | 5075574 / 6041554 / 6359109 / 6451902 / 6498950 | 5123123 / 6091442 / 6402310 / 6491696 / 6549145 | 0 / 0 / 0 / 0 / 0 | 5075574 / 6041554 / 6359109 / 6451902 / 6498950 | 5123123 / 6091442 / 6402310 / 6491696 / 6549145 | 1282517 | 5533433.293 |
| quickfix-native/scalar/tls/1 / 4 | 5093212 / 6051374 / 6352972 / 6440710 / 6497457 | 5122553 / 6090199 / 6403902 / 6500272 / 6543013 | 0 / 0 / 0 / 0 / 0 | 5093212 / 6051374 / 6352972 / 6440710 / 6497457 | 5122553 / 6090199 / 6403902 / 6500272 / 6543013 | 1282508 | 5533858.857 |
| quickfix-native/scalar/tls/2 / 1 | 5905947 / 7152279 / 7375569 / 7510399 / 7531479 | 5952955 / 7207399 / 7431618 / 7564548 / 7589770 | 0 / 0 / 0 / 0 / 0 | 5905947 / 7152279 / 7375569 / 7510399 / 7531479 | 5952955 / 7207399 / 7431618 / 7564548 / 7589770 | 1238429 | 4256339.686 |
| quickfix-native/scalar/tls/2 / 2 | 5908135 / 7150861 / 7375535 / 7510720 / 7538241 | 5951303 / 7206322 / 7432004 / 7563989 / 7588602 | 0 / 0 / 0 / 0 / 0 | 5908135 / 7150861 / 7375535 / 7510720 / 7538241 | 5951303 / 7206322 / 7432004 / 7563989 / 7588602 | 1282453 | 4786106.224 |
| quickfix-native/scalar/tls/2 / 3 | 5900647 / 7150317 / 7372360 / 7508642 / 7532810 | 5950242 / 7205692 / 7431370 / 7565877 / 7586075 | 0 / 0 / 0 / 0 / 0 | 5900647 / 7150317 / 7372360 / 7508642 / 7532810 | 5950242 / 7205692 / 7431370 / 7565877 / 7586075 | 1282517 | 4785976.985 |
| quickfix-native/scalar/tls/2 / 4 | 5908833 / 7149513 / 7374259 / 7509199 / 7535676 | 5950176 / 7206107 / 7431242 / 7564867 / 7593365 | 0 / 0 / 0 / 0 / 0 | 5908833 / 7149513 / 7374259 / 7509199 / 7535676 | 5950176 / 7206107 / 7431242 / 7564867 / 7593365 | 1282508 | 4786441.356 |
| quickfix-native/scalar/tls/3 / 1 | 5102462 / 7134544 / 7198578 / 7262121 / 7357466 | 5147268 / 7194270 / 7258731 / 7327207 / 7420929 | 0 / 0 / 0 / 0 / 0 | 5102462 / 7134544 / 7198578 / 7262121 / 7357466 | 5147268 / 7194270 / 7258731 / 7327207 / 7420929 | 1238429 | 3907737.337 |
| quickfix-native/scalar/tls/3 / 2 | 5099928 / 7134330 / 7198097 / 7260891 / 7358857 | 5146295 / 7194317 / 7258244 / 7323261 / 7429538 | 0 / 0 / 0 / 0 / 0 | 5099928 / 7134330 / 7198097 / 7260891 / 7358857 | 5146295 / 7194317 / 7258244 / 7323261 / 7429538 | 1282453 | 4394126.356 |
| quickfix-native/scalar/tls/3 / 3 | 5112906 / 7142703 / 7205990 / 7281656 / 7357674 | 5145454 / 7194019 / 7258624 / 7322890 / 7408210 | 0 / 0 / 0 / 0 / 0 | 5112906 / 7142703 / 7205990 / 7281656 / 7357674 | 5145454 / 7194019 / 7258624 / 7322890 / 7408210 | 1282517 | 4393886.726 |
| quickfix-native/scalar/tls/3 / 4 | 5101854 / 7133469 / 7196562 / 7266989 / 7350526 | 5145529 / 7193827 / 7259431 / 7326577 / 7416358 | 0 / 0 / 0 / 0 / 0 | 5101854 / 7133469 / 7196562 / 7266989 / 7350526 | 5145529 / 7193827 / 7259431 / 7326577 / 7416358 | 1282508 | 4394307.823 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
