# FIX measured baseline

Build label: `release-server-io-owners-and-report-layout`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| quickfix-native / tcp / scalar | 4 | 3 | 62897.0 | 65712.6 | 6.146 | 6.160 |
| quickfix-native / tls / scalar | 4 | 3 | 49770.8 | 49943.3 | 6.659 | 6.714 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| quickfix-native / tcp / scalar | 4 | 1.323 | 1.211 | 32.875 | 43.988 |
| quickfix-native / tls / scalar | 4 | 1.658 | 1.219 | 37.684 | 47.051 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 17651.7 | 3385584 | 5858076 | 5878118 | 5878118 | 7347648 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 16023.1 | 4152161 | 6145664 | 6160173 | 6160173 | 7700217 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 16019.1 | 4149684 | 6146271 | 6160449 | 6160449 | 7700562 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 16018.7 | 4152566 | 6145532 | 6160388 | 6160388 | 7700485 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 12475.0 | 5039876 | 6659098 | 6714304 | 6714304 | 8392880 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 12481.8 | 5029318 | 6622798 | 6675146 | 6675146 | 8343933 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 12488.7 | 5024363 | 6624469 | 6672851 | 6672851 | 8341064 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 12497.9 | 5025136 | 6623363 | 6670024 | 6670024 | 8337530 |

Raw artifacts: `/tmp/zfix-acceptor-investigation/server-owner-wire-ablation`.
