# FIX process load measurements

Build label: release-server-io-owners-only. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix-native / scalar / tcp / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 54816.820 | 56868.996 | 1.460701 / 34213888 | 1.296726 / 45391872 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 57227.199 | 59416.586 | 1.423089 / 34377728 | 1.292150 / 45416448 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 58304.693 | 60657.792 | 1.414357 / 34336768 | 1.281820 / 45535232 |
| quickfix-native / scalar / tls / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 45569.550 | 45798.887 | 1.783963 / 38879232 | 1.207959 / 49381376 |
| quickfix-native / scalar / tls / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 43808.053 | 43907.476 | 1.823178 / 38825984 | 1.252314 / 47595520 |
| quickfix-native / scalar / tls / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 42321.196 | 42464.558 | 1.855809 / 39137280 | 1.373508 / 50163712 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4916105 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631197 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631096 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631516 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4916105 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5631197 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5631096 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5631516 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915891 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631173 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631069 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631448 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915891 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5631173 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5631069 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5631448 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915843 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631263 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631051 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631641 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915843 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5631263 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5631051 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5631641 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915788 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631172 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5630979 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631576 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915788 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5631172 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5630979 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5631576 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915979 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631209 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5630943 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631637 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915979 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5631209 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5630943 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5631637 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915873 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631090 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5630959 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5631511 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915873 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5631090 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5630959 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5631511 | 5505024 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix-native/scalar/tcp/1 / 1 | 4101501 / 5565243 / 5748421 / 5880830 / 5902531 | 4111647 / 5579356 / 5767552 / 5891042 / 5911864 | 0 / 0 / 0 / 0 / 0 | 4101501 / 5565243 / 5748421 / 5880830 / 5902531 | 4111647 / 5579356 / 5767552 / 5891042 / 5911864 | 1238429 | 3178626.590 |
| quickfix-native/scalar/tcp/1 / 2 | 4242322 / 5846560 / 5985479 / 6105671 / 6116450 | 4253907 / 5865703 / 5999381 / 6117375 / 6700917 | 0 / 0 / 0 / 0 / 0 | 4242322 / 5846560 / 5985479 / 6105671 / 6116450 | 4253907 / 5865703 / 5999381 / 6117375 / 6700917 | 1282453 | 3567838.830 |
| quickfix-native/scalar/tcp/1 / 3 | 4243735 / 5852732 / 5983460 / 6112689 / 6119492 | 4255308 / 5865443 / 5996142 / 6122372 / 6280196 | 0 / 0 / 0 / 0 / 0 | 4243735 / 5852732 / 5983460 / 6112689 / 6119492 | 4255308 / 5865443 / 5996142 / 6122372 / 6280196 | 1282517 | 3567768.542 |
| quickfix-native/scalar/tcp/1 / 4 | 4245964 / 5833505 / 5985166 / 6119078 / 6130611 | 4256915 / 5849983 / 5997272 / 6129717 / 6140511 | 0 / 0 / 0 / 0 / 0 | 4245964 / 5833505 / 5985166 / 6119078 / 6130611 | 4256915 / 5849983 / 5997272 / 6129717 / 6140511 | 1282508 | 3568022.695 |
| quickfix-native/scalar/tcp/2 / 1 | 3983666 / 5501302 / 5860687 / 6207174 / 6247515 | 4017883 / 5543465 / 5873147 / 6215165 / 6256488 | 0 / 0 / 0 / 0 / 0 | 3983666 / 5501302 / 5860687 / 6207174 / 6247515 | 4017883 / 5543465 / 5873147 / 6215165 / 6256488 | 1238429 | 3159447.689 |
| quickfix-native/scalar/tcp/2 / 2 | 4276126 / 5813552 / 6091991 / 6458395 / 6468100 | 4288602 / 5835298 / 6106207 / 6473332 / 7186575 | 0 / 0 / 0 / 0 / 0 | 4276126 / 5813552 / 6091991 / 6458395 / 6468100 | 4288602 / 5835298 / 6106207 / 6473332 / 7186575 | 1282453 | 3546411.571 |
| quickfix-native/scalar/tcp/2 / 3 | 4279394 / 5813642 / 6087489 / 6423143 / 6447212 | 4291546 / 5841337 / 6101718 / 6453316 / 6928155 | 0 / 0 / 0 / 0 / 0 | 4279394 / 5813642 / 6087489 / 6423143 / 6447212 | 4291546 / 5841337 / 6101718 / 6453316 / 6928155 | 1282517 | 3546340.317 |
| quickfix-native/scalar/tcp/2 / 4 | 4277925 / 5799675 / 6087807 / 6400609 / 6407883 | 4291736 / 5819191 / 6103158 / 6415880 / 7278122 | 0 / 0 / 0 / 0 / 0 | 4277925 / 5799675 / 6087807 / 6400609 / 6407883 | 4291736 / 5819191 / 6103158 / 6415880 / 7278122 | 1282508 | 3546573.974 |
| quickfix-native/scalar/tcp/3 / 1 | 3947789 / 5239703 / 5418083 / 5612592 / 5623895 | 3976263 / 5257550 / 5427673 / 5621250 / 5642381 | 0 / 0 / 0 / 0 / 0 | 3947789 / 5239703 / 5418083 / 5612592 / 5623895 | 3976263 / 5257550 / 5427673 / 5621250 / 5642381 | 1238429 | 3082950.933 |
| quickfix-native/scalar/tcp/3 / 2 | 4236773 / 5487961 / 5650772 / 5809256 / 5813066 | 4246825 / 5502699 / 5703703 / 5925209 / 6554300 | 0 / 0 / 0 / 0 / 0 | 4236773 / 5487961 / 5650772 / 5809256 / 5813066 | 4246825 / 5502699 / 5703703 / 5925209 / 6554300 | 1282453 | 3460610.579 |
| quickfix-native/scalar/tcp/3 / 3 | 4234026 / 5490480 / 5661654 / 5805065 / 5812435 | 4245982 / 5503802 / 5686768 / 5890282 / 6752797 | 0 / 0 / 0 / 0 / 0 | 4234026 / 5490480 / 5661654 / 5805065 / 5812435 | 4245982 / 5503802 / 5686768 / 5890282 / 6752797 | 1282517 | 3460492.289 |
| quickfix-native/scalar/tcp/3 / 4 | 4236442 / 5492100 / 5661939 / 5820666 / 5825889 | 4247489 / 5506025 / 5721614 / 5937614 / 6538308 | 0 / 0 / 0 / 0 / 0 | 4236442 / 5492100 / 5661939 / 5820666 / 5825889 | 4247489 / 5506025 / 5721614 / 5937614 / 6538308 | 1282508 | 3460815.555 |
| quickfix-native/scalar/tls/1 / 1 | 5426186 / 7129171 / 7646311 / 8017435 / 8062571 | 5475818 / 7179275 / 7711746 / 8061716 / 8111474 | 0 / 0 / 0 / 0 / 0 | 5426186 / 7129171 / 7646311 / 8017435 / 8062571 | 5475818 / 7179275 / 7711746 / 8061716 / 8111474 | 1238429 | 5049470.739 |
| quickfix-native/scalar/tls/1 / 2 | 5440096 / 7076442 / 7619901 / 7888739 / 7931776 | 5474772 / 7133189 / 7680260 / 7945898 / 7985201 | 0 / 0 / 0 / 0 / 0 | 5440096 / 7076442 / 7619901 / 7888739 / 7931776 | 5474772 / 7133189 / 7680260 / 7945898 / 7985201 | 1282453 | 5668006.246 |
| quickfix-native/scalar/tls/1 / 3 | 5430328 / 6828380 / 7602126 / 7876927 / 7893578 | 5474746 / 6876989 / 7661013 / 7935815 / 7953097 | 0 / 0 / 0 / 0 / 0 | 5430328 / 6828380 / 7602126 / 7876927 / 7893578 | 5474746 / 6876989 / 7661013 / 7935815 / 7953097 | 1282517 | 5667826.552 |
| quickfix-native/scalar/tls/1 / 4 | 5424122 / 6618683 / 7602276 / 7876380 / 7893817 | 5474698 / 6667894 / 7666192 / 7936747 / 7957768 | 0 / 0 / 0 / 0 / 0 | 5424122 / 6618683 / 7602276 / 7876380 / 7893817 | 5474698 / 6667894 / 7666192 / 7936747 / 7957768 | 1282508 | 5668361.199 |
| quickfix-native/scalar/tls/2 / 1 | 5511013 / 7304042 / 7562528 / 7651203 / 7704573 | 5552190 / 7369564 / 7621110 / 7709853 / 7728118 | 0 / 0 / 0 / 0 / 0 | 5511013 / 7304042 / 7562528 / 7651203 / 7704573 | 5552190 / 7369564 / 7621110 / 7709853 / 7728118 | 1238429 | 5003687.741 |
| quickfix-native/scalar/tls/2 / 2 | 5504405 / 7307887 / 7561565 / 7649800 / 7687984 | 5552234 / 7370552 / 7623868 / 7711777 / 7745021 | 0 / 0 / 0 / 0 / 0 | 5504405 / 7307887 / 7561565 / 7649800 / 7687984 | 5552234 / 7370552 / 7623868 / 7711777 / 7745021 | 1282453 | 5616485.065 |
| quickfix-native/scalar/tls/2 / 3 | 5503520 / 7314171 / 7562698 / 7642688 / 7676268 | 5551980 / 7370824 / 7618687 / 7709094 / 7753099 | 0 / 0 / 0 / 0 / 0 | 5503520 / 7314171 / 7562698 / 7642688 / 7676268 | 5551980 / 7370824 / 7618687 / 7709094 / 7753099 | 1282517 | 5616253.513 |
| quickfix-native/scalar/tls/2 / 4 | 5503619 / 7320230 / 7563153 / 7644219 / 7680406 | 5552065 / 7370306 / 7619713 / 7707377 / 7758933 | 0 / 0 / 0 / 0 / 0 | 5503619 / 7320230 / 7563153 / 7644219 / 7680406 | 5552065 / 7370306 / 7619713 / 7707377 / 7758933 | 1282508 | 5616854.376 |
| quickfix-native/scalar/tls/3 / 1 | 5628249 / 7298565 / 7828939 / 8369075 / 8479996 | 5672547 / 7356801 / 7890257 / 8428215 / 8546260 | 0 / 0 / 0 / 0 / 0 | 5628249 / 7298565 / 7828939 / 8369075 / 8479996 | 5672547 / 7356801 / 7890257 / 8428215 / 8546260 | 1238429 | 5097458.261 |
| quickfix-native/scalar/tls/3 / 2 | 5627376 / 7291155 / 7826460 / 8191528 / 8477802 | 5671712 / 7350054 / 7881355 / 8256776 / 8536154 | 0 / 0 / 0 / 0 / 0 | 5627376 / 7291155 / 7826460 / 8191528 / 8477802 | 5671712 / 7350054 / 7881355 / 8256776 / 8536154 | 1282453 | 5721739.567 |
| quickfix-native/scalar/tls/3 / 3 | 5625019 / 7287316 / 7821578 / 8122789 / 8300139 | 5671327 / 7345038 / 7877119 / 8183324 / 8356008 | 0 / 0 / 0 / 0 / 0 | 5625019 / 7287316 / 7821578 / 8122789 / 8300139 | 5671327 / 7345038 / 7877119 / 8183324 / 8356008 | 1282517 | 5721604.450 |
| quickfix-native/scalar/tls/3 / 4 | 5627810 / 7286348 / 7805214 / 8055154 / 8185182 | 5670840 / 7341454 / 7870087 / 8108372 / 8249199 | 0 / 0 / 0 / 0 / 0 | 5627810 / 7286348 / 7805214 / 8055154 / 8185182 | 5670840 / 7341454 / 7870087 / 8108372 / 8249199 | 1282508 | 5722110.579 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
