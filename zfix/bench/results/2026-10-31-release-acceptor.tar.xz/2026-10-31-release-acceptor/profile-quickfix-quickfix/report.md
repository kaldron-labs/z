# FIX process load measurements

Build label: release-sampling-diagnostic. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 400000 / 0 | 0 / 0 / 0 | 60563.467 | 62034.887 | 12.041959 / 59293696 | 11.598635 / 47308800 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 100000 / 100000 / 100000 | 100000 / 200000 | 0 / 64 | 202002 / 101002 | 44923616 / 17743167 | 1246667 |
| quickfix-quickfix/scalar/tcp/1 / client / 2 | 100000 / 100000 / 100000 | 100000 / 200000 | 0 / 64 | 202002 / 101002 | 50931978 / 18763062 | 1286630 |
| quickfix-quickfix/scalar/tcp/1 / client / 3 | 100000 / 100000 / 100000 | 100000 / 200000 | 0 / 64 | 202002 / 101002 | 50931386 / 18762896 | 1286607 |
| quickfix-quickfix/scalar/tcp/1 / client / 4 | 100000 / 100000 / 100000 | 100000 / 200000 | 0 / 64 | 202002 / 101002 | 50932369 / 18763098 | 1286644 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 101000 / 101000 / 101000 | 101000 / 202000 | 0 / 0 | 101002 / 202002 | 17743167 / 44923616 | 1444515 |
| quickfix-quickfix/scalar/tcp/1 / server / 2 | 101000 / 101000 / 101000 | 101000 / 202000 | 0 / 0 | 101002 / 202002 | 18763062 / 50931978 | 1559646 |
| quickfix-quickfix/scalar/tcp/1 / server / 3 | 101000 / 101000 / 101000 | 101000 / 202000 | 0 / 0 | 101002 / 202002 | 18762896 / 50931386 | 1559558 |
| quickfix-quickfix/scalar/tcp/1 / server / 4 | 101000 / 101000 / 101000 | 101000 / 202000 | 0 / 0 | 101002 / 202002 | 18763098 / 50932369 | 1559639 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix-quickfix/scalar/tcp/1 / 1 | 3596391 / 4448316 / 5621618 / 5902720 / 6161679 | 3906775 / 4460661 / 5637312 / 5916065 / 6176895 | 0 / 0 / 0 / 0 / 0 | 3596391 / 4448316 / 5621618 / 5902720 / 6161679 | 3906775 / 4460661 / 5637312 / 5916065 / 6176895 | 1246667 | 8177615.153 |
| quickfix-quickfix/scalar/tcp/1 / 2 | 4317500 / 4653246 / 5804400 / 6115518 / 6329021 | 4328308 / 4664268 / 5820384 / 6128796 / 6337940 | 0 / 0 / 0 / 0 / 0 | 4317500 / 4653246 / 5804400 / 6115518 / 6329021 | 4328308 / 4664268 / 5820384 / 6128796 / 6337940 | 1286630 | 9094757.827 |
| quickfix-quickfix/scalar/tcp/1 / 3 | 4317460 / 4665786 / 5801568 / 6122867 / 6315752 | 4328696 / 4678258 / 5829069 / 6138298 / 6325650 | 0 / 0 / 0 / 0 / 0 | 4317460 / 4665786 / 5801568 / 6122867 / 6315752 | 4328696 / 4678258 / 5829069 / 6138298 / 6325650 | 1286607 | 9094658.913 |
| quickfix-quickfix/scalar/tcp/1 / 4 | 4319344 / 4673470 / 5806744 / 6137011 / 6311478 | 4330013 / 4686900 / 5825382 / 6156571 / 6322846 | 0 / 0 / 0 / 0 / 0 | 4319344 / 4673470 / 5806744 / 6137011 / 6311478 | 4330013 / 4686900 / 5825382 / 6156571 / 6322846 | 1286644 | 9094813.548 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
