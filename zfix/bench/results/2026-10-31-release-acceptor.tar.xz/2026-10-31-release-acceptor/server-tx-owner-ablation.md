# FIX measured baseline

Build label: `release-server-shared-tx-separate-rx`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 3 | 57310.7 | 57421.0 | 5.379 | 5.422 |
| native-native / tls / scalar | 4 | 3 | 55486.2 | 55568.6 | 5.727 | 5.774 |
| quickfix-native / tcp / scalar | 4 | 3 | 56539.2 | 58687.6 | 5.721 | 5.732 |
| quickfix-native / tls / scalar | 4 | 3 | 46802.2 | 47003.5 | 7.376 | 7.432 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 1.861 | 1.453 | 42.000 | 51.422 |
| native-native / tls / scalar | 4 | 1.972 | 1.540 | 48.418 | 56.539 |
| quickfix-native / tcp / scalar | 4 | 1.481 | 1.466 | 32.984 | 48.422 |
| quickfix-native / tls / scalar | 4 | 1.736 | 1.487 | 37.699 | 53.055 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 4 / 1 | 3 | 14339.2 | 4489342 | 5377157 | 5422465 | 5422465 | 6778082 |
| native-native / tcp / scalar / 4 / 2 | 3 | 14350.2 | 4490044 | 5378032 | 5421121 | 5421121 | 6776402 |
| native-native / tcp / scalar / 4 / 3 | 3 | 14361.1 | 4487047 | 5373669 | 5419461 | 5419461 | 6774327 |
| native-native / tcp / scalar / 4 / 4 | 3 | 14380.5 | 4483458 | 5379249 | 5421035 | 5421035 | 6776294 |
| native-native / tls / scalar / 4 / 1 | 3 | 13872.5 | 4644700 | 5727075 | 5773632 | 5773632 | 7217040 |
| native-native / tls / scalar / 4 / 2 | 3 | 13896.4 | 4640676 | 5715711 | 5763397 | 5763397 | 7204247 |
| native-native / tls / scalar / 4 / 3 | 3 | 13906.2 | 4638011 | 5720688 | 5768017 | 5768017 | 7210022 |
| native-native / tls / scalar / 4 / 4 | 3 | 13893.4 | 4641017 | 5725654 | 5773435 | 5773435 | 7216794 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 15665.7 | 4076080 | 5459427 | 5471957 | 5471957 | 6839947 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 14337.3 | 4381977 | 5707580 | 5718996 | 5718996 | 7148745 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 14333.4 | 4388316 | 5721441 | 5731630 | 5731630 | 7164538 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 14351.2 | 4382090 | 5703367 | 5714898 | 5714898 | 7143623 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 11736.8 | 5102462 | 7375569 | 7431618 | 7431618 | 9289523 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 11745.7 | 5099928 | 7375535 | 7432004 | 7432004 | 9290005 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 11755.7 | 5112906 | 7372360 | 7431370 | 7431370 | 9289213 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 11765.3 | 5101854 | 7374259 | 7431242 | 7431242 | 9289053 |

Raw artifacts: `/tmp/zfix-acceptor-investigation/server-tx-owner-ablation`.
