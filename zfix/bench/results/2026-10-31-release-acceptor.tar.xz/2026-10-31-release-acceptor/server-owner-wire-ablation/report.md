# FIX process load measurements

Build label: release-server-io-owners-and-report-layout. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix-native / scalar / tcp / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 62896.959 | 65712.567 | 1.323348 / 34471936 | 1.207443 / 45314048 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 61118.553 | 63820.267 | 1.383970 / 34013184 | 1.235053 / 46125056 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 63206.222 | 65977.268 | 1.313208 / 34328576 | 1.210647 / 45342720 |
| quickfix-native / scalar / tls / 1 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 50227.888 | 50418.064 | 1.608305 / 39514112 | 1.162884 / 48431104 |
| quickfix-native / scalar / tls / 2 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 49770.825 | 49943.315 | 1.658456 / 38887424 | 1.283388 / 48410624 |
| quickfix-native / scalar / tls / 3 | timing | passed | 40000 / 0 | 0 / 0 / 0 | 47292.972 | 47440.049 | 1.726304 / 39362560 | 1.219132 / 49336320 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805923 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521292 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521099 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521625 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805923 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521292 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5521099 | 5505024 |
| quickfix-native/scalar/tcp/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521625 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805958 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521124 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520969 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521639 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805958 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521124 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520969 | 5505024 |
| quickfix-native/scalar/tcp/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521639 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805906 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521106 / 2033631 | 1282453 |
| quickfix-native/scalar/tcp/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520928 / 2033581 | 1282517 |
| quickfix-native/scalar/tcp/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521487 / 2033707 | 1282508 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805906 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521106 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520928 | 5505024 |
| quickfix-native/scalar/tcp/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521487 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805934 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521089 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/1 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521062 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/1 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521505 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805934 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521089 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5521062 | 5505024 |
| quickfix-native/scalar/tls/1 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521505 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805891 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521086 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/2 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5520988 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/2 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521524 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805891 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521086 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5520988 | 5505024 |
| quickfix-native/scalar/tls/2 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521524 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805945 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / client / 2 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521042 / 2033631 | 1282453 |
| quickfix-native/scalar/tls/3 / client / 3 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521005 / 2033581 | 1282517 |
| quickfix-native/scalar/tls/3 / client / 4 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 5521559 / 2033707 | 1282508 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805945 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 2 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033631 / 5521042 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 3 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033581 / 5521005 | 5505024 |
| quickfix-native/scalar/tls/3 / server / 4 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 2033707 / 5521559 | 5505024 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix-native/scalar/tcp/1 / 1 | 3363947 / 4237710 / 4923705 / 5063508 / 5110195 | 3407284 / 4263530 / 4931231 / 5067856 / 5114941 | 0 / 0 / 0 / 0 / 0 | 3363947 / 4237710 / 4923705 / 5063508 / 5110195 | 3407284 / 4263530 / 4931231 / 5067856 / 5114941 | 1238429 | 2928878.212 |
| quickfix-native/scalar/tcp/1 / 2 | 4112349 / 4794548 / 5140134 / 5284567 / 5313063 | 4123164 / 4912790 / 5150917 / 5290580 / 5320018 | 0 / 0 / 0 / 0 / 0 | 4112349 / 4794548 / 5140134 / 5284567 / 5313063 | 4123164 / 4912790 / 5150917 / 5290580 / 5320018 | 1282453 | 3293511.832 |
| quickfix-native/scalar/tcp/1 / 3 | 4115434 / 4833009 / 5138704 / 5237520 / 5297681 | 4124325 / 4873745 / 5146315 / 5249163 / 5304154 | 0 / 0 / 0 / 0 / 0 | 4115434 / 4833009 / 5138704 / 5237520 / 5297681 | 4124325 / 4873745 / 5146315 / 5249163 / 5304154 | 1282517 | 3293405.898 |
| quickfix-native/scalar/tcp/1 / 4 | 4115829 / 4826869 / 5142281 / 5246317 / 5271434 | 4126336 / 4912063 / 5149626 / 5256070 / 5280635 | 0 / 0 / 0 / 0 / 0 | 4115829 / 4826869 / 5142281 / 5246317 / 5271434 | 4126336 / 4912063 / 5149626 / 5256070 / 5280635 | 1282508 | 3293690.133 |
| quickfix-native/scalar/tcp/2 / 1 | 3540656 / 4748544 / 5858076 / 6133650 / 6246109 | 3920764 / 4777886 / 5878118 / 6143033 / 6254834 | 0 / 0 / 0 / 0 / 0 | 3540656 / 4748544 / 5858076 / 6133650 / 6246109 | 3920764 / 4777886 / 5878118 / 6143033 / 6254834 | 1238429 | 3037469.603 |
| quickfix-native/scalar/tcp/2 / 2 | 4173957 / 5255465 / 6145664 / 6414749 / 6507154 | 4185456 / 5285274 / 6160173 / 6430562 / 6520376 | 0 / 0 / 0 / 0 / 0 | 4173957 / 5255465 / 6145664 / 6414749 / 6507154 | 4185456 / 5285274 / 6160173 / 6430562 / 6520376 | 1282453 | 3415528.670 |
| quickfix-native/scalar/tcp/2 / 3 | 4170672 / 5257312 / 6146271 / 6512383 / 6535050 | 4180406 / 5278962 / 6160449 / 6525649 / 6548514 | 0 / 0 / 0 / 0 / 0 | 4170672 / 5257312 / 6146271 / 6512383 / 6535050 | 4180406 / 5278962 / 6160449 / 6525649 / 6548514 | 1282517 | 3415435.989 |
| quickfix-native/scalar/tcp/2 / 4 | 4169287 / 5259030 / 6145532 / 6509259 / 6518853 | 4180378 / 5291243 / 6160388 / 6524558 / 6530593 | 0 / 0 / 0 / 0 / 0 | 4169287 / 5259030 / 6145532 / 6509259 / 6518853 | 4180378 / 5291243 / 6160388 / 6524558 / 6530593 | 1282508 | 3415795.863 |
| quickfix-native/scalar/tcp/3 / 1 | 3385584 / 4195590 / 4383968 / 4615747 / 4628325 | 3406745 / 4206544 / 4390595 / 4621717 / 4638187 | 0 / 0 / 0 / 0 / 0 | 3385584 / 4195590 / 4383968 / 4615747 / 4628325 | 3406745 / 4206544 / 4390595 / 4621717 / 4638187 | 1238429 | 2862028.785 |
| quickfix-native/scalar/tcp/3 / 2 | 4152161 / 4426637 / 4658021 / 4806483 / 4815838 | 4161249 / 4445563 / 4684640 / 4812174 / 4824432 | 0 / 0 / 0 / 0 / 0 | 4152161 / 4426637 / 4658021 / 4806483 / 4815838 | 4161249 / 4445563 / 4684640 / 4812174 / 4824432 | 1282453 | 3218268.828 |
| quickfix-native/scalar/tcp/3 / 3 | 4149684 / 4415943 / 4654908 / 4818880 / 4849059 | 4158944 / 4425365 / 4661296 / 4826483 / 4849934 | 0 / 0 / 0 / 0 / 0 | 4149684 / 4415943 / 4654908 / 4818880 / 4849059 | 4158944 / 4425365 / 4661296 / 4826483 / 4849934 | 1282517 | 3218171.701 |
| quickfix-native/scalar/tcp/3 / 4 | 4152566 / 4422880 / 4691644 / 4802424 / 4852574 | 4161677 / 4431722 / 4698081 / 4807953 / 4863814 | 0 / 0 / 0 / 0 / 0 | 4152566 / 4422880 / 4691644 / 4802424 / 4852574 | 4161677 / 4431722 / 4698081 / 4807953 / 4863814 | 1282508 | 3218463.507 |
| quickfix-native/scalar/tls/1 / 1 | 5019206 / 5233397 / 5385025 / 5422045 / 5439340 | 5061819 / 5276215 / 5428187 / 5468113 / 5484526 | 0 / 0 / 0 / 0 / 0 | 5019206 / 5233397 / 5385025 / 5422045 / 5439340 | 5061819 / 5276215 / 5428187 / 5468113 / 5484526 | 1238429 | 3456517.831 |
| quickfix-native/scalar/tls/1 / 2 | 5018234 / 5232474 / 5383622 / 5421983 / 5436645 | 5061314 / 5276608 / 5427596 / 5468048 / 5482087 | 0 / 0 / 0 / 0 / 0 | 5018234 / 5232474 / 5383622 / 5421983 / 5436645 | 5061314 / 5276608 / 5427596 / 5468048 / 5482087 | 1282453 | 3886729.671 |
| quickfix-native/scalar/tls/1 / 3 | 5017908 / 5232703 / 5383597 / 5422576 / 5437640 | 5061063 / 5276207 / 5427842 / 5468106 / 5481844 | 0 / 0 / 0 / 0 / 0 | 5017908 / 5232703 / 5383597 / 5422576 / 5437640 | 5061063 / 5276207 / 5427842 / 5468106 / 5481844 | 1282517 | 3886690.057 |
| quickfix-native/scalar/tls/1 / 4 | 5025136 / 5239697 / 5386907 / 5426506 / 5443352 | 5061406 / 5276590 / 5428030 / 5468622 / 5484172 | 0 / 0 / 0 / 0 / 0 | 5025136 / 5239697 / 5386907 / 5426506 / 5443352 | 5061406 / 5276590 / 5428030 / 5468622 / 5484172 | 1282508 | 3886982.794 |
| quickfix-native/scalar/tls/2 / 1 | 5075541 / 5391260 / 5511555 / 5588623 / 5606112 | 5113314 / 5434279 / 5554275 / 5632856 / 5652156 | 0 / 0 / 0 / 0 / 0 | 5075541 / 5391260 / 5511555 / 5588623 / 5606112 | 5113314 / 5434279 / 5554275 / 5632856 / 5652156 | 1238429 | 4823867.014 |
| quickfix-native/scalar/tls/2 / 2 | 5076378 / 5393989 / 5512522 / 5592486 / 5603883 | 5113161 / 5434581 / 5554617 / 5633012 / 5651311 | 0 / 0 / 0 / 0 / 0 | 5076378 / 5393989 / 5512522 / 5592486 / 5603883 | 5113161 / 5434581 / 5554617 / 5633012 / 5651311 | 1282453 | 5424297.088 |
| quickfix-native/scalar/tls/2 / 3 | 5075207 / 5392251 / 5513032 / 5591696 / 5612538 | 5113314 / 5434504 / 5554428 / 5632606 / 5651431 | 0 / 0 / 0 / 0 / 0 | 5075207 / 5392251 / 5513032 / 5591696 / 5612538 | 5113314 / 5434504 / 5554428 / 5632606 / 5651431 | 1282517 | 5424190.824 |
| quickfix-native/scalar/tls/2 / 4 | 5070063 / 5389275 / 5509947 / 5589073 / 5605011 | 5113167 / 5433993 / 5555339 / 5633806 / 5649883 | 0 / 0 / 0 / 0 / 0 | 5070063 / 5389275 / 5509947 / 5589073 / 5605011 | 5113167 / 5433993 / 5555339 / 5633806 / 5649883 | 1282508 | 5424666.141 |
| quickfix-native/scalar/tls/3 / 1 | 5039876 / 6525648 / 6659098 / 7102395 / 7225957 | 5071963 / 6579440 / 6714304 / 7152317 / 7278250 | 0 / 0 / 0 / 0 / 0 | 5039876 / 6525648 / 6659098 / 7102395 / 7225957 | 5071963 / 6579440 / 6714304 / 7152317 / 7278250 | 1238429 | 4830431.380 |
| quickfix-native/scalar/tls/3 / 2 | 5029318 / 6525390 / 6622798 / 6937245 / 7044946 | 5071292 / 6576515 / 6675146 / 6987656 / 7095046 | 0 / 0 / 0 / 0 / 0 | 5029318 / 6525390 / 6622798 / 6937245 / 7044946 | 5071292 / 6576515 / 6675146 / 6987656 / 7095046 | 1282453 | 5431603.233 |
| quickfix-native/scalar/tls/3 / 3 | 5024363 / 6527231 / 6624469 / 6904903 / 7043350 | 5071058 / 6575834 / 6672851 / 6959641 / 7090466 | 0 / 0 / 0 / 0 / 0 | 5024363 / 6527231 / 6624469 / 6904903 / 7043350 | 5071058 / 6575834 / 6672851 / 6959641 / 7090466 | 1282517 | 5431540.683 |
| quickfix-native/scalar/tls/3 / 4 | 5023294 / 6528066 / 6623363 / 6933569 / 7563585 | 5070930 / 6575309 / 6670024 / 6988405 / 7608493 | 0 / 0 / 0 / 0 / 0 | 5023294 / 6528066 / 6623363 / 6933569 / 7563585 | 5070930 / 6575309 / 6670024 / 6988405 / 7608493 | 1282508 | 5432029.584 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
