# FIX process load measurements

Build label: clang21-O3-release-io-owners-report-layout. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 54243.756 | 54243.756 | 0.337135 / 25100288 | 0.352507 / 25100288 |
| native-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 57676.358 | 57676.358 | 0.318728 / 25231360 | 0.328128 / 25231360 |
| native-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 58857.571 | 58857.571 | 0.318443 / 25231360 | 0.325420 / 25231360 |
| native-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 60263.154 | 60263.154 | 0.286310 / 26853376 | 0.321177 / 25673728 |
| native-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 60773.551 | 60773.551 | 0.284580 / 27156480 | 0.316893 / 25583616 |
| native-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 59506.763 | 59506.763 | 0.290899 / 27254784 | 0.324411 / 25452544 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 51396.286 | 51396.286 | 0.342942 / 25231360 | 0.390907 / 25231360 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 58451.412 | 58451.412 | 0.312348 / 25231360 | 0.360043 / 25231360 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 53033.831 | 53033.831 | 0.329932 / 25231360 | 0.394389 / 25231360 |
| native-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 42926.109 | 42926.109 | 0.348868 / 26140672 | 0.452260 / 26017792 |
| native-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 41928.325 | 41928.325 | 0.354425 / 26214400 | 0.453077 / 26042368 |
| native-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 34502.353 | 34502.353 | 0.389492 / 25907200 | 0.522868 / 25882624 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 66682.434 | 66682.434 | 0.364633 / 25231360 | 0.314948 / 25231360 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 44136.402 | 44136.402 | 0.469664 / 25231360 | 0.401716 / 25231360 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 62746.748 | 62746.748 | 0.376842 / 25231360 | 0.323906 / 25231360 |
| quickfix-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 34597.255 | 34597.255 | 0.577267 / 25231360 | 0.411903 / 25767936 |
| quickfix-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 35438.520 | 35438.520 | 0.568282 / 25231360 | 0.407588 / 26066944 |
| quickfix-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 35231.407 | 35231.407 | 0.568665 / 25231360 | 0.400741 / 26570752 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 55442.042 | 55442.042 | 0.411481 / 25362432 | 0.394011 / 25362432 |
| quickfix-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 56596.080 | 56596.080 | 0.404849 / 25362432 | 0.387054 / 25362432 |
| quickfix-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 57610.129 | 57610.129 | 0.402272 / 25362432 | 0.385076 / 25362432 |
| quickfix-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 36619.684 | 36619.684 | 0.564342 / 25362432 | 0.469267 / 26353664 |
| quickfix-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 34920.396 | 34920.396 | 0.571134 / 25362432 | 0.497293 / 26042368 |
| quickfix-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 37808.725 | 37808.725 | 0.538773 / 25362432 | 0.485406 / 26275840 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805940 / 1910194 | 5505024 |
| native-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910194 / 4805940 | 5505024 |
| native-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805894 / 1910081 | 5505024 |
| native-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910081 / 4805894 | 5505024 |
| native-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805832 / 1910137 | 5505024 |
| native-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910137 / 4805832 | 5505024 |
| native-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805961 / 1910130 | 5505024 |
| native-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910130 / 4805961 | 5505024 |
| native-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806065 / 1910130 | 5505024 |
| native-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910130 / 4806065 | 5505024 |
| native-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805803 / 1910117 | 5505024 |
| native-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910117 / 4805803 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910185 | 5505024 |
| native-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910185 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910086 | 5505024 |
| native-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910086 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910081 | 5505024 |
| native-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910081 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910200 | 5505024 |
| native-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910200 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910167 | 5505024 |
| native-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910167 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910128 | 5505024 |
| native-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910128 / 4810790 | 1428169 |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805926 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805926 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805999 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805999 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806008 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4806008 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806023 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4806023 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805919 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805919 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805854 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805854 | 5505024 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 1171747 / 1359572 / 1489741 / 1590228 / 1776328 | 1177806 / 1366634 / 1495423 / 1598301 / 1778430 | 0 / 0 / 0 / 0 / 0 | 1171747 / 1359572 / 1489741 / 1590228 / 1776328 | 1177806 / 1366634 / 1495423 / 1598301 / 1778430 | 5505024 | 26760931.055 |
| native-native/scalar/tcp/2 / 1 | 1079408 / 1329523 / 1403016 / 1448200 / 1486887 | 1084847 / 1337770 / 1407119 / 1461059 / 1499249 | 0 / 0 / 0 / 0 / 0 | 1079408 / 1329523 / 1403016 / 1448200 / 1486887 | 1084847 / 1337770 / 1407119 / 1461059 / 1499249 | 5505024 | 28785119.505 |
| native-native/scalar/tcp/3 / 1 | 1082757 / 1190962 / 1264477 / 1353578 / 1403373 | 1089100 / 1197337 / 1274091 / 1359113 / 1405371 | 0 / 0 / 0 / 0 / 0 | 1082757 / 1190962 / 1264477 / 1353578 / 1403373 | 1089100 / 1197337 / 1274091 / 1359113 / 1405371 | 5505024 | 29320108.901 |
| native-native/scalar/tls/1 / 1 | 1044196 / 1187449 / 1260555 / 1608191 / 1627372 | 1051339 / 1194832 / 1266466 / 1610908 / 1630192 | 0 / 0 / 0 / 0 / 0 | 1044196 / 1187449 / 1260555 / 1608191 / 1627372 | 1051339 / 1194832 / 1266466 / 1610908 / 1630192 | 5505024 | 28981140.472 |
| native-native/scalar/tls/2 / 1 | 1055994 / 1121631 / 1146614 / 1166449 / 1175466 | 1063410 / 1128991 / 1153148 / 1172226 / 1181543 | 0 / 0 / 0 / 0 / 0 | 1055994 / 1121631 / 1146614 / 1166449 / 1175466 | 1063410 / 1128991 / 1153148 / 1172226 / 1181543 | 5505024 | 29078753.474 |
| native-native/scalar/tls/3 / 1 | 1079619 / 1147024 / 1212425 / 1250886 / 1273373 | 1087004 / 1154885 / 1221824 / 1261665 / 1278254 | 0 / 0 / 0 / 0 / 0 | 1079619 / 1147024 / 1212425 / 1250886 / 1273373 | 1087004 / 1154885 / 1221824 / 1261665 / 1278254 | 5505024 | 28811258.492 |
| native-quickfix/scalar/tcp/1 / 1 | 1139851 / 1543633 / 1587453 / 1621731 / 1634989 | 1145808 / 1552472 / 1596402 / 1632919 / 1646572 | 0 / 0 / 0 / 0 / 0 | 1139851 / 1543633 / 1587453 / 1621731 / 1634989 | 1145808 / 1552472 / 1596402 / 1632919 / 1646572 | 5505024 | 7210808.913 |
| native-quickfix/scalar/tcp/2 / 1 | 1086912 / 1174244 / 1212365 / 1260091 / 1268705 | 1092916 / 1179908 / 1217660 / 1263918 / 1272109 | 0 / 0 / 0 / 0 / 0 | 1086912 / 1174244 / 1212365 / 1260091 / 1268705 | 1092916 / 1179908 / 1217660 / 1263918 / 1272109 | 5505024 | 7161866.551 |
| native-quickfix/scalar/tcp/3 / 1 | 1136545 / 1422283 / 1484568 / 1532036 / 1552701 | 1143003 / 1427597 / 1491794 / 1539548 / 1554274 | 0 / 0 / 0 / 0 / 0 | 1136545 / 1422283 / 1484568 / 1532036 / 1552701 | 1143003 / 1427597 / 1491794 / 1539548 / 1554274 | 5505024 | 7274400.290 |
| native-quickfix/scalar/tls/1 / 1 | 1478039 / 1564505 / 1623052 / 1698686 / 1714657 | 1487044 / 1573152 / 1636717 / 1709668 / 1721518 | 0 / 0 / 0 / 0 / 0 | 1478039 / 1564505 / 1623052 / 1698686 / 1714657 | 1487044 / 1573152 / 1636717 / 1709668 / 1721518 | 5505024 | 18929110.865 |
| native-quickfix/scalar/tls/2 / 1 | 1518686 / 1623156 / 1677281 / 1759938 / 1811861 | 1528454 / 1632484 / 1686119 / 1770501 / 1817439 | 0 / 0 / 0 / 0 / 0 | 1518686 / 1623156 / 1677281 / 1759938 / 1811861 | 1528454 / 1632484 / 1686119 / 1770501 / 1817439 | 5505024 | 18708856.449 |
| native-quickfix/scalar/tls/3 / 1 | 1842061 / 1981901 / 2047262 / 2088132 / 2112604 | 1855787 / 1996824 / 2060616 / 2102776 / 2114544 | 0 / 0 / 0 / 0 / 0 | 1842061 / 1981901 / 2047262 / 2088132 / 2112604 | 1855787 / 1996824 / 2060616 / 2102776 / 2114544 | 5505024 | 16467959.405 |
| quickfix-native/scalar/tcp/1 / 1 | 948071 / 1010806 / 1048992 / 1083834 / 1090957 | 953271 / 1016096 / 1054597 / 1089809 / 1099076 | 0 / 0 / 0 / 0 / 0 | 948071 / 1010806 / 1048992 / 1083834 / 1090957 | 953271 / 1016096 / 1054597 / 1089809 / 1099076 | 1238429 | 4094070.258 |
| quickfix-native/scalar/tcp/2 / 1 | 1437916 / 1534420 / 1555086 / 1616518 / 1684096 | 1449397 / 1546450 / 1566978 / 1617341 / 1685182 | 0 / 0 / 0 / 0 / 0 | 1437916 / 1534420 / 1555086 / 1616518 / 1684096 | 1449397 / 1546450 / 1566978 / 1617341 / 1685182 | 1238429 | 4444219.237 |
| quickfix-native/scalar/tcp/3 / 1 | 1009787 / 1076684 / 1116546 / 1174227 / 1214180 | 1015771 / 1082809 / 1123831 / 1180510 / 1220410 | 0 / 0 / 0 / 0 / 0 | 1009787 / 1076684 / 1116546 / 1174227 / 1214180 | 1015771 / 1082809 / 1123831 / 1180510 / 1220410 | 1238429 | 4096588.499 |
| quickfix-native/scalar/tls/1 / 1 | 1825438 / 2070582 / 2124753 / 2157862 / 2183590 | 1838861 / 2085889 / 2138983 / 2175930 / 2201681 | 0 / 0 / 0 / 0 / 0 | 1825438 / 2070582 / 2124753 / 2157862 / 2183590 | 1838861 / 2085889 / 2138983 / 2175930 / 2201681 | 1238429 | 4869034.011 |
| quickfix-native/scalar/tls/2 / 1 | 1785625 / 2125217 / 2190086 / 2258032 / 2284768 | 1799021 / 2142971 / 2208026 / 2274081 / 2300646 | 0 / 0 / 0 / 0 / 0 | 1785625 / 2125217 / 2190086 / 2258032 / 2284768 | 1799021 / 2142971 / 2208026 / 2274081 / 2300646 | 1238429 | 4843431.874 |
| quickfix-native/scalar/tls/3 / 1 | 1665022 / 2095761 / 2154169 / 2206003 / 2230145 | 1678350 / 2111915 / 2169932 / 2220610 / 2247216 | 0 / 0 / 0 / 0 / 0 | 1665022 / 2095761 / 2154169 / 2206003 / 2230145 | 1678350 / 2111915 / 2169932 / 2220610 / 2247216 | 1238429 | 7714868.070 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 1062383 / 1421798 / 1454562 / 1488044 / 1540599 | 1068288 / 1432608 / 1464114 / 1496985 / 1542387 | 0 / 0 / 0 / 0 / 0 | 1062383 / 1421798 / 1454562 / 1488044 / 1540599 | 1068288 / 1432608 / 1464114 / 1496985 / 1542387 | 1238429 | 4235012.085 |
| quickfix-quickfix/scalar/tcp/2 / 1 | 1066043 / 1372922 / 1417319 / 1444877 / 1476323 | 1072793 / 1382983 / 1428330 / 1452780 / 1477519 | 0 / 0 / 0 / 0 / 0 | 1066043 / 1372922 / 1417319 / 1444877 / 1476323 | 1072793 / 1382983 / 1428330 / 1452780 / 1477519 | 1238429 | 4214462.607 |
| quickfix-quickfix/scalar/tcp/3 / 1 | 1066182 / 1431031 / 1512860 / 1543799 / 1556030 | 1072241 / 1443080 / 1524117 / 1555493 / 1565842 | 0 / 0 / 0 / 0 / 0 | 1066182 / 1431031 / 1512860 / 1543799 / 1556030 | 1072241 / 1443080 / 1524117 / 1555493 / 1565842 | 1238429 | 4202103.755 |
| quickfix-quickfix/scalar/tls/1 / 1 | 1796713 / 1954447 / 2011006 / 2097758 / 2115408 | 1810746 / 1969726 / 2027214 / 2112693 / 2130246 | 0 / 0 / 0 / 0 / 0 | 1796713 / 1954447 / 2011006 / 2097758 / 2115408 | 1810746 / 1969726 / 2027214 / 2112693 / 2130246 | 1238429 | 4555386.191 |
| quickfix-quickfix/scalar/tls/2 / 1 | 1650412 / 2223503 / 2286480 / 2328889 / 2339175 | 1663739 / 2240789 / 2304368 / 2347663 / 2357548 | 0 / 0 / 0 / 0 / 0 | 1650412 / 2223503 / 2286480 / 2328889 / 2339175 | 1663739 / 2240789 / 2304368 / 2347663 / 2357548 | 1238429 | 7400085.640 |
| quickfix-quickfix/scalar/tls/3 / 1 | 1629148 / 2090732 / 2182843 / 2251024 / 2269239 | 1642337 / 2107714 / 2198968 / 2266871 / 2285745 | 0 / 0 / 0 / 0 / 0 | 1629148 / 2090732 / 2182843 / 2251024 / 2269239 | 1642337 / 2107714 / 2198968 / 2266871 / 2285745 | 1238429 | 7471701.399 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
