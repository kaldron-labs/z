# FIX process load measurements

Build label: release-wire-diagnostic-strace. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix-native / scalar / tcp / 1 | timing | passed | 8 / 0 | 0 / 0 / 0 | 3904.650 | 3904.650 | 0.084906 / 25202688 | 0.189174 / 25202688 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 8 / 0 | 0 / 0 / 0 | 3260.438 | 3260.438 | 0.063941 / 25333760 | 0.223843 / 25333760 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| quickfix-native/scalar/tcp/1 / client / 1 | 8 / 8 / 8 | 8 / 16 | 0 / 1 | 18 / 10 | 3581 / 1525 | 2805 |
| quickfix-native/scalar/tcp/1 / server / 1 | 8 / 8 / 8 | 8 / 16 | 0 / 0 | 10 / 18 | 1525 / 3581 | 21504 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 8 / 8 / 8 | 8 / 16 | 0 / 1 | 18 / 10 | 3485 / 1525 | 2805 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 8 / 8 / 8 | 8 / 16 | 0 / 0 | 10 / 18 | 1525 / 3485 | 5789 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix-native/scalar/tcp/1 / 1 | 166709 / 452818 / 452818 / 452818 / 452818 | 204518 / 543893 / 543893 / 543893 / 543893 | 0 / 0 / 0 / 0 / 0 | 166709 / 452818 / 452818 / 452818 / 452818 | 204518 / 543893 / 543893 / 543893 / 543893 | 2805 | 2350.655 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 208856 / 425295 / 425295 / 425295 / 425295 | 272383 / 519329 / 519329 / 519329 / 519329 | 0 / 0 / 0 / 0 / 0 | 208856 / 425295 / 425295 / 425295 / 425295 | 272383 / 519329 / 519329 / 519329 / 519329 | 2805 | 2338.391 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
