# FIX measured baseline

Build label: `release-thread-rerun-acceptor-shared`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 3 | 54307.9 | 54307.9 | 1.492 | 1.504 |
| native-native / tcp / scalar | 4 | 3 | 57011.8 | 57182.4 | 5.176 | 5.217 |
| native-native / tls / scalar | 1 | 3 | 53559.5 | 53559.5 | 1.544 | 1.554 |
| native-native / tls / scalar | 4 | 3 | 55421.4 | 55495.9 | 5.482 | 5.525 |
| native-quickfix / tcp / scalar | 1 | 3 | 52186.5 | 52186.5 | 1.592 | 1.604 |
| native-quickfix / tcp / scalar | 4 | 3 | 47809.4 | 48032.7 | 6.456 | 6.468 |
| native-quickfix / tls / scalar | 1 | 3 | 39094.9 | 39094.9 | 2.066 | 2.079 |
| native-quickfix / tls / scalar | 4 | 3 | 43313.0 | 43340.7 | 7.180 | 7.195 |
| quickfix-native / tcp / scalar | 1 | 3 | 58458.8 | 58458.8 | 1.599 | 1.600 |
| quickfix-native / tcp / scalar | 4 | 3 | 62836.2 | 65587.8 | 6.126 | 6.139 |
| quickfix-native / tls / scalar | 1 | 3 | 38252.8 | 38252.8 | 2.247 | 2.266 |
| quickfix-native / tls / scalar | 4 | 3 | 50837.8 | 51018.7 | 5.359 | 5.401 |
| quickfix-quickfix / tcp / scalar | 1 | 3 | 58476.9 | 58476.9 | 1.515 | 1.530 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 62227.0 | 64338.4 | 6.589 | 6.603 |
| quickfix-quickfix / tls / scalar | 1 | 3 | 37183.6 | 37183.6 | 2.195 | 2.212 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 49798.2 | 49893.4 | 6.773 | 6.824 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 0.475 | 0.348 | 24.039 | 24.039 |
| native-native / tcp / scalar | 4 | 1.872 | 1.364 | 39.336 | 43.246 |
| native-native / tls / scalar | 1 | 0.507 | 0.361 | 24.359 | 24.414 |
| native-native / tls / scalar | 4 | 1.963 | 1.335 | 43.910 | 48.352 |
| native-quickfix / tcp / scalar | 1 | 0.504 | 0.412 | 24.039 | 24.039 |
| native-quickfix / tcp / scalar | 4 | 2.038 | 1.598 | 40.676 | 36.926 |
| native-quickfix / tls / scalar | 1 | 0.584 | 0.475 | 24.469 | 25.016 |
| native-quickfix / tls / scalar | 4 | 2.236 | 1.768 | 46.883 | 41.031 |
| quickfix-native / tcp / scalar | 1 | 0.405 | 0.350 | 24.039 | 24.039 |
| quickfix-native / tcp / scalar | 4 | 1.322 | 1.195 | 33.051 | 43.242 |
| quickfix-native / tls / scalar | 1 | 0.552 | 0.385 | 24.039 | 25.125 |
| quickfix-native / tls / scalar | 4 | 1.624 | 1.246 | 37.602 | 47.352 |
| quickfix-quickfix / tcp / scalar | 1 | 0.406 | 0.398 | 24.164 | 24.164 |
| quickfix-quickfix / tcp / scalar | 4 | 1.353 | 1.326 | 32.859 | 37.012 |
| quickfix-quickfix / tls / scalar | 1 | 0.549 | 0.489 | 24.164 | 25.109 |
| quickfix-quickfix / tls / scalar | 4 | 1.657 | 1.455 | 37.723 | 41.102 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 1 / 1 | 3 | 54307.9 | 1145515 | 1491931 | 1504269 | 1504269 | 1880337 |
| native-native / tcp / scalar / 4 / 1 | 3 | 14291.0 | 4747416 | 5161396 | 5206148 | 5206148 | 6507685 |
| native-native / tcp / scalar / 4 / 2 | 3 | 14294.6 | 4746938 | 5175946 | 5216983 | 5216983 | 6521229 |
| native-native / tcp / scalar / 4 / 3 | 3 | 14296.3 | 4745790 | 5171683 | 5210785 | 5210785 | 6513482 |
| native-native / tcp / scalar / 4 / 4 | 3 | 14300.5 | 4750197 | 5160809 | 5204941 | 5204941 | 6506177 |
| native-native / tls / scalar / 1 / 1 | 3 | 53559.5 | 1223924 | 1544400 | 1554094 | 1554094 | 1942618 |
| native-native / tls / scalar / 4 / 1 | 3 | 13871.3 | 4678777 | 5479292 | 5521504 | 5521504 | 6901880 |
| native-native / tls / scalar / 4 / 2 | 3 | 13873.5 | 4679672 | 5476370 | 5522724 | 5522724 | 6903405 |
| native-native / tls / scalar / 4 / 3 | 3 | 13873.8 | 4676861 | 5478335 | 5523709 | 5523709 | 6904637 |
| native-native / tls / scalar / 4 / 4 | 3 | 13877.2 | 4678650 | 5482002 | 5525264 | 5525264 | 6906580 |
| native-quickfix / tcp / scalar / 1 / 1 | 3 | 52186.5 | 1189762 | 1591998 | 1604482 | 1604482 | 2005603 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 11989.2 | 5141958 | 6456293 | 6467571 | 6467571 | 8084464 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 11995.4 | 5026015 | 6448134 | 6461899 | 6461899 | 8077374 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 12000.7 | 5210372 | 6400577 | 6414436 | 6414436 | 8018045 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 12047.4 | 5066152 | 6451620 | 6464589 | 6464589 | 8080737 |
| native-quickfix / tls / scalar / 1 / 1 | 3 | 39094.9 | 1581212 | 2065822 | 2079015 | 2079015 | 2598769 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 10839.9 | 6254009 | 7179606 | 7194307 | 7194307 | 8992884 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 10834.6 | 6254408 | 7179031 | 7194691 | 7194691 | 8993364 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 10832.7 | 6254654 | 7178561 | 7194737 | 7194737 | 8993422 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 10833.5 | 6254571 | 7178642 | 7195011 | 7195011 | 8993764 |
| quickfix-native / tcp / scalar / 1 / 1 | 3 | 58458.8 | 1042836 | 1599203 | 1599808 | 1599808 | 1999760 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 17586.5 | 3414607 | 5882847 | 5898590 | 5898590 | 7373238 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 16002.5 | 4201094 | 6119912 | 6136345 | 6136345 | 7670432 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 15997.7 | 4201011 | 6125544 | 6137457 | 6137457 | 7671822 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 16001.1 | 4202172 | 6124508 | 6139240 | 6139240 | 7674050 |
| quickfix-native / tls / scalar / 1 / 1 | 3 | 38252.8 | 1606083 | 2247152 | 2265835 | 2265835 | 2832294 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 12741.5 | 4966408 | 5332044 | 5370662 | 5370662 | 6713328 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 12751.1 | 4965552 | 5320897 | 5369241 | 5369241 | 6711552 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 12758.7 | 4970222 | 5359052 | 5400802 | 5400802 | 6751003 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 12767.4 | 4970922 | 5327417 | 5367677 | 5367677 | 6709597 |
| quickfix-quickfix / tcp / scalar / 1 / 1 | 3 | 58476.9 | 1055879 | 1515458 | 1530484 | 1530484 | 1913105 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 17298.8 | 3439505 | 6333339 | 6348743 | 6348743 | 7935929 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 15688.6 | 4257877 | 6589194 | 6603358 | 6603358 | 8254198 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 15675.6 | 4256117 | 6577499 | 6590688 | 6590688 | 8238360 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 15675.4 | 4253606 | 6586613 | 6601324 | 6601324 | 8251655 |
| quickfix-quickfix / tls / scalar / 1 / 1 | 3 | 37183.6 | 1661645 | 2194783 | 2212101 | 2212101 | 2765127 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 12477.6 | 4992250 | 6766958 | 6821369 | 6821369 | 8526712 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 12469.5 | 4985783 | 6766779 | 6818151 | 6818151 | 8522689 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 12470.6 | 4985726 | 6770317 | 6820579 | 6820579 | 8525724 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 12475.7 | 4985793 | 6773067 | 6823540 | 6823540 | 8529425 |

Raw artifacts: `/tmp/zfix-thread-rerun-20261031/acceptor-shared-s1`, `/tmp/zfix-thread-rerun-20261031/acceptor-shared-s4`.
