# FIX process load measurements

Build label: release-thread-rerun-separate. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 69858.997 | 69858.997 | 0.420435 / 25145344 | 0.430051 / 25145344 |
| native-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 71296.002 | 71296.002 | 0.413466 / 25145344 | 0.422161 / 25145344 |
| native-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 68670.945 | 68670.945 | 0.419419 / 25145344 | 0.428845 / 25145344 |
| native-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 63889.965 | 63889.965 | 0.452258 / 25329664 | 0.477675 / 29655040 |
| native-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 63350.087 | 63350.087 | 0.462154 / 25280512 | 0.480360 / 30699520 |
| native-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 60213.141 | 60213.141 | 0.470606 / 25620480 | 0.496335 / 29175808 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 47964.637 | 47964.637 | 0.524598 / 25145344 | 0.428067 / 25145344 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 45318.289 | 45318.289 | 0.534093 / 25145344 | 0.437750 / 25145344 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 42755.952 | 42755.952 | 0.551840 / 25145344 | 0.454612 / 25145344 |
| native-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 35894.020 | 35894.020 | 0.619941 / 25714688 | 0.513739 / 25567232 |
| native-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 36782.235 | 36782.235 | 0.616573 / 25169920 | 0.515082 / 25923584 |
| native-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 37656.261 | 37656.261 | 0.604136 / 25853952 | 0.496628 / 26304512 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 51644.586 | 51644.586 | 0.438939 / 25145344 | 0.512556 / 25145344 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 49780.243 | 49780.243 | 0.458886 / 25145344 | 0.532430 / 25145344 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 61302.975 | 61302.975 | 0.385389 / 25145344 | 0.477123 / 25145344 |
| quickfix-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 36576.792 | 36576.792 | 0.548390 / 25145344 | 0.634886 / 28049408 |
| quickfix-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 30674.556 | 30674.556 | 0.624231 / 25276416 | 0.679057 / 27709440 |
| quickfix-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 33541.557 | 33541.557 | 0.574953 / 25276416 | 0.661598 / 27439104 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 53922.210 | 53922.210 | 0.422864 / 25276416 | 0.390014 / 25276416 |
| quickfix-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 58256.509 | 58256.509 | 0.404519 / 25276416 | 0.382283 / 25276416 |
| quickfix-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 54742.912 | 54742.912 | 0.416267 / 25276416 | 0.375113 / 25276416 |
| quickfix-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 36093.386 | 36093.386 | 0.564644 / 25276416 | 0.491536 / 26140672 |
| quickfix-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 32713.543 | 32713.543 | 0.610811 / 25276416 | 0.500021 / 26095616 |
| quickfix-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 38697.378 | 38697.378 | 0.526273 / 25276416 | 0.468279 / 26275840 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805909 / 1910100 | 5505024 |
| native-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910100 / 4805909 | 5505024 |
| native-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805955 / 1910181 | 5505024 |
| native-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910181 / 4805955 | 5505024 |
| native-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806079 / 1910206 | 5505024 |
| native-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910206 / 4806079 | 5505024 |
| native-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805801 / 1910123 | 5505024 |
| native-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910123 / 4805801 | 5505024 |
| native-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805881 / 1910098 | 5505024 |
| native-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910098 / 4805881 | 5505024 |
| native-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805798 / 1910115 | 5505024 |
| native-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910115 / 4805798 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910094 | 5505024 |
| native-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910094 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910205 | 5505024 |
| native-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910205 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910138 | 5505024 |
| native-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910138 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910289 | 5505024 |
| native-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910289 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910123 | 5505024 |
| native-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910123 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910115 | 5505024 |
| native-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910115 / 4810790 | 1428169 |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805866 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805866 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805975 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805975 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805933 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805933 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805805 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805805 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805819 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805819 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805884 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805884 | 5505024 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 909374 / 1020406 / 1061523 / 1087639 / 1101756 | 915257 / 1026133 / 1067911 / 1092931 / 1104440 | 0 / 0 / 0 / 0 / 0 | 909374 / 1020406 / 1061523 / 1087639 / 1101756 | 915257 / 1026133 / 1067911 / 1092931 / 1104440 | 5505024 | 33231107.578 |
| native-native/scalar/tcp/2 / 1 | 883139 / 1009592 / 1064720 / 1493566 / 1564878 | 888748 / 1015442 / 1074424 / 1495946 / 1567913 | 0 / 0 / 0 / 0 / 0 | 883139 / 1009592 / 1064720 / 1493566 / 1564878 | 888748 / 1015442 / 1074424 / 1495946 / 1567913 | 5505024 | 33793103.461 |
| native-native/scalar/tcp/3 / 1 | 922714 / 1029626 / 1098062 / 1454417 / 1525049 | 928484 / 1035773 / 1104991 / 1458848 / 1547225 | 0 / 0 / 0 / 0 / 0 | 922714 / 1029626 / 1098062 / 1454417 / 1525049 | 928484 / 1035773 / 1104991 / 1458848 / 1547225 | 5505024 | 32834380.627 |
| native-native/scalar/tls/1 / 1 | 998009 / 1114312 / 1182456 / 1346053 / 1387360 | 1004458 / 1121888 / 1190253 / 1349063 / 1390379 | 0 / 0 / 0 / 0 / 0 | 998009 / 1114312 / 1182456 / 1346053 / 1387360 | 1004458 / 1121888 / 1190253 / 1349063 / 1390379 | 5505024 | 30004134.951 |
| native-native/scalar/tls/2 / 1 | 1004631 / 1134248 / 1188960 / 1228765 / 1250175 | 1011159 / 1141910 / 1196592 / 1235207 / 1255972 | 0 / 0 / 0 / 0 / 0 | 1004631 / 1134248 / 1188960 / 1228765 / 1250175 | 1011159 / 1141910 / 1196592 / 1235207 / 1255972 | 5505024 | 29660169.532 |
| native-native/scalar/tls/3 / 1 | 1057939 / 1167938 / 1271596 / 2300720 / 2320927 | 1064612 / 1175822 / 1283641 / 2303890 / 2323473 | 0 / 0 / 0 / 0 / 0 | 1057939 / 1167938 / 1271596 / 2300720 / 2320927 | 1064612 / 1175822 / 1283641 / 2303890 / 2323473 | 5505024 | 28765666.898 |
| native-quickfix/scalar/tcp/1 / 1 | 1339621 / 1463781 / 1580278 / 1719820 / 1801463 | 1350859 / 1475293 / 1592587 / 1732548 / 1811253 | 0 / 0 / 0 / 0 / 0 | 1339621 / 1463781 / 1580278 / 1719820 / 1801463 | 1350859 / 1475293 / 1592587 / 1732548 / 1811253 | 5505024 | 7410510.494 |
| native-quickfix/scalar/tcp/2 / 1 | 1414600 / 1515820 / 1561395 / 1603980 / 1633671 | 1426332 / 1527020 / 1574207 / 1615535 / 1645075 | 0 / 0 / 0 / 0 / 0 | 1414600 / 1515820 / 1561395 / 1603980 / 1633671 | 1426332 / 1527020 / 1574207 / 1615535 / 1645075 | 5505024 | 7372145.049 |
| native-quickfix/scalar/tcp/3 / 1 | 1480839 / 1573256 / 1644472 / 1670844 / 1693779 | 1493394 / 1585392 / 1658304 / 1683746 / 1696663 | 0 / 0 / 0 / 0 / 0 | 1480839 / 1573256 / 1644472 / 1670844 / 1693779 | 1493394 / 1585392 / 1658304 / 1683746 / 1696663 | 5505024 | 7361091.465 |
| native-quickfix/scalar/tls/1 / 1 | 1818468 / 1971803 / 2072805 / 2124860 / 2152103 | 1831470 / 1984338 / 2090046 / 2142934 / 2169619 | 0 / 0 / 0 / 0 / 0 | 1818468 / 1971803 / 2072805 / 2124860 / 2152103 | 1831470 / 1984338 / 2090046 / 2142934 / 2169619 | 5505024 | 16652474.196 |
| native-quickfix/scalar/tls/2 / 1 | 1750013 / 1938604 / 2012038 / 2110118 / 2206049 | 1763383 / 1953323 / 2028179 / 2122301 / 2208503 | 0 / 0 / 0 / 0 / 0 | 1750013 / 1938604 / 2012038 / 2110118 / 2206049 | 1763383 / 1953323 / 2028179 / 2122301 / 2208503 | 5505024 | 16964750.261 |
| native-quickfix/scalar/tls/3 / 1 | 1630061 / 1938171 / 2077632 / 2587292 / 2781043 | 1643125 / 1952663 / 2092741 / 2589450 / 2786392 | 0 / 0 / 0 / 0 / 0 | 1630061 / 1938171 / 2077632 / 2587292 / 2781043 | 1643125 / 1952663 / 2092741 / 2589450 / 2786392 | 5505024 | 17399552.106 |
| quickfix-native/scalar/tcp/1 / 1 | 1274549 / 1383944 / 1422231 / 1463959 / 1470984 | 1282848 / 1392931 / 1430322 / 1473183 / 1480279 | 0 / 0 / 0 / 0 / 0 | 1274549 / 1383944 / 1422231 / 1463959 / 1470984 | 1282848 / 1392931 / 1430322 / 1473183 / 1480279 | 1238429 | 4448390.400 |
| quickfix-native/scalar/tcp/2 / 1 | 1270793 / 1357132 / 1405116 / 1445092 / 1461425 | 1278742 / 1365544 / 1414683 / 1452959 / 1468309 | 0 / 0 / 0 / 0 / 0 | 1270793 / 1357132 / 1405116 / 1445092 / 1461425 | 1278742 / 1365544 / 1414683 / 1452959 / 1468309 | 1238429 | 4474663.927 |
| quickfix-native/scalar/tcp/3 / 1 | 1019663 / 1263488 / 1369260 / 1573160 / 1596973 | 1025920 / 1271004 / 1377920 / 1581036 / 1602558 | 0 / 0 / 0 / 0 / 0 | 1019663 / 1263488 / 1369260 / 1573160 / 1596973 | 1025920 / 1271004 / 1377920 / 1581036 / 1602558 | 1238429 | 4119097.701 |
| quickfix-native/scalar/tls/1 / 1 | 1688404 / 2045212 / 2135213 / 2211979 / 2224978 | 1701639 / 2061208 / 2151672 / 2228090 / 2241843 | 0 / 0 / 0 / 0 / 0 | 1688404 / 2045212 / 2135213 / 2211979 / 2224978 | 1701639 / 2061208 / 2151672 / 2228090 / 2241843 | 1238429 | 7701507.139 |
| quickfix-native/scalar/tls/2 / 1 | 2064692 / 2232459 / 2292495 / 2399462 / 2428241 | 2081929 / 2250930 / 2310716 / 2417016 / 2439269 | 0 / 0 / 0 / 0 / 0 | 2064692 / 2232459 / 2292495 / 2399462 / 2428241 | 2081929 / 2250930 / 2310716 / 2417016 / 2439269 | 1238429 | 5114617.363 |
| quickfix-native/scalar/tls/3 / 1 | 1909663 / 2109944 / 2219684 / 2369283 / 2427679 | 1924312 / 2126522 / 2236077 / 2389333 / 2442487 | 0 / 0 / 0 / 0 / 0 | 1909663 / 2109944 / 2219684 / 2369283 / 2427679 | 1924312 / 2126522 / 2236077 / 2389333 / 2442487 | 1238429 | 7695181.157 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 1102085 / 1501725 / 1543995 / 1598347 / 1616519 | 1108207 / 1510511 / 1553934 / 1608681 / 1619192 | 0 / 0 / 0 / 0 / 0 | 1102085 / 1501725 / 1543995 / 1598347 / 1616519 | 1108207 / 1510511 / 1553934 / 1608681 / 1619192 | 1238429 | 4245886.557 |
| quickfix-quickfix/scalar/tcp/2 / 1 | 1048938 / 1384248 / 1426318 / 1456117 / 1471388 | 1055079 / 1395710 / 1437777 / 1465540 / 1479589 | 0 / 0 / 0 / 0 / 0 | 1048938 / 1384248 / 1426318 / 1456117 / 1471388 | 1055079 / 1395710 / 1437777 / 1465540 / 1479589 | 1238429 | 4194508.793 |
| quickfix-quickfix/scalar/tcp/3 / 1 | 1065805 / 1547325 / 1589556 / 1785623 / 1874129 | 1072266 / 1556707 / 1599889 / 1797597 / 1879414 | 0 / 0 / 0 / 0 / 0 | 1065805 / 1547325 / 1589556 / 1785623 / 1874129 | 1072266 / 1556707 / 1599889 / 1797597 / 1879414 | 1238429 | 4212152.649 |
| quickfix-quickfix/scalar/tls/1 / 1 | 1645821 / 2215438 / 2263138 / 2278397 / 2284118 | 1658869 / 2232816 / 2280062 / 2295534 / 2300776 | 0 / 0 / 0 / 0 / 0 | 1645821 / 2215438 / 2263138 / 2278397 / 2284118 | 1658869 / 2232816 / 2280062 / 2295534 / 2300776 | 1238429 | 7411511.120 |
| quickfix-quickfix/scalar/tls/2 / 1 | 1918750 / 2142149 / 2191507 / 2226161 / 2233355 | 1933997 / 2159477 / 2209922 / 2244910 / 2253942 | 0 / 0 / 0 / 0 / 0 | 1918750 / 2142149 / 2191507 / 2226161 / 2233355 | 1933997 / 2159477 / 2209922 / 2244910 / 2253942 | 1238429 | 4688617.439 |
| quickfix-quickfix/scalar/tls/3 / 1 | 1619278 / 1806080 / 1941108 / 2143049 / 2163679 | 1632897 / 1820156 / 1951893 / 2157787 / 2178413 | 0 / 0 / 0 / 0 / 0 | 1619278 / 1806080 / 1941108 / 2143049 / 2163679 | 1632897 / 1820156 / 1951893 / 2157787 / 2178413 | 1238429 | 7364936.516 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
