# FIX measured baseline

Build label: `release-thread-rerun-separate`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 3 | 69859.0 | 69859.0 | 1.098 | 1.105 |
| native-native / tcp / scalar | 4 | 3 | 81616.0 | 81819.0 | 4.011 | 4.013 |
| native-native / tls / scalar | 1 | 3 | 63350.1 | 63350.1 | 1.272 | 1.284 |
| native-native / tls / scalar | 4 | 3 | 72664.7 | 72798.2 | 4.309 | 4.315 |
| native-quickfix / tcp / scalar | 1 | 3 | 45318.3 | 45318.3 | 1.644 | 1.658 |
| native-quickfix / tcp / scalar | 4 | 3 | 44242.1 | 44411.7 | 6.532 | 6.544 |
| native-quickfix / tls / scalar | 1 | 3 | 36782.2 | 36782.2 | 2.078 | 2.093 |
| native-quickfix / tls / scalar | 4 | 3 | 44406.7 | 44432.9 | 7.174 | 7.194 |
| quickfix-native / tcp / scalar | 1 | 3 | 51644.6 | 51644.6 | 1.422 | 1.430 |
| quickfix-native / tcp / scalar | 4 | 3 | 54980.3 | 57300.9 | 6.117 | 6.128 |
| quickfix-native / tls / scalar | 1 | 3 | 33541.6 | 33541.6 | 2.292 | 2.311 |
| quickfix-native / tls / scalar | 4 | 3 | 42367.6 | 42548.6 | 7.398 | 7.454 |
| quickfix-quickfix / tcp / scalar | 1 | 3 | 54742.9 | 54742.9 | 1.590 | 1.600 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 62979.3 | 64826.2 | 5.994 | 6.005 |
| quickfix-quickfix / tls / scalar | 1 | 3 | 36093.4 | 36093.4 | 2.263 | 2.280 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 49411.6 | 49633.7 | 7.068 | 7.121 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 0.419 | 0.429 | 23.980 | 23.980 |
| native-native / tcp / scalar | 4 | 1.574 | 1.612 | 43.047 | 49.895 |
| native-native / tls / scalar | 1 | 0.462 | 0.480 | 24.434 | 29.277 |
| native-native / tls / scalar | 4 | 1.772 | 1.825 | 47.602 | 62.301 |
| native-quickfix / tcp / scalar | 1 | 0.534 | 0.438 | 23.980 | 23.980 |
| native-quickfix / tcp / scalar | 4 | 2.126 | 1.669 | 40.293 | 36.988 |
| native-quickfix / tls / scalar | 1 | 0.617 | 0.514 | 24.656 | 25.086 |
| native-quickfix / tls / scalar | 4 | 2.242 | 1.786 | 45.320 | 41.246 |
| quickfix-native / tcp / scalar | 1 | 0.439 | 0.513 | 23.980 | 23.980 |
| quickfix-native / tcp / scalar | 4 | 1.524 | 1.949 | 33.152 | 45.113 |
| quickfix-native / tls / scalar | 1 | 0.575 | 0.662 | 24.105 | 26.750 |
| quickfix-native / tls / scalar | 4 | 1.866 | 1.995 | 37.684 | 54.305 |
| quickfix-quickfix / tcp / scalar | 1 | 0.416 | 0.382 | 24.105 | 24.105 |
| quickfix-quickfix / tcp / scalar | 4 | 1.337 | 1.309 | 32.879 | 37.035 |
| quickfix-quickfix / tls / scalar | 1 | 0.565 | 0.492 | 24.105 | 25.059 |
| quickfix-quickfix / tls / scalar | 4 | 1.637 | 1.428 | 38.031 | 40.957 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 1 / 1 | 3 | 69859.0 | 909374 | 1098062 | 1104991 | 1104991 | 1381239 |
| native-native / tcp / scalar / 4 / 1 | 3 | 20454.5 | 3120021 | 4010675 | 4013465 | 4013465 | 5016832 |
| native-native / tcp / scalar / 4 / 2 | 3 | 20440.2 | 3116131 | 3760402 | 3769843 | 3769843 | 4712304 |
| native-native / tcp / scalar / 4 / 3 | 3 | 20463.8 | 3118735 | 3753453 | 3759903 | 3759903 | 4699879 |
| native-native / tcp / scalar / 4 / 4 | 3 | 20460.5 | 3120855 | 3736212 | 3740795 | 3740795 | 4675994 |
| native-native / tls / scalar / 1 / 1 | 3 | 63350.1 | 1004631 | 1271596 | 1283641 | 1283641 | 1604552 |
| native-native / tls / scalar / 4 / 1 | 3 | 18208.0 | 3536336 | 4191024 | 4202195 | 4202195 | 5252744 |
| native-native / tls / scalar / 4 / 2 | 3 | 18196.9 | 3538919 | 4309452 | 4315295 | 4315295 | 5394119 |
| native-native / tls / scalar / 4 / 3 | 3 | 18194.0 | 3540931 | 4267487 | 4279427 | 4279427 | 5349284 |
| native-native / tls / scalar / 4 / 4 | 3 | 18199.3 | 3537499 | 4187193 | 4194525 | 4194525 | 5243157 |
| native-quickfix / tcp / scalar / 1 / 1 | 3 | 45318.3 | 1414600 | 1644472 | 1658304 | 1658304 | 2072880 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 11082.3 | 5993225 | 6532469 | 6544376 | 6544376 | 8180470 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 11087.5 | 5977533 | 6523725 | 6538373 | 6538373 | 8172967 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 11099.7 | 5994946 | 6484527 | 6496880 | 6496880 | 8121100 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 11142.2 | 5994783 | 6499519 | 6513356 | 6513356 | 8141695 |
| native-quickfix / tls / scalar / 1 / 1 | 3 | 36782.2 | 1750013 | 2077632 | 2092741 | 2092741 | 2615927 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 11108.5 | 5992889 | 7165989 | 7189808 | 7189808 | 8987260 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 11107.5 | 5994438 | 7174478 | 7193953 | 7193953 | 8992442 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 11107.9 | 5992057 | 7170024 | 7185731 | 7185731 | 8982164 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 11109.0 | 5977422 | 7163730 | 7183777 | 7183777 | 8979722 |
| quickfix-native / tcp / scalar / 1 / 1 | 3 | 51644.6 | 1270793 | 1422231 | 1430322 | 1430322 | 1787903 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 15157.2 | 4214087 | 5827375 | 5843040 | 5843040 | 7303800 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 14034.9 | 4390334 | 6096695 | 6109334 | 6109334 | 7636668 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 14047.7 | 4389515 | 6105511 | 6116620 | 6116620 | 7645775 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 14061.1 | 4389429 | 6117115 | 6128455 | 6128455 | 7660569 |
| quickfix-native / tls / scalar / 1 / 1 | 3 | 33541.6 | 1909663 | 2292495 | 2310716 | 2310716 | 2888395 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 10617.6 | 6124709 | 7397779 | 7448287 | 7448287 | 9310359 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 10629.6 | 6121972 | 7393462 | 7451984 | 7451984 | 9314980 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 10644.3 | 6121802 | 7393589 | 7453507 | 7453507 | 9316884 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 10657.2 | 6118049 | 7388724 | 7449604 | 7449604 | 9312005 |
| quickfix-quickfix / tcp / scalar / 1 / 1 | 3 | 54742.9 | 1065805 | 1589556 | 1599889 | 1599889 | 1999862 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 17436.6 | 3397567 | 5959273 | 5969348 | 5969348 | 7461685 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 15788.0 | 4158462 | 5978196 | 5987347 | 5987347 | 7484184 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 15796.1 | 4157948 | 5994270 | 6005228 | 6005228 | 7506535 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 15805.5 | 4158317 | 5992669 | 6001562 | 6001562 | 7501953 |
| quickfix-quickfix / tls / scalar / 1 / 1 | 3 | 36093.4 | 1645821 | 2263138 | 2280062 | 2280062 | 2850078 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 12383.6 | 4976385 | 7058130 | 7116414 | 7116414 | 8895518 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 12393.7 | 4976842 | 7062020 | 7114345 | 7114345 | 8892932 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 12420.3 | 4981573 | 7058288 | 7115005 | 7115005 | 8893757 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 12436.1 | 4975098 | 7067989 | 7120641 | 7120641 | 8900802 |

Raw artifacts: `/tmp/zfix-thread-rerun-20261031/separate-s1`, `/tmp/zfix-thread-rerun-20261031/separate-s4`.
