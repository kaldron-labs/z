# FIX process load measurements

Build label: release-thread-rerun-both-shared. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 57256.437 | 57256.437 | 0.319810 / 25206784 | 0.331818 / 25206784 |
| native-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 52990.397 | 52990.397 | 0.341603 / 25337856 | 0.357549 / 25337856 |
| native-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 59696.377 | 59696.377 | 0.309152 / 25337856 | 0.315635 / 25337856 |
| native-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 61847.487 | 61847.487 | 0.300161 / 27344896 | 0.331111 / 25833472 |
| native-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 61601.629 | 61601.629 | 0.296192 / 28549120 | 0.325499 / 25460736 |
| native-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 58416.533 | 58416.533 | 0.289141 / 26632192 | 0.333793 / 26169344 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 58473.359 | 58473.359 | 0.315931 / 25337856 | 0.361706 / 25337856 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 48728.052 | 48728.052 | 0.363796 / 25337856 | 0.417795 / 25337856 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 54572.976 | 54572.976 | 0.334967 / 25337856 | 0.393197 / 25337856 |
| native-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 39685.718 | 39685.718 | 0.357212 / 25731072 | 0.476093 / 26083328 |
| native-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 39725.457 | 39725.457 | 0.363372 / 26914816 | 0.465552 / 26099712 |
| native-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 40343.876 | 40343.876 | 0.364710 / 26841088 | 0.466285 / 26423296 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 59743.608 | 59743.608 | 0.397371 / 25337856 | 0.339755 / 25337856 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 64483.343 | 64483.343 | 0.379163 / 25337856 | 0.325824 / 25337856 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 62624.201 | 62624.201 | 0.389001 / 25337856 | 0.329461 / 25337856 |
| quickfix-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 31530.955 | 31530.955 | 0.620180 / 25337856 | 0.416021 / 25649152 |
| quickfix-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 38391.997 | 38391.997 | 0.538586 / 25468928 | 0.380626 / 25976832 |
| quickfix-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 39121.692 | 39121.692 | 0.532498 / 25468928 | 0.369105 / 25899008 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 54618.652 | 54618.652 | 0.433632 / 25468928 | 0.416176 / 25468928 |
| quickfix-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 61306.064 | 61306.064 | 0.391445 / 25468928 | 0.371445 / 25468928 |
| quickfix-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 53882.302 | 53882.302 | 0.421307 / 25468928 | 0.396451 / 25468928 |
| quickfix-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 37595.252 | 37595.252 | 0.546140 / 25468928 | 0.490342 / 26128384 |
| quickfix-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 35891.072 | 35891.072 | 0.561527 / 25468928 | 0.503620 / 26431488 |
| quickfix-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 33992.935 | 33992.935 | 0.578723 / 25468928 | 0.479763 / 26218496 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805964 / 1910193 | 5505024 |
| native-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910193 / 4805964 | 5505024 |
| native-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805802 / 1910162 | 5505024 |
| native-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910162 / 4805802 | 5505024 |
| native-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805971 / 1910181 | 5505024 |
| native-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910181 / 4805971 | 5505024 |
| native-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805999 / 1910144 | 5505024 |
| native-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910144 / 4805999 | 5505024 |
| native-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805847 / 1910049 | 5505024 |
| native-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910049 / 4805847 | 5505024 |
| native-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805839 / 1910135 | 5505024 |
| native-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910135 / 4805839 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910121 | 5505024 |
| native-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910121 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910170 | 5505024 |
| native-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910170 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910146 | 5505024 |
| native-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910146 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910106 | 5505024 |
| native-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910106 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910167 | 5505024 |
| native-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910167 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910054 | 5505024 |
| native-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910054 / 4810790 | 1428169 |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805959 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805959 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805930 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805930 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805967 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805967 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805916 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805916 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805898 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805898 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805913 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805913 | 5505024 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 1105012 / 1285539 / 1331404 / 1433588 / 1472269 | 1111482 / 1291482 / 1338519 / 1441780 / 1484960 | 0 / 0 / 0 / 0 / 0 | 1105012 / 1285539 / 1331404 / 1433588 / 1472269 | 1111482 / 1291482 / 1338519 / 1441780 / 1484960 | 5505024 | 28245268.113 |
| native-native/scalar/tcp/2 / 1 | 1221099 / 1306715 / 1405866 / 1705727 / 1843864 | 1227827 / 1312868 / 1416872 / 1709502 / 1848871 | 0 / 0 / 0 / 0 / 0 | 1221099 / 1306715 / 1405866 / 1705727 / 1843864 | 1227827 / 1312868 / 1416872 / 1709502 / 1848871 | 5505024 | 26204866.294 |
| native-native/scalar/tcp/3 / 1 | 1047962 / 1276686 / 1440977 / 1545915 / 1605225 | 1054013 / 1285163 / 1450933 / 1557058 / 1610460 | 0 / 0 / 0 / 0 / 0 | 1047962 / 1276686 / 1440977 / 1545915 / 1605225 | 1054013 / 1285163 / 1450933 / 1557058 / 1610460 | 5505024 | 29614939.755 |
| native-native/scalar/tls/1 / 1 | 976520 / 1239761 / 1277930 / 1351469 / 1382020 | 982905 / 1247579 / 1289227 / 1359985 / 1385137 | 0 / 0 / 0 / 0 / 0 | 976520 / 1239761 / 1277930 / 1351469 / 1382020 | 982905 / 1247579 / 1289227 / 1359985 / 1385137 | 5505024 | 28704474.881 |
| native-native/scalar/tls/2 / 1 | 1045091 / 1129252 / 1209176 / 1257415 / 1271008 | 1052181 / 1137760 / 1216637 / 1265363 / 1292052 | 0 / 0 / 0 / 0 / 0 | 1045091 / 1129252 / 1209176 / 1257415 / 1271008 | 1052181 / 1137760 / 1216637 / 1265363 / 1292052 | 5505024 | 29352865.115 |
| native-native/scalar/tls/3 / 1 | 1080161 / 1174220 / 1204875 / 1246644 / 1281635 | 1087223 / 1181279 / 1211667 / 1248591 / 1283488 | 0 / 0 / 0 / 0 / 0 | 1080161 / 1174220 / 1204875 / 1246644 / 1281635 | 1087223 / 1181279 / 1211667 / 1248591 / 1283488 | 5505024 | 28003118.886 |
| native-quickfix/scalar/tcp/1 / 1 | 1084527 / 1193012 / 1237915 / 1301884 / 1330663 | 1089772 / 1199094 / 1244928 / 1308016 / 1333447 | 0 / 0 / 0 / 0 / 0 | 1084527 / 1193012 / 1237915 / 1301884 / 1330663 | 1089772 / 1199094 / 1244928 / 1308016 / 1333447 | 5505024 | 7132158.884 |
| native-quickfix/scalar/tcp/2 / 1 | 1298564 / 1490873 / 1551397 / 1714698 / 1837453 | 1305453 / 1498819 / 1556289 / 1723164 / 1848653 | 0 / 0 / 0 / 0 / 0 | 1298564 / 1490873 / 1551397 / 1714698 / 1837453 | 1305453 / 1498819 / 1556289 / 1723164 / 1848653 | 5505024 | 7259655.036 |
| native-quickfix/scalar/tcp/3 / 1 | 1144239 / 1319927 / 1454030 / 1538766 / 1567113 | 1150452 / 1326887 / 1460205 / 1547158 / 1572094 | 0 / 0 / 0 / 0 / 0 | 1144239 / 1319927 / 1454030 / 1538766 / 1567113 | 1150452 / 1326887 / 1460205 / 1547158 / 1572094 | 5505024 | 7268121.656 |
| native-quickfix/scalar/tls/1 / 1 | 1541040 / 1903709 / 2022373 / 2146296 / 2172764 | 1551091 / 1917803 / 2036885 / 2160835 / 2180529 | 0 / 0 / 0 / 0 / 0 | 1541040 / 1903709 / 2022373 / 2146296 / 2172764 | 1551091 / 1917803 / 2036885 / 2160835 / 2180529 | 5505024 | 18029060.844 |
| native-quickfix/scalar/tls/2 / 1 | 1495959 / 1913467 / 2006877 / 2124741 / 2161200 | 1506363 / 1925931 / 2019263 / 2145183 / 2184234 | 0 / 0 / 0 / 0 / 0 | 1495959 / 1913467 / 2006877 / 2124741 / 2161200 | 1506363 / 1925931 / 2019263 / 2145183 / 2184234 | 5505024 | 18084604.959 |
| native-quickfix/scalar/tls/3 / 1 | 1537310 / 1865191 / 1916833 / 1959474 / 1975381 | 1547836 / 1875856 / 1929943 / 1973309 / 1994626 | 0 / 0 / 0 / 0 / 0 | 1537310 / 1865191 / 1916833 / 1959474 / 1975381 | 1547836 / 1875856 / 1929943 / 1973309 / 1994626 | 5505024 | 18186305.789 |
| quickfix-native/scalar/tcp/1 / 1 | 988621 / 1473210 / 1541106 / 1649276 / 1663068 | 994145 / 1484908 / 1553617 / 1659973 / 1679039 | 0 / 0 / 0 / 0 / 0 | 988621 / 1473210 / 1541106 / 1649276 / 1663068 | 994145 / 1484908 / 1553617 / 1659973 / 1679039 | 1238429 | 4238663.165 |
| quickfix-native/scalar/tcp/2 / 1 | 963522 / 1052791 / 1438974 / 1495138 / 1520011 | 969267 / 1059160 / 1450412 / 1505609 / 1521554 | 0 / 0 / 0 / 0 / 0 | 963522 / 1052791 / 1438974 / 1495138 / 1520011 | 969267 / 1059160 / 1450412 / 1505609 / 1521554 | 1238429 | 4108352.512 |
| quickfix-native/scalar/tcp/3 / 1 | 976364 / 1239663 / 1314983 / 2398537 / 2427982 | 981640 / 1246592 / 1320477 / 2405955 / 2430966 | 0 / 0 / 0 / 0 / 0 | 976364 / 1239663 / 1314983 / 2398537 / 2427982 | 981640 / 1246592 / 1320477 / 2405955 / 2430966 | 1238429 | 4115001.982 |
| quickfix-native/scalar/tls/1 / 1 | 2055763 / 2190590 / 2257214 / 2330349 / 2341534 | 2072840 / 2207972 / 2274181 / 2347926 / 2357681 | 0 / 0 / 0 / 0 / 0 | 2055763 / 2190590 / 2257214 / 2330349 / 2341534 | 2072840 / 2207972 / 2274181 / 2347926 / 2357681 | 1238429 | 5056500.443 |
| quickfix-native/scalar/tls/2 / 1 | 1586449 / 1891476 / 1995724 / 2031177 / 2057009 | 1599607 / 1906114 / 2009123 / 2047096 / 2072082 | 0 / 0 / 0 / 0 / 0 | 1586449 / 1891476 / 1995724 / 2031177 / 2057009 | 1599607 / 1906114 / 2009123 / 2047096 / 2072082 | 1238429 | 4646751.378 |
| quickfix-native/scalar/tls/3 / 1 | 1602412 / 1818729 / 1922272 / 2039062 / 2073213 | 1615490 / 1833356 / 1933014 / 2054391 / 2088016 | 0 / 0 / 0 / 0 / 0 | 1602412 / 1818729 / 1922272 / 2039062 / 2073213 | 1615490 / 1833356 / 1933014 / 2054391 / 2088016 | 1238429 | 4645410.421 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 1092113 / 1525739 / 1607537 / 1749729 / 1859051 | 1096783 / 1536963 / 1619227 / 1755732 / 1860034 | 0 / 0 / 0 / 0 / 0 | 1092113 / 1525739 / 1607537 / 1749729 / 1859051 | 1096783 / 1536963 / 1619227 / 1755732 / 1860034 | 1238429 | 4319456.532 |
| quickfix-quickfix/scalar/tcp/2 / 1 | 1029780 / 1108617 / 1158321 / 1210211 / 1223100 | 1035900 / 1114634 / 1164104 / 1217303 / 1230317 | 0 / 0 / 0 / 0 / 0 | 1029780 / 1108617 / 1158321 / 1210211 / 1223100 | 1035900 / 1114634 / 1164104 / 1217303 / 1230317 | 1238429 | 4160390.526 |
| quickfix-quickfix/scalar/tcp/3 / 1 | 1136312 / 1424037 / 1477529 / 1514436 / 1542655 | 1142623 / 1432796 / 1486854 / 1524617 / 1548077 | 0 / 0 / 0 / 0 / 0 | 1136312 / 1424037 / 1477529 / 1514436 / 1542655 | 1142623 / 1432796 / 1486854 / 1524617 / 1548077 | 1238429 | 4258147.824 |
| quickfix-quickfix/scalar/tls/1 / 1 | 1584310 / 2140623 / 2229744 / 2278898 / 2295286 | 1597151 / 2156958 / 2248618 / 2296743 / 2312277 | 0 / 0 / 0 / 0 / 0 | 1584310 / 2140623 / 2229744 / 2278898 / 2295286 | 1597151 / 2156958 / 2248618 / 2296743 / 2312277 | 1238429 | 7469301.909 |
| quickfix-quickfix/scalar/tls/2 / 1 | 1766796 / 1841954 / 1885645 / 1985205 / 1989810 | 1780477 / 1855355 / 1900218 / 1998617 / 2003423 | 0 / 0 / 0 / 0 / 0 | 1766796 / 1841954 / 1885645 / 1985205 / 1989810 | 1780477 / 1855355 / 1900218 / 1998617 / 2003423 | 1238429 | 4626703.784 |
| quickfix-quickfix/scalar/tls/3 / 1 | 1887165 / 2113307 / 2175673 / 2304944 / 2317832 | 1902062 / 2129715 / 2193839 / 2320456 / 2332136 | 0 / 0 / 0 / 0 / 0 | 1887165 / 2113307 / 2175673 / 2304944 / 2317832 | 1902062 / 2129715 / 2193839 / 2320456 / 2332136 | 1238429 | 7470214.294 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
