# FIX process load measurements

Build label: release-thread-rerun-acceptor-shared. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 57622.271 | 57622.271 | 0.464898 / 25206784 | 0.334045 / 25206784 |
| native-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 53755.083 | 53755.083 | 0.480983 / 25206784 | 0.360014 / 25206784 |
| native-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 54307.945 | 54307.945 | 0.475055 / 25206784 | 0.347942 / 25206784 |
| native-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 53559.536 | 53559.536 | 0.507375 / 25509888 | 0.361468 / 25485312 |
| native-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 54159.318 | 54159.318 | 0.503956 / 25542656 | 0.357997 / 25600000 |
| native-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 48104.312 | 48104.312 | 0.534145 / 25391104 | 0.388450 / 25296896 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 49691.530 | 49691.530 | 0.507142 / 25206784 | 0.421621 / 25206784 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 54087.745 | 54087.745 | 0.496112 / 25206784 | 0.401872 / 25206784 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 52186.543 | 52186.543 | 0.504232 / 25206784 | 0.411817 / 25206784 |
| native-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 39094.873 | 39094.873 | 0.584025 / 25657344 | 0.474670 / 26230784 |
| native-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 39955.578 | 39955.578 | 0.582535 / 25464832 | 0.468444 / 25862144 |
| native-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 35974.387 | 35974.387 | 0.626386 / 25477120 | 0.518096 / 26140672 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 62349.509 | 62349.509 | 0.386995 / 25206784 | 0.329578 / 25206784 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 58458.802 | 58458.802 | 0.405379 / 25206784 | 0.350022 / 25206784 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 57320.543 | 57320.543 | 0.410333 / 25206784 | 0.350116 / 25206784 |
| quickfix-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 38252.808 | 38252.808 | 0.552162 / 25206784 | 0.384654 / 25518080 |
| quickfix-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 33160.779 | 33160.779 | 0.602039 / 25206784 | 0.419467 / 26345472 |
| quickfix-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 38978.615 | 38978.615 | 0.519125 / 25206784 | 0.375665 / 25841664 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 53855.483 | 53855.483 | 0.418893 / 25206784 | 0.398437 / 25206784 |
| quickfix-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 58547.596 | 58547.596 | 0.398226 / 25206784 | 0.386740 / 25206784 |
| quickfix-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 58476.884 | 58476.884 | 0.405900 / 25337856 | 0.400225 / 25337856 |
| quickfix-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 39307.715 | 39307.715 | 0.518161 / 25337856 | 0.474147 / 26050560 |
| quickfix-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 31322.417 | 31322.417 | 0.609216 / 25337856 | 0.526370 / 26030080 |
| quickfix-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 37183.626 | 37183.626 | 0.548583 / 25337856 | 0.489312 / 26329088 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805961 / 1910223 | 5505024 |
| native-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910223 / 4805961 | 5505024 |
| native-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805921 / 1910149 | 5505024 |
| native-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910149 / 4805921 | 5505024 |
| native-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805774 / 1910115 | 5505024 |
| native-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910115 / 4805774 | 5505024 |
| native-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805903 / 1910126 | 5505024 |
| native-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910126 / 4805903 | 5505024 |
| native-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805778 / 1910136 | 5505024 |
| native-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910136 / 4805778 | 5505024 |
| native-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805828 / 1910133 | 5505024 |
| native-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910133 / 4805828 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910180 | 5505024 |
| native-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910180 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910139 | 5505024 |
| native-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910139 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910176 | 5505024 |
| native-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910176 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910138 | 5505024 |
| native-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910138 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910103 | 5505024 |
| native-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910103 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910121 | 5505024 |
| native-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910121 / 4810790 | 1428169 |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805811 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805811 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806012 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4806012 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805897 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805897 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805942 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805942 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4806005 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4806005 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4805939 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4805939 | 5505024 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 1079094 / 1262534 / 1321461 / 1441341 / 1467424 | 1086669 / 1271378 / 1331673 / 1448565 / 1480387 | 0 / 0 / 0 / 0 / 0 | 1079094 / 1262534 / 1321461 / 1441341 / 1467424 | 1086669 / 1271378 / 1331673 / 1448565 / 1480387 | 5505024 | 28569301.307 |
| native-native/scalar/tcp/2 / 1 | 1145515 / 1371565 / 1422836 / 1494272 / 1527376 | 1154131 / 1382540 / 1433009 / 1506353 / 1528816 | 0 / 0 / 0 / 0 / 0 | 1145515 / 1371565 / 1422836 / 1494272 / 1527376 | 1154131 / 1382540 / 1433009 / 1506353 / 1528816 | 5505024 | 27094553.474 |
| native-native/scalar/tcp/3 / 1 | 1199808 / 1383751 / 1491931 / 1724705 / 1777320 | 1208955 / 1394258 / 1504269 / 1730071 / 1778917 | 0 / 0 / 0 / 0 / 0 | 1199808 / 1383751 / 1491931 / 1724705 / 1777320 | 1208955 / 1394258 / 1504269 / 1730071 / 1778917 | 5505024 | 27358859.480 |
| native-native/scalar/tls/1 / 1 | 1223924 / 1369745 / 1427509 / 1510654 / 1527349 | 1232875 / 1380573 / 1441070 / 1523244 / 1543634 | 0 / 0 / 0 / 0 / 0 | 1223924 / 1369745 / 1427509 / 1510654 / 1527349 | 1232875 / 1380573 / 1441070 / 1523244 / 1543634 | 5505024 | 26005647.725 |
| native-native/scalar/tls/2 / 1 | 1222404 / 1354442 / 1410554 / 1440483 / 1457715 | 1231922 / 1363016 / 1419802 / 1452931 / 1466055 | 0 / 0 / 0 / 0 / 0 | 1222404 / 1354442 / 1410554 / 1440483 / 1457715 | 1231922 / 1363016 / 1419802 / 1452931 / 1466055 | 5505024 | 26169909.794 |
| native-native/scalar/tls/3 / 1 | 1320293 / 1438094 / 1544400 / 1604152 / 1635944 | 1330483 / 1448941 / 1554094 / 1612923 / 1645422 | 0 / 0 / 0 / 0 / 0 | 1320293 / 1438094 / 1544400 / 1604152 / 1635944 | 1330483 / 1448941 / 1554094 / 1612923 / 1645422 | 5505024 | 24211899.363 |
| native-quickfix/scalar/tcp/1 / 1 | 1194895 / 1513288 / 1563165 / 1607575 / 1620986 | 1203332 / 1525242 / 1575385 / 1621171 / 1633454 | 0 / 0 / 0 / 0 / 0 | 1194895 / 1513288 / 1563165 / 1607575 / 1620986 | 1203332 / 1525242 / 1575385 / 1621171 / 1633454 | 5505024 | 7403357.103 |
| native-quickfix/scalar/tcp/2 / 1 | 1171526 / 1248872 / 1308065 / 1419618 / 1460378 | 1179965 / 1258381 / 1319234 / 1429120 / 1463018 | 0 / 0 / 0 / 0 / 0 | 1171526 / 1248872 / 1308065 / 1419618 / 1460378 | 1179965 / 1258381 / 1319234 / 1429120 / 1463018 | 5505024 | 7339899.326 |
| native-quickfix/scalar/tcp/3 / 1 | 1189762 / 1495973 / 1591998 / 1785817 / 1808264 | 1198507 / 1508453 / 1604482 / 1794841 / 1809898 | 0 / 0 / 0 / 0 / 0 | 1189762 / 1495973 / 1591998 / 1785817 / 1808264 | 1198507 / 1508453 / 1604482 / 1794841 / 1809898 | 5505024 | 7348003.724 |
| native-quickfix/scalar/tls/1 / 1 | 1581212 / 1896353 / 1948108 / 1973259 / 1982795 | 1592620 / 1909012 / 1959105 / 1985172 / 1998395 | 0 / 0 / 0 / 0 / 0 | 1581212 / 1896353 / 1948108 / 1973259 / 1982795 | 1592620 / 1909012 / 1959105 / 1985172 / 1998395 | 5505024 | 17936533.848 |
| native-quickfix/scalar/tls/2 / 1 | 1517142 / 1898038 / 1945033 / 1978116 / 2005560 | 1528618 / 1910922 / 1955587 / 1991998 / 2008734 | 0 / 0 / 0 / 0 / 0 | 1517142 / 1898038 / 1945033 / 1978116 / 2005560 | 1528618 / 1910922 / 1955587 / 1991998 / 2008734 | 5505024 | 18136654.294 |
| native-quickfix/scalar/tls/3 / 1 | 1816589 / 1992092 / 2065822 / 2114679 / 2129775 | 1830618 / 2006945 / 2079015 / 2131020 / 2158667 | 0 / 0 / 0 / 0 / 0 | 1816589 / 1992092 / 2065822 / 2114679 / 2129775 | 1830618 / 2006945 / 2079015 / 2131020 / 2158667 | 5505024 | 16661201.935 |
| quickfix-native/scalar/tcp/1 / 1 | 1007716 / 1135424 / 1238706 / 1347972 / 1362092 | 1013561 / 1141852 / 1244815 / 1355345 / 1363390 | 0 / 0 / 0 / 0 / 0 | 1007716 / 1135424 / 1238706 / 1347972 / 1362092 | 1013561 / 1141852 / 1244815 / 1355345 / 1363390 | 1238429 | 4111686.766 |
| quickfix-native/scalar/tcp/2 / 1 | 1042836 / 1419923 / 1491783 / 1548411 / 1575001 | 1048328 / 1429718 / 1503140 / 1558167 / 1586293 | 0 / 0 / 0 / 0 / 0 | 1042836 / 1419923 / 1491783 / 1548411 / 1575001 | 1048328 / 1429718 / 1503140 / 1558167 / 1586293 | 1238429 | 4262266.710 |
| quickfix-native/scalar/tcp/3 / 1 | 1058527 / 1491298 / 1599203 / 1796981 / 1814346 | 1064115 / 1502494 / 1599808 / 1804403 / 1816670 | 0 / 0 / 0 / 0 / 0 | 1058527 / 1491298 / 1599203 / 1796981 / 1814346 | 1064115 / 1502494 / 1599808 / 1804403 / 1816670 | 1238429 | 4272365.532 |
| quickfix-native/scalar/tls/1 / 1 | 1606083 / 1885880 / 1929038 / 1970142 / 2042834 | 1618912 / 1900646 / 1942656 / 1984900 / 2044247 | 0 / 0 / 0 / 0 / 0 | 1606083 / 1885880 / 1929038 / 1970142 / 2042834 | 1618912 / 1900646 / 1942656 / 1984900 / 2044247 | 1238429 | 4843551.189 |
| quickfix-native/scalar/tls/2 / 1 | 1873598 / 2179106 / 2247152 / 2348240 / 2361675 | 1887408 / 2197134 / 2265835 / 2365765 / 2379631 | 0 / 0 / 0 / 0 / 0 | 1873598 / 2179106 / 2247152 / 2348240 / 2361675 | 1887408 / 2197134 / 2265835 / 2365765 / 2379631 | 1238429 | 5051494.085 |
| quickfix-native/scalar/tls/3 / 1 | 1588042 / 1871356 / 1914612 / 1933874 / 1942292 | 1601084 / 1885049 / 1928095 / 1946986 / 1955548 | 0 / 0 / 0 / 0 / 0 | 1588042 / 1871356 / 1914612 / 1933874 / 1942292 | 1601084 / 1885049 / 1928095 / 1946986 / 1955548 | 1238429 | 7554144.784 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 1181417 / 1410309 / 1445250 / 1469772 / 1489061 | 1188979 / 1421213 / 1455183 / 1480742 / 1492452 | 0 / 0 / 0 / 0 / 0 | 1181417 / 1410309 / 1445250 / 1469772 / 1489061 | 1188979 / 1421213 / 1455183 / 1480742 / 1492452 | 1238429 | 4266867.403 |
| quickfix-quickfix/scalar/tcp/2 / 1 | 1055879 / 1304834 / 1359920 / 1387624 / 1391767 | 1062212 / 1314217 / 1369804 / 1395389 / 1401697 | 0 / 0 / 0 / 0 / 0 | 1055879 / 1304834 / 1359920 / 1387624 / 1391767 | 1062212 / 1314217 / 1369804 / 1395389 / 1401697 | 1238429 | 4186935.697 |
| quickfix-quickfix/scalar/tcp/3 / 1 | 1042223 / 1337957 / 1515458 / 1990982 / 2003398 | 1046607 / 1347724 / 1530484 / 1998809 / 2013318 | 0 / 0 / 0 / 0 / 0 | 1042223 / 1337957 / 1515458 / 1990982 / 2003398 | 1046607 / 1347724 / 1530484 / 1998809 / 2013318 | 1238429 | 4264916.261 |
| quickfix-quickfix/scalar/tls/1 / 1 | 1546573 / 2137207 / 2190314 / 2220171 / 2229454 | 1559418 / 2153928 / 2207044 / 2236132 / 2244927 | 0 / 0 / 0 / 0 / 0 | 1546573 / 2137207 / 2190314 / 2220171 / 2229454 | 1559418 / 2153928 / 2207044 / 2236132 / 2244927 | 1238429 | 4492209.976 |
| quickfix-quickfix/scalar/tls/2 / 1 | 2027822 / 2142732 / 2194783 / 2220380 / 2235786 | 2044512 / 2160480 / 2212101 / 2236021 / 2253074 | 0 / 0 / 0 / 0 / 0 | 2027822 / 2142732 / 2194783 / 2220380 / 2235786 | 2044512 / 2160480 / 2212101 / 2236021 / 2253074 | 1238429 | 4700445.763 |
| quickfix-quickfix/scalar/tls/3 / 1 | 1661645 / 1949136 / 2121322 / 2164030 / 2177709 | 1675028 / 1963510 / 2139289 / 2185296 / 2196266 | 0 / 0 / 0 / 0 / 0 | 1661645 / 1949136 / 2121322 / 2164030 / 2177709 | 1675028 / 1963510 / 2139289 / 2185296 / 2196266 | 1238429 | 4553395.333 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
