# FIX measured baseline

Build label: `release-thread-rerun-both-shared`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 3 | 57256.4 | 57256.4 | 1.441 | 1.451 |
| native-native / tcp / scalar | 4 | 3 | 64743.9 | 64791.7 | 5.412 | 5.438 |
| native-native / tls / scalar | 1 | 3 | 61601.6 | 61601.6 | 1.278 | 1.289 |
| native-native / tls / scalar | 4 | 3 | 62904.6 | 62957.9 | 4.882 | 4.919 |
| native-quickfix / tcp / scalar | 1 | 3 | 54573.0 | 54573.0 | 1.551 | 1.556 |
| native-quickfix / tcp / scalar | 4 | 3 | 54076.3 | 54159.0 | 6.325 | 6.333 |
| native-quickfix / tls / scalar | 1 | 3 | 39725.5 | 39725.5 | 2.022 | 2.037 |
| native-quickfix / tls / scalar | 4 | 3 | 47896.9 | 47915.5 | 6.958 | 6.972 |
| quickfix-native / tcp / scalar | 1 | 3 | 62624.2 | 62624.2 | 1.541 | 1.554 |
| quickfix-native / tcp / scalar | 4 | 3 | 59712.9 | 61903.7 | 6.407 | 6.421 |
| quickfix-native / tls / scalar | 1 | 3 | 38392.0 | 38392.0 | 2.257 | 2.274 |
| quickfix-native / tls / scalar | 4 | 3 | 50014.9 | 50240.9 | 6.892 | 6.937 |
| quickfix-quickfix / tcp / scalar | 1 | 3 | 54618.7 | 54618.7 | 1.608 | 1.619 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 61708.4 | 64377.4 | 5.459 | 5.467 |
| quickfix-quickfix / tls / scalar | 1 | 3 | 35891.1 | 35891.1 | 2.230 | 2.249 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 46446.9 | 46634.2 | 7.888 | 7.951 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 0.320 | 0.332 | 24.164 | 24.164 |
| native-native / tcp / scalar | 4 | 1.178 | 1.180 | 48.168 | 45.723 |
| native-native / tls / scalar | 1 | 0.296 | 0.331 | 27.227 | 24.957 |
| native-native / tls / scalar | 4 | 1.137 | 1.226 | 51.914 | 49.230 |
| native-quickfix / tcp / scalar | 1 | 0.335 | 0.393 | 24.164 | 24.164 |
| native-quickfix / tcp / scalar | 4 | 1.285 | 1.428 | 47.633 | 37.160 |
| native-quickfix / tls / scalar | 1 | 0.363 | 0.466 | 25.668 | 25.199 |
| native-quickfix / tls / scalar | 4 | 1.298 | 1.645 | 50.762 | 41.566 |
| quickfix-native / tcp / scalar | 1 | 0.389 | 0.329 | 24.164 | 24.164 |
| quickfix-native / tcp / scalar | 4 | 1.379 | 1.243 | 33.004 | 43.480 |
| quickfix-native / tls / scalar | 1 | 0.539 | 0.381 | 24.289 | 24.773 |
| quickfix-native / tls / scalar | 4 | 1.649 | 1.231 | 37.535 | 47.719 |
| quickfix-quickfix / tcp / scalar | 1 | 0.421 | 0.396 | 24.289 | 24.289 |
| quickfix-quickfix / tcp / scalar | 4 | 1.339 | 1.306 | 33.004 | 36.848 |
| quickfix-quickfix / tls / scalar | 1 | 0.562 | 0.490 | 24.289 | 25.207 |
| quickfix-quickfix / tls / scalar | 4 | 1.772 | 1.559 | 37.965 | 40.992 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 1 / 1 | 3 | 57256.4 | 1105012 | 1440977 | 1450933 | 1450933 | 1813667 |
| native-native / tcp / scalar / 4 / 1 | 3 | 16196.1 | 3820604 | 5410696 | 5432791 | 5432791 | 6790989 |
| native-native / tcp / scalar / 4 / 2 | 3 | 16195.8 | 3820452 | 5411588 | 5436694 | 5436694 | 6795868 |
| native-native / tcp / scalar / 4 / 3 | 3 | 16198.6 | 3821015 | 5394582 | 5437667 | 5437667 | 6797084 |
| native-native / tcp / scalar / 4 / 4 | 3 | 16200.9 | 3821070 | 5406765 | 5437903 | 5437903 | 6797379 |
| native-native / tls / scalar / 1 / 1 | 3 | 61601.6 | 1045091 | 1277930 | 1289227 | 1289227 | 1611534 |
| native-native / tls / scalar / 4 / 1 | 3 | 15745.3 | 3990884 | 4875222 | 4912619 | 4912619 | 6140774 |
| native-native / tls / scalar / 4 / 2 | 3 | 15740.9 | 3992451 | 4882038 | 4913340 | 4913340 | 6141675 |
| native-native / tls / scalar / 4 / 3 | 3 | 15733.8 | 3993530 | 4873100 | 4918583 | 4918583 | 6148229 |
| native-native / tls / scalar / 4 / 4 | 3 | 15737.8 | 3992759 | 4877336 | 4915650 | 4915650 | 6144563 |
| native-quickfix / tcp / scalar / 1 / 1 | 3 | 54573.0 | 1144239 | 1551397 | 1556289 | 1556289 | 1945362 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 13553.7 | 4571253 | 6306644 | 6314437 | 6314437 | 7893047 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 13534.4 | 4572996 | 6290876 | 6300275 | 6300275 | 7875344 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 13535.7 | 4571160 | 6322346 | 6329826 | 6329826 | 7912283 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 13535.2 | 4572680 | 6325227 | 6333114 | 6333114 | 7916393 |
| native-quickfix / tls / scalar / 1 / 1 | 3 | 39725.5 | 1537310 | 2022373 | 2036885 | 2036885 | 2546107 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 11978.2 | 5070601 | 6957777 | 6972154 | 6972154 | 8715193 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 11978.9 | 5071663 | 6953171 | 6967746 | 6967746 | 8709683 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 11979.0 | 5070670 | 6953323 | 6967778 | 6967778 | 8709723 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 11979.5 | 5071387 | 6954909 | 6969502 | 6969502 | 8711878 |
| quickfix-native / tcp / scalar / 1 / 1 | 3 | 62624.2 | 976364 | 1541106 | 1553617 | 1553617 | 1942022 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 16651.6 | 3581225 | 6061882 | 6112370 | 6112370 | 7640463 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 15074.6 | 4333125 | 6407243 | 6421193 | 6421193 | 8026492 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 15085.0 | 4330336 | 6392396 | 6406353 | 6406353 | 8007942 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 15092.5 | 4330830 | 6386255 | 6397872 | 6397872 | 7997340 |
| quickfix-native / tls / scalar / 1 / 1 | 3 | 38392.0 | 1602412 | 2257214 | 2274181 | 2274181 | 2842727 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 12534.7 | 4977465 | 6892110 | 6936945 | 6936945 | 8671182 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 12554.3 | 4975567 | 6871993 | 6931856 | 6931856 | 8664820 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 12567.8 | 4981691 | 6865909 | 6923154 | 6923154 | 8653943 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 12584.1 | 4980664 | 6863206 | 6917157 | 6917157 | 8646447 |
| quickfix-quickfix / tcp / scalar / 1 / 1 | 3 | 54618.7 | 1092113 | 1607537 | 1619227 | 1619227 | 2024034 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 17341.2 | 3459804 | 5440641 | 5450856 | 5450856 | 6813570 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 15680.7 | 4250258 | 5457214 | 5466794 | 5466794 | 6833493 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 15670.6 | 4248566 | 5452118 | 5462139 | 5462139 | 6827674 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 15684.9 | 4248596 | 5458592 | 5466917 | 5466917 | 6833647 |
| quickfix-quickfix / tls / scalar / 1 / 1 | 3 | 35891.1 | 1766796 | 2229744 | 2248618 | 2248618 | 2810773 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 11639.7 | 4978771 | 7876631 | 7938228 | 7938228 | 9922785 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 11648.8 | 4976343 | 7877535 | 7940908 | 7940908 | 9926135 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 11666.3 | 4980309 | 7888282 | 7944741 | 7944741 | 9930927 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 11679.4 | 4977313 | 7886655 | 7951118 | 7951118 | 9938898 |

Raw artifacts: `/tmp/zfix-thread-rerun-20261031/both-shared-s1`, `/tmp/zfix-thread-rerun-20261031/both-shared-s4`.
