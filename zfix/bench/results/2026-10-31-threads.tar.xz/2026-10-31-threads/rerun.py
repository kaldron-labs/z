import hashlib
import json
import pathlib
import shutil
import subprocess

repo = pathlib.Path('/home/ubuntu/src/z')
root = pathlib.Path('/tmp/zfix-thread-rerun-20261031')
root.mkdir()
src = repo / 'zfix/util/load_native.cc'
original = src.read_text()
assert original.count('s.nThreads(4)') == 2
assert 'typename Net::ServerParams params{&mx, "3", "4"};' in original
assert 'typename Net::ClientParams params{&mx, "3", "4"};' in original
split = '''s.nThreads(4)
      .thread(1, [](auto &t) { t.isolated(1); }).thread(2, [](auto &t) { t.isolated(1); })
      .thread(3, [](auto &t) { t.isolated(1); }).thread(4, [](auto &t) { t.isolated(1); });'''
shared = '''s.nThreads(2)
      .thread(1, [](auto &t) { t.isolated(1); }).thread(2, [](auto &t) { t.isolated(1); });'''
assert original.count(split) == 2
server = original.replace(split, shared, 1).replace(
    'typename Net::ServerParams params{&mx, "3", "4"};',
    'typename Net::ServerParams params{&mx};')
both = server.replace(split, shared, 1).replace(
    'typename Net::ClientParams params{&mx, "3", "4"};',
    'typename Net::ClientParams params{&mx};')
configs = {'separate': original, 'acceptor-shared': server, 'both-shared': both}
dictionary = '/tmp/zfix-qf-release/quickfix-2ce8a60667d95a55cdc57a210f165e19cb757126/spec/FIX44.xml'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def run(argv, log):
    with (root / log).open('w') as out:
        subprocess.run(argv, cwd=repo, stdout=out, stderr=subprocess.STDOUT, check=True)

run(['make', '-C', 'zfix/util', '-j8'], 'initial-build.log')
backups = root / 'restore'
paths = ['load_native.cc', 'libZfixLoadNative.la', 'libZfixLoadNative_la-load_native.lo',
         '.deps/libZfixLoadNative_la-load_native.Plo',
         '.libs/libZfixLoadNative_la-load_native.o', '.libs/libZfixLoadNative.a',
         'zfix', 'zfixd', '.libs/zfix', '.libs/zfixd']
for name in paths:
    target = backups / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo / 'zfix/util' / name, target)
verification = {}
try:
    for label, text in configs.items():
        if label != 'separate':
            src.write_text(text)
            run(['make', '-C', 'zfix/util', '-j8'], label + '-build.log')
        (root / (label + '-load_native.cc')).write_text(text)
        print(json.dumps({'event': 'configuration', 'name': label}), flush=True)
        for sessions in [1, 4]:
            name = f'{label}-s{sessions}'
            run(['python3', 'zfix/bench/load.py', '--dictionary', dictionary,
                 '--artifacts', str(root / name), '--count', '10000', '--warmup', '1000',
                 '--sessions', str(sessions), '--inflight', '64', '--repeat', '3',
                 '--profile', 'scalar', '--build-label', 'release-thread-rerun-' + label],
                name + '.log')
            print(json.dumps({'event': 'matrix-complete', 'name': name}), flush=True)
        run(['python3', 'zfix/bench/results.py', str(root / (label + '-s1')),
             str(root / (label + '-s4')), '--output', str(root / (label + '.md'))],
            label + '-reducer.log')
        manifest = json.loads((root / (label + '-s4') / 'manifest.json').read_text())
        assert '-fsanitize' not in manifest['buildFlags']['CXXFLAGS']
        for entry in manifest['programs'].values():
            assert sha(pathlib.Path(entry['elf'])) == entry['elfSha256']
            assert sha(pathlib.Path(entry['path'])) == entry['wrapperSha256']
        for entry in manifest['linkedLibraries'].values():
            assert sha(pathlib.Path(entry['resolvedPath'])) == entry['sha256']
        for path, digest in manifest['sourceFiles'].items():
            assert sha(repo / path) == digest, path
        binaries = {entry['elf'] for entry in manifest['programs'].values()}
        binaries.update(entry['resolvedPath'] for entry in manifest['linkedLibraries'].values())
        for binary in binaries:
            for mode in ['-a', '-D']:
                symbols = subprocess.run(['nm', mode, binary], capture_output=True).stdout
                assert b'__asan_' not in symbols and b'__lsan_' not in symbols, binary
        verification[label] = {'sourceAndExecutableAndLibraryHashes': 'passed',
                               'sanitizerReferences': 0}
        (root / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
finally:
    if src.read_text() not in configs.values():
        raise RuntimeError('Unexpected source edit; originals retained in restore/, not overwriting')
    for name in paths:
        shutil.copy2(backups / name, repo / 'zfix/util' / name)
    assert all(sha(backups / name) == sha(repo / 'zfix/util' / name) for name in paths)
    print(json.dumps({'event': 'restored', 'originalSourceAndBuild': True}), flush=True)
