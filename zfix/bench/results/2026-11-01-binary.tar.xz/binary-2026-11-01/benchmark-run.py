import hashlib,json,os,pathlib,subprocess,tempfile,time
repo=pathlib.Path('/home/ubuntu/src/z')
out=pathlib.Path(tempfile.mkdtemp(prefix='zfix-binary-bench-'))
cpu=min(os.sched_getaffinity(0));manifest={'cpu':cpu,'affinity':sorted(os.sched_getaffinity(0)),'commands':[],'sha256':{},'observerCompile':'clang++ -std=gnu++2b -march=x86-64-v2 -O3 -g -DNDEBUG -DZ_VMAJOR=10 -DZ_VMINOR=0 -DZ_VPATCH=0 -fPIC -shared -fno-builtin -Wall -Wextra -isystem ../../zu/src heaptrace.cc -ldl -o heaptrace.so'}
for p in ['zfix/bench/.libs/nativecodec','zfix/bench/.libs/binarycodec','zfix/bench/.libs/txbodycodec','zfix/bench/heaptrace.so','zfix/src/.libs/libZfix.so','zfix/src/.libs/libZfixFmt.so','zfix/bench/binarycodec.cc','zfix/bench/txbodycodec.cc','zfix/bench/nativecodec.cc','zfix/src/ZfixFmt.hh','zfix/src/ZfixFmt.cc','zfix/src/ZfixTxMsg.hh','zfix/src/ZfixTxMsg.cc']:
 manifest['sha256'][p]=hashlib.sha256((repo/p).read_bytes()).hexdigest()
manifest['compiler']=subprocess.check_output(['clang++','--version'],text=True)
manifest['uname']=list(os.uname())
manifest['cpuinfo']=pathlib.Path('/proc/cpuinfo').read_text().split('\n\n')[cpu]
manifest['LD_LIBRARY_PATH']=os.environ.get('LD_LIBRARY_PATH','')
(out/'prior-ordinary.jsonl').write_bytes(pathlib.Path('/tmp/zfix-binary-text-codec.jsonl').read_bytes())
(out/'configured-flags.json').write_bytes(pathlib.Path('/tmp/zfix-binary-postquickfix-flags.json').read_bytes())
def run(name,args,observer=False):
 cmd=['taskset','-c',str(cpu),*args];env=os.environ.copy();log=out/(name+'.jsonl')
 if observer:
  env['LD_PRELOAD']=str(repo/'zfix/bench/heaptrace.so');env['ZFIX_HEAPTRACE_FILE']=str(out/(name+'.heap.json'))
 manifest['commands'].append({'name':name,'command':cmd,'observer':observer})
 p=subprocess.run(cmd,cwd=repo,env=env,text=True,capture_output=True)
 log.write_text(p.stdout);(out/(name+'.stderr')).write_text(p.stderr)
 manifest['commands'][-1]['returncode']=p.returncode
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 if p.returncode:raise RuntimeError((name,p.returncode,p.stderr))
 if observer:json.loads((out/(name+'.heap.json')).read_text())
 return [json.loads(s) for s in p.stdout.splitlines() if s]
for rep in range(3):
 run(f'ordinary-{rep}',['zfix/bench/nativecodec','10000','1000'])
 for size in [0,32,4096,65536]:run(f'binary-{size}-{rep}',['zfix/bench/binarycodec','10000','1000',str(size)])
for size in range(768,1025,16):run(f'txbody-{size}',['zfix/bench/txbodycodec','10000','1000',str(size)])
# Discover each actual capacity transition, then measure both neighbouring sizes.
for mode in ['dense','sparse']:
 rows=[]
 for size in range(768,1025,16):
  rows.extend(x for x in map(json.loads,(out/f'txbody-{size}.jsonl').read_text().splitlines()) if x['mode']==mode)
 for lo,hi in zip(rows,rows[1:]):
  if lo['poolBytes']==hi['poolBytes']:continue
  a,b=lo['payloadBytes'],hi['payloadBytes'];cap=lo['poolBytes']
  while b-a>1:
   m=(a+b)//2;r=run(f'threshold-{mode}-{m}',['zfix/bench/txbodycodec','10000','1000',str(m),mode])[0]
   if r['poolBytes']==cap:a=m
   else:b=m
  for size in [a,b]:
   for rep in range(3):run(f'boundary-{mode}-{size}-{rep}',['zfix/bench/txbodycodec','10000','1000',str(size),mode])
print(out,flush=True)
# Diagnostics are intentionally after all uninstrumented timing.
for mode in ['text-live','text-indexed','string-live','string-indexed','bytes-live','bytes-indexed']:
 for size in [32,4096,65536]:
  for count in [1000,10000]:
   for phase in ['encode','decode']:
    run(f'heap-{mode}-{size}-{count}-{phase}',['zfix/bench/binarycodec',str(count),'1000',str(size),mode,phase],True)
for mode in ['dense','sparse']:
 for size in [800,832,928,960]:
  for count in [1000,10000]:run(f'heap-txbody-{mode}-{size}-{count}',['zfix/bench/txbodycodec',str(count),'1000',str(size),mode],True)
print('complete',out,flush=True)
