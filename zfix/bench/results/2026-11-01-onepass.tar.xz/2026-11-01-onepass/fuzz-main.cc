#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
extern "C" int LLVMFuzzerTestOneInput(const uint8_t *, size_t);
int main(int argc, char **argv) {
  unsigned runs = 0;
  uint32_t state = 1;
  for (int a = 1; a < argc; ++a) {
    auto f = fopen(argv[a], "rb"); if (!f) return 2;
    fseek(f, 0, SEEK_END); auto n = ftell(f); rewind(f);
    if (n < 0 || n > 4096) return 2;
    auto p = static_cast<uint8_t *>(malloc(n + 1));
    if (fread(p, 1, n, f) != unsigned(n)) return 2;
    fclose(f);
    for (unsigned k = 0; k <= unsigned(n); ++k) {
      LLVMFuzzerTestOneInput(p, k); ++runs;
    }
    for (unsigned k = 0; n && k < 256; ++k) {
      state = state * 1664525U + 1013904223U;
      unsigned j = state % n; auto old = p[j];
      p[j] ^= 1U << ((state >> 16) & 7);
      LLVMFuzzerTestOneInput(p, n); ++runs; p[j] = old;
    }
    free(p);
  }
  printf("{\"cases\":%u,\"seed\":1}\n", runs);
}
