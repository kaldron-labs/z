# FIX measured baseline

Build label: `release-one-pass-static-tags-text-only`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 3 | 83361.6 | 84042.1 | 3.734 | 3.735 |
| native-native / tls / scalar | 4 | 3 | 76393.3 | 76561.4 | 4.222 | 4.228 |
| native-quickfix / tcp / scalar | 4 | 3 | 47907.7 | 47984.2 | 6.142 | 6.158 |
| native-quickfix / tls / scalar | 4 | 3 | 47054.6 | 47075.9 | 6.758 | 6.774 |
| quickfix-native / tcp / scalar | 4 | 3 | 60738.0 | 63229.2 | 5.566 | 5.576 |
| quickfix-native / tls / scalar | 4 | 3 | 42509.2 | 42678.3 | 7.015 | 7.067 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 58570.5 | 60312.6 | 5.451 | 5.462 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 49967.8 | 50223.0 | 6.905 | 6.959 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 1.509 | 1.557 | 42.793 | 49.328 |
| native-native / tls / scalar | 4 | 1.689 | 1.733 | 49.977 | 63.387 |
| native-quickfix / tcp / scalar | 4 | 1.981 | 1.567 | 40.031 | 37.051 |
| native-quickfix / tls / scalar | 4 | 2.105 | 1.663 | 45.320 | 41.184 |
| quickfix-native / tcp / scalar | 4 | 1.364 | 1.766 | 32.766 | 45.805 |
| quickfix-native / tls / scalar | 4 | 1.829 | 2.067 | 37.719 | 54.246 |
| quickfix-quickfix / tcp / scalar | 4 | 1.380 | 1.344 | 32.762 | 37.035 |
| quickfix-quickfix / tls / scalar | 4 | 1.606 | 1.490 | 37.855 | 40.926 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 4 / 1 | 3 | 21019.0 | 3044014 | 3665525 | 3672625 | 3672625 | 4590782 |
| native-native / tcp / scalar / 4 / 2 | 3 | 21001.5 | 3041464 | 3640733 | 3648841 | 3648841 | 4561052 |
| native-native / tcp / scalar / 4 / 3 | 3 | 20996.2 | 3044450 | 3733912 | 3735483 | 3735483 | 4669354 |
| native-native / tcp / scalar / 4 / 4 | 3 | 21025.5 | 3043014 | 3683447 | 3688929 | 3688929 | 4611162 |
| native-native / tls / scalar / 4 / 1 | 3 | 19171.9 | 3329910 | 4019683 | 4032855 | 4032855 | 5041069 |
| native-native / tls / scalar / 4 / 2 | 3 | 19134.9 | 3330242 | 4001761 | 4012095 | 4012095 | 5015119 |
| native-native / tls / scalar / 4 / 3 | 3 | 19126.4 | 3330654 | 4221937 | 4228312 | 4228312 | 5285390 |
| native-native / tls / scalar / 4 / 4 | 3 | 19128.1 | 3331210 | 4054762 | 4080047 | 4080047 | 5100059 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 11990.3 | 5482840 | 6105121 | 6116602 | 6116602 | 7645753 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 11992.1 | 5476041 | 6142472 | 6157695 | 6157695 | 7697119 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 11999.4 | 5471548 | 6066431 | 6080095 | 6080095 | 7600119 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 12002.4 | 5480102 | 6077423 | 6089921 | 6089921 | 7612402 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 11771.3 | 4934318 | 6753558 | 6768207 | 6768207 | 8460259 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 11768.9 | 4932504 | 6757546 | 6773761 | 6773761 | 8467202 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 11767.7 | 4933972 | 6756820 | 6773081 | 6773081 | 8466352 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 11768.0 | 4934895 | 6753586 | 6771509 | 6771509 | 8464387 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 16935.0 | 3481596 | 5327920 | 5338461 | 5338461 | 6673077 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 15432.5 | 4175621 | 5549679 | 5560611 | 5560611 | 6950764 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 15427.2 | 4166961 | 5556534 | 5565814 | 5565814 | 6957268 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 15434.4 | 4177500 | 5566364 | 5575932 | 5575932 | 6969915 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 10651.3 | 6307622 | 7005952 | 7065917 | 7065917 | 8832397 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 10656.5 | 6308010 | 7015217 | 7066409 | 7066409 | 8833012 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 10677.3 | 6308968 | 7011408 | 7067150 | 7067150 | 8833938 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 10693.1 | 6306372 | 7014923 | 7066076 | 7066076 | 8832595 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 15727.6 | 3965433 | 5436047 | 5444684 | 5444684 | 6805855 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 14846.5 | 4107181 | 5413987 | 5423594 | 5423594 | 6779493 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 14867.7 | 4104463 | 5450767 | 5462268 | 5462268 | 6827835 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 14870.7 | 4102563 | 5380146 | 5389175 | 5389175 | 6736469 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 12559.6 | 4886042 | 6904433 | 6954942 | 6954942 | 8693678 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 12558.2 | 4889238 | 6904975 | 6954043 | 6954043 | 8692554 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 12553.4 | 4888714 | 6898980 | 6956098 | 6956098 | 8695123 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 12551.9 | 4886489 | 6903773 | 6959182 | 6959182 | 8698978 |

Raw artifacts: `/tmp/zfix-tag-dispatch-20261101/process-after`.
