# FIX measured baseline

Build label: `release-before-static-tag-dispatch`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 3 | 84246.5 | 84737.2 | 3.776 | 3.784 |
| native-native / tls / scalar | 4 | 3 | 76892.9 | 77007.3 | 3.913 | 3.943 |
| native-quickfix / tcp / scalar | 4 | 3 | 48918.2 | 49012.0 | 6.234 | 6.245 |
| native-quickfix / tls / scalar | 4 | 3 | 43027.1 | 43057.5 | 6.671 | 6.688 |
| quickfix-native / tcp / scalar | 4 | 3 | 54567.3 | 57022.0 | 5.663 | 5.681 |
| quickfix-native / tls / scalar | 4 | 3 | 44956.5 | 45180.3 | 6.834 | 6.885 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 64413.2 | 67253.9 | 5.332 | 5.342 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 51568.0 | 51745.9 | 6.843 | 6.894 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 1.554 | 1.577 | 43.301 | 51.098 |
| native-native / tls / scalar | 4 | 1.703 | 1.742 | 49.168 | 63.051 |
| native-quickfix / tcp / scalar | 4 | 1.963 | 1.542 | 41.031 | 37.156 |
| native-quickfix / tls / scalar | 4 | 2.236 | 1.753 | 45.133 | 41.527 |
| quickfix-native / tcp / scalar | 4 | 1.481 | 1.871 | 32.984 | 44.691 |
| quickfix-native / tls / scalar | 4 | 1.762 | 2.020 | 37.523 | 54.332 |
| quickfix-quickfix / tcp / scalar | 4 | 1.303 | 1.270 | 33.051 | 36.758 |
| quickfix-quickfix / tls / scalar | 4 | 1.583 | 1.460 | 37.453 | 41.520 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 4 / 1 | 3 | 21179.9 | 2998866 | 3745658 | 3747868 | 3747868 | 4684835 |
| native-native / tcp / scalar / 4 / 2 | 3 | 21162.2 | 3008737 | 3719930 | 3722147 | 3722147 | 4652684 |
| native-native / tcp / scalar / 4 / 3 | 3 | 21210.1 | 2999573 | 3731765 | 3735982 | 3735982 | 4669978 |
| native-native / tcp / scalar / 4 / 4 | 3 | 21185.0 | 2997722 | 3776442 | 3784444 | 3784444 | 4730555 |
| native-native / tls / scalar / 4 / 1 | 3 | 19251.4 | 3333973 | 3891268 | 3926525 | 3926525 | 4908157 |
| native-native / tls / scalar / 4 / 2 | 3 | 19251.8 | 3341590 | 3839197 | 3864380 | 3864380 | 4830475 |
| native-native / tls / scalar / 4 / 3 | 3 | 19254.2 | 3335583 | 3862234 | 3898618 | 3898618 | 4873273 |
| native-native / tls / scalar / 4 / 4 | 3 | 19249.9 | 3341266 | 3912877 | 3942812 | 3942812 | 4928515 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 12240.2 | 5204896 | 6169403 | 6182337 | 6182337 | 7727922 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 12248.9 | 5170233 | 6140745 | 6151027 | 6151027 | 7688784 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 12258.4 | 5165250 | 6207464 | 6219700 | 6219700 | 7774625 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 12264.5 | 5221682 | 6233723 | 6244910 | 6244910 | 7806138 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 10770.5 | 6122562 | 6670520 | 6685695 | 6685695 | 8357119 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 10762.9 | 6122866 | 6671148 | 6687724 | 6687724 | 8359655 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 10762.1 | 6122526 | 6671260 | 6688107 | 6688107 | 8360134 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 10762.0 | 6123314 | 6670656 | 6688373 | 6688373 | 8360467 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 15342.0 | 4141986 | 5421268 | 5440319 | 5440319 | 6800399 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 13882.4 | 4454740 | 5662789 | 5680829 | 5680829 | 7101037 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 13896.8 | 4460528 | 5644462 | 5655535 | 5655535 | 7069419 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 13900.8 | 4458799 | 5649733 | 5661751 | 5661751 | 7077189 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 11273.6 | 5938491 | 6832528 | 6883606 | 6883606 | 8604508 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 11290.8 | 5943571 | 6830458 | 6884224 | 6884224 | 8605280 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 11302.5 | 5940444 | 6833870 | 6884850 | 6884850 | 8606063 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 11313.4 | 5938503 | 6828075 | 6884437 | 6884437 | 8605547 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 18047.8 | 3303342 | 5318880 | 5328273 | 5328273 | 6660342 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 16400.5 | 4079549 | 5331705 | 5342092 | 5342092 | 6677615 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 16408.2 | 4086485 | 5291781 | 5299732 | 5299732 | 6624665 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 16397.4 | 4087698 | 5284789 | 5293721 | 5293721 | 6617152 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 12930.9 | 4754997 | 6840657 | 6894343 | 6894343 | 8617929 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 12936.5 | 4752949 | 6843473 | 6893421 | 6893421 | 8616777 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 12937.5 | 4758961 | 6837615 | 6893029 | 6893029 | 8616287 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 12941.0 | 4759673 | 6836737 | 6893189 | 6893189 | 8616487 |

Raw artifacts: `/tmp/zfix-tag-dispatch-20261101/process-before`.
