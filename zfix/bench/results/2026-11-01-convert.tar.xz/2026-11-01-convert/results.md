# FIX measured baseline

Build label: `release-onepass-native-conversion-no-prevalidation`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 3 | 82618.3 | 82869.6 | 3.827 | 3.833 |
| native-native / tls / scalar | 4 | 3 | 74981.7 | 75102.0 | 3.926 | 3.950 |
| native-quickfix / tcp / scalar | 4 | 3 | 47819.0 | 47919.5 | 6.215 | 6.230 |
| native-quickfix / tls / scalar | 4 | 3 | 44483.4 | 44505.4 | 6.791 | 6.807 |
| quickfix-native / tcp / scalar | 4 | 3 | 55289.6 | 57604.6 | 5.743 | 5.753 |
| quickfix-native / tls / scalar | 4 | 3 | 45000.6 | 45196.2 | 6.984 | 7.036 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 61565.9 | 64045.3 | 6.007 | 6.017 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 47934.1 | 48045.7 | 6.643 | 6.667 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 1.536 | 1.589 | 43.141 | 50.355 |
| native-native / tls / scalar | 4 | 1.704 | 1.756 | 48.328 | 63.641 |
| native-quickfix / tcp / scalar | 4 | 1.995 | 1.601 | 39.797 | 36.840 |
| native-quickfix / tls / scalar | 4 | 2.168 | 1.746 | 45.094 | 41.031 |
| quickfix-native / tcp / scalar | 4 | 1.504 | 1.866 | 32.590 | 43.824 |
| quickfix-native / tls / scalar | 4 | 1.791 | 2.076 | 37.762 | 54.684 |
| quickfix-quickfix / tcp / scalar | 4 | 1.341 | 1.300 | 32.625 | 36.930 |
| quickfix-quickfix / tls / scalar | 4 | 1.672 | 1.499 | 38.309 | 41.699 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 4 / 1 | 3 | 20752.1 | 3074244 | 3796972 | 3803454 | 3803454 | 4754318 |
| native-native / tcp / scalar / 4 / 2 | 3 | 20687.2 | 3075098 | 3826971 | 3832605 | 3832605 | 4790757 |
| native-native / tcp / scalar / 4 / 3 | 3 | 20696.5 | 3075128 | 3782062 | 3789345 | 3789345 | 4736682 |
| native-native / tcp / scalar / 4 / 4 | 3 | 20733.8 | 3078187 | 3804334 | 3814689 | 3814689 | 4768362 |
| native-native / tls / scalar / 4 / 1 | 3 | 18798.6 | 3391517 | 3906565 | 3928225 | 3928225 | 4910282 |
| native-native / tls / scalar / 4 / 2 | 3 | 18774.7 | 3388806 | 3921161 | 3940067 | 3940067 | 4925084 |
| native-native / tls / scalar / 4 / 3 | 3 | 18762.4 | 3391611 | 3911611 | 3929801 | 3929801 | 4912252 |
| native-native / tls / scalar / 4 / 4 | 3 | 18766.2 | 3389242 | 3926008 | 3949764 | 3949764 | 4937205 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 11973.9 | 5504301 | 6206195 | 6219067 | 6219067 | 7773834 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 11977.6 | 5502304 | 6175108 | 6185546 | 6185546 | 7731933 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 11984.0 | 5465621 | 6190095 | 6201374 | 6201374 | 7751718 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 11983.9 | 5500374 | 6215333 | 6230354 | 6230354 | 7787943 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 11126.9 | 6118442 | 6790923 | 6804411 | 6804411 | 8505514 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 11126.8 | 6117955 | 6790731 | 6806671 | 6806671 | 8508339 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 11125.5 | 6118127 | 6791137 | 6804490 | 6804490 | 8505613 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 11126.1 | 6117538 | 6788429 | 6802200 | 6802200 | 8502750 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 15280.4 | 4046089 | 5518554 | 5532411 | 5532411 | 6915514 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 14105.2 | 4317050 | 5742979 | 5753417 | 5753417 | 7191772 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 14119.3 | 4308954 | 5737690 | 5748090 | 5748090 | 7185113 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 14131.5 | 4312005 | 5739911 | 5751347 | 5751347 | 7189184 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 11282.4 | 5819193 | 6981975 | 7035651 | 7035651 | 8794564 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 11292.8 | 5818645 | 6983894 | 7035733 | 7035733 | 8794667 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 11304.8 | 5814762 | 6976170 | 7034804 | 7034804 | 8793505 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 11316.3 | 5815405 | 6983050 | 7035094 | 7035094 | 8793868 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 17135.0 | 3706515 | 6007465 | 6016947 | 6016947 | 7521184 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 15640.3 | 4061674 | 5989168 | 5998940 | 5998940 | 7498675 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 15630.2 | 4064798 | 5994267 | 6002985 | 6002985 | 7503732 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 15639.9 | 4068839 | 6001888 | 6011555 | 6011555 | 7514444 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 12009.9 | 4931695 | 6642562 | 6666568 | 6666568 | 8333210 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 12013.1 | 4928107 | 6634200 | 6656084 | 6656084 | 8320105 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 12009.4 | 4928586 | 6631573 | 6654214 | 6654214 | 8317768 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 12013.3 | 4926955 | 6622675 | 6642533 | 6642533 | 8303167 |

## Standalone codec

Per-call encode includes typed body and full FIX framing; decode includes framing/checksum, typed construction and validation. QuickFIX also applies its canonical dictionary validation. Native reuses its output backing; QuickFIX constructs its SDK message and returns its SDK string. QuickFIX decode includes its input string and selected-field arena copies; Native decoded spans borrow input. These ownership costs are included. Clock-pair overhead is reported separately without subtraction.

| Engine / shape | Runs | Frame bytes | Encode p50 median ns | Encode p99 worst ns | Decode p50 median ns | Decode p99 worst ns | Clock p50 median ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix / groups | 3 | 910 | 13447 | 21669 | 12776 | 21241 | 22 |
| quickfix / scalar | 3 | 170 | 1564 | 2502 | 3368 | 4444 | 22 |
| zfix / groups | 3 | 910 | 3627 | 4875 | 2668 | 3774 | 22 |
| zfix / scalar | 3 | 170 | 728 | 891 | 318 | 400 | 22 |

Raw artifacts: `/tmp/zfix-unchecked-20261101/process`.
