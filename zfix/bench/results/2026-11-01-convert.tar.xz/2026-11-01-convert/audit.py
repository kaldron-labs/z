import hashlib, json, pathlib, shutil, subprocess
root = pathlib.Path(__file__).resolve().parent
repo = pathlib.Path('/home/ubuntu/src/z')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((root / 'process/manifest.json').read_text())
for path, digest in m['sourceFiles'].items():
    src = repo / path
    assert sha(src) == digest, path
    dst = root / 'source' / path
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)
before = json.loads(pathlib.Path('/tmp/zfix-loader-20261101/process/manifest.json').read_text())
for key in ['buildFlags', 'dictionarySha256', 'cpu', 'affinity']:
    assert m[key] == before[key], key
for path, entry in before['linkedLibraries'].items():
    if '/zfix/' not in path:
        assert entry['sha256'] == m['linkedLibraries'][path]['sha256'], path
elfs = set()
codecs = {}
for engine in ['native', 'quickfix']:
    path = repo / ('zfix/bench/.libs/' + engine + 'codec')
    codecs[engine] = {'elf': str(path), 'sha256': sha(path)}
    elfs.add(str(path))
(root / 'codec-programs.json').write_text(json.dumps(codecs, indent=2) + '\n')
for entry in m['programs'].values():
    assert sha(pathlib.Path(entry['elf'])) == entry['elfSha256']
    elfs.add(entry['elf'])
for entry in m['linkedLibraries'].values():
    assert sha(pathlib.Path(entry['resolvedPath'])) == entry['sha256']
    elfs.add(entry['resolvedPath'])
for path in elfs:
    for mode in ['-a', '-D']:
        result = subprocess.run(['nm', mode, path], capture_output=True)
        assert b'__asan_' not in result.stdout and b'__lsan_' not in result.stdout, path
summary = json.loads((root / 'process/summary.json').read_text())
assert summary['cases'] == 24 and summary['failed'] == 0
cases = list((root / 'process').glob('*/case.json'))
assert len(cases) == 24
orders = 0
for path in cases:
    case = json.loads(path.read_text())
    assert case['complete'] == 40000 and not any(case[k] for k in
      ['unfinished', 'errors', 'processErrors', 'timeouts']), path
    orders += case['complete']
assert orders == 960000
report = {'sourceFiles': len(m['sourceFiles']), 'checkedELFs': len(elfs),
          'cases': len(cases), 'orders': orders, 'noASan': True}
(root / 'audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
