	.file	"lookup.cc"
                                        # Start of file scope inline assembly
	.globl	_ZSt21ios_base_library_initv

                                        # End of file scope inline assembly
	.text
	.globl	orderTag                        # -- Begin function orderTag
	.p2align	4
	.type	orderTag,@function
orderTag:                               # @orderTag
	.cfi_startproc
# %bb.0:
                                        # kill: def $edi killed $edi def $rdi
	leal	(,%rdi,8), %edx
	subl	%edi, %edx
	andl	$63, %edx
	leaq	(%rdx,%rdx,2), %rsi
	leaq	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE(%rip), %rcx
	leaq	_ZZN10ZuNullRef_Ij5ZuCmpIjEjE4nullEvE4null(%rip), %rax
	testb	$4, 20(%rcx,%rsi,4)
	jne	.LBB0_1
.LBB0_6:
	movl	(%rax), %eax
	retq
.LBB0_1:
	movl	%edx, %edx
	leaq	(%rdx,%rdx,2), %rsi
	cmpl	%edi, 12(%rcx,%rsi,4)
	je	.LBB0_3
	.p2align	4
.LBB0_5:                                # =>This Inner Loop Header: Depth=1
	leaq	(%rdx,%rdx,2), %rdx
	movl	20(%rcx,%rdx,4), %edx
	testb	$2, %dl
	jne	.LBB0_6
# %bb.4:                                #   in Loop: Header=BB0_5 Depth=1
	shrl	$3, %edx
	leaq	(%rdx,%rdx,2), %rsi
	cmpl	%edi, 12(%rcx,%rsi,4)
	jne	.LBB0_5
.LBB0_3:
	leaq	(%rdx,%rdx,2), %rax
	leaq	(%rcx,%rax,4), %rax
	addq	$16, %rax
	movl	(%rax), %eax
	retq
.Lfunc_end0:
	.size	orderTag, .Lfunc_end0-orderTag
	.cfi_endproc
                                        # -- End function
	.globl	reportTag                       # -- Begin function reportTag
	.p2align	4
	.type	reportTag,@function
reportTag:                              # @reportTag
	.cfi_startproc
# %bb.0:
	imull	$71, %edi, %edx
	andl	$127, %edx
	leaq	(%rdx,%rdx,2), %rsi
	leaq	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE(%rip), %rcx
	leaq	_ZZN10ZuNullRef_Ij5ZuCmpIjEjE4nullEvE4null(%rip), %rax
	testb	$4, 20(%rcx,%rsi,4)
	jne	.LBB1_1
.LBB1_6:
	movl	(%rax), %eax
	retq
.LBB1_1:
	movl	%edx, %edx
	leaq	(%rdx,%rdx,2), %rsi
	cmpl	%edi, 12(%rcx,%rsi,4)
	je	.LBB1_3
	.p2align	4
.LBB1_5:                                # =>This Inner Loop Header: Depth=1
	leaq	(%rdx,%rdx,2), %rdx
	movl	20(%rcx,%rdx,4), %edx
	testb	$2, %dl
	jne	.LBB1_6
# %bb.4:                                #   in Loop: Header=BB1_5 Depth=1
	shrl	$3, %edx
	leaq	(%rdx,%rdx,2), %rsi
	cmpl	%edi, 12(%rcx,%rsi,4)
	jne	.LBB1_5
.LBB1_3:
	leaq	(%rdx,%rdx,2), %rax
	leaq	(%rcx,%rax,4), %rax
	addq	$16, %rax
	movl	(%rax), %eax
	retq
.Lfunc_end1:
	.size	reportTag, .Lfunc_end1-reportTag
	.cfi_endproc
                                        # -- End function
	.globl	messageType                     # -- Begin function messageType
	.p2align	4
	.type	messageType,@function
messageType:                            # @messageType
	.cfi_startproc
# %bb.0:
	movl	$-1, %eax
	cmpl	$1, %esi
	jne	.LBB2_7
# %bb.1:
	movzbl	(%rdi), %ecx
	addl	$-56, %ecx
	cmpl	$15, %ecx
	ja	.LBB2_7
# %bb.2:
	leaq	.LJTI2_0(%rip), %rdx
	movslq	(%rdx,%rcx,4), %rcx
	addq	%rdx, %rcx
	jmpq	*%rcx
.LBB2_4:
	movl	$1, %eax
	retq
.LBB2_5:
	movl	$3, %eax
	retq
.LBB2_3:
	xorl	%eax, %eax
	retq
.LBB2_6:
	movl	$4, %eax
.LBB2_7:
	retq
.Lfunc_end2:
	.size	messageType, .Lfunc_end2-messageType
	.cfi_endproc
	.section	.rodata,"a",@progbits
	.p2align	2, 0x0
.LJTI2_0:
	.long	.LBB2_4-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_3-.LJTI2_0
	.long	.LBB2_7-.LJTI2_0
	.long	.LBB2_5-.LJTI2_0
	.long	.LBB2_6-.LJTI2_0
                                        # -- End function
	.section	.text.startup,"axG",@progbits,_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE,comdat
	.p2align	4                               # -- Begin function __cxx_global_var_init
	.type	__cxx_global_var_init,@function
__cxx_global_var_init:                  # @__cxx_global_var_init
	.cfi_startproc
# %bb.0:
	cmpb	$0, _ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE(%rip)
	je	.LBB3_2
# %bb.1:
	retq
.LBB3_2:
	movb	$1, _ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE(%rip)
	leaq	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE(%rip), %rdi
	jmp	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE8TagIndexC2Ev # TAILCALL
.Lfunc_end3:
	.size	__cxx_global_var_init, .Lfunc_end3-__cxx_global_var_init
	.cfi_endproc
                                        # -- End function
	.section	.text._ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE8TagIndexC2Ev,"axG",@progbits,_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE8TagIndexC2Ev,comdat
	.weak	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE8TagIndexC2Ev # -- Begin function _ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE8TagIndexC2Ev
	.p2align	4
	.type	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE8TagIndexC2Ev,@function
_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE8TagIndexC2Ev: # @_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE8TagIndexC2Ev
	.cfi_startproc
# %bb.0:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$32, %rsp
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	addq	$8, %rdi
	movl	$768, %edx                      # imm = 0x300
	xorl	%esi, %esi
	callq	memset@PLT
	movl	$0, (%rbx)
	movl	$0, 4(%rbx)
	movl	$0, 20(%rbx)
	movl	$0, 32(%rbx)
	movl	$0, 44(%rbx)
	movl	$0, 56(%rbx)
	movl	$0, 68(%rbx)
	movl	$0, 80(%rbx)
	movl	$0, 92(%rbx)
	movl	$0, 104(%rbx)
	movl	$0, 116(%rbx)
	movl	$0, 128(%rbx)
	movl	$0, 140(%rbx)
	movl	$0, 152(%rbx)
	movl	$0, 164(%rbx)
	movl	$0, 176(%rbx)
	movl	$0, 188(%rbx)
	movl	$0, 200(%rbx)
	movl	$0, 212(%rbx)
	movl	$0, 224(%rbx)
	movl	$0, 236(%rbx)
	movl	$0, 248(%rbx)
	movl	$0, 260(%rbx)
	movl	$0, 272(%rbx)
	movl	$0, 284(%rbx)
	movl	$0, 296(%rbx)
	movl	$0, 308(%rbx)
	movl	$0, 320(%rbx)
	movl	$0, 332(%rbx)
	movl	$0, 344(%rbx)
	movl	$0, 356(%rbx)
	movl	$0, 368(%rbx)
	movl	$0, 380(%rbx)
	movl	$0, 392(%rbx)
	movl	$0, 404(%rbx)
	movl	$0, 416(%rbx)
	movl	$0, 428(%rbx)
	movl	$0, 440(%rbx)
	movl	$0, 452(%rbx)
	movl	$0, 464(%rbx)
	movl	$0, 476(%rbx)
	movl	$0, 488(%rbx)
	movl	$0, 500(%rbx)
	movl	$0, 512(%rbx)
	movl	$0, 524(%rbx)
	movl	$0, 536(%rbx)
	movl	$0, 548(%rbx)
	movl	$0, 560(%rbx)
	movl	$0, 572(%rbx)
	movl	$0, 584(%rbx)
	movl	$0, 596(%rbx)
	movl	$0, 608(%rbx)
	movl	$0, 620(%rbx)
	movl	$0, 632(%rbx)
	movl	$0, 644(%rbx)
	movl	$0, 656(%rbx)
	movl	$0, 668(%rbx)
	movl	$0, 680(%rbx)
	movl	$0, 692(%rbx)
	movl	$0, 704(%rbx)
	movl	$0, 716(%rbx)
	movl	$0, 728(%rbx)
	movl	$0, 740(%rbx)
	movl	$0, 752(%rbx)
	movl	$0, 764(%rbx)
	movl	$0, 776(%rbx)
	movl	$11, 12(%rsp)
	movl	$0, 8(%rsp)
	leaq	12(%rsp), %r14
	movq	%r14, 16(%rsp)
	leaq	8(%rsp), %r15
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$63, %ecx
	ja	.LBB4_5
# %bb.1:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB4_2:                                # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB4_4
# %bb.3:                                #   in Loop: Header=BB4_2 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB4_2
.LBB4_4:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$865977613, %edx                # imm = 0x339DC50D
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB4_5:
	movl	$21, 12(%rsp)
	movl	$2, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$63, %ecx
	ja	.LBB4_10
# %bb.6:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB4_7:                                # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB4_9
# %bb.8:                                #   in Loop: Header=BB4_7 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB4_7
.LBB4_9:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$91423699, %edx                 # imm = 0x57303D3
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB4_10:
	movl	$55, 12(%rsp)
	movl	$4, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$63, %ecx
	ja	.LBB4_15
# %bb.11:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB4_12:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB4_14
# %bb.13:                               #   in Loop: Header=BB4_12 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB4_12
.LBB4_14:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$34920769, %edx                 # imm = 0x214D941
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB4_15:
	movl	$54, 12(%rsp)
	movl	$6, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$63, %ecx
	ja	.LBB4_20
# %bb.16:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB4_17:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB4_19
# %bb.18:                               #   in Loop: Header=BB4_17 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB4_17
.LBB4_19:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-1605610758, %edx              # imm = 0xA04C52FA
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB4_20:
	movl	$60, 12(%rsp)
	movl	$8, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$63, %ecx
	ja	.LBB4_25
# %bb.21:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB4_22:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB4_24
# %bb.23:                               #   in Loop: Header=BB4_22 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB4_22
.LBB4_24:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-352356188, %edx               # imm = 0xEAFF78A4
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB4_25:
	movl	$38, 12(%rsp)
	movl	$10, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$63, %ecx
	ja	.LBB4_30
# %bb.26:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB4_27:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB4_29
# %bb.28:                               #   in Loop: Header=BB4_27 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB4_27
.LBB4_29:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-2084311414, %edx              # imm = 0x83C3EE8A
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB4_30:
	movl	$40, 12(%rsp)
	movl	$12, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$63, %ecx
	ja	.LBB4_35
# %bb.31:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB4_32:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB4_34
# %bb.33:                               #   in Loop: Header=BB4_32 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB4_32
.LBB4_34:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$1196751640, %edx               # imm = 0x4754FB18
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB4_35:
	movl	$44, 12(%rsp)
	movl	$14, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$63, %ecx
	ja	.LBB4_40
# %bb.36:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB4_37:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB4_39
# %bb.38:                               #   in Loop: Header=BB4_37 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB4_37
.LBB4_39:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-831056844, %edx               # imm = 0xCE771434
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB4_40:
	movl	$453, 12(%rsp)                  # imm = 0x1C5
	movl	$17, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$63, %ecx
	ja	.LBB4_45
# %bb.41:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB4_42:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB4_44
# %bb.43:                               #   in Loop: Header=BB4_42 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB4_42
.LBB4_44:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$131439523, %edx                # imm = 0x7D59BA3
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB4_45:
	movl	$58, 12(%rsp)
	movl	$18, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$63, %ecx
	ja	.LBB4_50
# %bb.46:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB4_47:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB4_49
# %bb.48:                               #   in Loop: Header=BB4_47 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB4_47
.LBB4_49:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$661548054, %edx                # imm = 0x276E6C16
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB4_50:
	addq	$32, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end4:
	.size	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE8TagIndexC2Ev, .Lfunc_end4-_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE8TagIndexC2Ev
	.cfi_endproc
                                        # -- End function
	.section	.text.startup,"axG",@progbits,_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE,comdat
	.p2align	4                               # -- Begin function __cxx_global_var_init.1
	.type	__cxx_global_var_init.1,@function
__cxx_global_var_init.1:                # @__cxx_global_var_init.1
	.cfi_startproc
# %bb.0:
	cmpb	$0, _ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE(%rip)
	je	.LBB5_2
# %bb.1:
	retq
.LBB5_2:
	movb	$1, _ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE(%rip)
	leaq	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE(%rip), %rdi
	jmp	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE8TagIndexC2Ev # TAILCALL
.Lfunc_end5:
	.size	__cxx_global_var_init.1, .Lfunc_end5-__cxx_global_var_init.1
	.cfi_endproc
                                        # -- End function
	.section	.text._ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE8TagIndexC2Ev,"axG",@progbits,_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE8TagIndexC2Ev,comdat
	.weak	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE8TagIndexC2Ev # -- Begin function _ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE8TagIndexC2Ev
	.p2align	4
	.type	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE8TagIndexC2Ev,@function
_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE8TagIndexC2Ev: # @_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE8TagIndexC2Ev
	.cfi_startproc
# %bb.0:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$32, %rsp
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	addq	$8, %rdi
	movl	$1540, %edx                     # imm = 0x604
	xorl	%esi, %esi
	callq	memset@PLT
	movl	$0, (%rbx)
	movl	$0, 4(%rbx)
	movl	$104, %eax
	.p2align	4
.LBB6_1:                                # =>This Inner Loop Header: Depth=1
	movl	$0, -84(%rbx,%rax)
	movl	$0, -72(%rbx,%rax)
	movl	$0, -60(%rbx,%rax)
	movl	$0, -48(%rbx,%rax)
	movl	$0, -36(%rbx,%rax)
	movl	$0, -24(%rbx,%rax)
	movl	$0, -12(%rbx,%rax)
	movl	$0, (%rbx,%rax)
	addq	$96, %rax
	cmpq	$1640, %rax                     # imm = 0x668
	jne	.LBB6_1
# %bb.2:
	movl	$6, 12(%rsp)
	movl	$0, 8(%rsp)
	leaq	12(%rsp), %r14
	movq	%r14, 16(%rsp)
	leaq	8(%rsp), %r15
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_7
# %bb.3:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_4:                                # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_6
# %bb.5:                                #   in Loop: Header=BB6_4 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_4
.LBB6_6:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$1253254570, %edx               # imm = 0x4AB325AA
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_7:
	movl	$11, 12(%rsp)
	movl	$2, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_12
# %bb.8:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_9:                                # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_11
# %bb.10:                               #   in Loop: Header=BB6_9 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_9
.LBB6_11:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$865977613, %edx                # imm = 0x339DC50D
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_12:
	movl	$14, 12(%rsp)
	movl	$4, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_17
# %bb.13:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_14:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_16
# %bb.15:                               #   in Loop: Header=BB6_14 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_14
.LBB6_16:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$1492604898, %edx               # imm = 0x58F757E2
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_17:
	movl	$17, 12(%rsp)
	movl	$6, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_22
# %bb.18:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_19:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_21
# %bb.20:                               #   in Loop: Header=BB6_19 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_19
.LBB6_21:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$2119232183, %edx               # imm = 0x7E50EAB7
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_22:
	movl	$31, 12(%rsp)
	movl	$8, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_27
# %bb.23:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_24:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_26
# %bb.25:                               #   in Loop: Header=BB6_24 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_24
.LBB6_26:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-683130215, %edx               # imm = 0xD7484299
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_27:
	movl	$32, 12(%rsp)
	movl	$10, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_32
# %bb.28:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_29:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_31
# %bb.30:                               #   in Loop: Header=BB6_29 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_29
.LBB6_31:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$957401312, %edx                # imm = 0x3910C8E0
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_32:
	movl	$37, 12(%rsp)
	movl	$12, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_37
# %bb.33:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_34:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_36
# %bb.35:                               #   in Loop: Header=BB6_34 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_34
.LBB6_36:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$570124355, %edx                # imm = 0x21FB6843
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_37:
	movl	$38, 12(%rsp)
	movl	$14, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_42
# %bb.38:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_39:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_41
# %bb.40:                               #   in Loop: Header=BB6_39 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_39
.LBB6_41:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-2084311414, %edx              # imm = 0x83C3EE8A
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_42:
	movl	$39, 12(%rsp)
	movl	$16, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_47
# %bb.43:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_44:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_46
# %bb.45:                               #   in Loop: Header=BB6_44 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_44
.LBB6_46:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-443779887, %edx               # imm = 0xE58C74D1
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_47:
	movl	$41, 12(%rsp)
	movl	$18, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_52
# %bb.48:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_49:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_51
# %bb.50:                               #   in Loop: Header=BB6_49 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_49
.LBB6_51:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-1457684129, %edx              # imm = 0xA91D815F
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_52:
	movl	$44, 12(%rsp)
	movl	$20, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_57
# %bb.53:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_54:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_56
# %bb.55:                               #   in Loop: Header=BB6_54 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_54
.LBB6_56:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-831056844, %edx               # imm = 0xCE771434
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_57:
	movl	$54, 12(%rsp)
	movl	$22, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_62
# %bb.58:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_59:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_61
# %bb.60:                               #   in Loop: Header=BB6_59 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_59
.LBB6_61:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-1605610758, %edx              # imm = 0xA04C52FA
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_62:
	movl	$55, 12(%rsp)
	movl	$24, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_67
# %bb.63:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_64:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_66
# %bb.65:                               #   in Loop: Header=BB6_64 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_64
.LBB6_66:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$34920769, %edx                 # imm = 0x214D941
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_67:
	movl	$58, 12(%rsp)
	movl	$26, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_72
# %bb.68:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_69:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_71
# %bb.70:                               #   in Loop: Header=BB6_69 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_69
.LBB6_71:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$661548054, %edx                # imm = 0x276E6C16
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_72:
	movl	$60, 12(%rsp)
	movl	$28, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_77
# %bb.73:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_74:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_76
# %bb.75:                               #   in Loop: Header=BB6_74 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_74
.LBB6_76:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-352356188, %edx               # imm = 0xEAFF78A4
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_77:
	movl	$150, 12(%rsp)
	movl	$30, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_82
# %bb.78:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_79:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_81
# %bb.80:                               #   in Loop: Header=BB6_79 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_79
.LBB6_81:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$1266593178, %edx               # imm = 0x4B7EAD9A
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_82:
	movl	$151, 12(%rsp)
	movl	$32, 8(%rsp)
	movq	%r14, 16(%rsp)
	movq	%r15, 24(%rsp)
	movl	(%rbx), %ecx
	cmpl	$127, %ecx
	ja	.LBB6_87
# %bb.83:
	leal	1(%rcx), %edx
	movl	%edx, (%rbx)
	.p2align	4
.LBB6_84:                               # =>This Inner Loop Header: Depth=1
	movl	4(%rbx), %eax
	cmpl	%ecx, %eax
	ja	.LBB6_86
# %bb.85:                               #   in Loop: Header=BB6_84 Depth=1
	lock		cmpxchgl	%edx, 4(%rbx)
	jne	.LBB6_84
.LBB6_86:
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movl	$-1387842591, %edx              # imm = 0xAD4733E1
	callq	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
.LBB6_87:
	addq	$32, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end6:
	.size	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE8TagIndexC2Ev, .Lfunc_end6-_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE8TagIndexC2Ev
	.cfi_endproc
                                        # -- End function
	.section	.text._ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j,"axG",@progbits,_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j,comdat
	.weak	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j # -- Begin function _ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
	.p2align	4
	.type	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j,@function
_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j: # @_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %rbp, -16
                                        # kill: def $edx killed $edx def $rdx
	movl	%edx, %eax
	andl	$63, %eax
	leaq	(%rax,%rax,2), %r8
	leaq	(%rdi,%r8,4), %rcx
	addq	$12, %rcx
	movl	20(%rdi,%r8,4), %r8d
	testl	%r8d, %r8d
	je	.LBB7_21
# %bb.1:
	leaq	12(%rdi), %r9
	leal	3(%rdx), %r11d
	movl	$63, %ebx
	.p2align	4
.LBB7_2:                                # =>This Inner Loop Header: Depth=1
	leal	-2(%r11), %r10d
	andl	$63, %r10d
	leaq	(%r10,%r10,2), %r14
	cmpl	$0, 20(%rdi,%r14,4)
	je	.LBB7_8
# %bb.3:                                #   in Loop: Header=BB7_2 Depth=1
	leal	-1(%r11), %r10d
	andl	$63, %r10d
	leaq	(%r10,%r10,2), %r14
	cmpl	$0, 20(%rdi,%r14,4)
	je	.LBB7_8
# %bb.4:                                #   in Loop: Header=BB7_2 Depth=1
	movl	%r11d, %r10d
	andl	$63, %r10d
	leaq	(%r10,%r10,2), %r14
	cmpl	$0, 20(%rdi,%r14,4)
	je	.LBB7_8
# %bb.5:                                #   in Loop: Header=BB7_2 Depth=1
	addl	$3, %r11d
	addl	$-3, %ebx
	jne	.LBB7_2
.LBB7_6:
	movl	$-1, %eax
                                        # kill: def $eax killed $eax killed $rax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB7_8:
	.cfi_def_cfa_offset 32
	testb	$4, %r8b
	jne	.LBB7_22
# %bb.9:
	addl	$-2, %edx
	movl	$62, %r11d
	jmp	.LBB7_11
	.p2align	4
.LBB7_10:                               #   in Loop: Header=BB7_11 Depth=1
	addl	$-2, %edx
	addl	$-2, %r11d
.LBB7_11:                               # =>This Inner Loop Header: Depth=1
	leal	1(%rdx), %ebx
	andl	$63, %ebx
	shll	$2, %ebx
	leaq	(%rbx,%rbx,2), %rbx
	movl	20(%rdi,%rbx), %r14d
	movl	%r14d, %ebp
	shrl	$3, %ebp
	cmpl	%eax, %ebp
	jne	.LBB7_14
# %bb.12:                               #   in Loop: Header=BB7_11 Depth=1
	testl	%r14d, %r14d
	je	.LBB7_14
# %bb.13:                               #   in Loop: Header=BB7_11 Depth=1
	movl	%r14d, %ebp
	andl	$2, %ebp
	je	.LBB7_18
.LBB7_14:                               #   in Loop: Header=BB7_11 Depth=1
	testl	%r11d, %r11d
	je	.LBB7_6
# %bb.15:                               #   in Loop: Header=BB7_11 Depth=1
	movl	%edx, %ebx
	andl	$63, %ebx
	shll	$2, %ebx
	leaq	(%rbx,%rbx,2), %rbx
	movl	20(%rdi,%rbx), %r14d
	movl	%r14d, %ebp
	shrl	$3, %ebp
	cmpl	%eax, %ebp
	jne	.LBB7_10
# %bb.16:                               #   in Loop: Header=BB7_11 Depth=1
	testl	%r14d, %r14d
	je	.LBB7_10
# %bb.17:                               #   in Loop: Header=BB7_11 Depth=1
	movl	%r14d, %ebp
	andl	$2, %ebp
	jne	.LBB7_10
.LBB7_18:
	cmpl	%eax, %r10d
	je	.LBB7_20
# %bb.19:
	movl	%r10d, %edx
	leaq	(%rdx,%rdx,2), %rdx
	movl	%r8d, 8(%r9,%rdx,4)
	movq	(%rcx), %rdi
	movq	%rdi, (%r9,%rdx,4)
	movl	8(%r9,%rbx), %r14d
.LBB7_20:
	andl	$7, %r14d
	leal	(%r14,%r10,8), %edx
	movl	%edx, 8(%r9,%rbx)
.LBB7_21:
	movq	(%rsi), %rdx
	movl	(%rdx), %edx
	movl	%edx, (%rcx)
	movq	8(%rsi), %rdx
	movl	(%rdx), %edx
	movl	%edx, 4(%rcx)
	movl	$7, %edx
	jmp	.LBB7_25
.LBB7_22:
	movl	%r10d, %edx
	leaq	(%rdx,%rdx,2), %rdx
	leaq	(%r9,%rdx,4), %rdx
	cmpl	%eax, %r10d
	je	.LBB7_27
# %bb.23:
	movq	(%rcx), %rdi
	movq	%rdi, (%rdx)
	andl	$-5, %r8d
.LBB7_24:
	movl	%r8d, 8(%rdx)
	movq	(%rsi), %rdx
	movl	(%rdx), %edx
	movl	%edx, (%rcx)
	movq	8(%rsi), %rdx
	movl	(%rdx), %edx
	movl	%edx, 4(%rcx)
	leal	5(,%r10,8), %edx
.LBB7_25:
	movl	%edx, 8(%rcx)
                                        # kill: def $eax killed $eax killed $rax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB7_27:
	.cfi_def_cfa_offset 32
	xorl	%r8d, %r8d
	jmp	.LBB7_24
.Lfunc_end7:
	.size	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j, .Lfunc_end7-_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj6E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
	.cfi_endproc
                                        # -- End function
	.section	.text._ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j,"axG",@progbits,_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j,comdat
	.weak	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j # -- Begin function _ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
	.p2align	4
	.type	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j,@function
_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j: # @_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
	.cfi_startproc
# %bb.0:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %rbp, -16
                                        # kill: def $edx killed $edx def $rdx
	movl	%edx, %eax
	andl	$127, %eax
	leaq	(%rax,%rax,2), %r8
	leaq	(%rdi,%r8,4), %rcx
	addq	$12, %rcx
	movl	20(%rdi,%r8,4), %r8d
	testl	%r8d, %r8d
	je	.LBB8_19
# %bb.1:
	leaq	12(%rdi), %r9
	leal	2(%rdx), %r11d
	movl	$126, %ebx
	.p2align	4
.LBB8_2:                                # =>This Inner Loop Header: Depth=1
	leal	-1(%r11), %r10d
	andl	$127, %r10d
	leaq	(%r10,%r10,2), %r14
	cmpl	$0, 20(%rdi,%r14,4)
	je	.LBB8_6
# %bb.3:                                #   in Loop: Header=BB8_2 Depth=1
	testl	%ebx, %ebx
	je	.LBB8_25
# %bb.4:                                #   in Loop: Header=BB8_2 Depth=1
	movl	%r11d, %r10d
	andl	$127, %r10d
	leaq	(%r10,%r10,2), %r14
	cmpl	$0, 20(%rdi,%r14,4)
	je	.LBB8_6
# %bb.5:                                #   in Loop: Header=BB8_2 Depth=1
	addl	$2, %r11d
	addl	$-2, %ebx
	jmp	.LBB8_2
.LBB8_6:
	testb	$4, %r8b
	jne	.LBB8_20
# %bb.7:
	addl	$-2, %edx
	movl	$126, %r11d
	jmp	.LBB8_9
	.p2align	4
.LBB8_8:                                #   in Loop: Header=BB8_9 Depth=1
	addl	$-2, %edx
	addl	$-2, %r11d
.LBB8_9:                                # =>This Inner Loop Header: Depth=1
	leal	1(%rdx), %ebx
	andl	$127, %ebx
	shll	$2, %ebx
	leaq	(%rbx,%rbx,2), %rbx
	movl	20(%rdi,%rbx), %r14d
	movl	%r14d, %ebp
	shrl	$3, %ebp
	cmpl	%eax, %ebp
	jne	.LBB8_12
# %bb.10:                               #   in Loop: Header=BB8_9 Depth=1
	testl	%r14d, %r14d
	je	.LBB8_12
# %bb.11:                               #   in Loop: Header=BB8_9 Depth=1
	movl	%r14d, %ebp
	andl	$2, %ebp
	je	.LBB8_16
.LBB8_12:                               #   in Loop: Header=BB8_9 Depth=1
	testl	%r11d, %r11d
	je	.LBB8_25
# %bb.13:                               #   in Loop: Header=BB8_9 Depth=1
	movl	%edx, %ebx
	andl	$127, %ebx
	shll	$2, %ebx
	leaq	(%rbx,%rbx,2), %rbx
	movl	20(%rdi,%rbx), %r14d
	movl	%r14d, %ebp
	shrl	$3, %ebp
	cmpl	%eax, %ebp
	jne	.LBB8_8
# %bb.14:                               #   in Loop: Header=BB8_9 Depth=1
	testl	%r14d, %r14d
	je	.LBB8_8
# %bb.15:                               #   in Loop: Header=BB8_9 Depth=1
	movl	%r14d, %ebp
	andl	$2, %ebp
	jne	.LBB8_8
.LBB8_16:
	cmpl	%eax, %r10d
	je	.LBB8_18
# %bb.17:
	movl	%r10d, %edx
	leaq	(%rdx,%rdx,2), %rdx
	movl	%r8d, 8(%r9,%rdx,4)
	movq	(%rcx), %rdi
	movq	%rdi, (%r9,%rdx,4)
	movl	8(%r9,%rbx), %r14d
.LBB8_18:
	andl	$7, %r14d
	leal	(%r14,%r10,8), %edx
	movl	%edx, 8(%r9,%rbx)
.LBB8_19:
	movq	(%rsi), %rdx
	movl	(%rdx), %edx
	movl	%edx, (%rcx)
	movq	8(%rsi), %rdx
	movl	(%rdx), %edx
	movl	%edx, 4(%rcx)
	movl	$7, %edx
	jmp	.LBB8_23
.LBB8_25:
	movl	$-1, %eax
                                        # kill: def $eax killed $eax killed $rax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB8_20:
	.cfi_def_cfa_offset 32
	movl	%r10d, %edx
	leaq	(%rdx,%rdx,2), %rdx
	leaq	(%r9,%rdx,4), %rdx
	cmpl	%eax, %r10d
	je	.LBB8_27
# %bb.21:
	movq	(%rcx), %rdi
	movq	%rdi, (%rdx)
	andl	$-5, %r8d
.LBB8_22:
	movl	%r8d, 8(%rdx)
	movq	(%rsi), %rdx
	movl	(%rdx), %edx
	movl	%edx, (%rcx)
	movq	8(%rsi), %rdx
	movl	(%rdx), %edx
	movl	%edx, 4(%rcx)
	leal	5(,%r10,8), %edx
.LBB8_23:
	movl	%edx, 8(%rcx)
                                        # kill: def $eax killed $eax killed $rax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB8_27:
	.cfi_def_cfa_offset 32
	xorl	%r8d, %r8d
	jmp	.LBB8_22
.Lfunc_end8:
	.size	_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j, .Lfunc_end8-_ZN7ZmLHashIN3Zu_5TupleIJijEEE13ZmLHashKeyValIXtlZ11ZuTupleAxorILj0EEDavEUlTnjTyOT0_E_EEXtlZS4_ILj1EEDavEUlTnjTyS6_E_EE13ZmLHashStaticILj7E12ZmLHashLocalI16ZmLHash_DefaultsEEEvE5add__INS1_IJOiSH_EEEEEiOT_j
	.cfi_endproc
                                        # -- End function
	.type	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE,@object # @_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE
	.section	.bss._ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE,"awGR",@nobits,_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE,comdat
	.weak	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE
	.p2align	2, 0x0
_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE:
	.zero	780
	.size	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE, 780

	.type	_ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE,@object # @_ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE
	.section	.bss._ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE,"awG",@nobits,_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE,comdat
	.weak	_ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE
	.p2align	3, 0x0
_ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE:
	.quad	0                               # 0x0
	.size	_ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE, 8

	.type	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE,@object # @_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE
	.section	.bss._ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE,"awGR",@nobits,_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE,comdat
	.weak	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE
	.p2align	2, 0x0
_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE:
	.zero	1548
	.size	_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE, 1548

	.type	_ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE,@object # @_ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE
	.section	.bss._ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE,"awG",@nobits,_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE,comdat
	.weak	_ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE
	.p2align	3, 0x0
_ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE:
	.quad	0                               # 0x0
	.size	_ZGVN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE, 8

	.type	_ZZN10ZuNullRef_Ij5ZuCmpIjEjE4nullEvE4null,@object # @_ZZN10ZuNullRef_Ij5ZuCmpIjEjE4nullEvE4null
	.section	.rodata._ZZN10ZuNullRef_Ij5ZuCmpIjEjE4nullEvE4null,"aG",@progbits,_ZZN10ZuNullRef_Ij5ZuCmpIjEjE4nullEvE4null,comdat
	.weak	_ZZN10ZuNullRef_Ij5ZuCmpIjEjE4nullEvE4null
	.p2align	2, 0x0
_ZZN10ZuNullRef_Ij5ZuCmpIjEjE4nullEvE4null:
	.long	4294967295                      # 0xffffffff
	.size	_ZZN10ZuNullRef_Ij5ZuCmpIjEjE4nullEvE4null, 4

	.section	.init_array,"awG",@init_array,_ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE,comdat
	.p2align	3, 0x0
	.quad	__cxx_global_var_init
	.section	.init_array,"awG",@init_array,_ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE,comdat
	.p2align	3, 0x0
	.quad	__cxx_global_var_init.1
	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __cxx_global_var_init
	.addrsig_sym __cxx_global_var_init.1
	.addrsig_sym __gxx_personality_v0
	.addrsig_sym _ZN4Zfix3Fmt7Schema_IN8ZfixLoad5OrderEN7ZuFacet3FIXE10ZuTypeListIJ14ZfField_UInt64INS2_17ZuField_Order_keyELb0EE14ZfField_StringINS2_22ZuField_Order_handlingELb0EESA_INS2_20ZuField_Order_symbolELb0EESA_INS2_18ZuField_Order_sideELb0EE16ZfField_DateTimeINS2_18ZuField_Order_timeELb0EE14ZfField_UInt32INS2_17ZuField_Order_qtyELb0EESA_INS2_18ZuField_Order_typeELb0EE15ZfField_DecimalINS2_19ZuField_Order_priceELb0EE11ZfField_UDTINS2_21ZuField_Order_partiesELb0EESA_INS2_18ZuField_Order_textELb0EEEELb0EE5indexE
	.addrsig_sym _ZN4Zfix3Fmt7Schema_IN8ZfixLoad6ReportEN7ZuFacet3FIXE10ZuTypeListIJ15ZfField_DecimalINS2_18ZuField_Report_avgELb0EE14ZfField_UInt64INS2_18ZuField_Report_keyELb0EE14ZfField_UInt32INS2_18ZuField_Report_cumELb0EESA_INS2_19ZuField_Report_execELb0EES7_INS2_21ZuField_Report_lastPxELb0EESD_INS2_22ZuField_Report_lastQtyELb0EESA_INS2_20ZuField_Report_orderELb0EESD_INS2_18ZuField_Report_qtyELb0EE14ZfField_StringINS2_21ZuField_Report_statusELb0EESA_INS2_23ZuField_Report_originalELb0EES7_INS2_20ZuField_Report_priceELb0EESQ_INS2_19ZuField_Report_sideELb0EESQ_INS2_21ZuField_Report_symbolELb0EESQ_INS2_19ZuField_Report_textELb0EE16ZfField_DateTimeINS2_19ZuField_Report_timeELb0EESQ_INS2_19ZuField_Report_kindELb0EESD_INS2_21ZuField_Report_leavesELb0EEEELb0EE5indexE
