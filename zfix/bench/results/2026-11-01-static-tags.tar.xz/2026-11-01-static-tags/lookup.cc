#include <zlib/ZfixDispatch.hh>
#include "/home/ubuntu/src/z/zfix/util/load_fix.hh"

extern "C" int orderTag(int32_t key) {
#ifdef BEFORE
  return Zfix::Fmt::Schema<ZfixLoad::Order, ZuFacet::FIX>::index().find(key);
#else
  return Zfix::Fmt::Schema<ZfixLoad::Order, ZuFacet::FIX>::find(key);
#endif
}
extern "C" int reportTag(int32_t key) {
#ifdef BEFORE
  return Zfix::Fmt::Schema<ZfixLoad::Report, ZuFacet::FIX>::index().find(key);
#else
  return Zfix::Fmt::Schema<ZfixLoad::Report, ZuFacet::FIX>::find(key);
#endif
}
extern "C" int messageType(const char *data, unsigned length) {
#ifdef BEFORE
  return Zfix::Dispatch_::index<ZfixLoad::Dictionary::Messages>().find({data, length});
#else
  return Zfix::Dispatch_::find<ZfixLoad::Dictionary::Messages>({data, length});
#endif
}
