# FIX measured baseline

Build label: `release-onepass-static-int32-tags`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 3 | 81969.3 | 82232.6 | 3.832 | 3.835 |
| native-native / tls / scalar | 4 | 3 | 73854.9 | 74000.7 | 3.964 | 3.978 |
| native-quickfix / tcp / scalar | 4 | 3 | 49464.4 | 49670.1 | 6.250 | 6.252 |
| native-quickfix / tls / scalar | 4 | 3 | 45202.9 | 45227.9 | 6.592 | 6.605 |
| quickfix-native / tcp / scalar | 4 | 3 | 56067.4 | 58070.4 | 5.645 | 5.657 |
| quickfix-native / tls / scalar | 4 | 3 | 47051.8 | 47238.0 | 6.898 | 6.949 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 62014.8 | 64073.4 | 5.648 | 5.661 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 53177.4 | 53315.5 | 6.495 | 6.516 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 1.531 | 1.584 | 42.957 | 48.801 |
| native-native / tls / scalar | 4 | 1.725 | 1.790 | 48.598 | 62.449 |
| native-quickfix / tcp / scalar | 4 | 1.954 | 1.528 | 39.727 | 36.980 |
| native-quickfix / tls / scalar | 4 | 2.132 | 1.704 | 45.098 | 41.180 |
| quickfix-native / tcp / scalar | 4 | 1.435 | 1.834 | 32.672 | 44.340 |
| quickfix-native / tls / scalar | 4 | 1.741 | 2.034 | 37.398 | 54.375 |
| quickfix-quickfix / tcp / scalar | 4 | 1.322 | 1.295 | 32.594 | 36.953 |
| quickfix-quickfix / tls / scalar | 4 | 1.539 | 1.411 | 37.918 | 41.242 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 4 / 1 | 3 | 20532.7 | 3127366 | 3805678 | 3811802 | 3811802 | 4764753 |
| native-native / tcp / scalar / 4 / 2 | 3 | 20597.2 | 3130492 | 3831897 | 3835284 | 3835284 | 4794105 |
| native-native / tcp / scalar / 4 / 3 | 3 | 20536.2 | 3124892 | 3810899 | 3817901 | 3817901 | 4772377 |
| native-native / tcp / scalar / 4 / 4 | 3 | 20566.5 | 3122203 | 3774979 | 3779733 | 3779733 | 4724667 |
| native-native / tls / scalar / 4 / 1 | 3 | 18506.7 | 3475232 | 3955899 | 3964410 | 3964410 | 4955513 |
| native-native / tls / scalar / 4 / 2 | 3 | 18505.2 | 3473262 | 3940771 | 3952790 | 3952790 | 4940988 |
| native-native / tls / scalar / 4 / 3 | 3 | 18494.0 | 3474390 | 3962280 | 3971589 | 3971589 | 4964487 |
| native-native / tls / scalar / 4 / 4 | 3 | 18494.8 | 3474532 | 3964007 | 3977885 | 3977885 | 4972357 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 12400.0 | 5317368 | 6121837 | 6133397 | 6133397 | 7666747 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 12409.1 | 5311019 | 6250336 | 6252263 | 6252263 | 7815329 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 12414.6 | 5315790 | 6199332 | 6218321 | 6218321 | 7772902 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 12446.5 | 5315355 | 6148081 | 6164118 | 6164118 | 7705148 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 11310.4 | 5987269 | 6571393 | 6587152 | 6587152 | 8233940 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 11305.2 | 5987713 | 6563762 | 6580537 | 6580537 | 8225672 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 11305.6 | 5987426 | 6575785 | 6593378 | 6593378 | 8241723 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 11306.7 | 5987886 | 6591592 | 6604689 | 6604689 | 8255862 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 15430.4 | 4174449 | 5401271 | 5417209 | 5417209 | 6771512 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 14210.9 | 4811185 | 5626377 | 5636561 | 5636561 | 7045702 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 14210.2 | 4786069 | 5625766 | 5640862 | 5640862 | 7051078 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 14218.9 | 4797473 | 5644808 | 5656907 | 5656907 | 7071134 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 11797.9 | 4936241 | 6897556 | 6949055 | 6949055 | 8686319 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 11803.1 | 4937164 | 6895466 | 6947831 | 6947831 | 8684789 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 11814.5 | 4933880 | 6897163 | 6948699 | 6948699 | 8685874 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 11822.4 | 4939443 | 6892220 | 6948352 | 6948352 | 8685440 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 16702.7 | 3831453 | 5440908 | 5452974 | 5452974 | 6816218 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 15775.8 | 3999224 | 5640365 | 5652750 | 5652750 | 7065938 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 15782.5 | 3999065 | 5642603 | 5654437 | 5654437 | 7068047 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 15783.3 | 3997597 | 5648477 | 5660905 | 5660905 | 7076132 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 13331.1 | 4755906 | 6487548 | 6505747 | 6505747 | 8132184 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 13329.9 | 4754352 | 6491746 | 6505591 | 6505591 | 8131989 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 13325.4 | 4756347 | 6494564 | 6506992 | 6506992 | 8133740 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 13329.1 | 4756237 | 6494186 | 6516222 | 6516222 | 8145278 |

## Standalone codec

Per-call encode includes typed body and full FIX framing; decode includes framing/checksum, typed construction and validation. QuickFIX also applies its canonical dictionary validation. Native reuses its output backing; QuickFIX constructs its SDK message and returns its SDK string. QuickFIX decode includes its input string and selected-field arena copies; Native decoded spans borrow input. These ownership costs are included. Clock-pair overhead is reported separately without subtraction.

| Engine / shape | Runs | Frame bytes | Encode p50 median ns | Encode p99 worst ns | Decode p50 median ns | Decode p99 worst ns | Clock p50 median ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix / groups | 3 | 910 | 13409 | 21607 | 12761 | 20894 | 22 |
| quickfix / scalar | 3 | 170 | 1564 | 2355 | 3374 | 4178 | 22 |
| zfix / groups | 3 | 910 | 3928 | 5390 | 3124 | 4832 | 22 |
| zfix / scalar | 3 | 170 | 837 | 1039 | 482 | 591 | 22 |

Raw artifacts: `/tmp/zfix-static-tags-20261101/process`.
