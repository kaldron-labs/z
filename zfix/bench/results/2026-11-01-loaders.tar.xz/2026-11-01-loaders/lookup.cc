#include <zlib/ZfixFmt.hh>
#include "/home/ubuntu/src/z/zfix/util/load_fix.hh"
extern "C" void loadOrder(ZfixLoad::Order &o, ZuCSpan input, Zfix::Fmt::Error &error) {
  Zfix::Fmt::read<ZfixLoad::Order, ZuFacet::FIX, ZfFieldFilter::Init>(o, input, error);
}
