# FIX measured baseline

Build label: `release-onepass-direct-loaders-int32`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -O3 -g  -DNDEBUG`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 3 | 83502.1 | 83716.5 | 3.962 | 3.969 |
| native-native / tls / scalar | 4 | 3 | 74912.3 | 75056.8 | 3.946 | 3.964 |
| native-quickfix / tcp / scalar | 4 | 3 | 47067.0 | 47121.3 | 6.213 | 6.227 |
| native-quickfix / tls / scalar | 4 | 3 | 43259.1 | 43299.4 | 6.819 | 6.835 |
| quickfix-native / tcp / scalar | 4 | 3 | 54432.7 | 57006.2 | 5.828 | 5.840 |
| quickfix-native / tls / scalar | 4 | 3 | 43436.4 | 43633.5 | 6.906 | 6.955 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 60168.8 | 62412.9 | 6.155 | 6.166 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 51903.6 | 52026.1 | 8.020 | 8.081 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 4 | 1.560 | 1.602 | 42.871 | 49.523 |
| native-native / tls / scalar | 4 | 1.717 | 1.779 | 47.910 | 66.156 |
| native-quickfix / tcp / scalar | 4 | 2.045 | 1.604 | 39.637 | 37.023 |
| native-quickfix / tls / scalar | 4 | 2.211 | 1.757 | 45.426 | 40.926 |
| quickfix-native / tcp / scalar | 4 | 1.492 | 1.898 | 32.711 | 45.391 |
| quickfix-native / tls / scalar | 4 | 1.822 | 1.966 | 37.488 | 53.930 |
| quickfix-quickfix / tcp / scalar | 4 | 1.369 | 1.320 | 32.762 | 36.906 |
| quickfix-quickfix / tls / scalar | 4 | 1.564 | 1.480 | 37.660 | 40.910 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 4 / 1 | 3 | 20951.2 | 3034376 | 3950447 | 3955809 | 3955809 | 4944762 |
| native-native / tcp / scalar / 4 / 2 | 3 | 20931.3 | 3036110 | 3945615 | 3951975 | 3951975 | 4939969 |
| native-native / tcp / scalar / 4 / 3 | 3 | 20926.2 | 3036800 | 3962103 | 3969487 | 3969487 | 4961859 |
| native-native / tcp / scalar / 4 / 4 | 3 | 20932.0 | 3032868 | 3950051 | 3956973 | 3956973 | 4946217 |
| native-native / tls / scalar / 4 / 1 | 3 | 18795.1 | 3389740 | 3884435 | 3895240 | 3895240 | 4869050 |
| native-native / tls / scalar / 4 / 2 | 3 | 18758.6 | 3392965 | 3945808 | 3963999 | 3963999 | 4954999 |
| native-native / tls / scalar / 4 / 3 | 3 | 18752.0 | 3394189 | 3906206 | 3915760 | 3915760 | 4894700 |
| native-native / tls / scalar / 4 / 4 | 3 | 18751.2 | 3393377 | 3891406 | 3898523 | 3898523 | 4873154 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 11786.2 | 5705242 | 6204195 | 6215089 | 6215089 | 7768862 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 11775.5 | 5707293 | 6209658 | 6221098 | 6221098 | 7776373 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 11776.0 | 5703014 | 6193116 | 6207734 | 6207734 | 7759668 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 11783.6 | 5698880 | 6212599 | 6226659 | 6226659 | 7783324 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 10829.8 | 6203980 | 6817450 | 6833523 | 6833523 | 8541904 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 10823.4 | 6205399 | 6818041 | 6833812 | 6833812 | 8542265 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 10822.8 | 6205030 | 6818632 | 6834875 | 6834875 | 8543594 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 10823.3 | 6204957 | 6818913 | 6835205 | 6835205 | 8544007 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 15510.4 | 4111230 | 5585433 | 5598839 | 5598839 | 6998549 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 13833.4 | 4392947 | 5828309 | 5840129 | 5840129 | 7300162 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 13828.1 | 4394977 | 5823864 | 5835663 | 5835663 | 7294579 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 13834.2 | 4392485 | 5821779 | 5835489 | 5835489 | 7294362 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 10889.7 | 5907472 | 6905506 | 6954079 | 6954079 | 8692599 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 10903.2 | 5906418 | 6896199 | 6954814 | 6954814 | 8693518 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 10914.4 | 5905189 | 6902527 | 6953147 | 6953147 | 8691434 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 10926.3 | 5903966 | 6900254 | 6954034 | 6954034 | 8692543 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 16790.5 | 3435322 | 6152103 | 6163929 | 6163929 | 7704912 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 15195.4 | 4144856 | 6145174 | 6155726 | 6155726 | 7694658 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 15217.2 | 4146746 | 6132414 | 6141326 | 6141326 | 7676658 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 15209.8 | 4144410 | 6154972 | 6165765 | 6165765 | 7707207 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 13008.7 | 4830271 | 8016140 | 8079508 | 8079508 | 10099385 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 13008.8 | 4830958 | 8019965 | 8081180 | 8081180 | 10101475 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 13002.4 | 4828544 | 8014187 | 8080898 | 8080898 | 10101123 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 13006.2 | 4832824 | 8012871 | 8079811 | 8079811 | 10099764 |

## Standalone codec

Per-call encode includes typed body and full FIX framing; decode includes framing/checksum, typed construction and validation. QuickFIX also applies its canonical dictionary validation. Native reuses its output backing; QuickFIX constructs its SDK message and returns its SDK string. QuickFIX decode includes its input string and selected-field arena copies; Native decoded spans borrow input. These ownership costs are included. Clock-pair overhead is reported separately without subtraction.

| Engine / shape | Runs | Frame bytes | Encode p50 median ns | Encode p99 worst ns | Decode p50 median ns | Decode p99 worst ns | Clock p50 median ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix / groups | 3 | 910 | 13431 | 21611 | 12699 | 21135 | 22 |
| quickfix / scalar | 3 | 170 | 1565 | 2121 | 3375 | 4359 | 22 |
| zfix / groups | 3 | 910 | 4106 | 5416 | 3055 | 4822 | 22 |
| zfix / scalar | 3 | 170 | 849 | 1048 | 458 | 571 | 22 |

Raw artifacts: `/tmp/zfix-loader-20261101/process`.
