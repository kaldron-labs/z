# FIX measured baseline

Build label: `clang21-O3-ASan-2881f4e2-measurement-window`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -g -DZDEBUG -O3 -DNDEBUG -fsanitize=address -fno-omit-frame-pointer`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

## Client and server comparison

Shared-window rate divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates use independent intervals. Rates are medians across repetitions. Worst p99 is the largest session p99 in any repetition. Both peers run in separate local processes.

| Pair / transport / shape | Sessions | Runs | Shared-window orders/s median | Sum session orders/s median | Ack p99 worst ms | Terminal p99 worst ms |
| --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 3 | 31150.9 | 31150.9 | 2.639 | 2.651 |
| native-native / tcp / scalar | 4 | 3 | 31681.3 | 31784.3 | 10.683 | 10.742 |
| native-native / tls / scalar | 1 | 3 | 25282.4 | 25282.4 | 4.315 | 4.350 |
| native-native / tls / scalar | 4 | 3 | 31307.6 | 31361.5 | 10.528 | 10.580 |
| native-quickfix / tcp / scalar | 1 | 3 | 18969.5 | 18969.5 | 4.827 | 4.860 |
| native-quickfix / tcp / scalar | 4 | 3 | 17863.4 | 17942.8 | 25.887 | 25.911 |
| native-quickfix / tls / scalar | 1 | 3 | 15027.5 | 15027.5 | 5.633 | 5.666 |
| native-quickfix / tls / scalar | 4 | 3 | 15934.1 | 15971.8 | 23.927 | 23.958 |
| quickfix-native / tcp / scalar | 1 | 3 | 12792.5 | 12792.5 | 7.095 | 7.148 |
| quickfix-native / tcp / scalar | 4 | 3 | 13415.7 | 13979.9 | 28.070 | 28.176 |
| quickfix-native / tls / scalar | 1 | 3 | 10671.7 | 10671.7 | 8.348 | 8.407 |
| quickfix-native / tls / scalar | 4 | 3 | 12551.9 | 12577.3 | 29.918 | 30.125 |
| quickfix-quickfix / tcp / scalar | 1 | 3 | 15917.7 | 15917.7 | 6.230 | 6.280 |
| quickfix-quickfix / tcp / scalar | 4 | 3 | 15071.1 | 15764.1 | 27.665 | 27.867 |
| quickfix-quickfix / tls / scalar | 1 | 3 | 12009.2 | 12009.2 | 7.698 | 7.756 |
| quickfix-quickfix / tls / scalar | 4 | 3 | 14483.1 | 14540.5 | 27.905 | 28.085 |

## Local process resources

CPU seconds include startup, warmup and shutdown. RSS is the largest process high-water mark across repetitions; fork/exec can inherit the parent's pre-exec high-water floor. These are whole-process observations, not isolated measured-phase costs.

| Pair / transport / shape | Sessions | Client CPU s median | Server CPU s median | Client RSS MiB max | Server RSS MiB max |
| --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar | 1 | 0.986 | 1.096 | 154.598 | 169.555 |
| native-native / tcp / scalar | 4 | 3.772 | 4.078 | 461.984 | 471.082 |
| native-native / tls / scalar | 1 | 1.156 | 1.242 | 224.336 | 207.953 |
| native-native / tls / scalar | 4 | 3.737 | 4.151 | 252.188 | 240.910 |
| native-quickfix / tcp / scalar | 1 | 1.166 | 1.249 | 154.391 | 258.605 |
| native-quickfix / tcp / scalar | 4 | 4.545 | 4.684 | 462.410 | 469.602 |
| native-quickfix / tls / scalar | 1 | 1.369 | 1.488 | 223.992 | 273.652 |
| native-quickfix / tls / scalar | 4 | 4.741 | 5.236 | 252.254 | 479.117 |
| quickfix-native / tcp / scalar | 1 | 1.571 | 1.321 | 309.879 | 169.230 |
| quickfix-native / tcp / scalar | 4 | 5.452 | 4.958 | 448.766 | 470.477 |
| quickfix-native / tls / scalar | 1 | 1.859 | 1.429 | 331.961 | 207.363 |
| quickfix-native / tls / scalar | 4 | 5.982 | 4.734 | 461.863 | 239.301 |
| quickfix-quickfix / tcp / scalar | 1 | 1.349 | 1.310 | 306.188 | 257.254 |
| quickfix-quickfix / tcp / scalar | 4 | 4.919 | 4.591 | 450.582 | 470.648 |
| quickfix-quickfix / tls / scalar | 1 | 1.670 | 1.481 | 328.535 | 270.703 |
| quickfix-quickfix / tls / scalar | 4 | 5.410 | 5.111 | 462.105 | 478.500 |

## Individual session measurements

| Pair / transport / shape / session count / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / scalar / 1 / 1 | 3 | 31150.9 | 2027850 | 2639103 | 2651270 | 2651270 | 3314088 |
| native-native / tcp / scalar / 4 / 1 | 3 | 7941.8 | 7997992 | 10597641 | 10742223 | 10742223 | 13427779 |
| native-native / tcp / scalar / 4 / 2 | 3 | 7944.6 | 8008808 | 10589861 | 10646730 | 10646730 | 13308413 |
| native-native / tcp / scalar / 4 / 3 | 3 | 7946.9 | 8015054 | 10683388 | 10724936 | 10724936 | 13406170 |
| native-native / tcp / scalar / 4 / 4 | 3 | 7951.0 | 8014323 | 10546361 | 10635569 | 10635569 | 13294462 |
| native-native / tls / scalar / 1 / 1 | 3 | 25282.4 | 2110278 | 4314993 | 4349779 | 4349779 | 5437224 |
| native-native / tls / scalar / 4 / 1 | 3 | 7842.3 | 8159474 | 10510666 | 10571516 | 10571516 | 13214395 |
| native-native / tls / scalar / 4 / 2 | 3 | 7835.8 | 8165520 | 10516263 | 10580014 | 10580014 | 13225018 |
| native-native / tls / scalar / 4 / 3 | 3 | 7839.8 | 8174852 | 10469394 | 10555698 | 10555698 | 13194623 |
| native-native / tls / scalar / 4 / 4 | 3 | 7843.6 | 8164833 | 10528354 | 10580237 | 10580237 | 13225297 |
| native-quickfix / tcp / scalar / 1 / 1 | 3 | 18969.5 | 3356095 | 4826531 | 4859923 | 4859923 | 6074904 |
| native-quickfix / tcp / scalar / 4 / 1 | 3 | 4496.7 | 13542243 | 24806606 | 24843043 | 24843043 | 31053804 |
| native-quickfix / tcp / scalar / 4 / 2 | 3 | 4484.7 | 13651352 | 24143864 | 24152225 | 24152225 | 30190282 |
| native-quickfix / tcp / scalar / 4 / 3 | 3 | 4481.1 | 13609187 | 25886953 | 25910739 | 25910739 | 32388424 |
| native-quickfix / tcp / scalar / 4 / 4 | 3 | 4480.3 | 13686564 | 25323482 | 25356651 | 25356651 | 31695814 |
| native-quickfix / tls / scalar / 1 / 1 | 3 | 15027.5 | 4101448 | 5632919 | 5665534 | 5665534 | 7081918 |
| native-quickfix / tls / scalar / 4 / 1 | 3 | 4002.6 | 15654025 | 23902035 | 23937445 | 23937445 | 29921807 |
| native-quickfix / tls / scalar / 4 / 2 | 3 | 3998.1 | 15674832 | 23926731 | 23951043 | 23951043 | 29938804 |
| native-quickfix / tls / scalar / 4 / 3 | 3 | 3985.3 | 15696822 | 23916496 | 23957652 | 23957652 | 29947065 |
| native-quickfix / tls / scalar / 4 / 4 | 3 | 3985.8 | 15709840 | 23888625 | 23925639 | 23925639 | 29907049 |
| quickfix-native / tcp / scalar / 1 / 1 | 3 | 12792.5 | 4852884 | 7094945 | 7148046 | 7148046 | 8935058 |
| quickfix-native / tcp / scalar / 4 / 1 | 3 | 3711.8 | 16750280 | 25722869 | 25915911 | 25915911 | 32394889 |
| quickfix-native / tcp / scalar / 4 / 2 | 3 | 3419.7 | 19126670 | 28070114 | 28175939 | 28175939 | 35219924 |
| quickfix-native / tcp / scalar / 4 / 3 | 3 | 3423.7 | 19132173 | 27309850 | 27555472 | 27555472 | 34444340 |
| quickfix-native / tcp / scalar / 4 / 4 | 3 | 3424.8 | 19137305 | 27373936 | 27497612 | 27497612 | 34372015 |
| quickfix-native / tls / scalar / 1 / 1 | 3 | 10671.7 | 6003186 | 8348093 | 8407367 | 8407367 | 10509209 |
| quickfix-native / tls / scalar / 4 / 1 | 3 | 3142.3 | 20081192 | 29883429 | 30098431 | 30098431 | 37623039 |
| quickfix-native / tls / scalar / 4 / 2 | 3 | 3143.0 | 20071703 | 29917545 | 30124712 | 30124712 | 37655890 |
| quickfix-native / tls / scalar / 4 / 3 | 3 | 3145.1 | 20063645 | 29893269 | 30088628 | 30088628 | 37610785 |
| quickfix-native / tls / scalar / 4 / 4 | 3 | 3147.0 | 20053860 | 29909041 | 30093836 | 30093836 | 37617295 |
| quickfix-quickfix / tcp / scalar / 1 / 1 | 3 | 15917.7 | 3860446 | 6229544 | 6280096 | 6280096 | 7850120 |
| quickfix-quickfix / tcp / scalar / 4 / 1 | 3 | 4233.7 | 14626832 | 25410575 | 25600042 | 25600042 | 32000053 |
| quickfix-quickfix / tcp / scalar / 4 / 2 | 3 | 3865.2 | 16020513 | 27665270 | 27866968 | 27866968 | 34833710 |
| quickfix-quickfix / tcp / scalar / 4 / 3 | 3 | 3871.4 | 15980775 | 27520453 | 27847662 | 27847662 | 34809578 |
| quickfix-quickfix / tcp / scalar / 4 / 4 | 3 | 3875.7 | 16094664 | 27301469 | 27377316 | 27377316 | 34221645 |
| quickfix-quickfix / tls / scalar / 1 / 1 | 3 | 12009.2 | 4755579 | 7698344 | 7756317 | 7756317 | 9695397 |
| quickfix-quickfix / tls / scalar / 4 / 1 | 3 | 3634.2 | 16927817 | 27904906 | 28018195 | 28018195 | 35022744 |
| quickfix-quickfix / tls / scalar / 4 / 2 | 3 | 3634.3 | 16928346 | 27837492 | 28084880 | 28084880 | 35106100 |
| quickfix-quickfix / tls / scalar / 4 / 3 | 3 | 3634.5 | 16905177 | 27863909 | 28051333 | 28051333 | 35064167 |
| quickfix-quickfix / tls / scalar / 4 / 4 | 3 | 3637.4 | 16945100 | 27890052 | 28048289 | 28048289 | 35060362 |

Raw artifacts: `/tmp/zfix-window-bundle/2026-10-31-10k-multisession/sessions-1`, `/tmp/zfix-window-bundle/2026-10-31-10k-multisession/sessions-4`.
