# FIX process load measurements

Build label: clang21-O3-ASan-2881f4e2-measurement-window. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Shared-window orders/s divides all measured completions by the interval from the first session's measured start to the last session's measured finish in the same client process. Sum-of-session rates are also retained. LinkState quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Transport | Status | Complete / unfinished | Errors / bad exits / timeouts | Shared-window orders/s | Sum session orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 31150.894 | 31150.894 | 0.985997 / 162103296 | 1.096477 / 177180672 |
| native-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 30447.791 | 30447.791 | 0.991470 / 162107392 | 1.119425 / 177790976 |
| native-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 31546.015 | 31546.015 | 0.981140 / 162078720 | 1.083075 / 177160192 |
| native-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 25282.421 | 25282.421 | 1.156115 / 235233280 | 1.252665 / 218054656 |
| native-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 25443.903 | 25443.903 | 1.152887 / 234848256 | 1.242286 / 217952256 |
| native-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 25217.819 | 25217.819 | 1.167173 / 235184128 | 1.242226 / 217624576 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 18064.293 | 18064.293 | 1.189854 / 161890304 | 1.266654 / 271167488 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 18969.519 | 18969.519 | 1.166016 / 161665024 | 1.249171 / 270581760 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 19118.314 | 19118.314 | 1.166494 / 161853440 | 1.247215 / 270958592 |
| native-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 15027.521 | 15027.521 | 1.349071 / 234872832 | 1.473407 / 286773248 |
| native-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 15109.558 | 15109.558 | 1.369352 / 234819584 | 1.488168 / 286945280 |
| native-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 14628.565 | 14628.565 | 1.369818 / 234835968 | 1.504520 / 286552064 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 13154.799 | 13154.799 | 1.562304 / 324931584 | 1.321443 / 177451008 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 12792.534 | 12792.534 | 1.577054 / 324603904 | 1.325999 / 177446912 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 12689.086 | 12689.086 | 1.571500 / 324562944 | 1.309987 / 177405952 |
| quickfix-native / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 10869.915 | 10869.915 | 1.809685 / 347996160 | 1.411588 / 217436160 |
| quickfix-native / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 10629.756 | 10629.756 | 1.859776 / 347787264 | 1.428626 / 217337856 |
| quickfix-native / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 10671.679 | 10671.679 | 1.858959 / 348086272 | 1.434574 / 217427968 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 14071.806 | 14071.806 | 1.434179 / 320593920 | 1.310087 / 269750272 |
| quickfix-quickfix / scalar / tcp / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 15941.697 | 15941.697 | 1.334255 / 321060864 | 1.382237 / 269295616 |
| quickfix-quickfix / scalar / tcp / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 15917.678 | 15917.678 | 1.349250 / 320851968 | 1.275444 / 269516800 |
| quickfix-quickfix / scalar / tls / 1 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 12009.210 | 12009.210 | 1.669832 / 344354816 | 1.473555 / 283852800 |
| quickfix-quickfix / scalar / tls / 2 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 12746.059 | 12746.059 | 1.634355 / 344256512 | 1.481490 / 283770880 |
| quickfix-quickfix / scalar / tls / 3 | timing | passed | 10000 / 0 | 0 / 0 / 0 | 11170.125 | 11170.125 | 1.744970 / 344494080 | 1.522006 / 283791360 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915694 / 1910085 | 5505024 |
| native-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910085 / 4915694 | 5505024 |
| native-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915870 / 1910196 | 5505024 |
| native-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910196 / 4915870 | 5505024 |
| native-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915799 / 1910094 | 5505024 |
| native-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910094 / 4915799 | 5505024 |
| native-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915831 / 1910072 | 5505024 |
| native-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910072 / 4915831 | 5505024 |
| native-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915810 / 1910152 | 5505024 |
| native-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910152 / 4915810 | 5505024 |
| native-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4916012 / 1910251 | 5505024 |
| native-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910251 / 4916012 | 5505024 |
| native-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910099 | 5505024 |
| native-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910099 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910225 | 5505024 |
| native-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910225 / 4810790 | 1428169 |
| native-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910126 | 5505024 |
| native-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910126 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910105 | 5505024 |
| native-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910105 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910078 | 5505024 |
| native-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910078 / 4810790 | 1428169 |
| native-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1910243 | 5505024 |
| native-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1910243 / 4810790 | 1428169 |
| quickfix-native/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915891 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915891 | 5505024 |
| quickfix-native/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4916065 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4916065 | 5505024 |
| quickfix-native/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4916063 / 1912574 | 1238429 |
| quickfix-native/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4916063 | 5505024 |
| quickfix-native/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4916004 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4916004 | 5505024 |
| quickfix-native/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915916 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915916 | 5505024 |
| quickfix-native/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4915899 / 1912574 | 1238429 |
| quickfix-native/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4915899 | 5505024 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tcp/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tcp/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/1 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/1 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/2 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/2 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |
| quickfix-quickfix/scalar/tls/3 / client / 1 | 10000 / 10000 / 10000 | 10000 / 20000 | 0 / 64 | 22002 / 11002 | 4810790 / 1912574 | 1238429 |
| quickfix-quickfix/scalar/tls/3 / server / 1 | 11000 / 11000 / 11000 | 11000 / 22000 | 0 / 0 | 11002 / 22002 | 1912574 / 4810790 | 1428169 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 2027850 / 2382831 / 2478018 / 2612156 / 2690929 | 2041416 / 2397668 / 2489369 / 2621998 / 2718934 | 0 / 0 / 0 / 0 / 0 | 2027850 / 2382831 / 2478018 / 2612156 / 2690929 | 2041416 / 2397668 / 2489369 / 2621998 / 2718934 | 5505024 | 14962116.178 |
| native-native/scalar/tcp/2 / 1 | 2076567 / 2437743 / 2639103 / 2800559 / 2940434 | 2088921 / 2453580 / 2651270 / 2810051 / 2963184 | 0 / 0 / 0 / 0 / 0 | 2076567 / 2437743 / 2639103 / 2800559 / 2940434 | 2088921 / 2453580 / 2651270 / 2810051 / 2963184 | 5505024 | 14653817.333 |
| native-native/scalar/tcp/3 / 1 | 2002074 / 2329678 / 2612232 / 2801758 / 2819510 | 2013656 / 2342196 / 2621933 / 2815133 / 2837175 | 0 / 0 / 0 / 0 / 0 | 2002074 / 2329678 / 2612232 / 2801758 / 2819510 | 2013656 / 2342196 / 2621933 / 2815133 / 2837175 | 5505024 | 15231527.499 |
| native-native/scalar/tls/1 / 1 | 2110278 / 4052629 / 4314993 / 4701919 / 4970103 | 2122429 / 4082872 / 4349779 / 4710424 / 4979581 | 0 / 0 / 0 / 0 / 0 | 2110278 / 4052629 / 4314993 / 4701919 / 4970103 | 2122429 / 4082872 / 4349779 / 4710424 / 4979581 | 5505024 | 11941182.840 |
| native-native/scalar/tls/2 / 1 | 2102329 / 3698423 / 4042017 / 4835198 / 4947804 | 2114205 / 3724282 / 4072874 / 4851889 / 4956785 | 0 / 0 / 0 / 0 / 0 | 2102329 / 3698423 / 4042017 / 4835198 / 4947804 | 2114205 / 3724282 / 4072874 / 4851889 / 4956785 | 5505024 | 12082455.896 |
| native-native/scalar/tls/3 / 1 | 2175599 / 4010163 / 4180020 / 4493483 / 4686575 | 2189435 / 4041297 / 4205967 / 4503217 / 4694294 | 0 / 0 / 0 / 0 / 0 | 2175599 / 4010163 / 4180020 / 4493483 / 4686575 | 2189435 / 4041297 / 4205967 / 4503217 / 4694294 | 5505024 | 11957460.591 |
| native-quickfix/scalar/tcp/1 / 1 | 3450929 / 4578045 / 4826531 / 5063427 / 5288281 | 3476630 / 4607095 / 4859923 / 5115439 / 5316016 | 0 / 0 / 0 / 0 / 0 | 3450929 / 4578045 / 4826531 / 5063427 / 5288281 | 3476630 / 4607095 / 4859923 / 5115439 / 5316016 | 5505024 | 3853189.224 |
| native-quickfix/scalar/tcp/2 / 1 | 3356095 / 4004367 / 4207812 / 4506740 / 4695849 | 3381485 / 4032366 / 4229863 / 4520010 / 4724799 | 0 / 0 / 0 / 0 / 0 | 3356095 / 4004367 / 4207812 / 4506740 / 4695849 | 3381485 / 4032366 / 4229863 / 4520010 / 4724799 | 5505024 | 8526122.063 |
| native-quickfix/scalar/tcp/3 / 1 | 3044073 / 4196526 / 4272254 / 4775731 / 5113275 | 3068600 / 4227111 / 4300813 / 4814053 / 5137633 | 0 / 0 / 0 / 0 / 0 | 3044073 / 4196526 / 4272254 / 4775731 / 5113275 | 3068600 / 4227111 / 4300813 / 4814053 / 5137633 | 5505024 | 3896828.361 |
| native-quickfix/scalar/tls/1 / 1 | 4035329 / 5490642 / 5593175 / 5646308 / 5684437 | 4062902 / 5527357 / 5629845 / 5681394 / 5715221 | 0 / 0 / 0 / 0 / 0 | 4035329 / 5490642 / 5593175 / 5646308 / 5684437 | 4062902 / 5527357 / 5629845 / 5681394 / 5715221 | 5505024 | 6714043.178 |
| native-quickfix/scalar/tls/2 / 1 | 4101448 / 5465813 / 5632919 / 5758690 / 5795621 | 4129124 / 5502522 / 5665534 / 5797190 / 5840693 | 0 / 0 / 0 / 0 / 0 | 4101448 / 5465813 / 5632919 / 5758690 / 5795621 | 4129124 / 5502522 / 5665534 / 5797190 / 5840693 | 5505024 | 6762372.467 |
| native-quickfix/scalar/tls/3 / 1 | 4229810 / 5492808 / 5590827 / 5703336 / 5751494 | 4255055 / 5529666 / 5629762 / 5747124 / 5791768 | 0 / 0 / 0 / 0 / 0 | 4229810 / 5492808 / 5590827 / 5703336 / 5751494 | 4255055 / 5529666 / 5629762 / 5747124 / 5791768 | 5505024 | 6638199.089 |
| quickfix-native/scalar/tcp/1 / 1 | 4842310 / 5548528 / 6857089 / 7068344 / 7117589 | 4877262 / 5581171 / 6902043 / 7118130 / 7167419 | 0 / 0 / 0 / 0 / 0 | 4842310 / 5548528 / 6857089 / 7068344 / 7117589 | 4877262 / 5581171 / 6902043 / 7118130 / 7167419 | 1238429 | 2866798.451 |
| quickfix-native/scalar/tcp/2 / 1 | 4852884 / 6800058 / 7094945 / 7266423 / 7433024 | 4887546 / 6851427 / 7148046 / 7319536 / 7502026 | 0 / 0 / 0 / 0 / 0 | 4852884 / 6800058 / 7094945 / 7266423 / 7433024 | 4887546 / 6851427 / 7148046 / 7319536 / 7502026 | 1238429 | 3866609.872 |
| quickfix-native/scalar/tcp/3 / 1 | 5004550 / 6624465 / 6965278 / 7125066 / 7164429 | 5038789 / 6675168 / 7012103 / 7175400 / 7216012 | 0 / 0 / 0 / 0 / 0 | 5004550 / 6624465 / 6965278 / 7125066 / 7164429 | 5038789 / 6675168 / 7012103 / 7175400 / 7216012 | 1238429 | 3934756.345 |
| quickfix-native/scalar/tls/1 / 1 | 5773127 / 7904646 / 8348093 / 8757733 / 8797984 | 5813087 / 7960231 / 8407367 / 8821756 / 8852765 | 0 / 0 / 0 / 0 / 0 | 5773127 / 7904646 / 8348093 / 8757733 / 8797984 | 5813087 / 7960231 / 8407367 / 8821756 / 8852765 | 1238429 | 3976032.942 |
| quickfix-native/scalar/tls/2 / 1 | 6092627 / 6656272 / 8079651 / 8318781 / 8366803 | 6138877 / 6707877 / 8137318 / 8381080 / 8425457 | 0 / 0 / 0 / 0 / 0 | 6092627 / 6656272 / 8079651 / 8318781 / 8366803 | 6138877 / 6707877 / 8137318 / 8381080 / 8425457 | 1238429 | 3994097.723 |
| quickfix-native/scalar/tls/3 / 1 | 6003186 / 6678902 / 6964006 / 8571179 / 8808465 | 6047190 / 6720469 / 7021708 / 8629928 / 8871551 | 0 / 0 / 0 / 0 / 0 | 6003186 / 6678902 / 6964006 / 8571179 / 8808465 | 6047190 / 6720469 / 7021708 / 8629928 / 8871551 | 1238429 | 4050589.649 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 3919341 / 5882735 / 6229544 / 6437882 / 6472611 | 3943077 / 5926692 / 6280096 / 6490682 / 6526068 | 0 / 0 / 0 / 0 / 0 | 3919341 / 5882735 / 6229544 / 6437882 / 6472611 | 3943077 / 5926692 / 6280096 / 6490682 / 6526068 | 1238429 | 2470090.424 |
| quickfix-quickfix/scalar/tcp/2 / 1 | 3860446 / 5005713 / 5182972 / 5285590 / 5366052 | 3890241 / 5040150 / 5215940 / 5298298 / 5399041 | 0 / 0 / 0 / 0 / 0 | 3860446 / 5005713 / 5182972 / 5285590 / 5366052 | 3890241 / 5040150 / 5215940 / 5298298 / 5399041 | 1238429 | 2447515.255 |
| quickfix-quickfix/scalar/tcp/3 / 1 | 3820061 / 4972983 / 5153045 / 5255018 / 5282766 | 3842263 / 5004392 / 5195721 / 5293869 / 5330330 | 0 / 0 / 0 / 0 / 0 | 3820061 / 4972983 / 5153045 / 5255018 / 5282766 | 3842263 / 5004392 / 5195721 / 5293869 / 5330330 | 1238429 | 2440214.819 |
| quickfix-quickfix/scalar/tls/1 / 1 | 4739851 / 7483227 / 7698344 / 7830108 / 7934752 | 4772304 / 7539660 / 7756317 / 7888205 / 7966719 | 0 / 0 / 0 / 0 / 0 | 4739851 / 7483227 / 7698344 / 7830108 / 7934752 | 4772304 / 7539660 / 7756317 / 7888205 / 7966719 | 1238429 | 3759975.678 |
| quickfix-quickfix/scalar/tls/2 / 1 | 4755579 / 6815973 / 7144151 / 7320343 / 7375249 | 4786829 / 6865814 / 7200925 / 7375154 / 7433227 | 0 / 0 / 0 / 0 / 0 | 4755579 / 6815973 / 7144151 / 7320343 / 7375249 | 4786829 / 6865814 / 7200925 / 7375154 / 7433227 | 1238429 | 2697765.536 |
| quickfix-quickfix/scalar/tls/3 / 1 | 5833707 / 7128485 / 7453912 / 7550234 / 7869589 | 5883096 / 7187492 / 7511437 / 7608680 / 7871329 | 0 / 0 / 0 / 0 / 0 | 5833707 / 7128485 / 7453912 / 7550234 / 7869589 | 5883096 / 7187492 / 7511437 / 7608680 / 7871329 | 1238429 | 2716048.812 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: application-selected native bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- measuredWindow: client CLOCK_MONOTONIC nanoseconds; first session's measured start through last session's measured finish; sum of session rates also reported.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
