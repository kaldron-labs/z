#!/usr/bin/env python3
"""Create a pinned post-Link correctness index after all current gates pass.

This script does not build, run a peer, rerun a verifier, install or publish.
It only checks existing completed artifacts and writes one new index JSON.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys

SANITIZER = re.compile(r'ERROR: (?:AddressSanitizer|LeakSanitizer)|SUMMARY: AddressSanitizer|runtime error:')
SHA = re.compile(r'^[0-9a-f]{64}$')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def check_hash(path, expected):
    require(bool(SHA.fullmatch(expected)), f'invalid recorded SHA256: {path}')
    require(path.is_file() and digest(path) == expected, f'changed/missing pinned artifact: {path}')


def checked_log(path, build=False):
    text = path.read_text()
    require(not SANITIZER.search(text), f'sanitizer diagnostic: {path}')
    if build:
        require(not re.search(r'warning:|error:', text), f'compiler diagnostic: {path}')
    return text


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work-root', type=Path, default=Path('/tmp/zfix-pq-repair'))
    parser.add_argument('--source-root', type=Path, default=Path('/home/ubuntu/src/z'))
    parser.add_argument('--measurement-root', type=Path,
                        default=Path('/tmp/zfix-pq-repair/final-codec-clang-opt-measurements'))
    parser.add_argument('--output', type=Path, required=True)
    options = parser.parse_args()
    work, repo, measured = (p.resolve() for p in
                             (options.work_root, options.source_root, options.measurement_root))
    require(not options.output.exists(), f'preserve existing index: {options.output}')
    artifacts = []
    targets = set()

    def retain(source, target):
        source = Path(source).resolve()
        target = str(target)
        relative = PurePosixPath(target)
        require(not relative.is_absolute() and target == relative.as_posix() and
                relative.parts and all(part not in ('.', '..') for part in relative.parts) and
                '\\' not in target and target not in targets and target != 'index.json',
                f'unsafe or duplicate target: {target}')
        require(source.is_file(), f'missing artifact: {source}')
        targets.add(target)
        artifacts.append({'source': str(source), 'target': target, 'sha256': digest(source)})

    def retain_tree(source, target):
        require(source.is_dir(), f'missing artifact directory: {source}')
        found = 0
        for path in sorted(source.rglob('*')):
            if path.is_file() and path.suffix in ('.json', '.jsonl', '.log', '.stdout', '.stderr'):
                retain(path, str(PurePosixPath(target) / path.relative_to(source).as_posix()))
                found += 1
        require(found > 0, f'empty artifact directory: {source}')

    # All compiler records must be final, hash-pinned, and for this source tree.
    compiler_path = work / 'link-final-compiler-summary.json'
    compiler = load(compiler_path)
    require(compiler['complete'] is True and compiler['phase'] == 'post-Link' and
            compiler['platform'] == 'Linux x64', 'compiler chain incomplete/wrong phase')
    require({c['label'] for c in compiler['checks']} == {'link-gcc-opt', 'link-clang-opt'} and
            len(compiler['checks']) == 2, 'both current compiler checks required')
    retain(compiler_path, 'compilers/summary.json')
    for check in compiler['checks']:
        label = check['label']
        require(check['unitPrograms'] == 30 and check['unitScopes'] == 309 and
                check['nativePrograms'] == 14 and check['nativeScopes'] == 225 and
                check['interopSmokeCases'] == 8, f'compiler result counts: {label}')
        require(set(check['logs']) == {'config', 'clean', 'build', 'unit', 'itest', 'smoke'},
                f'compiler logs incomplete: {label}')
        texts = {}
        for role, record in check['logs'].items():
            path = Path(record['path'])
            check_hash(path, record['sha256'])
            texts[role] = checked_log(path, build=role == 'build')
            retain(path, f'compilers/{label}/{role}.log')
        require('Files=30, Tests=309' in texts['unit'] and 'Result: PASS' in texts['unit'],
                f'unit gate not passed: {label}')
        groups = [tuple(map(int, match)) for match in
                  re.findall(r'Files=(\d+), Tests=(\d+)', texts['itest'])]
        require(sum(p for p, s in groups) == 14 and sum(s for p, s in groups) == 225 and
                'Result: FAIL' not in texts['itest'], f'native gate not passed: {label}')
        smoke = work / (label + '-smoke')
        smoke_cases = [load(path) for path in smoke.rglob('case.json')]
        require(len(smoke_cases) == 8 and all(c['status'] == 'passed' for c in smoke_cases),
                f'four-pair smoke not passed: {label}')
        for path in smoke.rglob('*.log'):
            checked_log(path)
        retain_tree(smoke, f'compilers/{label}/smoke')
    for name in ('config-scoped-gcc-opt.site', 'config-scoped-opt.site',
                 'link-compiler-checks.sh', 'link-final-compiler-summary.py'):
        retain(work / name, 'compilers/' + name)
    observer_log = compiler['observerBuildLog']
    check_hash(Path(observer_log['path']), observer_log['sha256'])
    checked_log(Path(observer_log['path']), build=True)
    retain(Path(observer_log['path']), 'compilers/observer-build.log')
    # The full core compiler chain predates one bench-only timestamp repair.
    # Accept that exact delta only with two terminal, pinned benchmark rebuilds.
    codec_path = work / 'codec-input-fix-summary.json'
    codec_fix = load(codec_path)
    require(codec_fix['complete'] is True and codec_fix['phase'] == 'post-Link-codec',
            'benchmark timestamp supplement incomplete')
    delta = codec_fix['source']
    require(delta['path'] == 'zfix/bench/codec.hh' and
            delta['beforeSha256'] == compiler['sourceFiles'][delta['path']] and
            delta['beforeSha256'] != delta['afterSha256'], 'unexpected benchmark source delta')
    check_hash(repo / delta['path'], delta['afterSha256'])
    header = (repo / delta['path']).read_text()
    require('20261028-12:34:56.123456789' in header and 'Zm::now()' not in header,
            'deterministic common codec timestamp absent')
    require({check['label'] for check in codec_fix['checks']} == {'gcc', 'clang'} and
            len(codec_fix['checks']) == 2, 'both benchmark rebuilds required')
    retain(codec_path, 'compilers/codec-input-fix-summary.json')
    retain(work / 'check-codec-input-fix.py', 'compilers/check-codec-input-fix.py')
    for check in codec_fix['checks']:
        require({'config', 'build'} <= set(check['logs']), 'benchmark config/build evidence missing')
        require(bool(check['compiler']), 'benchmark compiler identification missing')
        for role, record in check['logs'].items():
            path = Path(record['path'])
            check_hash(path, record['sha256'])
            text = checked_log(path, build=role == 'build')
            if role == 'build':
                require('nativecodec' in text and 'quickfixcodec' in text, 'both codec targets not recorded')
            retain(path, f'compilers/codec-{check["label"]}/{path.name}')
    failed_root = work / 'final-link-clang-opt-measurements'
    failed_verification = load(failed_root / 'process/verification.json')
    require(failed_verification['status'] == 'failed' and
            any('codec frame size differs' in error for error in failed_verification['errors']),
            'preserved nondeterministic-codec failure absent')
    require(load(failed_root / 'build-manifest.json')['sourceFiles'][delta['path']] ==
            delta['beforeSha256'], 'failed codec snapshot/source delta differ')
    retain(failed_root / 'process/verification.json', 'measurement/prior-failed-codec-verification.json')
    effective_sources = dict(compiler['sourceFiles'])
    effective_sources[delta['path']] = delta['afterSha256']
    for name, sha in effective_sources.items():
        check_hash(repo / name, sha)
    require(len(compiler['reusedDependencies']) == 9, 'reused dependency count')
    for row in compiler['reusedDependencies']:
        check_hash(Path(row['path']), row['sha256'])

    # Current native correctness is separate from timing evidence.
    runtime = load(work / 'link-runtime-summary.json')
    require(runtime['allPassed'] is True and runtime['cases'] == 76 and
            runtime['sanitizerDiagnostics'] == 0 and runtime['unitPrograms'] == 30 and
            runtime['unitScopes'] == 309 and runtime['nativePrograms'] == 14 and
            runtime['nativeScopes'] == 225 and runtime['nativeUnderlyingDemoCases'] == 42 and
            runtime['nativeUnderlyingProcessCases'] == 18, 'current runtime summary incomplete')
    retain(work / 'link-runtime-summary.json', 'runtime/summary.json')
    for name in ('link-unit-test.log', 'link-itest-test.log', 'link-canonical.log',
                 'link-src-build.log', 'link-unit-build.log', 'link-util-build.log',
                 'link-itest-build.log', 'link-interop-build.log', 'link-bench-build.log'):
        checked_log(work / name, build='build' in name)
        retain(work / name, 'runtime/' + name)
    canonical = work / 'link-canonical'
    canonical_cases = [load(path) for path in canonical.rglob('case.json')]
    require(len(canonical_cases) == 76 and all(c['status'] == 'passed' for c in canonical_cases),
            'current canonical76 missing/failed')
    for path in canonical.rglob('*.log'):
        checked_log(path)
    retain_tree(canonical, 'runtime/canonical')

    # Every current installed target is terminal; its logs and header closure agree.
    installed_path = work / 'link-installed-verified-summary.json'
    installed = load(installed_path)
    require(installed['complete'] is True and installed['diagnosticsClean'] is True and
            installed['tapPrograms'] == 42 and installed['tapScopes'] == 524 and
            len(installed['targets']) == 15, 'installed gate incomplete')
    require(all(row['exit'] == 0 for row in installed['targets']) and
            len({(r['directory'], r['target']) for r in installed['targets']}) == 15,
            'installed targets failed/duplicated')
    require(sum(r['tapPrograms'] for r in installed['targets']) == 42 and
            sum(r['tapScopes'] for r in installed['targets']) == 524, 'installed TAP totals')
    retain(installed_path, 'installed/summary.json')
    for row in installed['targets']:
        path = Path(row['log'])
        text = checked_log(path)
        require('Result: PASS' in text and 'Result: FAIL' not in text, f'installed log: {path}')
        retain(path, f'installed/{row["directory"]}-{row["target"]}.log')
    boundary_path = work / 'link-install-verification.json'
    boundary = load(boundary_path)
    prefix = Path(installed['prefix'])
    require(boundary['prefix'] == str(prefix) and boundary['headerCount'] == len(boundary['headers']) == 30 and
            all(r['matches'] for r in boundary['headers']) and boundary['globalPrefixAbsent'] is True,
            'installed header boundary record')
    for row in boundary['headers']:
        require(digest(prefix / 'include/zlib' / row['name']) == digest(repo / 'zfix/src' / row['name']),
                f'installed header changed: {row["name"]}')
    require(len(boundary['reusedDSOs']) == 9 and all(r['unchanged'] for r in boundary['reusedDSOs']),
            'installed dependencies not reused')
    for row in boundary['reusedDSOs']:
        check_hash(prefix / 'lib' / row['name'], row['sha256'])
    require({r['sha256'] for r in boundary['reusedDSOs']} ==
            {r['sha256'] for r in compiler['reusedDependencies']}, 'dependency closure differs')
    for name in ('link-install-verification.json', 'link-install-stage.json', 'link-installed-checks.py'):
        retain(work / name, 'installed/' + name)

    # Recheck standalone examples against exact sources, binaries and loader files.
    example_provenance = load(work / 'canonical-example-installed/provenance.json')
    require(example_provenance['prefix'] == str(prefix), 'example installed prefix differs')
    for name, sha in example_provenance['source'].items():
        check_hash(Path(name), sha)
        retain(Path(name), 'examples/source/' + Path(name).name)
    for name, sha in example_provenance['binaries'].items():
        check_hash(Path(name), sha)
    for libraries in example_provenance['loader'].values():
        for name, sha in libraries.items():
            check_hash(Path(name), sha)
    example_build = work / 'canonical-example-installed'
    require(load(example_build / 'build-results.json') == [0, 0], 'installed example compilation failed')
    for name in ('commands.json', 'build-results.json', 'provenance.json', 'zfix.build.log',
                 'zfixd.build.log', 'zfix.ldd.log', 'zfixd.ldd.log'):
        if name.endswith('.build.log'):
            checked_log(example_build / name, build=True)
        retain(example_build / name, 'examples/installed-build/' + name)
    require(not (work / 'post-layout-example-build5.log').read_text().count('error:'), 'source example build failed')
    retain(work / 'post-layout-example-build5.log', 'examples/source-build.log')
    for label, directory in (('source', 'canonical-example-pairs3'),
                             ('installed', 'canonical-example-installed-pairs')):
        folder = work / directory
        rows = load(folder / 'results.json')
        require(len(rows) == 2 and {r['tls'] for r in rows} == {False, True} and
                all(r['clientExit'] == r['serverExit'] == 0 for r in rows), 'example TCP/TLS result')
        for transport in ('tcp', 'tls'):
            for role in ('client', 'server'):
                require((folder / f'{transport}-{role}.stderr').read_bytes() == b'', 'example stderr not empty')
                require((folder / f'{transport}-{role}.stdout').stat().st_size > 0, 'example stdout missing')
        retain_tree(folder, 'examples/' + label)

    # Retain earlier memory evidence only for its unchanged compatible closure.
    # It is not a current networking/SDK Valgrind run.
    vg_dir = work / 'vg-current-zfix'
    vg = load(vg_dir / 'summary.json')
    require(vg['totalScopes'] == 71 and len(vg['results']) == 4 and
            vg['warningsFound'] is False and
            sum(row['tapScopes'] for row in vg['results']) == 71, 'format/sequence Valgrind summary')
    require({row['test']: row['tapScopes'] for row in vg['results']} ==
            {'Codec': 18, 'Frame': 11, 'Seq': 17, 'SeqTx': 25}, 'Valgrind scope coverage')
    for category in ('sources', 'headerSha256'):
        for name, sha in vg[category].items():
            check_hash(Path(name), sha)
    for name, sha in vg['foundationDsoSha256'].items():
        check_hash(Path(name), sha)
    check_hash(vg_dir / 'build.log', vg['buildLogSha256'])
    checked_log(vg_dir / 'build.log', build=True)
    for row in vg['results']:
        test = row['test']
        require(row['exit'] == row['valgrindErrors'] == 0 and
                row['lostBytes'] == {'definitely': 0, 'indirectly': 0, 'possibly': 0},
                f'Valgrind failed: {test}')
        check_hash(repo / 'zfix/test' / f'Zfix{test}Test.cc', row['sourceSha256'])
        check_hash(vg_dir / f'{test}.tap', row['tapSha256'])
        check_hash(vg_dir / f'{test}.vg', row['valgrindLogSha256'])
        require('ERROR SUMMARY: 0 errors' in (vg_dir / f'{test}.vg').read_text(),
                f'Valgrind raw summary: {test}')
        require(not any(any(name in line for name in ('libZi-', 'libZtcp-', 'libZtls-', 'libquickfix'))
                        for line in row['frameworkDependencies']), 'Valgrind networking/SDK closure')
        for suffix in ('.tap', '.vg', '-ldd.log', '-runtime.log', '-tap-check.log'):
            retain(vg_dir / (test + suffix), 'memory/format-sequence/' + test + suffix)
    for name in ('summary.json', 'commands.json', 'build.log'):
        retain(vg_dir / name, 'memory/format-sequence/' + name)
    retain(work / 'normal-foundation-reuse-audit.json', 'memory/normal-foundation-reuse-audit.json')

    observer_source = repo / 'zfix/bench/audittrace.cc'
    prior_manifest = load(work / 'final-clang-opt-measurements/build-manifest.json')
    observer_source_sha = prior_manifest['sourceFiles']['zfix/bench/audittrace.cc']
    check_hash(observer_source, observer_source_sha)
    fixture = load(work / 'audittrace/clang-fixture.json')
    expected_fixture = {'allocAttempts': 5, 'requestedBytes': 743, 'requestOverflows': 0,
                        'freeCalls': 4, 'copyCalls': 4, 'copyBytes': 80,
                        'asanCopyCalls': 2, 'asanCopyBytes': 36}
    require(all(fixture[key] == value for key, value in expected_fixture.items()),
            'observer controlled fixture counts')
    require((work / 'audittrace/clang-fixture.log').read_bytes() == b'', 'observer fixture diagnostics')
    require('ERROR: AddressSanitizer: heap-use-after-free' in
            (work / 'audittrace/clang-bad.log').read_text(), 'observer UAF negative diagnostic absent')
    retain(observer_source, 'memory/observer/audittrace.cc')
    for name in ('clang-fixture.json', 'clang-fixture.log', 'clang-fixture.out',
                 'clang-bad.log', 'clang-bad.out', 'fixture.cc', 'main.cc', 'bad.cc', 'badmain.cc'):
        retain(work / 'audittrace' / name, 'memory/observer/' + name)
    memory = {
        'formatSequenceValgrind': {'programs': 4, 'scopes': 71,
            'scope': 'Prior uninstrumented format/sequence scratch consumers using only the verified existing normal foundation closure; no networking or QuickFIX SDK memory claim.',
            'sourceAndHeaderHashesStillMatch': True, 'normalFoundationDSOsStillMatch': True,
            'retainedSummary': 'memory/format-sequence/summary.json'},
        'observer': {'recordedFixture': expected_fixture,
            'sourceSha256': observer_source_sha, 'sourceUnchangedSincePriorMeasurement': True,
            'recordedUAFNegativeExit': 99, 'negativeDiagnostic': 'AddressSanitizer heap-use-after-free',
            'rerun': False,
            'scope': 'Preserved controlled Clang/ASan fixture and UAF99 negative for the unchanged LD_AUDIT source; recorded exit99 is prior command evidence, while the retained raw log independently preserves the actual UAF report. This is not a newly executed control on the final observer ELF.'},
        'instrumentation': 'Current module and selected SDK/dependencies remain ASan-instrumented with compatible ZDEBUG ABI. Allowlisted SDK/dependency compiler flags are retained under measurement/. System crypto and external libraries are uninstrumented; this does not establish normal current networking/SDK Valgrind coverage.'}

    # Fresh data must have a completed independent audit with current hash enforcement.
    verification_path = measured / 'process/verification.json'
    verification = load(verification_path)
    require(verification['status'] == 'passed' and not verification['errors'] and
            verification['caseCount'] == 288 and verification['coverageGroups'] == 96 and
            verification['counts'] == {'timingCases': 144, 'heapRecords': 576,
                'resourceRecords': 672, 'auditCases': 144, 'auditRecords': 288} and
            verification['codec']['rows'] == 18 and verification['budgets']['groups'] == 48 and
            verification['stderrAudit']['files'] == 679 and
            verification['stderrAudit']['sanitizerDiagnostics'] == 0,
            'fresh independent measurement audit incomplete')
    provenance = verification['provenance']
    require(provenance['mode'] == 'require-current-hashes' and provenance['allCurrentHashesMatch'] is True and
            provenance['crossManifestInputsMatch'] is True and not provenance['currentPathDifferences'],
            'fresh audit is historical or hashes changed')
    check_hash(work / 'verify-measurements.py', verification['verifierSha256'])
    measured_manifest = load(measured / 'build-manifest.json')
    require({k: v for k, v in measured_manifest['sourceFiles'].items() if k.startswith('zfix/')} ==
            effective_sources, 'compiler plus benchmark supplement and measured sources differ')
    for name, sha in measured_manifest['sourceFiles'].items():
        check_hash(repo / name, sha)
    for row in measured_manifest['programs'].values():
        check_hash(Path(row['elf']), row['elfSha256'])
        check_hash(Path(row['path']), row['wrapperSha256'])
    for row in measured_manifest['linkedLibraries'].values():
        check_hash(Path(row['resolvedPath']), row['sha256'])
    for row in measured_manifest['observerLibraries'].values():
        check_hash(Path(row['path']), row['sha256'])
    for name in ('build-manifest.json', 'process/verification.json', 'process/summary.json'):
        retain(measured / name, 'measurement/' + name)
    retain(work / 'verify-measurements.py', 'measurement/verify-measurements.py')
    old_verifier = work / 'measurement-verifier-before-archive-scope-fix.py'
    old_verdict = work / 'verification-before-archive-scope-fix.json'
    scope_failure = work / 'archive-scope-failure.json'
    old_text = old_verifier.read_text()
    original_selection = "logs = sorted(root.rglob('*.log'))"
    corrected_selection = "logs = sorted([*root.glob('*.log'), *process.rglob('*.log')])"
    require(old_text.count(original_selection) == 1 and
            old_text.replace(original_selection, corrected_selection, 1) ==
            (work / 'verify-measurements.py').read_text(), 'verifier fix exceeds archive log scope')
    old_check, failed_check = load(old_verdict), load(scope_failure)
    require(old_check['status'] == 'passed' and not old_check['errors'] and
            old_check['verifierSha256'] == digest(old_verifier), 'old verifier verdict missing')
    require(failed_check['status'] == 'failed' and
            failed_check['verifierSha256'] == digest(old_verifier) and
            len(failed_check['errors']) == 1 and
            re.fullmatch(r'stderr: ValueError: stderr log count [0-9]+ != 679', failed_check['errors'][0]),
            'preserved archive-scope failure absent')
    for name in ('measurement-verifier-before-archive-scope-fix.py',
                 'verification-before-archive-scope-fix.json', 'archive-scope-failure.json',
                 'archive-verifier-scope-fix.md'):
        retain(work / name, 'measurement/archive-scope-fix/' + name)
    retain(work / 'sdk-build-metadata.json', 'measurement/sdk-build-metadata.json')
    retain(work / 'dependency-build-metadata.json', 'measurement/dependency-build-metadata.json')

    # Earlier comparison checkpoints explain the refactor; current measured hashes
    # above remain authoritative. A type rename is not a performance-equivalence proof.
    proof = load(work / 'link-refactor-proof.json')
    require(proof['coreBodyUnchangedAfterTypeRename'] is True and proof['newOwner'] == 'Zfix::Link' and
            proof['rawSessionStateAdded'] is False, 'owner structural comparison absent')
    for name in ('link-refactor-proof.json', 'pre-link-refactor-text.json',
                 'link-program-comparison.json', 'link-library-sections.json',
                 'post-measurement-layout.json', 'post-layout-runtime-summary.json'):
        retain(work / name, 'layout/' + name)
    retain(Path(__file__), 'publication-index-builder.py')
    output = {'complete': True, 'phase': 'post-Link',
        'createdAtUTC': datetime.now(timezone.utc).isoformat(),
        'scope': 'Linux x64; only Zfix built/tested/installed; existing dependencies reused; ARM/Windows out of scope',
        'applicability': 'Fresh post-Link deterministic-codec Clang optimized/ASan measurement snapshot with existing Clang-ASan dependencies. Core source hashes match the completed compiler chain; the sole benchmark timestamp header delta is covered by separate GCC/Clang benchmark rebuilds and the strict fresh measurement audit. GCC/Clang, native, installed and example checks are separate correctness evidence, not timing samples. Earlier source/section comparisons explain the transition but do not establish final binary or performance identity. Prior/pre-Link samples are retained separately and are neither substituted nor merged.',
        'currentSummary': {'compilers': 2, 'unitPrograms': 30, 'unitScopes': 309,
            'nativePrograms': 14, 'nativeScopes': 225, 'canonicalCases': 76,
            'installedTargets': 15, 'installedPrograms': 42, 'installedScopes': 524,
            'nestedNativeCases': 18, 'nestedPolicyCases': 42, 'exampleActors': 8,
            'measurementCases': 288, 'codecRows': 18,
            'sourceFiles': len(measured_manifest['sourceFiles']), 'reusedDependencyDSOs': 9},
        'limitations': ['Optimized instrumented baseline, not ordinary uninstrumented release or production throughput.',
            'System crypto and other external libraries are uninstrumented; normal Valgrind format/sequence evidence has a separate foundation-only closure.',
            'Shared host, finite per-run tails, inherited/pre-exec wait4 RSS; no merged quantiles or statistical confidence claim.',
            'Peer validation, ownership, history representation and wire-counter semantics differ as recorded.',
            'LD_AUDIT counts selected PLT attempts/copy entries; excludes direct/inlined/custom internals and may count nested calls.'],
        'codecInputRepair': {'source': delta, 'fullCoreCompilerSourceCount': len(compiler['sourceFiles']),
            'scope': 'One benchmark-only header delta; no library/protocol/test implementation changes. Previous failed final-link measurements are preserved separately. The current process and codec rows are all from a complete fresh common-source run, not a composite replacement.'},
        'verifierArchiveScopeRepair': {
            'change': 'Select current top-level codec/runner logs and current process logs; exclude separate archived historical/verification namespaces.',
            'preservedFailure': 'measurement/archive-scope-fix/archive-scope-failure.json',
            'explanation': 'measurement/archive-scope-fix/archive-verifier-scope-fix.md',
            'oldVerifierSha256': digest(old_verifier),
            'currentVerifierSha256': verification['verifierSha256'],
            'requiredCurrentLogs': 679, 'permittedSDKDiagnosticLogs': 72,
            'allOtherVerifierCodeUnchanged': True,
            'measuredRawAndManifestContentUnchanged': True},
        'memoryEvidence': memory,
        'artifacts': artifacts}
    options.output.parent.mkdir(parents=True, exist_ok=True)
    with options.output.open('x') as destination:
        json.dump(output, destination, indent=2)
        destination.write('\n')
    print(json.dumps({'complete': True, 'phase': 'post-Link', 'artifacts': len(artifacts),
                      'index': str(options.output), 'sha256': digest(options.output)}))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError) as error:
        print(f'index not created: {error}', file=sys.stderr)
        sys.exit(1)
