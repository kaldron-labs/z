#!/usr/bin/env python3
import os,json,subprocess,time
from pathlib import Path
root=Path('/tmp/zfix-pq-repair')
stage=json.loads((root/'link-install-stage.json').read_text())
prefix=stage['prefix'];env=dict(os.environ)
env.update(ASAN_OPTIONS='detect_leaks=1:exitcode=99',LSAN_OPTIONS='exitcode=99',LD_LIBRARY_PATH=prefix+'/lib'+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else ''))
groups={'test':['installed-test','installed-ingress-test','installed-trace-test','installed-dispatch-test','installed-context-test','installed-select-test','installed-work-test','installed-demo-test'], 'itest':['installed-test','installed-recovery-test','installed-raw-test','installed-reset-test','installed-ingress-test','installed-demo-test','installed-io-test']}
results=[]
for directory,targets in groups.items():
 for target in targets:
  command=['make','-j8','-C','/home/ubuntu/src/z/zfix/'+directory,target,'ZFIX_PREFIX='+prefix]
  log=root/f'link-installed-{directory}-{target}.log'
  print(f'RUN {directory}/{target}',flush=True)
  with log.open('w') as out: result=subprocess.run(command,env=env,stdout=out,stderr=subprocess.STDOUT)
  results.append(dict(directory=directory,target=target,exit=result.returncode,log=str(log),command=command))
  (root/'link-installed-summary.json').write_text(json.dumps({'prefix':prefix,'targets':results,'complete':False},indent=2)+'\n')
  if result.returncode: raise SystemExit(result.returncode)
(root/'link-installed-summary.json').write_text(json.dumps({'prefix':prefix,'targets':results,'complete':True},indent=2)+'\n')
print('PASS all',len(results),'installed targets',flush=True)
