# Retained-data verifier archive scope correction

The first unpacked archive reproduction failed because the verifier recursively
counted every `*.log` beneath the archive root. That included separately retained
historical snapshots and correctness-verification logs:2293 files rather than
the current measurement's679. This was a verifier input-scope error, not a
measurement or sanitizer failure.

The sole code change selects top-level codec/runner logs plus logs beneath the
current `process/` tree. The exact679-file count,72 permitted SDK certificate
diagnostics, rejection of all other stderr, every raw result/count/quantile/
heap/resource/audit/codec/budget check and strict current provenance invariant
are unchanged. Historical and correctness evidence remain in their separate
archive namespaces; they are not timing samples of the current run.

The old verifier, its passing pre-publication verdict and the failed unpacked
archive verdict are preserved alongside this explanation. The current strict
155-source/six-ELF/36-DSO audit passes with the corrected verifier. Raw288-case
process results,18 codec rows and all measurement manifests remain unchanged.
The first published archive and its unpacked tree are preserved by the publisher;
repackaging changes derived verification/index content, not measured inputs.
