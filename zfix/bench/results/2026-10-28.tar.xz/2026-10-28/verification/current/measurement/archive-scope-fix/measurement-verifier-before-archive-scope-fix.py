#!/usr/bin/env python3
"""Independently verify retained Zfix measurements; never launch workloads.

Captured manifests describe their historical snapshot. By default current paths
are compared and reported, but changed/missing files do not invalidate that
snapshot. --require-current-hashes additionally requires the captured paths to
match now. No historical ELF/source byte authentication is claimed when those
bytes were not retained. Run after results.py has produced budgets.json.
"""
import argparse
import collections
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys

PAIRS = ('native-native', 'native-quickfix', 'quickfix-native', 'quickfix-quickfix')
PROFILES = ('scalar', 'groups', 'binary', 'fragmentation', 'replay', 'overload')
METRICS = ('ackNs', 'terminalNs', 'scheduleNs', 'intendedAckNs', 'intendedTerminalNs')
QUANTILES = ('p50', 'p95', 'p99', 'p999', 'max')
CERT_DIAGNOSTIC = 'Certificate Verification: depth: 0, subject: /CN=localhost, issuer: /CN=localhost'
SHA = re.compile(r'^[0-9a-f]{64}$')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def uint(value):
    return type(value) is int and value >= 0


def number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def read_json(path):
    return json.loads(path.read_text())


def records(path):
    data = path.read_text()
    require(not data or data.endswith('\n'), f'incomplete JSONL: {path}')
    return [json.loads(line) for line in data.splitlines() if line.strip()]


def quantiles(row, count):
    require(row['count'] == count, f'quantile count {row["count"]} != {count}')
    values = [row[key] for key in QUANTILES]
    require(all(uint(value) for value in values), 'nonintegral/negative quantile')
    require(values == sorted(values), 'nonmonotonic quantiles')


def loader_paths(record):
    output = record['dependencies']
    require(output['exit'] == 0 and 'not found' not in output['output'], 'loader capture failed')
    return set(re.findall(r'(?:=>\s+|^\s*)(/\S+)\s+\(0x[0-9a-f]+\)',
                          output['output'], re.M))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path, help='directory containing build-manifest.json and process/')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--source-root', type=Path, default=Path('/home/ubuntu/src/z'))
    parser.add_argument('--require-current-hashes', action='store_true')
    parser.add_argument('--expected-source-count', type=int, default=147)
    options = parser.parse_args()
    root = options.root.resolve()
    process = root / 'process'
    errors = []
    report = {'status': 'failed', 'verifiedAtUTC': datetime.now(timezone.utc).isoformat(),
              'scope': 'Retained-data audit only; Linux x64; no builds or workloads; ARM/Windows out of scope',
              'root': str(root), 'verifierSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'errors': errors}

    def phase(name, fn):
        try:
            fn()
        except Exception as error:
            errors.append(f'{name}: {type(error).__name__}: {error}')

    cases = []
    coverage = collections.Counter()
    budgets = collections.defaultdict(list)
    counts = collections.Counter()

    def case_data():
        paths = sorted(process.glob('*/case.json'))
        require(len(paths) == 288, f'case count {len(paths)} != 288')
        manifest = read_json(process / 'manifest.json')
        summary = read_json(process / 'summary.json')
        require(summary['cases'] == 288 and summary['failed'] == 0, 'summary counts failed')
        for path in paths:
            try:
                case = read_json(path)
                pair, transport, profile, repeat, diagnostic = (case[key] for key in
                    ('pair', 'transport', 'profile', 'repeat', 'diagnostic'))
                require(pair in PAIRS and transport in ('tcp', 'tls') and profile in PROFILES,
                        'unexpected pair/transport/profile')
                require(type(diagnostic) is bool and repeat in (1, 2, 3), 'bad diagnostic/repeat')
                expected_dir = f'{pair}-{transport}-{profile}-{repeat}' + ('-audit' if diagnostic else '')
                require(path.parent.name == expected_dir, 'case identity differs from directory')
                require(case['status'] == 'passed' and not case['remote'], 'case failed or remote')
                require(case['diagnosticObserver'] == ('audit' if diagnostic else None), 'observer mismatch')
                require(all(case[key] == 0 for key in
                            ('timeouts', 'unfinished', 'errors', 'processErrors')), 'case errors/unfinished')
                require(case['expectedOrders'] == case['complete'] == 2000, 'completion count')
                require(number(case['wallSeconds']) and case['wallSeconds'] > 0, 'wall interval')
                coverage[(pair, transport, profile, diagnostic)] += 1
                counts['auditCases' if diagnostic else 'timingCases'] += 1
                for role, plural, engine, side, expected in (
                    ('client', 'clients', pair.split('-')[0], 'initiator', 2000),
                    ('server', 'servers', pair.split('-')[1], 'acceptor', 2200)):
                    require(len(case[plural]) == 1, 'one-session result missing/duplicated')
                    command = case['commands'][role]
                    program = manifest['programs'][f'{engine}_{role}']['path']
                    require(command.count(program) == 1 and command[:3] ==
                            [str(Path(program).parents[2] / 'libtool'), '--mode=execute', 'env'],
                            'peer executable/environment prefix')
                    require('ZFIX_HEAPSTATS=1' in command and
                            not any(token.startswith('LD_PRELOAD=') for token in command), 'peer heap/preload configuration')
                    observer = [token for token in command if token.startswith('LD_AUDIT=')]
                    audit_file = [token for token in command if token.startswith('ZFIX_AUDITTRACE_FILE=')]
                    if diagnostic:
                        require(observer == ['LD_AUDIT=' + manifest['observerLibraries']['audittrace']['path']] and
                                len(audit_file) == 1 and
                                Path(audit_file[0].split('=', 1)[1]).name == f'{role}-audit.json' and
                                Path(audit_file[0].split('=', 1)[1]).parent.name == path.parent.name,
                                'diagnostic observer arguments')
                    else:
                        require(not observer and not audit_file, 'observer in timing command')
                    for flag, value in {'count': '2000', 'warmup': '200', 'sessions': '1', 'inflight': '64',
                                        'seed': '1', 'retain': '4096', 'cache-bytes': '67108864',
                                        'queue-bytes': '16777216', 'mode': '4', 'version': 'FIX.4.4',
                                        'rate': '1000000' if profile == 'overload' else '0'}.items():
                        token = '--' + flag
                        require(command.count(token) == 1 and command[command.index(token) + 1] == value,
                                f'peer workload argument {token}')
                    require(('--tcp' in command) == (transport == 'tcp'), 'peer transport argument')
                    row = case[plural][0]
                    require(row['event'] == 'result' and row['role'] == side and
                            row['engine'] == ('zfix' if engine == 'native' else 'quickfix') and
                            row['session'] == 1 and row['errors'] == 0, 'result identity/error')
                    progress = row['progress']
                    require(all(progress[key] == expected for key in ('offered', 'admitted', 'ack', 'complete')),
                            f'{role} order counters')
                    require(progress['reports'] == 2 * expected, f'{role} report counter')
                    require(all(progress[key] == 0 for key in
                                ('duplicate', 'unknown', 'invalid', 'refused', 'inFlight')), f'{role} failed work')
                    require(row['warmup'] == 200 and row['seed'] == 1 and row['cap'] == 2000 and
                            row['inFlightLimit'] == 64 and row['connections'] == 1, 'workload mismatch')
                    require(row['elapsedNs'] > 0 and uint(row['elapsedNs']), 'elapsed interval')
                    for metric in METRICS:
                        quantiles(row[metric], 2000 if role == 'client' else 0)
                    if role == 'client':
                        for intended, actual in (('intendedAckNs', 'ackNs'),
                                                 ('intendedTerminalNs', 'terminalNs')):
                            require(all(row[intended][q] >= row[actual][q] for q in QUANTILES),
                                    'intended latency below actual')
                        if not diagnostic:
                            budgets[(pair, transport, profile, 1)].append(row['intendedTerminalNs']['p99'])
                    require(all(uint(row[key]) and row[key] > 0 for key in
                                ('rxFrames', 'txFrames', 'rxBytes', 'txBytes', 'retainedPeak')),
                            'wire/history measurements missing')
                    raw = records(path.parent / f'{role}.jsonl')
                    require([r for r in raw if r.get('event') == 'result'] == case[plural], 'raw result mismatch')
                    require(len([r for r in raw if r.get('event') == 'ready']) == 1, 'raw ready count')
                    heap = case['frameworkHeap'][role]
                    require([r for r in raw if r.get('event') == 'heap'] == [heap], 'raw heap mismatch')
                    require(heap['scope'] == 'process-framework-heaps-at-logical-drain' and
                            uint(heap['frameworkAllocCalls']) and heap['frameworkAllocCalls'] > 0 and
                            uint(heap['frameworkLiveBytes']), 'invalid framework heap')
                    counts['heapRecords'] += 1
                    if diagnostic:
                        audit = case['audit'][role]
                        require(read_json(path.parent / f'{role}-audit.json') == audit, 'raw audit mismatch')
                        require(audit['scope'].startswith('LD_AUDIT main-namespace PLT entries'), 'audit scope')
                        require(all(uint(audit[key]) for key in ('allocAttempts', 'requestedBytes',
                                'requestOverflows', 'freeCalls', 'copyCalls', 'copyBytes',
                                'asanCopyCalls', 'asanCopyBytes')), 'audit counter type')
                        require(audit['allocAttempts'] > 0 and audit['requestedBytes'] > 0 and
                                audit['copyCalls'] > 0 and audit['copyBytes'] > 0 and
                                audit['requestOverflows'] == 0, 'audit empty/overflow')
                        require(audit['asanCopyCalls'] <= audit['copyCalls'] and
                                audit['asanCopyBytes'] <= audit['copyBytes'], 'ASan copy subset')
                        counts['auditRecords'] += 1
                relay = profile in ('fragmentation', 'replay')
                require(set(case['resources']) == ({'client', 'server', 'relay'} if relay else
                                                   {'client', 'server'}), 'resource role set')
                for role, resource in case['resources'].items():
                    require(uint(resource['pid']) and resource['pid'] > 0 and resource['exit'] == 0,
                            f'{role} resource exit/pid')
                    wait = resource['wait4']
                    require(all(number(wait[key]) for key in ('userSeconds', 'systemSeconds')) and
                            all(uint(wait[key]) for key in ('maxRssBytes', 'minorFaults', 'majorFaults',
                                'voluntarySwitches', 'involuntarySwitches')) and
                            wait['maxRssBytes'] > 0, f'{role} wait4 counters')
                    counts['resourceRecords'] += 1
                if relay:
                    result = case['relay']
                    require([r for r in records(path.parent / 'relay-summary.jsonl')
                             if r['event'] == 'result'] == [result], 'relay raw mismatch')
                    require(result['errors'] == 0 and result['opened'] == result['closed'] == 1,
                            'relay failure')
                    require(result['faults'] == (1 if profile == 'replay' else 2200), 'relay fault proof')
                    if profile == 'fragmentation':
                        require(result['chunks'] > result['frames'], 'fragmentation proof')
                elif not diagnostic:
                    require('audit' not in case, 'audit metrics in timing run')
                cases.append(case)
            except Exception as error:
                errors.append(f'{path.relative_to(root)}: {type(error).__name__}: {error}')
        expected = {(p, t, s, d) for p in PAIRS for t in ('tcp', 'tls') for s in PROFILES for d in (False, True)}
        require(set(coverage) == expected and all(v == 3 for v in coverage.values()), '96 coverage groups/repeats')
        require(dict(counts) == {'timingCases': 144, 'heapRecords': 576, 'resourceRecords': 672,
                                'auditCases': 144, 'auditRecords': 288}, f'raw record counts: {dict(counts)}')
        report.update(caseCount=len(cases), coverageGroups=len(coverage), counts=dict(counts),
                      clientWork={'ordersPerCase': 2000, 'reportsPerCase': 4000,
                                  'quantileSamplesPerMetric': 2000, 'quantileMetrics': list(METRICS)},
                      serverWork={'ordersPerCaseIncludingWarmup': 2200, 'reportsPerCaseIncludingWarmup': 4400})
        ranges = {}
        for profile in PROFILES:
            rows = [c['clients'][0] for c in cases if c['profile'] == profile and not c['diagnostic']]
            values = {'ordersPerSecond': [r['progress']['complete'] * 1e9 / r['elapsedNs'] for r in rows],
                      'ackP99Ns': [r['ackNs']['p99'] for r in rows],
                      'terminalP99Ns': [r['terminalNs']['p99'] for r in rows],
                      'intendedTerminalP99Ns': [r['intendedTerminalNs']['p99'] for r in rows]}
            ranges[profile] = {'timingCases': len(rows)} | {key: {'min': min(v),
                'median': statistics.median(v), 'max': max(v)} for key, v in values.items()}
        report['timingOnlyObservedRunMetricRanges'] = ranges

    phase('cases', case_data)

    def budget_data():
        data = read_json(process / 'budgets.json')
        require(data['multiplier'] == 1.25 and data['hostSpecific'] is True and len(data['budgets']) == 48,
                'budget metadata/count')
        found = set()
        for row in data['budgets']:
            key = tuple(row[x] for x in ('pair', 'transport', 'profile', 'session'))
            require(key in budgets and key not in found, 'budget group missing/duplicate')
            found.add(key)
            worst = max(budgets[key])
            require(row['runs'] == 3 and len(budgets[key]) == 3 and
                    row['observedIntendedTerminalP99MaxNs'] == worst and
                    row['regressionEnvelopeNs'] == (worst * 5 + 3) // 4, 'budget rounding/value')
        require(found == set(budgets), 'budget coverage')
        report['budgets'] = {'groups': 48, 'multiplier': 1.25, 'roundingVerified': True}

    phase('budgets', budget_data)

    def codec_data():
        groups = collections.defaultdict(list)
        paths = sorted(root.glob('*codec-[123].jsonl'))
        require(len(paths) == 6, 'codec invocation count')
        for path in paths:
            rows = records(path)
            require(len(rows) == 3 and {r['shape'] for r in rows} == {'scalar', 'groups', 'binary'},
                    'codec shape coverage')
            for row in rows:
                engine = 'zfix' if path.name.startswith('native') else 'quickfix'
                require(row['event'] == 'codec' and row['engine'] == engine and
                        row['count'] == 10000 and row['warmup'] == 1000 and
                        uint(row['sink']) and row['sink'] > 0 and uint(row['bytes']) and row['bytes'] > 0,
                        'codec count/sink/identity')
                for metric in ('encodeNs', 'decodeNs', 'clockNs'):
                    quantiles(row[metric], 10000)
                groups[(row['engine'], row['shape'])].append(row)
        require(len(groups) == 6 and all(len(v) == 3 for v in groups.values()), 'codec repeat coverage')
        for shape in ('scalar', 'groups', 'binary'):
            require(len({r['bytes'] for engine in ('zfix', 'quickfix') for r in groups[(engine, shape)]}) == 1,
                    f'codec frame size differs: {shape}')
        report['codec'] = {'invocations': 6, 'rows': 18, 'engineShapeGroups': 6,
                           'repeatsPerGroup': 3, 'measuredSamplesPerMetric': 10000, 'warmup': 1000}

    phase('codec', codec_data)

    def diagnostics():
        logs = sorted(root.rglob('*.log'))
        require(len(logs) == 679, f'stderr log count {len(logs)} != 679')
        expected = {f'process/{p}-tls-{s}-{r}{d}/client.log' for p in ('quickfix-native', 'quickfix-quickfix')
                    for s in PROFILES for r in (1, 2, 3) for d in ('', '-audit')}
        nonempty = set()
        total = 0
        for path in logs:
            data = path.read_bytes()
            total += len(data)
            if data:
                relative = str(path.relative_to(root))
                nonempty.add(relative)
                require(relative in expected, f'unexpected stderr: {relative}')
                require(data.decode().splitlines() == [CERT_DIAGNOSTIC], f'undeclared stderr: {relative}')
        require(nonempty == expected, 'expected SDK diagnostics missing/extra')
        report['stderrAudit'] = {'files': len(logs), 'totalBytes': total,
            'nonemptyFiles': sorted(nonempty), 'sanitizerDiagnostics': 0,
            'benignSDKCertificateDiagnosticFiles': 72, 'benignSDKCertificateDiagnostic': CERT_DIAGNOSTIC}

    phase('stderr', diagnostics)

    def provenance():
        build = read_json(root / 'build-manifest.json')
        run = read_json(process / 'manifest.json')
        source_count = options.expected_source_count
        require(len(build['programs']) == 6 and len(run['programs']) == 4, 'program manifest counts')
        require(len(build['linkedLibraries']) == len(run['linkedLibraries']) == 36, 'DSO counts')
        require(len(build['sourceFiles']) == len(run['sourceFiles']) == source_count, 'source manifest count')
        for key in ('platform', 'machine', 'buildLabel', 'buildFlags', 'compiler', 'dictionary',
                    'dictionarySha256', 'quickfixLock', 'harnessSha256', 'sourceFiles',
                    'linkedLibraries', 'observerLibraries', 'differences'):
            require(build[key] == run[key], f'cross-manifest field differs: {key}')
        require(build['machine'] == 'x86_64' and build['compiler']['exit'] == 0, 'compiler/platform record')
        require(build['runtimeEnvironment'].get('ASAN_OPTIONS') == 'detect_leaks=1:exitcode=99' and
                build['runtimeEnvironment'].get('LSAN_OPTIONS') == 'exitcode=99', 'sanitizer environment')
        for name, row in run['programs'].items():
            prior = build['programs'][name]
            for key in ('path', 'wrapperSha256', 'elf', 'elfSha256', 'fileBytes', 'sections'):
                require(row[key] == prior[key], f'cross-manifest program {name}/{key}')
            require(loader_paths(row) == loader_paths(prior), f'loader maps differ: {name}')
        require(set(build['programs']) == {'native_client', 'native_server', 'quickfix_client',
                                         'quickfix_server', 'native_codec', 'quickfix_codec'}, 'program roles')
        require(len({r['elf'] for r in build['programs'].values()}) == 6, 'unique ELF count')
        require(len(build['codecCommands']) == 6, 'codec command count')
        require(len({(c['argv'][0], c['repeat']) for c in build['codecCommands']}) == 6, 'codec command repeats')
        for command in build['codecCommands']:
            require(command['argv'][1:] == ['10000', '1000'] and command['repeat'] in (1, 2, 3) and
                    (root / command['stdout']).is_file() and (root / command['stderr']).is_file(),
                    'codec command workload/evidence')
        args = run['arguments']
        for key, value in {'count': 2000, 'warmup': 200, 'inflight': 64, 'repeat': 3, 'sessions': 1,
                           'seed': 1, 'retain': 4096, 'cache_bytes': 67108864,
                           'queue_bytes': 16777216, 'framework_heaps': True}.items():
            require(args[key] == value, f'workload manifest: {key}')
        require('LD_AUDIT' not in build['runtimeEnvironment'] and 'LD_PRELOAD' not in build['runtimeEnvironment'],
                'observer inherited into timing environment')
        require(run['harnessSha256'] == run['sourceFiles']['zfix/bench/load.py'], 'harness hash record')
        require(f'QUICKFIX_FIX44_SHA256={run["dictionarySha256"]}' in run['quickfixLock'], 'dictionary pin')
        patch = run['sourceFiles']['zfix/interop/quickfix.patch']
        require(f'QUICKFIX_PATCH_SHA256={patch}' in run['quickfixLock'], 'patch pin')
        current = collections.defaultdict(lambda: collections.Counter())
        differences = []
        hashes = {}

        def captured(path, expected, category, size=None):
            require(bool(SHA.fullmatch(expected)), f'invalid captured SHA: {path}')
            path = Path(path)
            if not path.is_file():
                state = 'missing'
            else:
                if path not in hashes:
                    with path.open('rb') as source:
                        hashes[path] = hashlib.file_digest(source, 'sha256').hexdigest()
                state = 'matching' if hashes[path] == expected else 'changed'
                if state == 'matching' and size is not None:
                    require(path.stat().st_size == size, f'captured size mismatch {path}')
            current[category][state] += 1
            if state != 'matching':
                differences.append({'category': category, 'path': str(path), 'status': state})

        for row in build['programs'].values():
            require(row['sections']['exit'] == 0 and '.text' in row['sections']['output'], 'program section capture')
            require(loader_paths(row) <= set(build['linkedLibraries']), 'unrecorded loader library')
            captured(row['path'], row['wrapperSha256'], 'wrappers')
            captured(row['elf'], row['elfSha256'], 'executables', row['fileBytes'])
        for name, row in build['linkedLibraries'].items():
            require(row['sections']['exit'] == 0 and '.text' in row['sections']['output'], 'library section capture')
            captured(row['resolvedPath'], row['sha256'], 'libraries', row['fileBytes'])
        for name, value in build['sourceFiles'].items():
            captured(options.source_root / name, value, 'sources')
        for row in build['observerLibraries'].values():
            captured(row['path'], row['sha256'], 'observers', row['fileBytes'])
        captured(build['dictionary'], build['dictionarySha256'], 'dictionaries')
        report['provenance'] = {'mode': 'require-current-hashes' if options.require_current_hashes else 'captured-records',
            'uniqueBuildExecutables': 6, 'uniqueLinkedLibraryPaths': 36, 'uniqueSourcePaths': source_count,
            'crossManifestInputsMatch': True, 'allCurrentHashesMatch': not differences,
            'currentPathCounts': {k: dict(v) for k, v in current.items()},
            'currentPathDifferences': differences,
            'historicalLimit': 'Captured hash syntax and cross-manifest consistency are verified; historical bytes not retained cannot be reauthenticated from a hash record alone. Changed/missing current paths are reported, not treated as historical snapshot corruption.'}
        require(not options.require_current_hashes or not differences,
                f'{len(differences)} current-path hashes missing/changed')

    phase('provenance', provenance)
    report['status'] = 'failed' if errors else 'passed'
    options.output.parent.mkdir(parents=True, exist_ok=True)
    options.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'errors': errors, 'output': str(options.output)}))
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
