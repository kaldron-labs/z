#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/tmp/zfix-pq-repair');repo=Path('/home/ubuntu/src/z')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
for label,compiler in [('link-gcc-opt','g++'),('link-clang-opt','clang++')]:
 files={k:root/(label+'-'+k+'.log') for k in ['config','clean','build','unit','itest','smoke']}
 text={k:p.read_text() for k,p in files.items()}
 assert not re.search(r'warning:|error:',text['build']),label
 assert 'Files=30, Tests=309' in text['unit'] and 'Result: PASS' in text['unit'],label
 itest=[tuple(map(int,m)) for m in re.findall(r'Files=(\d+), Tests=(\d+)',text['itest'])]
 assert sum(x for x,y in itest)==14 and sum(y for x,y in itest)==225,(label,itest)
 assert not re.search(r'Result: FAIL|ERROR: (AddressSanitizer|LeakSanitizer)|SUMMARY: AddressSanitizer|runtime error:',text['unit']+text['itest']),label
 cases=[json.loads(p.read_text()) for p in (root/(label+'-smoke')).rglob('case.json')]
 assert len(cases)==8 and all(x['status']=='passed' for x in cases),label
 checks.append({'label':label,'compiler':subprocess.check_output([compiler,'--version'],text=True),'unitPrograms':30,'unitScopes':309,'nativePrograms':14,'nativeScopes':225,'interopSmokeCases':8,'logs':{k:{'path':str(p),'sha256':digest(p)} for k,p in files.items()}})
source={str(p.relative_to(repo)):digest(p) for p in sorted((repo/'zfix').rglob('*')) if p.is_file() and p.suffix in ['.cc','.hh','.am','.py','.sh','.patch','.lock'] and '/.deps/' not in str(p) and '/zlib/' not in str(p)}
old=json.loads((root/'link-install-verification.json').read_text());deps=[]
for dep in old['reusedDSOs']:
 name=dep['name'];module=name.split('-')[0][3:].lower()
 path=repo/module/'src/.libs'/name
 assert path.exists() and digest(path)==dep['sha256'],str(path)
 deps.append({'path':str(path),'sha256':dep['sha256']})
audit=root/'link-clang-opt-audittrace.log';assert audit.exists() and not re.search(r'warning:|error:',audit.read_text())
summary={'complete':True,'phase':'post-Link','platform':'Linux x64','scope':'Only Zfix cleaned/built/tested; existing dependencies reused','checks':checks,'sourceFiles':source,'reusedDependencies':deps,'observerBuildLog':{'path':str(audit),'sha256':digest(audit)}}
(root/'link-final-compiler-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'complete':True,'compilers':len(checks),'sourceFiles':len(source),'unchangedDependencyDSOs':len(deps)}))
