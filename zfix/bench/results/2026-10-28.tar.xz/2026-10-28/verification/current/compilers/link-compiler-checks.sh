#!/usr/bin/env bash
# Run only after all source and installed consumer jobs are terminal.
set -euo pipefail
cd /home/ubuntu/src/z
export ASAN_OPTIONS=detect_leaks=1:exitcode=99 LSAN_OPTIONS=exitcode=99
run_compiler() {
  local label=$1 site=$2
  shift 2
  CONFIG_SITE="$site" ./z.config "$@" /opt/z > "/tmp/zfix-pq-repair/$label-config.log" 2>&1
  make -C zfix clean > "/tmp/zfix-pq-repair/$label-clean.log" 2>&1
  make -C zfix -j8 > "/tmp/zfix-pq-repair/$label-build.log" 2>&1
  make -C zfix/test test > "/tmp/zfix-pq-repair/$label-unit.log" 2>&1
  make -C zfix/itest test > "/tmp/zfix-pq-repair/$label-itest.log" 2>&1
  python3 zfix/interop/matrix.py --profile smoke \
    --artifacts "/tmp/zfix-pq-repair/$label-smoke" \
    > "/tmp/zfix-pq-repair/$label-smoke.log" 2>&1
}
run_compiler link-gcc-opt /tmp/zfix-pq-repair/config-scoped-gcc-opt.site -c -d -G -P
run_compiler link-clang-opt /tmp/zfix-pq-repair/config-scoped-opt.site -L -d -G -P
make -C zfix/bench audittrace > /tmp/zfix-pq-repair/link-clang-opt-audittrace.log 2>&1
