#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path('/tmp/zfix-pq-repair');repo=Path('/home/ubuntu/src/z');bench=repo/'zfix/bench'
old=json.loads((root/'final-link-clang-opt-measurements/build-manifest.json').read_text())
source='zfix/bench/codec.hh'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pinned(p):return {'path':str(p),'sha256':digest(p)}
for name,sha in old['sourceFiles'].items():
 if name!=source:assert digest(repo/name)==sha,name
artifact=root/'codec-input-fix';artifact.mkdir(exist_ok=False)
gcc=json.loads((root/'gcc-opt-final-manifest.json').read_text())['buildFlags']
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:exitcode=99',LSAN_OPTIONS='exitcode=99')
checks=[]
for label,compiler in [('gcc','g++'),('clang','clang++')]:
 directory=artifact/label;directory.mkdir()
 for name in ['nativecodec.o','quickfixcodec-quickfixcodec.o']:(bench/name).unlink(missing_ok=True)
 command=['make','-C',str(bench),'-j8']
 if label=='gcc':command+=['CXX=g++','AM_CXXFLAGS='+gcc['Z_CXXFLAGS'],'CXXFLAGS='+gcc['CXXFLAGS'],'AM_LDFLAGS='+gcc['Z_LDFLAGS']]
 config=directory/'config.json';config.write_text(json.dumps({'scope':'Targeted benchmark-only fixture repair after complete module compiler gates; no library/protocol source changes','compiler':subprocess.check_output([compiler,'--version'],text=True),'command':command,'baselineConfiguration':pinned(root/('link-'+label+'-opt-config.log')),'flags':gcc if label=='gcc' else old['buildFlags']},indent=2)+'\n')
 log=directory/'build.log'
 with log.open('w') as out:subprocess.run(command,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
 assert not re.search(r'warning:|error:',log.read_text()),str(log)
 smoke=[]
 logs={'config':pinned(config),'build':pinned(log)}
 for engine in ['nativecodec','quickfixcodec']:
  output=directory/(engine+'.jsonl');error=directory/(engine+'.stderr')
  with output.open('w') as out,error.open('w') as err:subprocess.run([str(bench/engine),'10000','1000'],env=env,stdout=out,stderr=err,check=True)
  assert error.stat().st_size==0,str(error)
  rows=[json.loads(line) for line in output.read_text().splitlines()]
  assert len(rows)==3 and {r['shape']:r['bytes'] for r in rows}=={'scalar':170,'groups':910,'binary':4281}
  assert all(r['count']==10000 and r['warmup']==1000 for r in rows)
  logs[engine]=pinned(output);logs[engine+'Stderr']=pinned(error);smoke+=rows
 checks.append({'label':label,'compiler':subprocess.check_output([compiler,'--version'],text=True),'logs':logs,'shapes':len(smoke),'frameBytes':{'scalar':170,'groups':910,'binary':4281}})
for name in ['native_client','native_server','quickfix_client','quickfix_server']:
 p=old['programs'][name];assert digest(Path(p['elf']))==p['elfSha256'],name
for name,p in old['linkedLibraries'].items():assert digest(Path(p['resolvedPath']))==p['sha256'],name
summary={'complete':True,'phase':'post-Link-codec','source':{'path':source,'beforeSha256':old['sourceFiles'][source],'afterSha256':digest(repo/source)},'checks':checks,'protocolProgramsUnchanged':True,'linkedLibrariesUnchanged':True,'failedSnapshotPreserved':str(root/'final-link-clang-opt-measurements'),'reason':'Separate wall-clock samples plus trimmed Native FIX<-9> versus fixed QuickFIX FIX<9> precision made last frame byte lengths nondeterministic; common fixed nine-digit timestamp supplies identical inputs.'}
(root/'codec-input-fix-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'complete':True,'compilers':len(checks),'protocolProgramsUnchanged':True,'linkedLibrariesUnchanged':True}))
