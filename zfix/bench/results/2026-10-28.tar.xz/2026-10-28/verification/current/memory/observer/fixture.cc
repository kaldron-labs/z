#include <stdlib.h>
#include <string.h>
extern "C" void *__asan_memcpy(void *, const void *, size_t);
extern "C" void *__asan_memmove(void *, const void *, size_t);
extern "C" int fixture() {
  auto a = static_cast<unsigned char *>(malloc(128));
  auto b = static_cast<unsigned char *>(calloc(3, 13));
  if (!a || !b) abort();
  for (unsigned i = 0; i < 128; ++i) a[i] = i;
  a = static_cast<unsigned char *>(realloc(a, 256));
  auto c = static_cast<unsigned char *>(aligned_alloc(64, 128));
  void *aligned = nullptr; int status = posix_memalign(&aligned, 64, 192);
  auto d = static_cast<unsigned char *>(aligned);
  if (!a || !c || status || !d) abort();
  for (unsigned i = 0; i < 192; ++i) d[i] = 0;
  for (unsigned i = 0; i < 39; ++i) if (b[i]) abort();
  memcpy(c, a, 33); memmove(c + 1, c, 11);
  __asan_memcpy(d, a, 17); __asan_memmove(d + 1, d, 19);
  int bad = c[0] || c[1] || c[11] != 10 || c[32] != 32 ||
    d[0] || d[1] || d[17] != 16 || d[19];
  free(a); free(b); free(c); free(d); return bad;
}
