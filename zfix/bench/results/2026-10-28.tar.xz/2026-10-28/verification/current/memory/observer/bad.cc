#include <stdlib.h>
extern "C" int bad() {
  auto p = static_cast<unsigned char *>(malloc(32));
  if (!p) return 2;
  p[0] = 7; free(p); return *static_cast<volatile unsigned char *>(p);
}
