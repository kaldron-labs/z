extern "C" int bad();
int main() { return bad(); }
