#include <unistd.h>
extern "C" int fixture();
int main() { int result = fixture(); if (!result) write(1, "fixture PASS\n", 13); return result; }
