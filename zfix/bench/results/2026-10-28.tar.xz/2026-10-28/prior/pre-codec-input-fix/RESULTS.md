# FIX measured baseline

Build label: `clang21-O3-ZDEBUG-ASAN-existing-Clang-ASAN-dependencies`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: model name	: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -g -DZDEBUG -O3 -DNDEBUG -fsanitize=address -fno-omit-frame-pointer`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the adjacent report.md, manifest.json and case.json files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in report.md. Overload intended latency includes the delay before the bounded client can submit.

| Pair / transport / shape / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / binary / 1 | 3 | 11679.4 | 5452720 | 6575004 | 6608184 | 6608184 | 8260230 |
| native-native / tcp / fragmentation / 1 | 3 | 2813.7 | 22841687 | 37623918 | 37651644 | 37651644 | 47064555 |
| native-native / tcp / groups / 1 | 3 | 4379.1 | 11419239 | 21755764 | 21767647 | 21767647 | 27209559 |
| native-native / tcp / overload / 1 | 3 | 30607.5 | 2053409 | 2598691 | 2613152 | 69000656 | 86250820 |
| native-native / tcp / replay / 1 | 3 | 21182.2 | 2974802 | 4447719 | 4461716 | 4461716 | 5577145 |
| native-native / tcp / scalar / 1 | 3 | 26881.6 | 2314631 | 2718469 | 2739102 | 2739102 | 3423878 |
| native-native / tls / binary / 1 | 3 | 10645.4 | 6006475 | 7169159 | 7198979 | 7198979 | 8998724 |
| native-native / tls / fragmentation / 1 | 3 | 1833.9 | 33141354 | 59062365 | 59090656 | 59090656 | 73863320 |
| native-native / tls / groups / 1 | 3 | 4657.3 | 11353385 | 26249642 | 26267665 | 26267665 | 32834582 |
| native-native / tls / overload / 1 | 3 | 18669.6 | 3435555 | 3959633 | 3981910 | 109737689 | 137172112 |
| native-native / tls / replay / 1 | 3 | 16624.9 | 3728514 | 5261427 | 5272136 | 5272136 | 6590170 |
| native-native / tls / scalar / 1 | 3 | 17824.5 | 3537576 | 4170337 | 4207499 | 4207499 | 5259374 |
| native-quickfix / tcp / binary / 1 | 3 | 8236.7 | 7266680 | 10148651 | 10203622 | 10203622 | 12754528 |
| native-quickfix / tcp / fragmentation / 1 | 3 | 3308.3 | 19330703 | 31832087 | 31872684 | 31872684 | 39840855 |
| native-quickfix / tcp / groups / 1 | 3 | 1704.6 | 36057325 | 52403579 | 52411473 | 52411473 | 65514342 |
| native-quickfix / tcp / overload / 1 | 3 | 20590.1 | 3063690 | 4828142 | 4858330 | 122665880 | 153332350 |
| native-quickfix / tcp / replay / 1 | 3 | 21428.6 | 2892005 | 3744521 | 3748567 | 3748567 | 4685709 |
| native-quickfix / tcp / scalar / 1 | 3 | 16899.3 | 3834000 | 5111038 | 5130813 | 5130813 | 6413517 |
| native-quickfix / tls / binary / 1 | 3 | 7332.4 | 8946102 | 10608141 | 10672854 | 10672854 | 13341068 |
| native-quickfix / tls / fragmentation / 1 | 3 | 2090.6 | 30372461 | 42419444 | 42451964 | 42451964 | 53064955 |
| native-quickfix / tls / groups / 1 | 3 | 1658.6 | 37256154 | 58845294 | 58861592 | 58861592 | 73576990 |
| native-quickfix / tls / overload / 1 | 3 | 15650.1 | 4208472 | 5089880 | 5121857 | 133539753 | 166924692 |
| native-quickfix / tls / replay / 1 | 3 | 15523.0 | 4011641 | 5644487 | 5680205 | 5680205 | 7100257 |
| native-quickfix / tls / scalar / 1 | 3 | 16140.2 | 3711836 | 5021992 | 5064850 | 5064850 | 6331063 |
| quickfix-native / tcp / binary / 1 | 3 | 8262.7 | 7547926 | 8547917 | 8596100 | 8596100 | 10745125 |
| quickfix-native / tcp / fragmentation / 1 | 3 | 2919.8 | 22471231 | 35675921 | 35751094 | 35751094 | 44688868 |
| quickfix-native / tcp / groups / 1 | 3 | 892.3 | 71995104 | 82788477 | 82792034 | 82792034 | 103490043 |
| quickfix-native / tcp / overload / 1 | 3 | 13777.6 | 4910413 | 5414422 | 5444192 | 149216242 | 186520303 |
| quickfix-native / tcp / replay / 1 | 3 | 12471.0 | 4956025 | 7795385 | 7865962 | 7865962 | 9832453 |
| quickfix-native / tcp / scalar / 1 | 3 | 12526.6 | 5034949 | 5569364 | 5614614 | 5614614 | 7018268 |
| quickfix-native / tls / binary / 1 | 3 | 6555.9 | 9290689 | 10929990 | 11009125 | 11009125 | 13761407 |
| quickfix-native / tls / fragmentation / 1 | 3 | 1787.1 | 35914306 | 54866781 | 55006191 | 55006191 | 68757739 |
| quickfix-native / tls / groups / 1 | 3 | 868.9 | 73504343 | 87935711 | 87938177 | 87938177 | 109922722 |
| quickfix-native / tls / overload / 1 | 3 | 10648.9 | 6154878 | 7836379 | 7898529 | 196284704 | 245355880 |
| quickfix-native / tls / replay / 1 | 3 | 11153.0 | 5732625 | 8767751 | 8826510 | 8826510 | 11033138 |
| quickfix-native / tls / scalar / 1 | 3 | 11216.6 | 5225722 | 7252296 | 7284044 | 7284044 | 9105055 |
| quickfix-quickfix / tcp / binary / 1 | 3 | 7854.0 | 7425592 | 10143832 | 10209907 | 10209907 | 12762384 |
| quickfix-quickfix / tcp / fragmentation / 1 | 3 | 3197.6 | 19789043 | 33876467 | 33926989 | 33926989 | 42408737 |
| quickfix-quickfix / tcp / groups / 1 | 3 | 918.7 | 70021864 | 76670188 | 76674113 | 76674113 | 95842642 |
| quickfix-quickfix / tcp / overload / 1 | 3 | 13627.6 | 5025539 | 5780920 | 5834481 | 161024985 | 201281232 |
| quickfix-quickfix / tcp / replay / 1 | 3 | 13334.1 | 4861753 | 7548394 | 7591736 | 7591736 | 9489670 |
| quickfix-quickfix / tcp / scalar / 1 | 3 | 17695.8 | 3552840 | 4052344 | 4075274 | 4075274 | 5094093 |
| quickfix-quickfix / tls / binary / 1 | 3 | 7453.8 | 8315219 | 11245934 | 11325973 | 11325973 | 14157467 |
| quickfix-quickfix / tls / fragmentation / 1 | 3 | 1981.5 | 32309749 | 51136838 | 51184970 | 51184970 | 63981213 |
| quickfix-quickfix / tls / groups / 1 | 3 | 904.4 | 71270741 | 77861451 | 77863288 | 77863288 | 97329110 |
| quickfix-quickfix / tls / overload / 1 | 3 | 12944.4 | 4787835 | 6884230 | 6935606 | 175578978 | 219473723 |
| quickfix-quickfix / tls / replay / 1 | 3 | 12964.1 | 4776660 | 10262468 | 10337336 | 10337336 | 12921670 |
| quickfix-quickfix / tls / scalar / 1 | 3 | 13716.0 | 4638678 | 6018907 | 6056758 | 6056758 | 7570948 |

## Standalone codec

Per-call encode includes typed body and full FIX framing; decode includes framing/checksum, typed construction and validation. QuickFIX also applies its canonical dictionary validation. Native reuses its output backing; QuickFIX constructs its SDK message and returns its SDK string. QuickFIX decode includes its input string and selected-field arena copies; Native decoded spans borrow input. These ownership costs are included. Clock-pair overhead is reported separately without subtraction.

| Engine / shape | Runs | Frame bytes | Encode p50 median ns | Encode p99 worst ns | Decode p50 median ns | Decode p99 worst ns | Clock p50 median ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix / binary | 3 | 4281 | 16203 | 43389 | 20086 | 45776 | 41 |
| quickfix / groups | 3 | 910 | 120795 | 160249 | 78200 | 106152 | 41 |
| quickfix / scalar | 3 | 170 | 11004 | 28068 | 14396 | 33943 | 41 |
| zfix / binary | 3 | 4281 | 5071 | 8628 | 2627 | 4322 | 40 |
| zfix / groups | 3 | 908 | 16883 | 31546 | 29947 | 58808 | 41 |
| zfix / scalar | 3 | 170 | 3944 | 5194 | 1739 | 2188 | 40 |

Raw artifacts: `/tmp/zfix-pq-repair/final-link-clang-opt-measurements/process`.
