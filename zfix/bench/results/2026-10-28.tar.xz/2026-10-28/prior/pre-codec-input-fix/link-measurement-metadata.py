#!/usr/bin/env python3
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace

repo = Path('/home/ubuntu/src/z')
run_dir = Path(sys.argv[1])
assert not os.environ.get('LD_PRELOAD') and not os.environ.get('LD_AUDIT')
spec = importlib.util.spec_from_file_location('measurement_load', repo / 'zfix/bench/load.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
options = SimpleNamespace(
    build_label='clang21-O3-ZDEBUG-ASAN-existing-Clang-ASAN-dependencies',
    dictionary=Path('/tmp/zfix-qf-patch-review/sdk-asan/install/share/quickfix/FIX44.xml'),
    audittrace=repo / 'zfix/bench/audittrace.so', heaptrace=None)
programs = {name: repo / path for name, path in {
    'native_client': 'zfix/util/zfix', 'native_server': 'zfix/util/zfixd',
    'quickfix_client': 'zfix/interop/quickfix', 'quickfix_server': 'zfix/interop/quickfixd',
    'native_codec': 'zfix/bench/nativecodec', 'quickfix_codec': 'zfix/bench/quickfixcodec',
}.items()}
manifest = m.metadata(options, m.load_pair(), programs)
manifest['configure'] = {
    'argv': ['./z.config', '-L', '-d', '-G', '-P', '/opt/z'],
    'CONFIG_SITE': '/tmp/zfix-pq-repair/config-scoped-opt.site',
    'siteSha256': m.load_pair().digest(Path('/tmp/zfix-pq-repair/config-scoped-opt.site')),
    'buildScope': 'scoped Clang optimized configuration; post-Link clean zfix-only rebuild after the current GCC gate; existing dependencies unchanged'}
manifest['runtimeEnvironment'] = {key: os.environ[key] for key in ('ASAN_OPTIONS', 'LSAN_OPTIONS')}
manifest['codecCommands'] = [
    {'argv': [str(programs[name]), '10000', '1000'], 'repeat': repeat,
     'stdout': f'{engine}-{repeat}.jsonl', 'stderr': f'{engine}-{repeat}.log'}
    for repeat in (1, 2, 3)
    for name, engine in (('native_codec', 'nativecodec'), ('quickfix_codec', 'quickfixcodec'))]
manifest['measurementPhase'] = 'post-Link'
prior = Path('/tmp/zfix-pq-repair/final-clang-opt-measurements/build-manifest.json')
manifest['priorSnapshot'] = {
    'manifest': str(prior),
    'manifestSha256': hashlib.sha256(prior.read_bytes()).hexdigest(),
    'note': 'Historical pre-Link snapshot, retained separately; no timing samples are reused'}
(run_dir / 'build-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
