#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/src/z
run_dir=/tmp/zfix-pq-repair/final-link-clang-opt-measurements
if [[ -e "$run_dir" ]]; then
  printf 'preserving existing measurement directory: %s\n' "$run_dir" >&2
  exit 2
fi
mkdir "$run_dir"
export ASAN_OPTIONS=detect_leaks=1:exitcode=99
export LSAN_OPTIONS=exitcode=99
python3 /tmp/zfix-pq-repair/link-measurement-metadata.py "$run_dir"
for repeat in 1 2 3; do
  ./zfix/bench/nativecodec 10000 1000 > "$run_dir/nativecodec-$repeat.jsonl" 2> "$run_dir/nativecodec-$repeat.log"
  ./zfix/bench/quickfixcodec 10000 1000 > "$run_dir/quickfixcodec-$repeat.jsonl" 2> "$run_dir/quickfixcodec-$repeat.log"
done
python3 zfix/bench/load.py \
  --dictionary /tmp/zfix-qf-patch-review/sdk-asan/install/share/quickfix/FIX44.xml \
  --artifacts "$run_dir/process" --count 2000 --warmup 200 --inflight 64 --repeat 3 \
  --framework-heaps --audittrace /home/ubuntu/src/z/zfix/bench/audittrace.so \
  --build-label clang21-O3-ZDEBUG-ASAN-existing-Clang-ASAN-dependencies \
  > "$run_dir/load.jsonl" 2> "$run_dir/load.log"
python3 zfix/bench/results.py "$run_dir/process" \
  --codec "$run_dir/nativecodec-1.jsonl" --codec "$run_dir/nativecodec-2.jsonl" \
  --codec "$run_dir/nativecodec-3.jsonl" --codec "$run_dir/quickfixcodec-1.jsonl" \
  --codec "$run_dir/quickfixcodec-2.jsonl" --codec "$run_dir/quickfixcodec-3.jsonl" \
  --output "$run_dir/RESULTS.md"
