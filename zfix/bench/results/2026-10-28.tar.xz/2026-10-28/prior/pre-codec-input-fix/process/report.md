# FIX process load measurements

Build label: clang21-O3-ZDEBUG-ASAN-existing-Clang-ASAN-dependencies. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Orders/s is the sum of per-session rates, rather than a shared global interval. Session quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Mode | Status | Complete / unfinished | Errors / bad exits / timeouts | Orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 26881.633 | 0.317364 / 71786496 | 0.344843 / 72687616 |
| native-native / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 17220.628 | 0.403787 / 75554816 | 0.447414 / 76095488 |
| native-native / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 32436.633 | 0.292876 / 71774208 | 0.316097 / 72556544 |
| native-native / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 16592.678 | 0.411797 / 75423744 | 0.447802 / 76087296 |
| native-native / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 26727.065 | 0.314090 / 71569408 | 0.341121 / 72781824 |
| native-native / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 16272.883 | 0.409014 / 75296768 | 0.454187 / 75816960 |
| native-native / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4579.589 | 0.622172 / 152502272 | 0.837870 / 424001536 |
| native-native / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2203.004 | 0.967707 / 156831744 | 1.452400 / 427470848 |
| native-native / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4328.806 | 0.635717 / 152498176 | 0.888585 / 425439232 |
| native-native / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2217.239 | 1.006376 / 156102656 | 1.428605 / 427696128 |
| native-native / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4379.092 | 0.640840 / 152403968 | 0.850322 / 424148992 |
| native-native / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2265.411 | 0.937794 / 156131328 | 1.395376 / 427765760 |
| native-native / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11951.872 | 0.545400 / 199311360 | 0.593784 / 209256448 |
| native-native / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8489.529 | 0.639369 / 203583488 | 0.726382 / 212832256 |
| native-native / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10467.008 | 0.561334 / 199806976 | 0.617566 / 209154048 |
| native-native / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8618.665 | 0.651092 / 203366400 | 0.712575 / 212733952 |
| native-native / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11679.359 | 0.547171 / 198733824 | 0.588948 / 209350656 |
| native-native / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8598.117 | 0.641773 / 202928128 | 0.719800 / 212549632 |
| native-native / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3048.376 | 0.496014 / 194584576 | 1.461250 / 348860416 |
| native-native / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2561.338 | 0.654639 / 199180288 | 1.768108 / 373223424 |
| native-native / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2610.147 | 0.507259 / 194711552 | 1.627022 / 375021568 |
| native-native / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2699.928 | 0.628911 / 198180864 | 1.709354 / 373456896 |
| native-native / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2813.723 | 0.568082 / 197222400 | 1.497899 / 354729984 |
| native-native / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2818.336 | 0.619771 / 197849088 | 1.702093 / 371470336 |
| native-native / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 19899.069 | 0.297177 / 72134656 | 0.341120 / 72892416 |
| native-native / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 14298.685 | 0.433269 / 75591680 | 0.489469 / 75878400 |
| native-native / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 21607.207 | 0.295408 / 72278016 | 0.320382 / 72663040 |
| native-native / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13418.109 | 0.439546 / 75251712 | 0.476972 / 75780096 |
| native-native / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 21182.179 | 0.304547 / 71979008 | 0.324460 / 72527872 |
| native-native / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12271.650 | 0.429781 / 75366400 | 0.508094 / 75816960 |
| native-native / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 30607.533 | 0.296711 / 71798784 | 0.317199 / 72491008 |
| native-native / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 16368.343 | 0.405017 / 75067392 | 0.451257 / 75911168 |
| native-native / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 31062.384 | 0.299054 / 71602176 | 0.313421 / 72273920 |
| native-native / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 16966.319 | 0.404387 / 75325440 | 0.442528 / 75771904 |
| native-native / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 28018.187 | 0.305405 / 72105984 | 0.346293 / 72794112 |
| native-native / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 16987.060 | 0.405793 / 75354112 | 0.445077 / 75857920 |
| native-native / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 18447.998 | 0.403868 / 111525888 | 0.444135 / 146616320 |
| native-native / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13079.156 | 0.499188 / 114085888 | 0.560049 / 149868544 |
| native-native / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16893.215 | 0.397598 / 111407104 | 0.453956 / 146608128 |
| native-native / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13506.210 | 0.493178 / 114450432 | 0.562835 / 149483520 |
| native-native / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17824.460 | 0.403744 / 111075328 | 0.448720 / 146333696 |
| native-native / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13642.343 | 0.496006 / 114053120 | 0.546393 / 149245952 |
| native-native / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4657.285 | 0.687687 / 192385024 | 0.908437 / 382590976 |
| native-native / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2302.239 | 1.033245 / 195518464 | 1.435012 / 385839104 |
| native-native / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4732.427 | 0.708274 / 192475136 | 0.897809 / 383504384 |
| native-native / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2269.176 | 1.061889 / 195682304 | 1.465737 / 385708032 |
| native-native / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4464.160 | 0.725472 / 192442368 | 0.925305 / 383025152 |
| native-native / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2195.934 | 1.091290 / 195870720 | 1.493702 / 385892352 |
| native-native / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10436.978 | 0.603733 / 211894272 | 0.688117 / 261382144 |
| native-native / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8368.470 | 0.711348 / 216100864 | 0.840877 / 264896512 |
| native-native / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10649.915 | 0.594152 / 212955136 | 0.674718 / 261373952 |
| native-native / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8683.035 | 0.681355 / 213700608 | 0.806758 / 264134656 |
| native-native / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10645.442 | 0.605169 / 212996096 | 0.687165 / 261525504 |
| native-native / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8133.157 | 0.693675 / 210608128 | 0.826230 / 264400896 |
| native-native / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1833.945 | 0.636274 / 264634368 | 2.101282 / 365068288 |
| native-native / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1757.125 | 0.730840 / 268328960 | 2.370278 / 367939584 |
| native-native / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1762.817 | 0.632715 / 266006528 | 2.136438 / 364572672 |
| native-native / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1807.558 | 0.741384 / 268988416 | 2.337334 / 367960064 |
| native-native / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1871.188 | 0.641852 / 264876032 | 2.063775 / 365150208 |
| native-native / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1741.778 | 0.722613 / 268537856 | 2.387298 / 368144384 |
| native-native / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16624.931 | 0.372404 / 111321088 | 0.418175 / 146472960 |
| native-native / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10951.820 | 0.487852 / 114651136 | 0.622355 / 149676032 |
| native-native / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16952.316 | 0.375365 / 111439872 | 0.421200 / 146690048 |
| native-native / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10718.986 | 0.499214 / 114589696 | 0.633620 / 149643264 |
| native-native / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16324.397 | 0.368366 / 111112192 | 0.428265 / 146534400 |
| native-native / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11274.272 | 0.512797 / 114585600 | 0.615530 / 149516288 |
| native-native / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 19530.567 | 0.392005 / 111206400 | 0.434568 / 146558976 |
| native-native / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13088.383 | 0.490966 / 114548736 | 0.583938 / 149753856 |
| native-native / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17757.841 | 0.396573 / 110960640 | 0.447942 / 146407424 |
| native-native / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12845.262 | 0.502031 / 114364416 | 0.569324 / 149315584 |
| native-native / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 18669.607 | 0.390153 / 110972928 | 0.437007 / 146624512 |
| native-native / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13333.347 | 0.487083 / 114356224 | 0.553444 / 149590016 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 18288.012 | 0.327620 / 71974912 | 0.394750 / 115638272 |
| native-quickfix / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12471.456 | 0.429627 / 75538432 | 0.597516 / 118317056 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15949.148 | 0.330874 / 71860224 | 0.424299 / 115437568 |
| native-quickfix / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12044.886 | 0.420715 / 75735040 | 0.575661 / 118820864 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16899.277 | 0.334511 / 72110080 | 0.419887 / 115638272 |
| native-quickfix / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11942.061 | 0.432310 / 75632640 | 0.600443 / 118984704 |
| native-quickfix / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1704.597 | 0.667198 / 153501696 | 1.773425 / 427388928 |
| native-quickfix / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 916.650 | 1.023324 / 155136000 | 3.096865 / 430981120 |
| native-quickfix / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1712.253 | 0.644890 / 153038848 | 1.769059 / 427655168 |
| native-quickfix / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 949.441 | 1.006104 / 156565504 | 2.950024 / 430845952 |
| native-quickfix / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1631.666 | 0.672862 / 152834048 | 1.871375 / 427794432 |
| native-quickfix / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 966.570 | 0.997965 / 156602368 | 2.901019 / 431173632 |
| native-quickfix / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 8588.488 | 0.569680 / 200138752 | 0.645827 / 379047936 |
| native-quickfix / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6285.704 | 0.692639 / 203694080 | 0.893348 / 382246912 |
| native-quickfix / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7860.821 | 0.570630 / 199659520 | 0.682549 / 378953728 |
| native-quickfix / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6883.507 | 0.667446 / 203358208 | 0.845039 / 382033920 |
| native-quickfix / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 8236.664 | 0.560234 / 200228864 | 0.639245 / 378949632 |
| native-quickfix / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6302.952 | 0.673570 / 203448320 | 0.868134 / 381792256 |
| native-quickfix / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3458.959 | 0.496903 / 194166784 | 1.065244 / 394792960 |
| native-quickfix / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3520.013 | 0.636005 / 197271552 | 1.202530 / 389808128 |
| native-quickfix / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3308.338 | 0.497757 / 193863680 | 1.069403 / 396857344 |
| native-quickfix / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3147.892 | 0.651331 / 198086656 | 1.272513 / 394428416 |
| native-quickfix / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2999.715 | 0.543996 / 197214208 | 1.094539 / 397889536 |
| native-quickfix / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3391.775 | 0.572295 / 197447680 | 1.238675 / 392536064 |
| native-quickfix / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 21428.572 | 0.308129 / 72142848 | 0.389453 / 115183616 |
| native-quickfix / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10093.573 | 0.457995 / 75522048 | 0.650204 / 119107584 |
| native-quickfix / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 21213.234 | 0.305760 / 72007680 | 0.373940 / 115191808 |
| native-quickfix / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10278.415 | 0.452643 / 75468800 | 0.607493 / 118730752 |
| native-quickfix / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 21849.283 | 0.306160 / 72155136 | 0.369871 / 115142656 |
| native-quickfix / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9485.424 | 0.447597 / 75116544 | 0.661163 / 119062528 |
| native-quickfix / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 20590.105 | 0.325480 / 72044544 | 0.390123 / 115486720 |
| native-quickfix / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10660.377 | 0.433792 / 75149312 | 0.603880 / 118747136 |
| native-quickfix / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15931.529 | 0.340531 / 71708672 | 0.414423 / 115478528 |
| native-quickfix / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10944.468 | 0.421764 / 75214848 | 0.603549 / 118943744 |
| native-quickfix / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 20965.189 | 0.322343 / 71950336 | 0.384156 / 115511296 |
| native-quickfix / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11441.658 | 0.417371 / 75399168 | 0.588694 / 118890496 |
| native-quickfix / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17704.422 | 0.403879 / 111013888 | 0.462478 / 124858368 |
| native-quickfix / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9315.081 | 0.509219 / 114511872 | 0.706257 / 128049152 |
| native-quickfix / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14652.344 | 0.408425 / 111435776 | 0.456794 / 125255680 |
| native-quickfix / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10230.795 | 0.510321 / 114311168 | 0.690807 / 128229376 |
| native-quickfix / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16140.199 | 0.402511 / 111394816 | 0.469397 / 125050880 |
| native-quickfix / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10255.291 | 0.499305 / 114393088 | 0.666601 / 128241664 |
| native-quickfix / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1659.437 | 0.742719 / 192253952 | 1.849836 / 435781632 |
| native-quickfix / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 925.514 | 1.100145 / 195907584 | 3.094313 / 439320576 |
| native-quickfix / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1605.872 | 0.799180 / 192561152 | 1.903430 / 435965952 |
| native-quickfix / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 931.119 | 1.124867 / 196034560 | 3.082082 / 438849536 |
| native-quickfix / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1658.641 | 0.725347 / 192716800 | 1.869194 / 436137984 |
| native-quickfix / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 921.992 | 1.101313 / 195858432 | 3.091669 / 439242752 |
| native-quickfix / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7332.356 | 0.563821 / 207958016 | 0.721949 / 389488640 |
| native-quickfix / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5204.337 | 0.704882 / 217714688 | 1.005158 / 392318976 |
| native-quickfix / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7745.793 | 0.598694 / 209883136 | 0.732754 / 388980736 |
| native-quickfix / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5593.734 | 0.657173 / 221184000 | 0.973687 / 392482816 |
| native-quickfix / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 6423.542 | 0.595648 / 213618688 | 0.767592 / 389603328 |
| native-quickfix / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6221.439 | 0.651863 / 210571264 | 0.912389 / 392667136 |
| native-quickfix / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2187.926 | 0.642158 / 260030464 | 1.551274 / 436600832 |
| native-quickfix / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1206.349 | 0.730957 / 218009600 | 2.533415 / 439795712 |
| native-quickfix / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2087.183 | 0.642235 / 247525376 | 1.595080 / 436436992 |
| native-quickfix / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1289.841 | 0.672231 / 219115520 | 2.418777 / 439455744 |
| native-quickfix / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2090.576 | 0.609263 / 253263872 | 1.615761 / 436527104 |
| native-quickfix / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1268.227 | 0.656572 / 213676032 | 2.442302 / 439697408 |
| native-quickfix / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13362.578 | 0.379647 / 110989312 | 0.513124 / 124985344 |
| native-quickfix / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9017.384 | 0.529605 / 114544640 | 0.726829 / 128253952 |
| native-quickfix / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 18346.960 | 0.381878 / 111472640 | 0.456242 / 124952576 |
| native-quickfix / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10503.602 | 0.504349 / 114339840 | 0.667490 / 128446464 |
| native-quickfix / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15523.004 | 0.389978 / 110948352 | 0.468258 / 125095936 |
| native-quickfix / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8031.974 | 0.549484 / 114233344 | 0.762837 / 128290816 |
| native-quickfix / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17666.556 | 0.390572 / 111362048 | 0.448145 / 125132800 |
| native-quickfix / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8282.340 | 0.510519 / 114835456 | 0.748567 / 128057344 |
| native-quickfix / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14648.878 | 0.411473 / 110874624 | 0.460684 / 125022208 |
| native-quickfix / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9238.285 | 0.498144 / 114606080 | 0.709257 / 128180224 |
| native-quickfix / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15650.060 | 0.400095 / 111194112 | 0.448121 / 124702720 |
| native-quickfix / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9984.882 | 0.503854 / 114597888 | 0.692628 / 128475136 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15241.978 | 0.440244 / 123256832 | 0.367558 / 72609792 |
| quickfix-native / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7041.915 | 0.719318 / 126902272 | 0.464435 / 75821056 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12219.547 | 0.465391 / 123465728 | 0.379809 / 72556544 |
| quickfix-native / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7260.578 | 0.709539 / 126951424 | 0.502212 / 75718656 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12526.611 | 0.486447 / 123547648 | 0.369015 / 72445952 |
| quickfix-native / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8124.650 | 0.674876 / 126705664 | 0.470219 / 75743232 |
| quickfix-native / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 874.626 | 3.126490 / 437592064 | 1.033229 / 423923712 |
| quickfix-native / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 533.485 | 5.017975 / 440745984 | 1.622249 / 427429888 |
| quickfix-native / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 892.290 | 3.032798 / 437284864 | 0.994855 / 423952384 |
| quickfix-native / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 529.849 | 5.057312 / 440762368 | 1.615170 / 427511808 |
| quickfix-native / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 900.311 | 3.053064 / 437186560 | 0.989107 / 423395328 |
| quickfix-native / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 527.832 | 5.033414 / 440676352 | 1.630648 / 427388928 |
| quickfix-native / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 8262.678 | 0.680527 / 361623552 | 0.580924 / 209379328 |
| quickfix-native / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5129.386 | 0.954979 / 365199360 | 0.715646 / 212062208 |
| quickfix-native / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 8531.987 | 0.664545 / 361492480 | 0.578816 / 209498112 |
| quickfix-native / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5339.918 | 0.978724 / 365072384 | 0.698883 / 212791296 |
| quickfix-native / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7814.716 | 0.700950 / 361742336 | 0.587487 / 208891904 |
| quickfix-native / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4828.514 | 1.004945 / 364965888 | 0.688910 / 212385792 |
| quickfix-native / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2919.797 | 0.761534 / 361127936 | 1.503612 / 357834752 |
| quickfix-native / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2453.741 | 1.216368 / 364822528 | 1.806868 / 380280832 |
| quickfix-native / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2961.745 | 0.766815 / 360996864 | 1.515369 / 356687872 |
| quickfix-native / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2647.615 | 1.124680 / 364978176 | 1.729530 / 361627648 |
| quickfix-native / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2860.885 | 0.813670 / 361369600 | 1.523851 / 351272960 |
| quickfix-native / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2844.021 | 1.065225 / 365027328 | 1.656363 / 348786688 |
| quickfix-native / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12143.570 | 0.472636 / 123936768 | 0.416043 / 72785920 |
| quickfix-native / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6902.800 | 0.748026 / 126791680 | 0.500571 / 75857920 |
| quickfix-native / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13200.700 | 0.484055 / 123658240 | 0.367319 / 72134656 |
| quickfix-native / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7004.905 | 0.727783 / 126767104 | 0.528303 / 75943936 |
| quickfix-native / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12471.038 | 0.472226 / 123666432 | 0.411328 / 72409088 |
| quickfix-native / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6232.672 | 0.764508 / 127221760 | 0.566733 / 76247040 |
| quickfix-native / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13777.614 | 0.470242 / 123711488 | 0.381317 / 72077312 |
| quickfix-native / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7587.989 | 0.706808 / 126672896 | 0.504058 / 75509760 |
| quickfix-native / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13113.305 | 0.477665 / 123564032 | 0.365959 / 72388608 |
| quickfix-native / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6779.409 | 0.750710 / 126656512 | 0.488987 / 75800576 |
| quickfix-native / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14365.704 | 0.448909 / 123842560 | 0.372512 / 72249344 |
| quickfix-native / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7439.048 | 0.709304 / 126922752 | 0.486049 / 75603968 |
| quickfix-native / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11216.583 | 0.546249 / 137891840 | 0.485372 / 146472960 |
| quickfix-native / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6260.255 | 0.844155 / 140681216 | 0.599844 / 149323776 |
| quickfix-native / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11094.673 | 0.557221 / 137773056 | 0.478666 / 146644992 |
| quickfix-native / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6464.597 | 0.842239 / 141017088 | 0.587418 / 149528576 |
| quickfix-native / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11812.870 | 0.545916 / 137883648 | 0.489759 / 146034688 |
| quickfix-native / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6078.236 | 0.855976 / 141139968 | 0.583920 / 149663744 |
| quickfix-native / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 868.881 | 3.267381 / 448565248 | 0.997335 / 381689856 |
| quickfix-native / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 531.780 | 5.120267 / 451665920 | 1.696840 / 384671744 |
| quickfix-native / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 887.572 | 3.136789 / 448499712 | 0.977616 / 381747200 |
| quickfix-native / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 529.648 | 5.198872 / 451710976 | 1.668722 / 385069056 |
| quickfix-native / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 851.401 | 3.357776 / 448229376 | 1.060151 / 381714432 |
| quickfix-native / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 516.865 | 5.206242 / 451538944 | 1.730732 / 385003520 |
| quickfix-native / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 6332.167 | 0.828387 / 376643584 | 0.663791 / 260976640 |
| quickfix-native / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4566.442 | 1.086122 / 380108800 | 0.727166 / 261341184 |
| quickfix-native / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7144.664 | 0.789882 / 376905728 | 0.637642 / 259219456 |
| quickfix-native / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4839.137 | 1.046120 / 380317696 | 0.729880 / 261627904 |
| quickfix-native / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 6555.870 | 0.821611 / 376619008 | 0.624373 / 260292608 |
| quickfix-native / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4342.238 | 1.115655 / 379797504 | 0.771899 / 263036928 |
| quickfix-native / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1795.737 | 0.849137 / 376856576 | 2.155265 / 365060096 |
| quickfix-native / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1759.120 | 1.295155 / 379981824 | 2.350525 / 367771648 |
| quickfix-native / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1787.052 | 0.864904 / 376553472 | 2.168105 / 364724224 |
| quickfix-native / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1661.157 | 1.249520 / 379617280 | 2.473797 / 367685632 |
| quickfix-native / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1727.293 | 0.875990 / 376725504 | 2.185113 / 364625920 |
| quickfix-native / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1776.693 | 1.208344 / 379928576 | 2.372031 / 368001024 |
| quickfix-native / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 9476.269 | 0.591594 / 138637312 | 0.529003 / 147664896 |
| quickfix-native / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6034.126 | 0.888452 / 141430784 | 0.594077 / 150425600 |
| quickfix-native / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11298.824 | 0.555803 / 138006528 | 0.473034 / 147677184 |
| quickfix-native / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5610.230 | 0.889233 / 141381632 | 0.607407 / 150118400 |
| quickfix-native / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11152.973 | 0.549354 / 138027008 | 0.486365 / 147533824 |
| quickfix-native / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6235.971 | 0.862063 / 141168640 | 0.595035 / 150126592 |
| quickfix-native / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11735.398 | 0.555532 / 138194944 | 0.479989 / 146489344 |
| quickfix-native / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6392.716 | 0.830141 / 141029376 | 0.590177 / 149639168 |
| quickfix-native / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10015.058 | 0.595283 / 137723904 | 0.506679 / 146116608 |
| quickfix-native / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6188.258 | 0.840632 / 141135872 | 0.573334 / 149504000 |
| quickfix-native / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10648.851 | 0.573405 / 137408512 | 0.446813 / 146530304 |
| quickfix-native / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6277.554 | 0.835949 / 140922880 | 0.599721 / 149606400 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17695.808 | 0.416045 / 122699776 | 0.395154 / 114933760 |
| quickfix-quickfix / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9045.003 | 0.634408 / 126029824 | 0.575443 / 118120448 |
| quickfix-quickfix / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17801.900 | 0.419755 / 122744832 | 0.398608 / 114855936 |
| quickfix-quickfix / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8944.606 | 0.643156 / 126091264 | 0.582442 / 118464512 |
| quickfix-quickfix / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17101.893 | 0.408035 / 122662912 | 0.391277 / 115204096 |
| quickfix-quickfix / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8992.429 | 0.636663 / 126078976 | 0.634861 / 118259712 |
| quickfix-quickfix / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 918.696 | 3.076534 / 436473856 | 2.035086 / 427397120 |
| quickfix-quickfix / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 538.942 | 4.970219 / 439906304 | 3.248244 / 431153152 |
| quickfix-quickfix / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 925.911 | 3.030934 / 436547584 | 1.949872 / 428228608 |
| quickfix-quickfix / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 524.824 | 5.101490 / 439853056 | 3.290111 / 430886912 |
| quickfix-quickfix / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 911.707 | 3.053040 / 436703232 | 1.984992 / 428040192 |
| quickfix-quickfix / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 522.188 | 5.157138 / 440090624 | 3.307651 / 430686208 |
| quickfix-quickfix / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7853.970 | 0.680030 / 361975808 | 0.672303 / 365654016 |
| quickfix-quickfix / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5593.189 | 0.904955 / 364347392 | 0.849757 / 368693248 |
| quickfix-quickfix / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7832.242 | 0.685835 / 360579072 | 0.639512 / 365490176 |
| quickfix-quickfix / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5525.503 | 0.935977 / 364544000 | 0.836171 / 369131520 |
| quickfix-quickfix / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 8168.240 | 0.688024 / 360841216 | 0.637142 / 365400064 |
| quickfix-quickfix / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5620.959 | 0.917166 / 364367872 | 0.862705 / 368902144 |
| quickfix-quickfix / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3252.874 | 0.716905 / 361070592 | 1.150135 / 380870656 |
| quickfix-quickfix / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2772.502 | 1.087438 / 363954176 | 1.335812 / 384454656 |
| quickfix-quickfix / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2806.744 | 0.803732 / 360439808 | 1.132277 / 386392064 |
| quickfix-quickfix / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3317.827 | 0.973133 / 364404736 | 1.311163 / 381534208 |
| quickfix-quickfix / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3197.625 | 0.752785 / 360882176 | 1.108610 / 384790528 |
| quickfix-quickfix / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2703.298 | 0.952021 / 364519424 | 1.459114 / 385789952 |
| quickfix-quickfix / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13334.068 | 0.462708 / 123650048 | 0.428526 / 115347456 |
| quickfix-quickfix / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8588.711 | 0.689297 / 126029824 | 0.651145 / 118239232 |
| quickfix-quickfix / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16778.055 | 0.442277 / 122900480 | 0.420185 / 115122176 |
| quickfix-quickfix / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8941.798 | 0.633835 / 126668800 | 0.678113 / 118550528 |
| quickfix-quickfix / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12842.498 | 0.437250 / 124497920 | 0.455555 / 115531776 |
| quickfix-quickfix / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8740.651 | 0.650378 / 126402560 | 0.696443 / 118562816 |
| quickfix-quickfix / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17024.461 | 0.404451 / 122654720 | 0.388646 / 115146752 |
| quickfix-quickfix / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8418.249 | 0.663591 / 125878272 | 0.597455 / 118284288 |
| quickfix-quickfix / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12180.772 | 0.470151 / 122732544 | 0.430774 / 115351552 |
| quickfix-quickfix / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9076.805 | 0.627825 / 125865984 | 0.579594 / 118247424 |
| quickfix-quickfix / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13627.631 | 0.451286 / 122937344 | 0.437948 / 115122176 |
| quickfix-quickfix / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9034.134 | 0.636488 / 125788160 | 0.598142 / 118579200 |
| quickfix-quickfix / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14004.736 | 0.495682 / 136617984 | 0.450352 / 124375040 |
| quickfix-quickfix / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7047.833 | 0.789728 / 140255232 | 0.690100 / 127520768 |
| quickfix-quickfix / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11652.518 | 0.562402 / 137252864 | 0.466056 / 124260352 |
| quickfix-quickfix / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7155.731 | 0.789357 / 140304384 | 0.709297 / 127504384 |
| quickfix-quickfix / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13715.971 | 0.514299 / 136986624 | 0.458554 / 124436480 |
| quickfix-quickfix / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7309.897 | 0.792993 / 140152832 | 0.716612 / 127651840 |
| quickfix-quickfix / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 909.439 | 3.160251 / 448024576 | 2.042877 / 435572736 |
| quickfix-quickfix / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 500.615 | 5.416982 / 451555328 | 3.487806 / 438882304 |
| quickfix-quickfix / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 904.372 | 3.132249 / 448315392 | 2.047949 / 435458048 |
| quickfix-quickfix / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 528.975 | 5.185378 / 451555328 | 3.515636 / 438681600 |
| quickfix-quickfix / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 901.860 | 3.189737 / 448724992 | 2.114871 / 435613696 |
| quickfix-quickfix / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 512.998 | 5.316372 / 451870720 | 3.492700 / 438628352 |
| quickfix-quickfix / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7453.772 | 0.764231 / 376229888 | 0.691967 / 376254464 |
| quickfix-quickfix / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5006.708 | 1.044210 / 379699200 | 0.921126 / 379207680 |
| quickfix-quickfix / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7501.267 | 0.785383 / 376336384 | 0.713958 / 376066048 |
| quickfix-quickfix / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4861.515 | 1.053415 / 379555840 | 0.964385 / 378834944 |
| quickfix-quickfix / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7157.861 | 0.773865 / 376492032 | 0.695213 / 375730176 |
| quickfix-quickfix / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5046.515 | 1.027084 / 379699200 | 0.976593 / 378986496 |
| quickfix-quickfix / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1981.525 | 0.872586 / 376315904 | 1.574704 / 423657472 |
| quickfix-quickfix / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1213.486 | 1.352949 / 379441152 | 2.509704 / 426721280 |
| quickfix-quickfix / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1962.649 | 0.958765 / 376475648 | 1.628209 / 423358464 |
| quickfix-quickfix / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1296.216 | 1.315291 / 379453440 | 2.399598 / 426614784 |
| quickfix-quickfix / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2202.381 | 0.820878 / 376127488 | 1.584848 / 423354368 |
| quickfix-quickfix / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1300.781 | 1.253641 / 379678720 | 2.431295 / 426553344 |
| quickfix-quickfix / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12964.053 | 0.522876 / 137465856 | 0.478842 / 124596224 |
| quickfix-quickfix / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6719.702 | 0.832956 / 140967936 | 0.752957 / 127873024 |
| quickfix-quickfix / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13115.456 | 0.533393 / 137383936 | 0.446894 / 124538880 |
| quickfix-quickfix / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6539.738 | 0.786939 / 140656640 | 0.819735 / 127913984 |
| quickfix-quickfix / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11478.126 | 0.557402 / 137895936 | 0.497335 / 124891136 |
| quickfix-quickfix / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7059.884 | 0.813269 / 140464128 | 0.753812 / 127619072 |
| quickfix-quickfix / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12944.434 | 0.509864 / 137056256 | 0.473094 / 124342272 |
| quickfix-quickfix / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5898.351 | 0.847837 / 140165120 | 0.720776 / 127574016 |
| quickfix-quickfix / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11176.853 | 0.536838 / 136925184 | 0.485514 / 124370944 |
| quickfix-quickfix / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6793.167 | 0.791436 / 140234752 | 0.707024 / 127639552 |
| quickfix-quickfix / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13165.888 | 0.529811 / 136962048 | 0.480610 / 124309504 |
| quickfix-quickfix / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7269.661 | 0.783337 / 140488704 | 0.689357 / 127668224 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972620 / 380289 | 3097600 |
| native-native/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380289 / 972620 | 5767168 |
| native-native/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972587 / 380258 | 3097600 |
| native-native/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380258 / 972587 | 5767168 |
| native-native/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972614 / 380238 | 3097600 |
| native-native/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380238 / 972614 | 5767168 |
| native-native/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972630 / 10803924 | 39142400 |
| native-native/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803924 / 972630 | 5767168 |
| native-native/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972644 / 10803897 | 39142400 |
| native-native/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803897 / 972644 | 5767168 |
| native-native/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972640 / 10803900 | 39142400 |
| native-native/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803900 / 972640 | 5767168 |
| native-native/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061042 / 9424491 | 39142400 |
| native-native/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424491 / 19061042 | 67093632 |
| native-native/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061080 / 9424477 | 39142400 |
| native-native/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424477 / 19061080 | 67093632 |
| native-native/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061142 / 9424510 | 39142400 |
| native-native/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424510 / 19061142 | 67093632 |
| native-native/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061046 / 9424496 | 39142400 |
| native-native/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424496 / 19061046 | 67093632 |
| native-native/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061016 / 9424457 | 39142400 |
| native-native/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424457 / 19061016 | 67093632 |
| native-native/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061041 / 9424472 | 39142400 |
| native-native/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424472 / 19061041 | 67093632 |
| native-native/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972956 / 380680 | 3097600 |
| native-native/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380680 / 973169 | 5767168 |
| native-native/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 973047 / 380705 | 3097600 |
| native-native/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380705 / 973260 | 5767168 |
| native-native/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972863 / 380638 | 3097600 |
| native-native/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380638 / 973076 | 5767168 |
| native-native/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972568 / 380281 | 3097600 |
| native-native/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380281 / 972568 | 5767168 |
| native-native/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972647 / 380321 | 3097600 |
| native-native/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380321 / 972647 | 5767168 |
| native-native/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972622 / 380298 | 3097600 |
| native-native/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380298 / 972622 | 5767168 |
| native-native/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972657 / 380309 | 3097600 |
| native-native/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380309 / 972657 | 5767168 |
| native-native/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972560 / 380268 | 3097600 |
| native-native/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380268 / 972560 | 5767168 |
| native-native/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972627 / 380302 | 3097600 |
| native-native/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380302 / 972627 | 5767168 |
| native-native/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972588 / 10803887 | 39142400 |
| native-native/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803887 / 972588 | 5767168 |
| native-native/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972573 / 10803869 | 39142400 |
| native-native/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803869 / 972573 | 5767168 |
| native-native/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972660 / 10803945 | 39142400 |
| native-native/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803945 / 972660 | 5767168 |
| native-native/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061087 / 9424501 | 39142400 |
| native-native/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424501 / 19061087 | 67093632 |
| native-native/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061057 / 9424489 | 39142400 |
| native-native/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424489 / 19061057 | 67093632 |
| native-native/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061050 / 9424505 | 39142400 |
| native-native/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424505 / 19061050 | 67093632 |
| native-native/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061087 / 9424514 | 39142400 |
| native-native/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424514 / 19061087 | 67093632 |
| native-native/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19060967 / 9424458 | 39142400 |
| native-native/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424458 / 19060967 | 67093632 |
| native-native/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061074 / 9424489 | 39142400 |
| native-native/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424489 / 19061074 | 67093632 |
| native-native/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972970 / 380638 | 3097600 |
| native-native/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380638 / 973183 | 5767168 |
| native-native/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972968 / 380674 | 3097600 |
| native-native/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380674 / 973181 | 5767168 |
| native-native/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972968 / 380670 | 3097600 |
| native-native/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380670 / 973181 | 5767168 |
| native-native/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972673 / 380325 | 3097600 |
| native-native/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380325 / 972673 | 5767168 |
| native-native/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972638 / 380277 | 3097600 |
| native-native/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380277 / 972638 | 5767168 |
| native-native/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972633 / 380327 | 3097600 |
| native-native/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380327 / 972633 | 5767168 |
| native-quickfix/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380182 | 3097600 |
| native-quickfix/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380182 / 951453 | 1673273 |
| native-quickfix/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380155 | 3097600 |
| native-quickfix/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380155 / 951453 | 1673273 |
| native-quickfix/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951451 / 380130 | 3097600 |
| native-quickfix/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380130 / 951451 | 1673273 |
| native-quickfix/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803748 | 39142400 |
| native-quickfix/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803748 / 951453 | 1673273 |
| native-quickfix/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803745 | 39142400 |
| native-quickfix/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803745 / 951453 | 1673273 |
| native-quickfix/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951451 / 10803794 | 39142400 |
| native-quickfix/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803794 / 951451 | 1673273 |
| native-quickfix/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424382 | 39142400 |
| native-quickfix/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424382 / 19039853 | 18511929 |
| native-quickfix/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424356 | 39142400 |
| native-quickfix/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424356 / 19039853 | 18511929 |
| native-quickfix/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039852 / 9424325 | 39142400 |
| native-quickfix/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424325 / 19039852 | 18511929 |
| native-quickfix/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424382 | 39142400 |
| native-quickfix/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424382 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424314 | 39142400 |
| native-quickfix/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424314 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424364 | 39142400 |
| native-quickfix/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424364 / 19039853 | 18511929 |
| native-quickfix/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380377 | 3097600 |
| native-quickfix/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380377 / 951842 | 1673209 |
| native-quickfix/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380362 | 3097600 |
| native-quickfix/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380362 / 951842 | 1673209 |
| native-quickfix/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380378 | 3097600 |
| native-quickfix/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380378 / 951842 | 1673209 |
| native-quickfix/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 380160 | 3097600 |
| native-quickfix/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380160 / 951452 | 1673273 |
| native-quickfix/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380158 | 3097600 |
| native-quickfix/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380158 / 951453 | 1673273 |
| native-quickfix/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380130 | 3097600 |
| native-quickfix/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380130 / 951453 | 1673273 |
| native-quickfix/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 380144 | 3097600 |
| native-quickfix/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380144 / 951452 | 1673273 |
| native-quickfix/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380146 | 3097600 |
| native-quickfix/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380146 / 951453 | 1673273 |
| native-quickfix/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 380152 | 3097600 |
| native-quickfix/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380152 / 951452 | 1673273 |
| native-quickfix/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803744 | 39142400 |
| native-quickfix/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803744 / 951453 | 1673273 |
| native-quickfix/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 10803748 | 39142400 |
| native-quickfix/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803748 / 951452 | 1673273 |
| native-quickfix/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803769 | 39142400 |
| native-quickfix/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803769 / 951453 | 1673273 |
| native-quickfix/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039852 / 9424373 | 39142400 |
| native-quickfix/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424373 / 19039852 | 18511929 |
| native-quickfix/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424393 | 39142400 |
| native-quickfix/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424393 / 19039853 | 18511929 |
| native-quickfix/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424324 | 39142400 |
| native-quickfix/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424324 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424345 | 39142400 |
| native-quickfix/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424345 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424329 | 39142400 |
| native-quickfix/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424329 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039852 / 9424340 | 39142400 |
| native-quickfix/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424340 / 19039852 | 18511929 |
| native-quickfix/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951628 / 380394 | 3097600 |
| native-quickfix/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380394 / 951836 | 1673206 |
| native-quickfix/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380367 | 3097600 |
| native-quickfix/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380367 / 951842 | 1673209 |
| native-quickfix/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380353 | 3097600 |
| native-quickfix/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380353 / 951842 | 1673209 |
| native-quickfix/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 380134 | 3097600 |
| native-quickfix/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380134 / 951452 | 1673273 |
| native-quickfix/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 380155 | 3097600 |
| native-quickfix/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380155 / 951452 | 1673273 |
| native-quickfix/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380174 | 3097600 |
| native-quickfix/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380174 / 951453 | 1673273 |
| quickfix-native/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972444 / 380618 | 803594 |
| quickfix-native/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972444 | 5767168 |
| quickfix-native/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972483 / 380618 | 803594 |
| quickfix-native/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972483 | 5767168 |
| quickfix-native/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972456 / 380618 | 803594 |
| quickfix-native/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972456 | 5767168 |
| quickfix-native/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972400 / 10804218 | 11227194 |
| quickfix-native/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972400 | 5767168 |
| quickfix-native/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972498 / 10804218 | 11227194 |
| quickfix-native/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972498 | 5767168 |
| quickfix-native/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972440 / 10804218 | 11227194 |
| quickfix-native/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972440 | 5767168 |
| quickfix-native/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060949 / 9424818 | 9847794 |
| quickfix-native/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060949 | 67093632 |
| quickfix-native/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060883 / 9424817 | 9847793 |
| quickfix-native/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424817 / 19060883 | 67093632 |
| quickfix-native/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060868 / 9424818 | 9847794 |
| quickfix-native/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060868 | 67093632 |
| quickfix-native/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060922 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060922 | 67093632 |
| quickfix-native/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060894 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060894 | 67093632 |
| quickfix-native/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060899 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060899 | 67093632 |
| quickfix-native/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4461 / 2205 | 987295 / 380861 | 804221 |
| quickfix-native/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4462 | 380861 / 987508 | 5767168 |
| quickfix-native/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4441 / 2205 | 982096 / 380861 | 804221 |
| quickfix-native/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4442 | 380861 / 982309 | 5767168 |
| quickfix-native/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4449 / 2205 | 984140 / 380861 | 804221 |
| quickfix-native/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4450 | 380861 / 984353 | 5767168 |
| quickfix-native/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972535 / 380618 | 803594 |
| quickfix-native/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972535 | 5767168 |
| quickfix-native/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972535 / 380618 | 803594 |
| quickfix-native/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972535 | 5767168 |
| quickfix-native/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972438 / 380617 | 803593 |
| quickfix-native/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972438 | 5767168 |
| quickfix-native/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972429 / 380618 | 803594 |
| quickfix-native/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972429 | 5767168 |
| quickfix-native/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972471 / 380618 | 803594 |
| quickfix-native/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972471 | 5767168 |
| quickfix-native/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972542 / 380617 | 803593 |
| quickfix-native/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972542 | 5767168 |
| quickfix-native/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972461 / 10804218 | 11227194 |
| quickfix-native/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972461 | 5767168 |
| quickfix-native/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972514 / 10804217 | 11227193 |
| quickfix-native/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804217 / 972514 | 5767168 |
| quickfix-native/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972597 / 10804216 | 11227192 |
| quickfix-native/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804216 / 972597 | 5767168 |
| quickfix-native/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060876 / 9424817 | 9847793 |
| quickfix-native/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424817 / 19060876 | 67093632 |
| quickfix-native/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060905 / 9424818 | 9847794 |
| quickfix-native/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060905 | 67093632 |
| quickfix-native/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060869 / 9424818 | 9847794 |
| quickfix-native/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060869 | 67093632 |
| quickfix-native/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060849 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060849 | 67093632 |
| quickfix-native/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060902 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060902 | 67093632 |
| quickfix-native/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060883 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060883 | 67093632 |
| quickfix-native/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4434 / 2205 | 980412 / 380859 | 804219 |
| quickfix-native/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4435 | 380859 / 980625 | 5767168 |
| quickfix-native/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4434 / 2205 | 980299 / 380861 | 804221 |
| quickfix-native/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4435 | 380861 / 980512 | 5767168 |
| quickfix-native/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4448 / 2205 | 984012 / 380861 | 804221 |
| quickfix-native/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4449 | 380861 / 984225 | 5767168 |
| quickfix-native/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972475 / 380618 | 803594 |
| quickfix-native/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972475 | 5767168 |
| quickfix-native/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972519 / 380618 | 803594 |
| quickfix-native/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972519 | 5767168 |
| quickfix-native/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972428 / 380618 | 803594 |
| quickfix-native/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972428 | 5767168 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4419 / 2203 | 955618 / 380573 | 803549 |
| quickfix-quickfix/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4420 | 380573 / 955826 | 1673272 |
| quickfix-quickfix/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4438 / 2203 | 960369 / 380573 | 803549 |
| quickfix-quickfix/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4439 | 380573 / 960577 | 1673272 |
| quickfix-quickfix/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4426 / 2203 | 957360 / 380573 | 803549 |
| quickfix-quickfix/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4427 | 380573 / 957568 | 1673272 |
| quickfix-quickfix/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4430 / 2203 | 958364 / 380573 | 803549 |
| quickfix-quickfix/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4431 | 380573 / 958572 | 1673272 |
| quickfix-quickfix/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4427 / 2203 | 957617 / 380573 | 803549 |
| quickfix-quickfix/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4428 | 380573 / 957825 | 1673272 |
| quickfix-quickfix/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4449 / 2203 | 963125 / 380573 | 803549 |
| quickfix-quickfix/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4450 | 380573 / 963333 | 1673272 |
| quickfix-quickfix/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 2314631 / 2605063 / 2718469 / 2778871 / 2791974 | 2327105 / 2622936 / 2739102 / 2792571 / 2806673 | 0 / 0 / 0 / 0 / 0 | 2314631 / 2605063 / 2718469 / 2778871 / 2791974 | 2327105 / 2622936 / 2739102 / 2792571 / 2806673 | 3097600 | 5151535.253 |
| native-native/scalar/tcp/2 / 1 | 1957788 / 2129436 / 2246685 / 2330992 / 2336623 | 1968785 / 2138693 / 2258803 / 2343620 / 2355478 | 0 / 0 / 0 / 0 / 0 | 1957788 / 2129436 / 2246685 / 2330992 / 2336623 | 1968785 / 2138693 / 2258803 / 2343620 / 2355478 | 3097600 | 5498123.699 |
| native-native/scalar/tcp/3 / 1 | 2362558 / 2496242 / 2701184 / 2735082 / 2740264 | 2376435 / 2510855 / 2712945 / 2750300 / 2755195 | 0 / 0 / 0 / 0 / 0 | 2362558 / 2496242 / 2701184 / 2735082 / 2740264 | 2376435 / 2510855 / 2712945 / 2750300 / 2755195 | 3097600 | 5226967.955 |
| native-native/groups/tcp/1 / 1 | 11007793 / 21044904 / 21575316 / 21831968 / 21940312 | 11015363 / 21061007 / 21583540 / 21838535 / 21949263 | 0 / 0 / 0 / 0 / 0 | 11007793 / 21044904 / 21575316 / 21831968 / 21940312 | 11015363 / 21061007 / 21583540 / 21838535 / 21949263 | 39142400 | 16135131.994 |
| native-native/groups/tcp/2 / 1 | 11419239 / 21348282 / 21755764 / 22039374 / 22079262 | 11430953 / 21358888 / 21767647 / 22047817 / 22087252 | 0 / 0 / 0 / 0 / 0 | 11419239 / 21348282 / 21755764 / 22039374 / 22079262 | 11430953 / 21358888 / 21767647 / 22047817 / 22087252 | 39142400 | 15610624.219 |
| native-native/groups/tcp/3 / 1 | 11605368 / 20616529 / 21085554 / 21816800 / 21940199 | 11617539 / 20631540 / 21093487 / 21824762 / 21949078 | 0 / 0 / 0 / 0 / 0 | 11605368 / 20616529 / 21085554 / 21816800 / 21940199 | 11617539 / 20631540 / 21093487 / 21824762 / 21949078 | 39142400 | 15815617.311 |
| native-native/binary/tcp/1 / 1 | 5337082 / 5580846 / 5724797 / 5771906 / 5793347 | 5366501 / 5614034 / 5755848 / 5802552 / 5821933 | 0 / 0 / 0 / 0 / 0 | 5337082 / 5580846 / 5724797 / 5771906 / 5793347 | 5366501 / 5614034 / 5755848 / 5802552 / 5821933 | 39142400 | 74401852.938 |
| native-native/binary/tcp/2 / 1 | 6113314 / 6483283 / 6575004 / 6623502 / 6630283 | 6150392 / 6524812 / 6608184 / 6662809 / 6674377 | 0 / 0 / 0 / 0 / 0 | 6113314 / 6483283 / 6575004 / 6623502 / 6630283 | 6150392 / 6524812 / 6608184 / 6662809 / 6674377 | 39142400 | 70167202.732 |
| native-native/binary/tcp/3 / 1 | 5452720 / 5749827 / 5831343 / 5889311 / 5898461 | 5486044 / 5782664 / 5863261 / 5917456 / 5943051 | 0 / 0 / 0 / 0 / 0 | 5452720 / 5749827 / 5831343 / 5889311 / 5898461 | 5486044 / 5782664 / 5863261 / 5917456 / 5943051 | 39142400 | 74867408.937 |
| native-native/fragmentation/tcp/1 / 1 | 20290834 / 28495733 / 32479098 / 32609417 / 32624974 | 20321099 / 28529556 / 32505447 / 32643293 / 32655880 | 0 / 0 / 0 / 0 / 0 | 20290834 / 28495733 / 32479098 / 32609417 / 32624974 | 20321099 / 28529556 / 32505447 / 32643293 / 32655880 | 39142400 | 27988595.419 |
| native-native/fragmentation/tcp/2 / 1 | 23215001 / 29686368 / 37623918 / 37694737 / 37716560 | 23245277 / 29713346 / 37651644 / 37725666 / 37745532 | 0 / 0 / 0 / 0 / 0 | 23215001 / 29686368 / 37623918 / 37694737 / 37716560 | 23245277 / 29713346 / 37651644 / 37725666 / 37745532 | 39142400 | 25080529.659 |
| native-native/fragmentation/tcp/3 / 1 | 22841687 / 24084382 / 34424201 / 35421048 / 35483385 | 22881701 / 24121086 / 34462013 / 35468370 / 35535060 | 0 / 0 / 0 / 0 / 0 | 22841687 / 24084382 / 34424201 / 35421048 / 35483385 | 22881701 / 24121086 / 34462013 / 35468370 / 35535060 | 39142400 | 26502445.369 |
| native-native/replay/tcp/1 / 1 | 3124054 / 3755803 / 4447719 / 4811843 / 4852288 | 3135411 / 3761930 / 4461716 / 4830093 / 4864215 | 0 / 0 / 0 / 0 / 0 | 3124054 / 3755803 / 4447719 / 4811843 / 4852288 | 3135411 / 3761930 / 4461716 / 4830093 / 4864215 | 3097600 | 3792172.754 |
| native-native/replay/tcp/2 / 1 | 2957379 / 3524607 / 3721262 / 3992062 / 4020255 | 2970222 / 3533127 / 3732117 / 4007188 / 4031021 | 0 / 0 / 0 / 0 / 0 | 2957379 / 3524607 / 3721262 / 3992062 / 4020255 | 2970222 / 3533127 / 3732117 / 4007188 / 4031021 | 3097600 | 3993948.855 |
| native-native/replay/tcp/3 / 1 | 2974802 / 3468038 / 3827914 / 4250089 / 4251463 | 2990931 / 3473257 / 3847741 / 4262250 / 4274027 | 0 / 0 / 0 / 0 / 0 | 2974802 / 3468038 / 3827914 / 4250089 / 4251463 | 2990931 / 3473257 / 3847741 / 4262250 / 4274027 | 3097600 | 3951935.137 |
| native-native/overload/tcp/1 / 1 | 2053409 / 2267571 / 2336085 / 2392180 / 2406102 | 2067079 / 2281241 / 2356674 / 2407349 / 2412794 | 29746239 / 57836888 / 60674151 / 61275450 / 61329460 | 31718429 / 60223670 / 62804220 / 63286518 / 63335587 | 31724528 / 60231121 / 62823486 / 63292595 / 63344392 | 3097600 | 5574523.895 |
| native-native/overload/tcp/2 / 1 | 2015579 / 2291061 / 2324531 / 2343769 / 2355471 | 2027677 / 2304086 / 2336919 / 2355508 / 2367069 | 29569560 / 57608081 / 60319715 / 60971796 / 61033628 | 31527653 / 59798510 / 62134412 / 62359727 / 62381808 | 31537555 / 59810227 / 62145858 / 62365376 / 62387558 | 3097600 | 5431319.971 |
| native-native/overload/tcp/3 / 1 | 2270787 / 2449072 / 2598691 / 2635874 / 2639522 | 2284665 / 2464834 / 2613152 / 2647556 / 2652477 | 32902616 / 64305370 / 67302635 / 67917936 / 67993162 | 35234726 / 66765741 / 68976051 / 69337574 / 69377368 | 35252795 / 66783120 / 69000656 / 69352487 / 69383205 | 3097600 | 5253579.044 |
| native-native/scalar/tls/1 / 1 | 3463818 / 3784216 / 4170337 / 4328570 / 4364752 | 3490413 / 3813938 / 4207499 / 4358478 / 4400780 | 0 / 0 / 0 / 0 / 0 | 3463818 / 3784216 / 4170337 / 4328570 / 4364752 | 3490413 / 3813938 / 4207499 / 4358478 / 4400780 | 3097600 | 3888585.797 |
| native-native/scalar/tls/2 / 1 | 3774941 / 4085397 / 4126901 / 4145521 / 4148916 | 3804679 / 4116211 / 4152234 / 4173952 / 4200726 | 0 / 0 / 0 / 0 / 0 | 3774941 / 4085397 / 4126901 / 4145521 / 4148916 | 3804679 / 4116211 / 4152234 / 4173952 / 4200726 | 3097600 | 3795937.891 |
| native-native/scalar/tls/3 / 1 | 3537576 / 3926918 / 4048007 / 4075100 / 4123769 | 3566341 / 3948933 / 4070985 / 4121713 / 4136917 | 0 / 0 / 0 / 0 / 0 | 3537576 / 3926918 / 4048007 / 4075100 / 4123769 | 3566341 / 3948933 / 4070985 / 4121713 / 4136917 | 3097600 | 3880714.349 |
| native-native/groups/tls/1 / 1 | 11353385 / 21219264 / 21325709 / 21555624 / 21814573 | 11365809 / 21236134 / 21341171 / 21564725 / 21824409 | 0 / 0 / 0 / 0 / 0 | 11353385 / 21219264 / 21325709 / 21555624 / 21814573 | 11365809 / 21236134 / 21341171 / 21564725 / 21824409 | 39142400 | 15417850.929 |
| native-native/groups/tls/2 / 1 | 11179954 / 21475779 / 21647900 / 21930434 / 22118497 | 11193031 / 21491751 / 21666645 / 21938202 / 22128008 | 0 / 0 / 0 / 0 / 0 | 11179954 / 21475779 / 21647900 / 21930434 / 22118497 | 11193031 / 21491751 / 21666645 / 21938202 / 22128008 | 39142400 | 15679872.752 |
| native-native/groups/tls/3 / 1 | 11542460 / 22947567 / 26249642 / 26409853 / 26455950 | 11553345 / 22965326 / 26267665 / 26424878 / 26471409 | 0 / 0 / 0 / 0 / 0 | 11542460 / 22947567 / 26249642 / 26409853 / 26455950 | 11553345 / 22965326 / 26267665 / 26424878 / 26471409 | 39142400 | 15105324.461 |
| native-native/binary/tls/1 / 1 | 6107863 / 6678830 / 7169159 / 7494960 / 7506731 | 6148792 / 6728288 / 7198979 / 7521120 / 7550011 | 0 / 0 / 0 / 0 / 0 | 6107863 / 6678830 / 7169159 / 7494960 / 7506731 | 6148792 / 6728288 / 7198979 / 7521120 / 7550011 | 39142400 | 62586493.249 |
| native-native/binary/tls/2 / 1 | 5969931 / 6734687 / 6984081 / 7128409 / 7165601 | 6011243 / 6794267 / 7023675 / 7147313 / 7192864 | 0 / 0 / 0 / 0 / 0 | 5969931 / 6734687 / 6984081 / 7128409 / 7165601 | 6011243 / 6794267 / 7023675 / 7147313 / 7192864 | 39142400 | 62544007.492 |
| native-native/binary/tls/3 / 1 | 6006475 / 6610617 / 6863882 / 6976875 / 7005868 | 6044946 / 6651157 / 6893300 / 6994491 / 7048546 | 0 / 0 / 0 / 0 / 0 | 6006475 / 6610617 / 6863882 / 6976875 / 7005868 | 6044946 / 6651157 / 6893300 / 6994491 / 7048546 | 39142400 | 63880012.941 |
| native-native/fragmentation/tls/1 / 1 | 33141354 / 42584273 / 59062365 / 59117236 / 59147542 | 33162668 / 42610066 / 59090656 / 59143972 / 59178397 | 0 / 0 / 0 / 0 / 0 | 33141354 / 42584273 / 59062365 / 59117236 / 59147542 | 33162668 / 42610066 / 59090656 / 59143972 / 59178397 | 39142400 | 18583664.208 |
| native-native/fragmentation/tls/2 / 1 | 35064808 / 43123838 / 43304027 / 43419077 / 43454451 | 35097315 / 43152403 / 43342962 / 43438988 / 43476306 | 0 / 0 / 0 / 0 / 0 | 35064808 / 43123838 / 43304027 / 43419077 / 43454451 | 35097315 / 43152403 / 43342962 / 43438988 / 43476306 | 39142400 | 18063665.923 |
| native-native/fragmentation/tls/3 / 1 | 32610807 / 41196896 / 41557820 / 42089014 / 42166326 | 32629163 / 41230316 / 41576913 / 42108444 / 42203702 | 0 / 0 / 0 / 0 / 0 | 32610807 / 41196896 / 41557820 / 42089014 / 42166326 | 32629163 / 41230316 / 41576913 / 42108444 / 42203702 | 39142400 | 18752678.878 |
| native-native/replay/tls/1 / 1 | 3728514 / 4519848 / 4913288 / 5517924 / 5556780 | 3750325 / 4585644 / 5119675 / 5529200 / 5587814 | 0 / 0 / 0 / 0 / 0 | 3728514 / 4519848 / 4913288 / 5517924 / 5556780 | 3750325 / 4585644 / 5119675 / 5529200 / 5587814 | 3097600 | 3231920.149 |
| native-native/replay/tls/2 / 1 | 3656248 / 4344717 / 5020012 / 5112288 / 5138026 | 3685067 / 4368024 / 5051286 / 5125242 / 5148826 | 0 / 0 / 0 / 0 / 0 | 3656248 / 4344717 / 5020012 / 5112288 / 5138026 | 3685067 / 4368024 / 5051286 / 5125242 / 5148826 | 3097600 | 3148227.729 |
| native-native/replay/tls/3 / 1 | 3825796 / 4667348 / 5261427 / 6134849 / 6192300 | 3841956 / 4704887 / 5272136 / 6156918 / 6205184 | 0 / 0 / 0 / 0 / 0 | 3825796 / 4667348 / 5261427 / 6134849 / 6192300 | 3841956 / 4704887 / 5272136 / 6156918 / 6205184 | 3097600 | 3184572.392 |
| native-native/overload/tls/1 / 1 | 3171659 / 3618362 / 3690606 / 3718013 / 3731011 | 3193506 / 3644892 / 3718441 / 3740759 / 3743267 | 47689575 / 92235043 / 96762283 / 97774345 / 97859492 | 50832621 / 95935236 / 99655483 / 100331373 / 100385113 | 50853849 / 95948541 / 99666835 / 100343099 / 100404583 | 3097600 | 3986321.376 |
| native-native/overload/tls/2 / 1 | 3546446 / 3848407 / 3917581 / 3946770 / 3956663 | 3577600 / 3876393 / 3947064 / 3972799 / 3984759 | 51953313 / 102041683 / 106523810 / 107560572 / 107668620 | 55481692 / 105690986 / 109730874 / 110528958 / 110586809 | 55508951 / 105711494 / 109737689 / 110535449 / 110627302 | 3097600 | 3901857.914 |
| native-native/overload/tls/3 / 1 | 3435555 / 3645434 / 3959633 / 4092514 / 4151319 | 3461563 / 3676327 / 3981910 / 4121609 / 4160728 | 50029415 / 96638128 / 101379930 / 102394301 / 102439710 | 53230918 / 100247168 / 104144467 / 105016591 / 105117518 | 53244533 / 100258772 / 104153382 / 105042071 / 105126984 | 3097600 | 3966307.087 |
| native-quickfix/scalar/tcp/1 / 1 | 3354679 / 4129700 / 4167732 / 4201351 / 4241318 | 3375869 / 4162270 / 4202662 / 4231190 / 4255829 | 0 / 0 / 0 / 0 / 0 | 3354679 / 4129700 / 4167732 / 4201351 / 4241318 | 3375869 / 4162270 / 4202662 / 4231190 / 4255829 | 3097600 | 3494356.030 |
| native-quickfix/scalar/tcp/2 / 1 | 3834000 / 4477058 / 5111038 / 5298790 / 5309890 | 3859637 / 4508481 / 5130813 / 5330622 / 5338234 | 0 / 0 / 0 / 0 / 0 | 3834000 / 4477058 / 5111038 / 5298790 / 5309890 | 3859637 / 4508481 / 5130813 / 5330622 / 5338234 | 3097600 | 3302998.286 |
| native-quickfix/scalar/tcp/3 / 1 | 3841752 / 4022853 / 4074858 / 4100850 / 4105891 | 3871532 / 4051007 / 4104676 / 4125207 / 4130656 | 0 / 0 / 0 / 0 / 0 | 3841752 / 4022853 / 4074858 / 4100850 / 4105891 | 3871532 / 4051007 / 4104676 / 4125207 / 4130656 | 3097600 | 3358098.274 |
| native-quickfix/groups/tcp/1 / 1 | 36057325 / 50918431 / 51574753 / 55034372 / 55793941 | 36072960 / 50927311 / 51603775 / 55046849 / 55803865 | 0 / 0 / 0 / 0 / 0 | 36057325 / 50918431 / 51574753 / 55034372 / 55793941 | 36072960 / 50927311 / 51603775 / 55046849 / 55803865 | 39142400 | 6990177.699 |
| native-quickfix/groups/tcp/2 / 1 | 35806097 / 51104803 / 52403579 / 53643603 / 54529395 | 35814126 / 51127645 / 52411473 / 53652912 / 54539878 | 0 / 0 / 0 / 0 / 0 | 35806097 / 51104803 / 52403579 / 53643603 / 54529395 | 35814126 / 51127645 / 52411473 / 53652912 / 54539878 | 39142400 | 7031957.133 |
| native-quickfix/groups/tcp/3 / 1 | 38580932 / 49200976 / 50382522 / 53925920 / 54634237 | 38607678 / 49212912 / 50390187 / 53945742 / 54643513 | 0 / 0 / 0 / 0 / 0 | 38580932 / 49200976 / 50382522 / 53925920 / 54634237 | 38607678 / 49212912 / 50390187 / 53945742 / 54643513 | 39142400 | 6821369.721 |
| native-quickfix/binary/tcp/1 / 1 | 7266680 / 8252559 / 8575492 / 8786526 / 8809842 | 7308420 / 8308813 / 8627073 / 8838299 / 8854192 | 0 / 0 / 0 / 0 / 0 | 7266680 / 8252559 / 8575492 / 8786526 / 8809842 | 7308420 / 8308813 / 8627073 / 8838299 / 8854192 | 39142400 | 50562512.545 |
| native-quickfix/binary/tcp/2 / 1 | 7427810 / 9907400 / 10105896 / 10269391 / 10360956 | 7471761 / 9961904 / 10168394 / 10362881 / 10419914 | 0 / 0 / 0 / 0 / 0 | 7427810 / 9907400 / 10105896 / 10269391 / 10360956 | 7471761 / 9961904 / 10168394 / 10362881 / 10419914 | 39142400 | 48384128.249 |
| native-quickfix/binary/tcp/3 / 1 | 7250146 / 9881267 / 10148651 / 10212194 / 10243297 | 7293166 / 9947794 / 10203622 / 10287370 / 10323012 | 0 / 0 / 0 / 0 / 0 | 7250146 / 9881267 / 10148651 / 10212194 / 10243297 | 7293166 / 9947794 / 10203622 / 10287370 / 10323012 | 39142400 | 50024615.053 |
| native-quickfix/fragmentation/tcp/1 / 1 | 18490766 / 21769150 / 26039299 / 26628300 / 26636990 | 18521304 / 21795678 / 26075338 / 26661550 / 26674783 | 0 / 0 / 0 / 0 / 0 | 18490766 / 21769150 / 26039299 / 26628300 / 26636990 | 18521304 / 21795678 / 26075338 / 26661550 / 26674783 | 39142400 | 28334429.622 |
| native-quickfix/fragmentation/tcp/2 / 1 | 19330703 / 20827189 / 27484674 / 27541231 / 27577902 | 19361624 / 20855786 / 27511682 / 27569384 / 27606611 | 0 / 0 / 0 / 0 / 0 | 19330703 / 20827189 / 27484674 / 27541231 / 27577902 | 19361624 / 20855786 / 27511682 / 27569384 / 27606611 | 39142400 | 27744326.764 |
| native-quickfix/fragmentation/tcp/3 / 1 | 21345442 / 27715271 / 31832087 / 32072812 / 32074904 | 21386585 / 27756666 / 31872684 / 32108880 / 32113209 | 0 / 0 / 0 / 0 / 0 | 21345442 / 27715271 / 31832087 / 32072812 / 32074904 | 21386585 / 27756666 / 31872684 / 32108880 / 32113209 | 39142400 | 25681592.723 |
| native-quickfix/replay/tcp/1 / 1 | 2892005 / 3200854 / 3480969 / 3991178 / 4032407 | 2912476 / 3213658 / 3491036 / 4002449 / 4045792 | 0 / 0 / 0 / 0 / 0 | 2892005 / 3200854 / 3480969 / 3991178 / 4032407 | 2912476 / 3213658 / 3491036 / 4002449 / 4045792 | 3097600 | 3114292.756 |
| native-quickfix/replay/tcp/2 / 1 | 2909196 / 3552463 / 3744521 / 4350247 / 4374411 | 2925462 / 3566715 / 3748567 / 4356608 / 4383955 | 0 / 0 / 0 / 0 / 0 | 2909196 / 3552463 / 3744521 / 4350247 / 4374411 | 2925462 / 3566715 / 3748567 / 4356608 / 4383955 | 3097600 | 3087914.280 |
| native-quickfix/replay/tcp/3 / 1 | 2843826 / 3104322 / 3655070 / 3951604 / 3977051 | 2862009 / 3127338 / 3661600 / 3960960 / 3987789 | 0 / 0 / 0 / 0 / 0 | 2843826 / 3104322 / 3655070 / 3951604 / 3977051 | 2862009 / 3127338 / 3661600 / 3960960 / 3987789 | 3097600 | 3142597.606 |
| native-quickfix/overload/tcp/1 / 1 | 3063690 / 3239075 / 3318672 / 3345604 / 3354805 | 3087205 / 3259877 / 3343336 / 3369475 / 3378379 | 44825327 / 87163047 / 91238198 / 92129396 / 92233347 | 47833374 / 90500121 / 94286781 / 95029608 / 95110239 | 47859733 / 90524751 / 94293848 / 95047240 / 95135038 | 3097600 | 3517038.646 |
| native-quickfix/overload/tcp/2 / 1 | 4029378 / 4778857 / 4828142 / 4888465 / 4890640 | 4056024 / 4813405 / 4858330 / 4914826 / 4922929 | 54707323 / 113934943 / 119362116 / 120587900 / 120689716 | 59416131 / 118368281 / 122647485 / 123424851 / 123516032 | 59451454 / 118393656 / 122665880 / 123449817 / 123538230 | 3097600 | 3298058.353 |
| native-quickfix/overload/tcp/3 / 1 | 3008104 / 3185140 / 3262459 / 3284441 / 3291473 | 3030128 / 3212933 / 3286466 / 3311769 / 3316831 | 43782058 / 85522963 / 89518331 / 90413673 / 90505992 | 46756226 / 88775254 / 92477021 / 93301180 / 93387042 | 46782729 / 88787811 / 92528681 / 93316157 / 93397230 | 3097600 | 3584953.162 |
| native-quickfix/scalar/tls/1 / 1 | 3569071 / 3822696 / 3886074 / 3937533 / 3953514 | 3597381 / 3851102 / 3911381 / 3959470 / 3978922 | 0 / 0 / 0 / 0 / 0 | 3569071 / 3822696 / 3886074 / 3937533 / 3953514 | 3597381 / 3851102 / 3911381 / 3959470 / 3978922 | 3097600 | 2825838.666 |
| native-quickfix/scalar/tls/2 / 1 | 4298978 / 4553422 / 4684613 / 4727975 / 4732693 | 4329047 / 4584439 / 4717174 / 4759526 / 4763037 | 0 / 0 / 0 / 0 / 0 | 4298978 / 4553422 / 4684613 / 4727975 / 4732693 | 4329047 / 4584439 / 4717174 / 4759526 / 4763037 | 3097600 | 2724111.821 |
| native-quickfix/scalar/tls/3 / 1 | 3711836 / 4884958 / 5021992 / 5165054 / 5180545 | 3744854 / 4922893 / 5064850 / 5196718 / 5206645 | 0 / 0 / 0 / 0 / 0 | 3711836 / 4884958 / 5021992 / 5165054 / 5180545 | 3744854 / 4922893 / 5064850 / 5196718 / 5206645 | 3097600 | 2775746.431 |
| native-quickfix/groups/tls/1 / 1 | 37256154 / 50773502 / 51971208 / 55801157 / 56324579 | 37270365 / 50802378 / 51994104 / 55868619 / 56352659 | 0 / 0 / 0 / 0 / 0 | 37256154 / 50773502 / 51971208 / 55801157 / 56324579 | 37270365 / 50802378 / 51994104 / 55868619 / 56352659 | 39142400 | 5272598.397 |
| native-quickfix/groups/tls/2 / 1 | 36568215 / 57787064 / 58845294 / 62893466 / 63265163 | 36589309 / 57807000 / 58861592 / 62925620 / 63290228 | 0 / 0 / 0 / 0 / 0 | 36568215 / 57787064 / 58845294 / 62893466 / 63265163 | 36589309 / 57807000 / 58861592 / 62925620 / 63290228 | 39142400 | 6439934.695 |
| native-quickfix/groups/tls/3 / 1 | 37377946 / 49990085 / 50437668 / 54401009 / 55229702 | 37405238 / 50010897 / 50493127 / 54449599 / 55252113 | 0 / 0 / 0 / 0 / 0 | 37377946 / 49990085 / 50437668 / 54401009 / 55229702 | 37405238 / 50010897 / 50493127 / 54449599 / 55252113 | 39142400 | 6569765.156 |
| native-quickfix/binary/tls/1 / 1 | 8946102 / 9692107 / 9961355 / 10614408 / 10705427 | 9002099 / 9753794 / 10019686 / 10655297 / 10751023 | 0 / 0 / 0 / 0 / 0 | 8946102 / 9692107 / 9961355 / 10614408 / 10705427 | 9002099 / 9753794 / 10019686 / 10655297 / 10751023 | 39142400 | 42032392.212 |
| native-quickfix/binary/tls/2 / 1 | 7965044 / 9468442 / 10387511 / 10661166 / 10692711 | 8020009 / 9535824 / 10433760 / 10736991 / 10741923 | 0 / 0 / 0 / 0 / 0 | 7965044 / 9468442 / 10387511 / 10661166 / 10692711 | 8020009 / 9535824 / 10433760 / 10736991 / 10741923 | 39142400 | 42425716.539 |
| native-quickfix/binary/tls/3 / 1 | 9908647 / 10278348 / 10608141 / 10697268 / 10714756 | 9969697 / 10351515 / 10672854 / 10773558 / 10793170 | 0 / 0 / 0 / 0 / 0 | 9908647 / 10278348 / 10608141 / 10697268 / 10714756 | 9969697 / 10351515 / 10672854 / 10773558 / 10793170 | 39142400 | 39399657.377 |
| native-quickfix/fragmentation/tls/1 / 1 | 29129872 / 36163121 / 40865117 / 45658316 / 45797703 | 29187930 / 36189406 / 40889739 / 45703378 / 45822203 | 0 / 0 / 0 / 0 / 0 | 29129872 / 36163121 / 40865117 / 45658316 / 45797703 | 29187930 / 36189406 / 40889739 / 45703378 / 45822203 | 39142400 | 19246238.211 |
| native-quickfix/fragmentation/tls/2 / 1 | 30596690 / 34214428 / 42419444 / 52588848 / 52744609 | 30634935 / 34255510 / 42451964 / 52616723 / 52774421 | 0 / 0 / 0 / 0 / 0 | 30596690 / 34214428 / 42419444 / 52588848 / 52744609 | 30634935 / 34255510 / 42451964 / 52616723 / 52774421 | 39142400 | 18647241.660 |
| native-quickfix/fragmentation/tls/3 / 1 | 30372461 / 36786350 / 41127404 / 44897698 / 44907132 | 30443792 / 36811621 / 41150475 / 44915246 / 44925963 | 0 / 0 / 0 / 0 / 0 | 30372461 / 36786350 / 41127404 / 44897698 / 44907132 | 30443792 / 36811621 / 41150475 / 44915246 / 44925963 | 39142400 | 18573804.887 |
| native-quickfix/replay/tls/1 / 1 | 4689404 / 5191607 / 5644487 / 6092023 / 6222976 | 4723327 / 5215441 / 5680205 / 6110565 / 6251164 | 0 / 0 / 0 / 0 / 0 | 4689404 / 5191607 / 5644487 / 6092023 / 6222976 | 4723327 / 5215441 / 5680205 / 6110565 / 6251164 | 3097600 | 2305839.930 |
| native-quickfix/replay/tls/2 / 1 | 3423260 / 3822609 / 4289325 / 4720860 / 4776985 | 3446059 / 3844320 / 4302655 / 4736361 / 4789327 | 0 / 0 / 0 / 0 / 0 | 3423260 / 3822609 / 4289325 / 4720860 / 4776985 | 3446059 / 3844320 / 4302655 / 4736361 / 4789327 | 3097600 | 2478849.470 |
| native-quickfix/replay/tls/3 / 1 | 4011641 / 4388331 / 5119818 / 5867967 / 5927133 | 4038887 / 4399124 / 5136166 / 5881288 / 5938514 | 0 / 0 / 0 / 0 / 0 | 4011641 / 4388331 / 5119818 / 5867967 / 5927133 | 4038887 / 4399124 / 5136166 / 5881288 / 5938514 | 3097600 | 2438502.486 |
| native-quickfix/overload/tls/1 / 1 | 3504039 / 4073227 / 4960906 / 5065079 / 5080362 | 3530389 / 4113272 / 4982600 / 5101540 / 5116413 | 53421473 / 102022732 / 106830044 / 107849475 / 107974632 | 56948125 / 105913711 / 110188074 / 111079931 / 111174729 | 56992231 / 105923987 / 110207359 / 111107455 / 111209258 | 3097600 | 2871881.162 |
| native-quickfix/overload/tls/2 / 1 | 4233683 / 4983733 / 5089880 / 5152816 / 5178961 | 4265821 / 5013201 / 5121857 / 5190049 / 5204240 | 62598048 / 123344636 / 129641820 / 131121513 / 131248448 | 66809643 / 128391658 / 133530203 / 134408882 / 134499381 | 66842591 / 128430825 / 133539753 / 134425318 / 134530231 | 3097600 | 2747594.949 |
| native-quickfix/overload/tls/3 / 1 | 4208472 / 4422095 / 4614539 / 4865752 / 4885343 | 4235174 / 4452835 / 4644738 / 4875653 / 4924540 | 62689470 / 116735794 / 121312501 / 122323802 / 122442118 | 66913343 / 120426997 / 124740197 / 125669378 / 125763155 | 66943190 / 120455949 / 124767761 / 125696130 / 125796041 | 3097600 | 2764920.021 |
| quickfix-native/scalar/tcp/1 / 1 | 4255538 / 4477025 / 4854458 / 4900377 / 4925592 | 4293491 / 4512976 / 4890746 / 4933544 / 4935329 | 0 / 0 / 0 / 0 / 0 | 4255538 / 4477025 / 4854458 / 4900377 / 4925592 | 4293491 / 4512976 / 4890746 / 4933544 / 4935329 | 803594 | 686742.069 |
| quickfix-native/scalar/tcp/2 / 1 | 5204539 / 5408860 / 5569364 / 5638231 / 5650792 | 5246086 / 5451398 / 5614614 / 5679395 / 5698645 | 0 / 0 / 0 / 0 / 0 | 5204539 / 5408860 / 5569364 / 5638231 / 5650792 | 5246086 / 5451398 / 5614614 / 5679395 / 5698645 | 803594 | 1136907.771 |
| quickfix-native/scalar/tcp/3 / 1 | 5034949 / 5341044 / 5495682 / 5555664 / 5572876 | 5071460 / 5386003 / 5529694 / 5587636 / 5588288 | 0 / 0 / 0 / 0 / 0 | 5034949 / 5341044 / 5495682 / 5555664 / 5572876 | 5071460 / 5386003 / 5529694 / 5587636 / 5588288 | 803594 | 710471.225 |
| quickfix-native/groups/tcp/1 / 1 | 72502905 / 81008984 / 82788477 / 83011920 / 83045802 | 72504643 / 81011654 / 82792034 / 83016069 / 83049339 | 0 / 0 / 0 / 0 / 0 | 72502905 / 81008984 / 82788477 / 83011920 / 83045802 | 72504643 / 81011654 / 82792034 / 83016069 / 83049339 | 11227194 | 3701096.114 |
| quickfix-native/groups/tcp/2 / 1 | 71995104 / 78249536 / 79793019 / 80150776 / 80444502 | 71997652 / 78251519 / 79795308 / 80152865 / 80446710 | 0 / 0 / 0 / 0 / 0 | 71995104 / 78249536 / 79793019 / 80150776 / 80444502 | 71997652 / 78251519 / 79795308 / 80152865 / 80446710 | 11227194 | 3544225.538 |
| quickfix-native/groups/tcp/3 / 1 | 71211426 / 76621643 / 78846757 / 79437735 / 79615430 | 71213632 / 76623457 / 78848575 / 79440521 / 79617312 | 0 / 0 / 0 / 0 / 0 | 71211426 / 76621643 / 78846757 / 79437735 / 79615430 | 71213632 / 76623457 / 78848575 / 79440521 / 79617312 | 11227194 | 3581338.196 |
| quickfix-native/binary/tcp/1 / 1 | 7547926 / 8418469 / 8547917 / 8591986 / 8607101 | 7592752 / 8474259 / 8596100 / 8649834 / 8676493 | 0 / 0 / 0 / 0 / 0 | 7547926 / 8418469 / 8547917 / 8591986 / 8607101 | 7592752 / 8474259 / 8596100 / 8649834 / 8676493 | 9847794 | 17343603.259 |
| quickfix-native/binary/tcp/2 / 1 | 7405468 / 7810737 / 8346947 / 8436772 / 8438382 | 7447517 / 7861242 / 8410504 / 8480898 / 8492657 | 0 / 0 / 0 / 0 / 0 | 7405468 / 7810737 / 8346947 / 8436772 / 8438382 | 7447517 / 7861242 / 8410504 / 8480898 / 8492657 | 9847793 | 16810525.972 |
| quickfix-native/binary/tcp/3 / 1 | 8196439 / 8359250 / 8410170 / 8543459 / 8557376 | 8240505 / 8415176 / 8463452 / 8603631 / 8607328 | 0 / 0 / 0 / 0 / 0 | 8196439 / 8359250 / 8410170 / 8543459 / 8557376 | 8240505 / 8415176 / 8463452 / 8603631 / 8607328 | 9847794 | 26008966.935 |
| quickfix-native/fragmentation/tcp/1 / 1 | 22471231 / 27429678 / 29558097 / 31528723 / 31564096 | 22515184 / 27450878 / 29590766 / 31586786 / 31595181 | 0 / 0 / 0 / 0 / 0 | 22471231 / 27429678 / 29558097 / 31528723 / 31564096 | 22515184 / 27450878 / 29590766 / 31586786 / 31595181 | 9847794 | 13955446.861 |
| quickfix-native/fragmentation/tcp/2 / 1 | 21912826 / 29220551 / 32875638 / 33174311 / 33252018 | 21973996 / 29285407 / 32957681 / 33253674 / 33268810 | 0 / 0 / 0 / 0 / 0 | 21912826 / 29220551 / 32875638 / 33174311 / 33252018 | 21973996 / 29285407 / 32957681 / 33253674 / 33268810 | 9847794 | 18115319.926 |
| quickfix-native/fragmentation/tcp/3 / 1 | 22970229 / 32621762 / 35675921 / 35926712 / 36015835 | 23041058 / 32690327 / 35751094 / 35971786 / 36023310 | 0 / 0 / 0 / 0 / 0 | 22970229 / 32621762 / 35675921 / 35926712 / 36015835 | 23041058 / 32690327 / 35751094 / 35971786 / 36023310 | 9847794 | 14613259.263 |
| quickfix-native/replay/tcp/1 / 1 | 5127147 / 5423994 / 7795385 / 8445090 / 8522293 | 5165440 / 5463834 / 7865962 / 8489295 / 8548318 | 0 / 0 / 0 / 0 / 0 | 5127147 / 5423994 / 7795385 / 8445090 / 8522293 | 5165440 / 5463834 / 7865962 / 8489295 / 8548318 | 804221 | 1102184.515 |
| quickfix-native/replay/tcp/2 / 1 | 4725505 / 5270086 / 6746556 / 7204916 / 7241483 | 4750833 / 5308343 / 6783082 / 7238856 / 7245546 | 0 / 0 / 0 / 0 / 0 | 4725505 / 5270086 / 6746556 / 7204916 / 7241483 | 4750833 / 5308343 / 6783082 / 7238856 / 7245546 | 804221 | 695600.234 |
| quickfix-native/replay/tcp/3 / 1 | 4956025 / 5282500 / 7072938 / 7508065 / 7531941 | 4992019 / 5328684 / 7107906 / 7538839 / 7564782 | 0 / 0 / 0 / 0 / 0 | 4956025 / 5282500 / 7072938 / 7508065 / 7531941 | 4992019 / 5328684 / 7107906 / 7538839 / 7564782 | 804221 | 689932.288 |
| quickfix-native/overload/tcp/1 / 1 | 4910413 / 5130190 / 5195014 / 5225969 / 5236962 | 4944522 / 5168282 / 5229682 / 5255458 / 5268599 | 74258143 / 133337652 / 138204478 / 139242766 / 139369771 | 79211944 / 137247516 / 142025882 / 143025632 / 143138185 | 79243659 / 137272912 / 142051034 / 143055256 / 143164016 | 803594 | 709782.390 |
| quickfix-native/overload/tcp/2 / 1 | 5088688 / 5340410 / 5414422 / 5452488 / 5473395 | 5120641 / 5371744 / 5444192 / 5496685 / 5506309 | 65143836 / 138092310 / 144660265 / 146099861 / 146250469 | 70387922 / 143305436 / 149190229 / 150335791 / 150491646 | 70438288 / 143343624 / 149216242 / 150365470 / 150517849 | 803594 | 709397.938 |
| quickfix-native/overload/tcp/3 / 1 | 4645979 / 4817115 / 4871801 / 4915947 / 4917270 | 4680999 / 4853475 / 4891687 / 4948317 / 4951520 | 59864319 / 126274650 / 131991997 / 133246131 / 133364304 | 64554222 / 130875683 / 136007831 / 137062744 / 137183027 | 64590566 / 130903263 / 136038354 / 137092006 / 137221463 | 803593 | 705520.870 |
| quickfix-native/scalar/tls/1 / 1 | 5199336 / 6792083 / 7252296 / 7574399 / 7588034 | 5232596 / 6846638 / 7284044 / 7636688 / 7649663 | 0 / 0 / 0 / 0 / 0 | 5199336 / 6792083 / 7252296 / 7574399 / 7588034 | 5232596 / 6846638 / 7284044 / 7636688 / 7649663 | 803594 | 1130354.928 |
| quickfix-native/scalar/tls/2 / 1 | 5511126 / 6265503 / 6418743 / 6542569 / 6569469 | 5553964 / 6314069 / 6465351 / 6597293 / 6624217 | 0 / 0 / 0 / 0 / 0 | 5511126 / 6265503 / 6418743 / 6542569 / 6569469 | 5553964 / 6314069 / 6465351 / 6597293 / 6624217 | 803594 | 716834.451 |
| quickfix-native/scalar/tls/3 / 1 | 5225722 / 6219524 / 6380616 / 6461188 / 6513630 | 5264906 / 6272258 / 6425103 / 6496515 / 6516833 | 0 / 0 / 0 / 0 / 0 | 5225722 / 6219524 / 6380616 / 6461188 / 6513630 | 5264906 / 6272258 / 6425103 / 6496515 / 6516833 | 803593 | 1133869.563 |
| quickfix-native/groups/tls/1 / 1 | 73658525 / 79926145 / 80346081 / 80607501 / 80685853 | 73660365 / 79928629 / 80348056 / 80609431 / 80688313 | 0 / 0 / 0 / 0 / 0 | 73658525 / 79926145 / 80346081 / 80607501 / 80685853 | 73660365 / 79928629 / 80348056 / 80609431 / 80688313 | 11227194 | 3892852.572 |
| quickfix-native/groups/tls/2 / 1 | 72381538 / 77335539 / 77842241 / 78100963 / 78228586 | 72383498 / 77337647 / 77844188 / 78103308 / 78230459 | 0 / 0 / 0 / 0 / 0 | 72381538 / 77335539 / 77842241 / 78100963 / 78228586 | 72383498 / 77337647 / 77844188 / 78103308 / 78230459 | 11227193 | 3615462.357 |
| quickfix-native/groups/tls/3 / 1 | 73504343 / 86225272 / 87935711 / 88384862 / 88502384 | 73506665 / 86228247 / 87938177 / 88388505 / 88504609 | 0 / 0 / 0 / 0 / 0 | 73504343 / 86225272 / 87935711 / 88384862 / 88502384 | 73506665 / 86228247 / 87938177 / 88388505 / 88504609 | 11227192 | 2371051.798 |
| quickfix-native/binary/tls/1 / 1 | 10304932 / 10789866 / 10929990 / 11033497 / 11064023 | 10383154 / 10863240 / 11009125 / 11111334 / 11128985 | 0 / 0 / 0 / 0 / 0 | 10304932 / 10789866 / 10929990 / 11033497 / 11064023 | 10383154 / 10863240 / 11009125 / 11111334 / 11128985 | 9847793 | 25582303.316 |
| quickfix-native/binary/tls/2 / 1 | 8740457 / 9494576 / 9591597 / 9711585 / 9717743 | 8795975 / 9543513 / 9636580 / 9750920 / 9778506 | 0 / 0 / 0 / 0 / 0 | 8740457 / 9494576 / 9591597 / 9711585 / 9717743 | 8795975 / 9543513 / 9636580 / 9750920 / 9778506 | 9847794 | 25346702.592 |
| quickfix-native/binary/tls/3 / 1 | 9290689 / 10485438 / 10616179 / 10783080 / 10813435 | 9349999 / 10549085 / 10688493 / 10853259 / 10889164 | 0 / 0 / 0 / 0 / 0 | 9290689 / 10485438 / 10616179 / 10783080 / 10813435 | 9349999 / 10549085 / 10688493 / 10853259 / 10889164 | 9847794 | 25356378.599 |
| quickfix-native/fragmentation/tls/1 / 1 | 35914306 / 44845749 / 48845977 / 54333455 / 54373879 | 35979382 / 44906761 / 48886648 / 54383262 / 54395112 | 0 / 0 / 0 / 0 / 0 | 35914306 / 44845749 / 48845977 / 54333455 / 54373879 | 35979382 / 44906761 / 48886648 / 54383262 / 54395112 | 9847794 | 11522649.981 |
| quickfix-native/fragmentation/tls/2 / 1 | 35844352 / 44803072 / 54866781 / 60555249 / 60616758 | 35925491 / 44878845 / 55006191 / 60623042 / 60651841 | 0 / 0 / 0 / 0 / 0 | 35844352 / 44803072 / 54866781 / 60555249 / 60616758 | 35925491 / 44878845 / 55006191 / 60623042 / 60651841 | 9847794 | 13936507.177 |
| quickfix-native/fragmentation/tls/3 / 1 | 36764401 / 43169084 / 51067007 / 53249047 / 53255050 | 36849438 / 43211034 / 51113976 / 53319710 / 53328263 | 0 / 0 / 0 / 0 / 0 | 36764401 / 43169084 / 51067007 / 53249047 / 53255050 | 36849438 / 43211034 / 51113976 / 53319710 / 53328263 | 9847794 | 13741751.300 |
| quickfix-native/replay/tls/1 / 1 | 6611973 / 6892450 / 8545922 / 9611619 / 9664234 | 6664363 / 6944522 / 8607539 / 9668689 / 9723399 | 0 / 0 / 0 / 0 / 0 | 6611973 / 6892450 / 8545922 / 9611619 / 9664234 | 6664363 / 6944522 / 8607539 / 9668689 / 9723399 | 804219 | 1066866.318 |
| quickfix-native/replay/tls/2 / 1 | 5277903 / 6349241 / 7054453 / 7497519 / 7569593 | 5318529 / 6394955 / 7115422 / 7565675 / 7634765 | 0 / 0 / 0 / 0 / 0 | 5277903 / 6349241 / 7054453 / 7497519 / 7569593 | 5318529 / 6394955 / 7115422 / 7565675 / 7634765 | 804221 | 695740.618 |
| quickfix-native/replay/tls/3 / 1 | 5732625 / 6762043 / 8767751 / 9502794 / 9563565 | 5775247 / 6802609 / 8826510 / 9571965 / 9614177 | 0 / 0 / 0 / 0 / 0 | 5732625 / 6762043 / 8767751 / 9502794 / 9563565 | 5775247 / 6802609 / 8826510 / 9571965 / 9614177 | 804221 | 1086511.648 |
| quickfix-native/overload/tls/1 / 1 | 5012948 / 6494901 / 6759283 / 6979728 / 7017546 | 5045914 / 6543413 / 6813685 / 7025584 / 7066840 | 86619194 / 156437828 / 162462311 / 163890949 / 164032864 | 91590198 / 161222525 / 167100199 / 168268765 / 168392644 | 91619116 / 161254286 / 167131108 / 168299452 / 168425554 | 803594 | 717695.474 |
| quickfix-native/overload/tls/2 / 1 | 6418681 / 6699029 / 6781817 / 6891240 / 6913576 | 6468184 / 6749780 / 6829896 / 6940218 / 6945726 | 96328769 / 185241377 / 191641352 / 193102237 / 193267377 | 102709614 / 190387420 / 196252955 / 197539579 / 197669798 | 102751378 / 190426314 / 196284704 / 197572043 / 197700302 | 803594 | 740535.508 |
| quickfix-native/overload/tls/3 / 1 | 6154878 / 6468124 / 7836379 / 8031583 / 8060134 | 6194985 / 6520028 / 7898529 / 8070576 / 8084637 | 91758774 / 173380277 / 179821093 / 181291657 / 181421114 | 98041247 / 178585979 / 184485136 / 185647783 / 185779996 | 98079305 / 178624591 / 184513517 / 185684756 / 185814690 | 803594 | 1157973.667 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 3552840 / 3745260 / 3876878 / 3954152 / 3961367 | 3570322 / 3765488 / 3886810 / 3971481 / 3977849 | 0 / 0 / 0 / 0 / 0 | 3552840 / 3745260 / 3876878 / 3954152 / 3961367 | 3570322 / 3765488 / 3886810 / 3971481 / 3977849 | 803258 | 648287.759 |
| quickfix-quickfix/scalar/tcp/2 / 1 | 3538935 / 3729987 / 3780823 / 3831412 / 3840617 | 3558310 / 3751694 / 3805253 / 3858592 / 3862568 | 0 / 0 / 0 / 0 / 0 | 3538935 / 3729987 / 3780823 / 3831412 / 3840617 | 3558310 / 3751694 / 3805253 / 3858592 / 3862568 | 803258 | 648185.646 |
| quickfix-quickfix/scalar/tcp/3 / 1 | 3673133 / 3941225 / 4052344 / 4075099 / 4089559 | 3700253 / 3969257 / 4075274 / 4107782 / 4114887 | 0 / 0 / 0 / 0 / 0 | 3673133 / 3941225 / 4052344 / 4075099 / 4089559 | 3700253 / 3969257 / 4075274 / 4107782 / 4114887 | 803258 | 1055181.473 |
| quickfix-quickfix/groups/tcp/1 / 1 | 70021864 / 74592918 / 75896228 / 76879610 / 76945259 | 70023854 / 74595182 / 75897988 / 76881563 / 76947333 | 0 / 0 / 0 / 0 / 0 | 70021864 / 74592918 / 75896228 / 76879610 / 76945259 | 70023854 / 74595182 / 75897988 / 76881563 / 76947333 | 11226858 | 3619046.368 |
| quickfix-quickfix/groups/tcp/2 / 1 | 69280071 / 74155432 / 74656365 / 74874644 / 74883316 | 69281890 / 74157381 / 74658582 / 74876425 / 74885183 | 0 / 0 / 0 / 0 / 0 | 69280071 / 74155432 / 74656365 / 74874644 / 74883316 | 69281890 / 74157381 / 74658582 / 74876425 / 74885183 | 11226858 | 3563131.745 |
| quickfix-quickfix/groups/tcp/3 / 1 | 70330841 / 75383240 / 76670188 / 78548568 / 78588310 | 70333083 / 75385446 / 76674113 / 78550587 / 78592190 | 0 / 0 / 0 / 0 / 0 | 70330841 / 75383240 / 76670188 / 78548568 / 78588310 | 70333083 / 75385446 / 76674113 / 78550587 / 78592190 | 11226858 | 3538745.684 |
| quickfix-quickfix/binary/tcp/1 / 1 | 8145364 / 9627634 / 10143832 / 10330490 / 10393891 | 8197838 / 9694915 / 10209907 / 10379800 / 10473779 | 0 / 0 / 0 / 0 / 0 | 8145364 / 9627634 / 10143832 / 10330490 / 10393891 | 8197838 / 9694915 / 10209907 / 10379800 / 10473779 | 9847458 | 16129333.826 |
| quickfix-quickfix/binary/tcp/2 / 1 | 7425592 / 9613824 / 9794427 / 10158044 / 10194564 | 7475582 / 9693134 / 9871931 / 10206801 / 10264464 | 0 / 0 / 0 / 0 / 0 | 7425592 / 9613824 / 9794427 / 10158044 / 10194564 | 7475582 / 9693134 / 9871931 / 10206801 / 10264464 | 9847458 | 16282883.614 |
| quickfix-quickfix/binary/tcp/3 / 1 | 7388190 / 9764216 / 9933962 / 10049816 / 10072848 | 7435756 / 9838471 / 10002595 / 10128205 / 10154204 | 0 / 0 / 0 / 0 / 0 | 7388190 / 9764216 / 9933962 / 10049816 / 10072848 | 7435756 / 9838471 / 10002595 / 10128205 / 10154204 | 9847458 | 16255161.981 |
| quickfix-quickfix/fragmentation/tcp/1 / 1 | 19430752 / 25907848 / 29116904 / 31573011 / 31590227 | 19484889 / 25957368 / 29159350 / 31665320 / 31684705 | 0 / 0 / 0 / 0 / 0 | 19430752 / 25907848 / 29116904 / 31573011 / 31590227 | 19484889 / 25957368 / 29159350 / 31665320 / 31684705 | 9847458 | 13197042.905 |
| quickfix-quickfix/fragmentation/tcp/2 / 1 | 22432669 / 28383332 / 31077056 / 31141996 / 31160763 | 22483760 / 28480537 / 31163631 / 31227479 / 31231975 | 0 / 0 / 0 / 0 / 0 | 22432669 / 28383332 / 31077056 / 31141996 / 31160763 | 22483760 / 28480537 / 31163631 / 31227479 / 31231975 | 9847458 | 13770892.697 |
| quickfix-quickfix/fragmentation/tcp/3 / 1 | 19789043 / 26859620 / 33876467 / 34066447 / 34081976 | 19840250 / 26916432 / 33926989 / 34073549 / 34090336 | 0 / 0 / 0 / 0 / 0 | 19789043 / 26859620 / 33876467 / 34066447 / 34081976 | 19840250 / 26916432 / 33926989 / 34073549 / 34090336 | 9847458 | 13651791.587 |
| quickfix-quickfix/replay/tcp/1 / 1 | 4866822 / 5124654 / 5216168 / 5289244 / 5305612 | 4899422 / 5161272 / 5248974 / 5331159 / 5332110 | 0 / 0 / 0 / 0 / 0 | 4866822 / 5124654 / 5216168 / 5289244 / 5305612 | 4899422 / 5161272 / 5248974 / 5331159 / 5332110 | 803549 | 646658.507 |
| quickfix-quickfix/replay/tcp/2 / 1 | 3563168 / 4657518 / 7548394 / 8211462 / 8346964 | 3575346 / 4707018 / 7591736 / 8264699 / 8397510 | 0 / 0 / 0 / 0 / 0 | 3563168 / 4657518 / 7548394 / 8211462 / 8346964 | 3575346 / 4707018 / 7591736 / 8264699 / 8397510 | 803549 | 1031276.761 |
| quickfix-quickfix/replay/tcp/3 / 1 | 4861753 / 5087353 / 5153891 / 5196799 / 5244537 | 4899725 / 5126231 / 5191940 / 5253254 / 5271805 | 0 / 0 / 0 / 0 / 0 | 4861753 / 5087353 / 5153891 / 5196799 / 5244537 | 4899725 / 5126231 / 5191940 / 5253254 / 5271805 | 803549 | 639500.096 |
| quickfix-quickfix/overload/tcp/1 / 1 | 3663636 / 3936906 / 4004248 / 4026590 / 4033631 | 3689800 / 3962808 / 4031162 / 4050458 / 4057879 | 54633639 / 106048490 / 110911871 / 111853605 / 111969639 | 58231699 / 109964331 / 114401434 / 115350429 / 115451959 | 58257790 / 109989627 / 114421918 / 115375010 / 115479020 | 803258 | 1058397.819 |
| quickfix-quickfix/overload/tcp/2 / 1 | 5190965 / 5460515 / 5780920 / 5941832 / 5997964 | 5235527 / 5502910 / 5834481 / 5983860 / 6042119 | 77632009 / 150566496 / 156752098 / 158076359 / 158222324 | 82747116 / 155577924 / 160982569 / 162052667 / 162164842 | 82794530 / 155603447 / 161024985 / 162081057 / 162194201 | 803258 | 661884.223 |
| quickfix-quickfix/overload/tcp/3 / 1 | 5025539 / 5330816 / 5707473 / 5830071 / 5876297 | 5070500 / 5377608 / 5751215 / 5877011 / 5923832 | 77023327 / 134225421 / 139769976 / 140992228 / 141135059 | 82217482 / 138756462 / 143710570 / 144629954 / 144734035 | 82264510 / 138789258 / 143733439 / 144653485 / 144761655 | 803258 | 660020.857 |
| quickfix-quickfix/scalar/tls/1 / 1 | 4503511 / 4652383 / 4729415 / 4794774 / 4802961 | 4537582 / 4688139 / 4772531 / 4833356 / 4841661 | 0 / 0 / 0 / 0 / 0 | 4503511 / 4652383 / 4729415 / 4794774 / 4802961 | 4537582 / 4688139 / 4772531 / 4833356 / 4841661 | 803258 | 1029564.060 |
| quickfix-quickfix/scalar/tls/2 / 1 | 5780386 / 5960564 / 6018907 / 6056343 / 6091649 | 5817520 / 5997201 / 6056758 / 6091049 / 6133150 | 0 / 0 / 0 / 0 / 0 | 5780386 / 5960564 / 6018907 / 6056343 / 6091649 | 5817520 / 5997201 / 6056758 / 6091049 / 6133150 | 803258 | 689510.721 |
| quickfix-quickfix/scalar/tls/3 / 1 | 4638678 / 4815144 / 4886666 / 4935932 / 4943984 | 4666216 / 4841357 / 4915411 / 4970649 / 4974265 | 0 / 0 / 0 / 0 / 0 | 4638678 / 4815144 / 4886666 / 4935932 / 4943984 | 4666216 / 4841357 / 4915411 / 4970649 / 4974265 | 803258 | 666829.268 |
| quickfix-quickfix/groups/tls/1 / 1 | 70398698 / 75710864 / 77861451 / 78454593 / 78615968 | 70400974 / 75713059 / 77863288 / 78456743 / 78618116 | 0 / 0 / 0 / 0 / 0 | 70398698 / 75710864 / 77861451 / 78454593 / 78615968 | 70400974 / 75713059 / 77863288 / 78456743 / 78618116 | 11226858 | 3505868.220 |
| quickfix-quickfix/groups/tls/2 / 1 | 71270741 / 76287579 / 77179912 / 77399518 / 77413783 | 71273203 / 76289358 / 77182211 / 77402060 / 77415964 | 0 / 0 / 0 / 0 / 0 | 71270741 / 76287579 / 77179912 / 77399518 / 77413783 | 71273203 / 76289358 / 77182211 / 77402060 / 77415964 | 11226858 | 3739561.428 |
| quickfix-quickfix/groups/tls/3 / 1 | 71370544 / 76535985 / 77464053 / 77799915 / 77863625 | 71372847 / 76538074 / 77466585 / 77802192 / 77865573 | 0 / 0 / 0 / 0 / 0 | 71370544 / 76535985 / 77464053 / 77799915 / 77863625 | 71372847 / 76538074 / 77466585 / 77802192 / 77865573 | 11226858 | 3595844.643 |
| quickfix-quickfix/binary/tls/1 / 1 | 8315219 / 8900858 / 9989052 / 10411466 / 10519078 | 8372897 / 8959487 / 10016616 / 10474957 / 10526686 | 0 / 0 / 0 / 0 / 0 | 8315219 / 8900858 / 9989052 / 10411466 / 10519078 | 8372897 / 8959487 / 10016616 / 10474957 / 10526686 | 9847458 | 16280321.004 |
| quickfix-quickfix/binary/tls/2 / 1 | 8196355 / 10667451 / 11245934 / 11731394 / 11777277 | 8231529 / 10763152 / 11325973 / 11813146 / 11868458 | 0 / 0 / 0 / 0 / 0 | 8196355 / 10667451 / 11245934 / 11731394 / 11777277 | 8231529 / 10763152 / 11325973 / 11813146 / 11868458 | 9847458 | 16402695.220 |
| quickfix-quickfix/binary/tls/3 / 1 | 8374086 / 10844141 / 11156231 / 11601459 / 11634499 | 8431285 / 10934071 / 11248682 / 11700324 / 11718024 | 0 / 0 / 0 / 0 / 0 | 8374086 / 10844141 / 11156231 / 11601459 / 11634499 | 8431285 / 10934071 / 11248682 / 11700324 / 11718024 | 9847458 | 22894549.291 |
| quickfix-quickfix/fragmentation/tls/1 / 1 | 32352797 / 42385982 / 51136838 / 51711082 / 51776751 | 32475677 / 42459752 / 51184970 / 51745386 / 51829426 | 0 / 0 / 0 / 0 / 0 | 32352797 / 42385982 / 51136838 / 51711082 / 51776751 | 32475677 / 42459752 / 51184970 / 51745386 / 51829426 | 9847458 | 10464823.138 |
| quickfix-quickfix/fragmentation/tls/2 / 1 | 32309749 / 41581505 / 49026996 / 54216229 / 56074706 | 32392840 / 41651851 / 49120102 / 54341053 / 56200410 | 0 / 0 / 0 / 0 / 0 | 32309749 / 41581505 / 49026996 / 54216229 / 56074706 | 32392840 / 41651851 / 49120102 / 54341053 / 56200410 | 9847458 | 10952134.516 |
| quickfix-quickfix/fragmentation/tls/3 / 1 | 28548793 / 35681536 / 41816603 / 42940041 / 43587856 | 28626951 / 35761427 / 41880103 / 43024382 / 43598492 | 0 / 0 / 0 / 0 / 0 | 28548793 / 35681536 / 41816603 / 42940041 / 43587856 | 28626951 / 35761427 / 41880103 / 43024382 / 43598492 | 9847458 | 10650082.826 |
| quickfix-quickfix/replay/tls/1 / 1 | 4756161 / 5807584 / 6164223 / 6208762 / 6233645 | 4778209 / 5841076 / 6200584 / 6264374 / 6282067 | 0 / 0 / 0 / 0 / 0 | 4756161 / 5807584 / 6164223 / 6208762 / 6233645 | 4778209 / 5841076 / 6200584 / 6264374 / 6282067 | 803549 | 635000.237 |
| quickfix-quickfix/replay/tls/2 / 1 | 4776660 / 4992493 / 5137888 / 5194700 / 5211156 | 4797156 / 5008415 / 5160419 / 5220839 / 5223593 | 0 / 0 / 0 / 0 / 0 | 4776660 / 4992493 / 5137888 / 5194700 / 5211156 | 4797156 / 5008415 / 5160419 / 5220839 / 5223593 | 803549 | 631194.199 |
| quickfix-quickfix/replay/tls/3 / 1 | 5026496 / 7839780 / 10262468 / 11093205 / 11280851 | 5052267 / 7903129 / 10337336 / 11155114 / 11341684 | 0 / 0 / 0 / 0 / 0 | 5026496 / 7839780 / 10262468 / 11093205 / 11280851 | 5052267 / 7903129 / 10337336 / 11155114 / 11341684 | 803549 | 989027.032 |
| quickfix-quickfix/overload/tls/1 / 1 | 4653961 / 6246572 / 6466820 / 6540455 / 6543418 | 4682960 / 6298006 / 6507212 / 6599501 / 6604278 | 75451291 / 140307508 / 146400163 / 148131392 / 148299266 | 80348955 / 145205012 / 151186538 / 152352104 / 152477730 | 80406532 / 145231302 / 151216481 / 152383338 / 152507563 | 803258 | 1029891.885 |
| quickfix-quickfix/overload/tls/2 / 1 | 6125615 / 6428659 / 6884230 / 7072143 / 7121069 | 6179415 / 6482770 / 6935606 / 7121918 / 7184758 | 75979152 / 162838404 / 170600363 / 172321949 / 172551111 | 82193662 / 169082930 / 175549170 / 176714263 / 176856273 | 82247971 / 169140762 / 175578978 / 176749579 / 176942239 | 803258 | 1034268.872 |
| quickfix-quickfix/overload/tls/3 / 1 | 4787835 / 5061657 / 5180189 / 5259179 / 5283259 | 4816067 / 5090746 / 5208924 / 5305973 / 5314177 | 71333081 / 138490218 / 144329051 / 145575395 / 145752893 | 76167303 / 143256474 / 148590685 / 149716815 / 149847655 | 76200533 / 143289775 / 148620418 / 149750816 / 149908723 | 803258 | 1039064.981 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client | 1183 | 307368 | 0 | 34737 | 77560 | 891251 | 77336 / 889309 |
| native-native/scalar/tcp/1 / server | 831 | 284734 | 0 | 54061 | 152053 | 1857654 | 152019 / 1857338 |
| native-native/scalar/tcp/2 / client | 1183 | 307368 | 0 | 34737 | 77560 | 891245 | 77336 / 889303 |
| native-native/scalar/tcp/2 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857648 | 152019 / 1857332 |
| native-native/scalar/tcp/3 / client | 1186 | 307464 | 0 | 34741 | 77560 | 891237 | 77336 / 889295 |
| native-native/scalar/tcp/3 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857626 | 152019 / 1857310 |
| native-native/groups/tcp/1 / client | 1192 | 309480 | 0 | 43696 | 801443 | 30005133 | 801219 / 30003191 |
| native-native/groups/tcp/1 / server | 22837 | 209110270 | 0 | 210414 | 224673 | 454424338 | 224639 / 454424022 |
| native-native/groups/tcp/2 / client | 1190 | 309432 | 0 | 43694 | 801485 | 30005196 | 801261 / 30003254 |
| native-native/groups/tcp/2 / server | 22836 | 209109758 | 0 | 210414 | 224673 | 454424326 | 224639 / 454424010 |
| native-native/groups/tcp/3 / client | 1192 | 309480 | 0 | 43696 | 801462 | 30005204 | 801238 / 30003262 |
| native-native/groups/tcp/3 / server | 22837 | 209110270 | 0 | 210415 | 224673 | 454424274 | 224639 / 454423958 |
| native-native/binary/tcp/1 / client | 1185 | 307896 | 0 | 65348 | 84167 | 19350673 | 83943 / 19348731 |
| native-native/binary/tcp/1 / server | 833 | 285246 | 0 | 76040 | 165260 | 38989002 | 165226 / 38988686 |
| native-native/binary/tcp/2 / client | 1188 | 307992 | 0 | 65244 | 84167 | 19350694 | 83943 / 19348752 |
| native-native/binary/tcp/2 / server | 833 | 285246 | 0 | 76045 | 165260 | 38989071 | 165226 / 38988755 |
| native-native/binary/tcp/3 / client | 1188 | 308008 | 0 | 65204 | 84166 | 19350708 | 83942 / 19348766 |
| native-native/binary/tcp/3 / server | 833 | 285246 | 0 | 76051 | 165260 | 38989073 | 165226 / 38988757 |
| native-native/fragmentation/tcp/1 / client | 1188 | 307976 | 0 | 63053 | 84166 | 19350713 | 83942 / 19348771 |
| native-native/fragmentation/tcp/1 / server | 833 | 285246 | 0 | 168060 | 165260 | 38989128 | 165226 / 38988812 |
| native-native/fragmentation/tcp/2 / client | 1188 | 308008 | 0 | 62297 | 84166 | 19350729 | 83942 / 19348787 |
| native-native/fragmentation/tcp/2 / server | 833 | 285246 | 0 | 168137 | 165260 | 38989183 | 165226 / 38988867 |
| native-native/fragmentation/tcp/3 / client | 1188 | 307976 | 0 | 62238 | 84166 | 19350717 | 83942 / 19348775 |
| native-native/fragmentation/tcp/3 / server | 833 | 285246 | 0 | 167118 | 165260 | 38989110 | 165226 / 38988794 |
| native-native/replay/tcp/1 / client | 1187 | 307720 | 0 | 34866 | 77645 | 892426 | 77421 / 890484 |
| native-native/replay/tcp/1 / server | 831 | 284734 | 0 | 54095 | 152140 | 1858943 | 152106 / 1858627 |
| native-native/replay/tcp/2 / client | 1186 | 307736 | 0 | 34854 | 77645 | 892432 | 77421 / 890490 |
| native-native/replay/tcp/2 / server | 831 | 284734 | 0 | 54097 | 152140 | 1858973 | 152106 / 1858657 |
| native-native/replay/tcp/3 / client | 1186 | 307736 | 0 | 34866 | 77645 | 892444 | 77421 / 890502 |
| native-native/replay/tcp/3 / server | 831 | 284734 | 0 | 54094 | 152140 | 1858979 | 152106 / 1858663 |
| native-native/overload/tcp/1 / client | 1186 | 307464 | 0 | 34741 | 77559 | 891216 | 77335 / 889274 |
| native-native/overload/tcp/1 / server | 830 | 284222 | 0 | 54060 | 152053 | 1857622 | 152019 / 1857306 |
| native-native/overload/tcp/2 / client | 1183 | 307368 | 0 | 34737 | 77560 | 891265 | 77336 / 889323 |
| native-native/overload/tcp/2 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857682 | 152019 / 1857366 |
| native-native/overload/tcp/3 / client | 1183 | 307368 | 0 | 34741 | 77560 | 891258 | 77336 / 889316 |
| native-native/overload/tcp/3 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857674 | 152019 / 1857358 |
| native-native/scalar/tls/1 / client | 11711 | 972632 | 0 | 45837 | 88288 | 1356058 | 77354 / 889457 |
| native-native/scalar/tls/1 / server | 11470 | 998447 | 0 | 65134 | 173084 | 3087362 | 152031 / 1857461 |
| native-native/scalar/tls/2 / client | 11710 | 972632 | 0 | 45836 | 88290 | 1356121 | 77356 / 889490 |
| native-native/scalar/tls/2 / server | 11470 | 998447 | 0 | 65133 | 173085 | 3092224 | 152031 / 1857463 |
| native-native/scalar/tls/3 / client | 11710 | 972648 | 0 | 45836 | 88289 | 1356059 | 77355 / 889458 |
| native-native/scalar/tls/3 / server | 11470 | 998447 | 0 | 65133 | 173130 | 3092922 | 152031 / 1857431 |
| native-native/groups/tls/1 / client | 11718 | 996264 | 0 | 54790 | 812184 | 40893585 | 801250 / 30003369 |
| native-native/groups/tls/1 / server | 33478 | 209844879 | 0 | 210489 | 245697 | 455650295 | 224650 / 454424026 |
| native-native/groups/tls/2 / client | 11720 | 996312 | 0 | 54792 | 812125 | 40893475 | 801191 / 30003257 |
| native-native/groups/tls/2 / server | 33479 | 209845135 | 0 | 210498 | 245703 | 455652389 | 224653 / 454424057 |
| native-native/groups/tls/3 / client | 11718 | 996248 | 0 | 54790 | 812157 | 40893597 | 801223 / 30003346 |
| native-native/groups/tls/3 / server | 33479 | 209845135 | 0 | 210496 | 245776 | 455664682 | 224653 / 454424101 |
| native-native/binary/tls/1 / client | 11717 | 1010184 | 0 | 55097 | 94895 | 28859754 | 83961 / 19348919 |
| native-native/binary/tls/1 / server | 11476 | 1035951 | 0 | 76303 | 186328 | 58309902 | 165237 / 38988820 |
| native-native/binary/tls/2 / client | 11716 | 1010120 | 0 | 54943 | 94895 | 28859731 | 83961 / 19348910 |
| native-native/binary/tls/2 / server | 11476 | 1035951 | 0 | 76163 | 186300 | 58308759 | 165237 / 38988802 |
| native-native/binary/tls/3 / client | 11717 | 1010184 | 0 | 54726 | 94895 | 28859714 | 83961 / 19348904 |
| native-native/binary/tls/3 / server | 11476 | 1035951 | 0 | 76196 | 186337 | 58312833 | 165237 / 38988813 |
| native-native/fragmentation/tls/1 / client | 11722 | 1011976 | 0 | 58915 | 94917 | 28860166 | 83960 / 19348865 |
| native-native/fragmentation/tls/1 / server | 11474 | 1017551 | 0 | 223547 | 186291 | 58308384 | 165237 / 38988803 |
| native-native/fragmentation/tls/2 / client | 11722 | 1011976 | 0 | 58975 | 94917 | 28860172 | 83960 / 19348865 |
| native-native/fragmentation/tls/2 / server | 11476 | 1018063 | 0 | 223549 | 186310 | 58308739 | 165237 / 38988789 |
| native-native/fragmentation/tls/3 / client | 11719 | 1011880 | 0 | 58967 | 94917 | 28860271 | 83960 / 19348934 |
| native-native/fragmentation/tls/3 / server | 11475 | 1017807 | 0 | 223548 | 186326 | 58311369 | 165237 / 38988913 |
| native-native/replay/tls/1 / client | 11716 | 974696 | 0 | 45979 | 88409 | 1358139 | 77440 / 890623 |
| native-native/replay/tls/1 / server | 11470 | 998447 | 0 | 65170 | 173208 | 3094922 | 152118 / 1858700 |
| native-native/replay/tls/2 / client | 11717 | 974728 | 0 | 45966 | 88409 | 1358146 | 77440 / 890619 |
| native-native/replay/tls/2 / server | 11470 | 998447 | 0 | 65170 | 173198 | 3092871 | 152118 / 1858702 |
| native-native/replay/tls/3 / client | 11714 | 974648 | 0 | 45981 | 88409 | 1358150 | 77440 / 890626 |
| native-native/replay/tls/3 / server | 11473 | 999215 | 0 | 65173 | 173253 | 3098184 | 152118 / 1858715 |
| native-native/overload/tls/1 / client | 11708 | 972536 | 0 | 45834 | 88289 | 1356040 | 77355 / 889443 |
| native-native/overload/tls/1 / server | 11470 | 998447 | 0 | 65133 | 173093 | 3087128 | 152031 / 1857401 |
| native-native/overload/tls/2 / client | 11711 | 972632 | 0 | 45837 | 88288 | 1356040 | 77354 / 889424 |
| native-native/overload/tls/2 / server | 11470 | 998447 | 0 | 65133 | 173095 | 3088331 | 152031 / 1857399 |
| native-native/overload/tls/3 / client | 11710 | 972600 | 0 | 45836 | 88288 | 1356085 | 77354 / 889456 |
| native-native/overload/tls/3 / server | 11470 | 998447 | 0 | 65133 | 173091 | 3088618 | 152031 / 1857459 |
| native-quickfix/scalar/tcp/1 / client | 1186 | 307464 | 0 | 34744 | 77533 | 890859 | 77309 / 888917 |
| native-quickfix/scalar/tcp/1 / server | 1863 | 5813374 | 0 | 55013 | 815739 | 14618563 | 615389 / 8326125 |
| native-quickfix/scalar/tcp/2 / client | 1183 | 307368 | 0 | 34738 | 77533 | 890873 | 77309 / 888931 |
| native-quickfix/scalar/tcp/2 / server | 1863 | 5813374 | 0 | 55013 | 815738 | 11972252 | 615388 / 8326225 |
| native-quickfix/scalar/tcp/3 / client | 1186 | 307496 | 0 | 34735 | 77533 | 890877 | 77309 / 888935 |
| native-quickfix/scalar/tcp/3 / server | 1863 | 5813374 | 0 | 55013 | 815735 | 11249159 | 615387 / 8326198 |
| native-quickfix/groups/tcp/1 / client | 1193 | 309512 | 0 | 43690 | 801433 | 30004779 | 801209 / 30002837 |
| native-quickfix/groups/tcp/1 / server | 1866 | 5814142 | 0 | 347759 | 3157082 | 42107253 | 2953161 / 20577018 |
| native-quickfix/groups/tcp/2 / client | 1193 | 309544 | 0 | 43687 | 801389 | 30004723 | 801165 / 30002781 |
| native-quickfix/groups/tcp/2 / server | 1866 | 5814142 | 0 | 347759 | 3157084 | 42119335 | 2953163 / 20576948 |
| native-quickfix/groups/tcp/3 / client | 1190 | 309416 | 0 | 43684 | 801389 | 30004714 | 801165 / 30002772 |
| native-quickfix/groups/tcp/3 / server | 1866 | 5814142 | 0 | 347759 | 3157084 | 42165804 | 2953163 / 20576906 |
| native-quickfix/binary/tcp/1 / client | 1188 | 307976 | 0 | 65512 | 84140 | 19350299 | 83916 / 19348357 |
| native-quickfix/binary/tcp/1 / server | 1863 | 5813374 | 0 | 52815 | 851362 | 111668119 | 637600 / 71552803 |
| native-quickfix/binary/tcp/2 / client | 1185 | 307896 | 0 | 65366 | 84140 | 19350263 | 83916 / 19348321 |
| native-quickfix/binary/tcp/2 / server | 1863 | 5813374 | 0 | 52815 | 851319 | 111522417 | 637578 / 71552623 |
| native-quickfix/binary/tcp/3 / client | 1187 | 307992 | 0 | 65240 | 84140 | 19350333 | 83916 / 19348391 |
| native-quickfix/binary/tcp/3 / server | 1863 | 5813374 | 0 | 52815 | 851269 | 111354404 | 637553 / 71552684 |
| native-quickfix/fragmentation/tcp/1 / client | 1188 | 307992 | 0 | 61936 | 84140 | 19350378 | 83916 / 19348436 |
| native-quickfix/fragmentation/tcp/1 / server | 1863 | 5813374 | 0 | 52815 | 909613 | 110216730 | 666727 / 71669440 |
| native-quickfix/fragmentation/tcp/2 / client | 1188 | 307976 | 0 | 62296 | 84139 | 19350269 | 83915 / 19348327 |
| native-quickfix/fragmentation/tcp/2 / server | 1863 | 5813374 | 0 | 52815 | 947864 | 110249793 | 685852 / 71745785 |
| native-quickfix/fragmentation/tcp/3 / client | 1185 | 307912 | 0 | 62105 | 84140 | 19350268 | 83916 / 19348326 |
| native-quickfix/fragmentation/tcp/3 / server | 1863 | 5813374 | 0 | 52815 | 932017 | 110222109 | 677929 / 71714044 |
| native-quickfix/replay/tcp/1 / client | 1187 | 307736 | 0 | 34875 | 77591 | 891638 | 77367 / 889696 |
| native-quickfix/replay/tcp/1 / server | 1864 | 5813630 | 0 | 55019 | 816077 | 11615026 | 615643 / 8329807 |
| native-quickfix/replay/tcp/2 / client | 1186 | 307736 | 0 | 34830 | 77591 | 891617 | 77367 / 889675 |
| native-quickfix/replay/tcp/2 / server | 1864 | 5813630 | 0 | 55019 | 816077 | 11565423 | 615643 / 8329647 |
| native-quickfix/replay/tcp/3 / client | 1187 | 307720 | 0 | 34849 | 77591 | 891636 | 77367 / 889694 |
| native-quickfix/replay/tcp/3 / server | 1864 | 5813630 | 0 | 55019 | 816083 | 11963106 | 615646 / 8329774 |
| native-quickfix/overload/tcp/1 / client | 1183 | 307368 | 0 | 34726 | 77533 | 890851 | 77309 / 888909 |
| native-quickfix/overload/tcp/1 / server | 1863 | 5813374 | 0 | 55013 | 815733 | 11177339 | 615386 / 8326047 |
| native-quickfix/overload/tcp/2 / client | 1186 | 307480 | 0 | 34729 | 77533 | 890864 | 77309 / 888922 |
| native-quickfix/overload/tcp/2 / server | 1863 | 5813374 | 0 | 55013 | 815733 | 11421137 | 615386 / 8326286 |
| native-quickfix/overload/tcp/3 / client | 1185 | 307432 | 0 | 34737 | 77533 | 890846 | 77309 / 888904 |
| native-quickfix/overload/tcp/3 / server | 1863 | 5813374 | 0 | 55013 | 815739 | 12035997 | 615389 / 8326147 |
| native-quickfix/scalar/tls/1 / client | 11644 | 969840 | 0 | 45755 | 88341 | 1357099 | 77325 / 889041 |
| native-quickfix/scalar/tls/1 / server | 31795 | 7546492 | 0 | 309139 | 846867 | 12492653 | 615423 / 8327263 |
| native-quickfix/scalar/tls/2 / client | 11641 | 969744 | 0 | 45752 | 88341 | 1357058 | 77325 / 889035 |
| native-quickfix/scalar/tls/2 / server | 31794 | 7546237 | 0 | 309138 | 846881 | 12495578 | 615423 / 8327158 |
| native-quickfix/scalar/tls/3 / client | 11644 | 969824 | 0 | 45755 | 88341 | 1357080 | 77325 / 889044 |
| native-quickfix/scalar/tls/3 / server | 31795 | 7546493 | 0 | 309139 | 846862 | 12492339 | 615423 / 8327197 |
| native-quickfix/groups/tls/1 / client | 11652 | 993728 | 0 | 54711 | 812187 | 40894508 | 801171 / 30002879 |
| native-quickfix/groups/tls/1 / server | 31799 | 7548027 | 0 | 601948 | 3185494 | 45584763 | 2951832 / 20572502 |
| native-quickfix/groups/tls/2 / client | 11655 | 993792 | 0 | 54714 | 812233 | 40894599 | 801217 / 30002932 |
| native-quickfix/groups/tls/2 / server | 31799 | 7548028 | 0 | 601916 | 3185447 | 45578107 | 2951832 / 20572616 |
| native-quickfix/groups/tls/3 / client | 11654 | 993776 | 0 | 54713 | 812228 | 40894597 | 801212 / 30002941 |
| native-quickfix/groups/tls/3 / server | 31799 | 7548027 | 0 | 601916 | 3185475 | 45584308 | 2951832 / 20572583 |
| native-quickfix/binary/tls/1 / client | 11651 | 1016576 | 0 | 55127 | 94947 | 28860789 | 83931 / 19348524 |
| native-quickfix/binary/tls/1 / server | 31794 | 7546236 | 0 | 306940 | 882052 | 139000528 | 637423 / 71553084 |
| native-quickfix/binary/tls/2 / client | 11651 | 1016608 | 0 | 55394 | 94947 | 28860791 | 83931 / 19348515 |
| native-quickfix/binary/tls/2 / server | 31794 | 7546236 | 0 | 306940 | 882094 | 139007275 | 637423 / 71553111 |
| native-quickfix/binary/tls/3 / client | 11648 | 1016480 | 0 | 54616 | 94942 | 28860730 | 83931 / 19348491 |
| native-quickfix/binary/tls/3 / server | 31794 | 7546236 | 0 | 306940 | 882092 | 139005116 | 637423 / 71553036 |
| native-quickfix/fragmentation/tls/1 / client | 11723 | 1021224 | 0 | 55250 | 94886 | 28859642 | 83933 / 19348476 |
| native-quickfix/fragmentation/tls/1 / server | 177006 | 13356632 | 0 | 5243742 | 1753287 | 144239748 | 782623 / 72133822 |
| native-quickfix/fragmentation/tls/2 / client | 11723 | 1021240 | 0 | 55346 | 94886 | 28859660 | 83933 / 19348490 |
| native-quickfix/fragmentation/tls/2 / server | 177004 | 13356120 | 0 | 5243740 | 1753303 | 144243810 | 782623 / 72133834 |
| native-quickfix/fragmentation/tls/3 / client | 11723 | 1021256 | 0 | 54927 | 94886 | 28859693 | 83933 / 19348511 |
| native-quickfix/fragmentation/tls/3 / server | 177005 | 13356377 | 0 | 5243741 | 1753274 | 144239030 | 782623 / 72133870 |
| native-quickfix/replay/tls/1 / client | 11716 | 974744 | 0 | 45965 | 88347 | 1357092 | 77386 / 889843 |
| native-quickfix/replay/tls/1 / server | 31813 | 7548696 | 0 | 309286 | 847213 | 12498189 | 615679 / 8330880 |
| native-quickfix/replay/tls/2 / client | 11717 | 974744 | 0 | 45967 | 88347 | 1357080 | 77386 / 889837 |
| native-quickfix/replay/tls/2 / server | 31813 | 7548697 | 0 | 309286 | 847229 | 12498944 | 615679 / 8330862 |
| native-quickfix/replay/tls/3 / client | 11717 | 974744 | 0 | 45938 | 88347 | 1357018 | 77386 / 889817 |
| native-quickfix/replay/tls/3 / server | 31813 | 7548697 | 0 | 309286 | 847251 | 12499096 | 615679 / 8330736 |
| native-quickfix/overload/tls/1 / client | 11643 | 969840 | 0 | 45754 | 88341 | 1357127 | 77325 / 889065 |
| native-quickfix/overload/tls/1 / server | 31794 | 7546236 | 0 | 309138 | 846854 | 12487006 | 615423 / 8327269 |
| native-quickfix/overload/tls/2 / client | 11644 | 969824 | 0 | 45755 | 88341 | 1357139 | 77325 / 889066 |
| native-quickfix/overload/tls/2 / server | 31794 | 7546235 | 0 | 309138 | 846842 | 12486499 | 615423 / 8327306 |
| native-quickfix/overload/tls/3 / client | 11641 | 969728 | 0 | 45752 | 88341 | 1357131 | 77325 / 889054 |
| native-quickfix/overload/tls/3 / server | 31795 | 7546491 | 0 | 309139 | 846835 | 12488381 | 615423 / 8327320 |
| quickfix-native/scalar/tcp/1 / client | 1864 | 5813462 | 0 | 28614 | 970362 | 29380284 | 704491 / 8800821 |
| quickfix-native/scalar/tcp/1 / server | 831 | 284734 | 0 | 54050 | 152026 | 1857269 | 151992 / 1856953 |
| quickfix-native/scalar/tcp/2 / client | 1864 | 5813462 | 0 | 28614 | 970372 | 29333185 | 704501 / 8801347 |
| quickfix-native/scalar/tcp/2 / server | 831 | 284734 | 0 | 54049 | 152026 | 1857335 | 151992 / 1857019 |
| quickfix-native/scalar/tcp/3 / client | 1864 | 5813462 | 0 | 28614 | 970375 | 29321058 | 704504 / 8801109 |
| quickfix-native/scalar/tcp/3 / server | 831 | 284734 | 0 | 54050 | 152026 | 1857293 | 151992 / 1856977 |
| quickfix-native/groups/tcp/1 / client | 1867 | 5814230 | 0 | 96960 | 7512216 | 55597948 | 5787858 / 41881762 |
| quickfix-native/groups/tcp/1 / server | 22837 | 209110270 | 0 | 210404 | 224646 | 454423885 | 224612 / 454423569 |
| quickfix-native/groups/tcp/2 / client | 1867 | 5814230 | 0 | 96960 | 7515628 | 55621969 | 5791269 / 41981611 |
| quickfix-native/groups/tcp/2 / server | 22837 | 209110270 | 0 | 210404 | 224646 | 454423863 | 224612 / 454423547 |
| quickfix-native/groups/tcp/3 / client | 1867 | 5814230 | 0 | 96960 | 7516320 | 55591302 | 5791962 / 42001872 |
| quickfix-native/groups/tcp/3 / server | 22837 | 209110270 | 0 | 210404 | 224647 | 454423867 | 224613 / 454423551 |
| quickfix-native/binary/tcp/1 / client | 1864 | 5813462 | 0 | 24216 | 1076311 | 147787264 | 827844 / 81978325 |
| quickfix-native/binary/tcp/1 / server | 833 | 285246 | 0 | 75816 | 165233 | 38988728 | 165199 / 38988412 |
| quickfix-native/binary/tcp/2 / client | 1864 | 5813462 | 0 | 24216 | 1076649 | 147538882 | 828152 / 81986296 |
| quickfix-native/binary/tcp/2 / server | 833 | 285246 | 0 | 76052 | 165234 | 38988577 | 165200 / 38988261 |
| quickfix-native/binary/tcp/3 / client | 1864 | 5813462 | 0 | 24216 | 1076535 | 147596559 | 828046 / 81983946 |
| quickfix-native/binary/tcp/3 / server | 833 | 285246 | 0 | 75855 | 165234 | 38988750 | 165200 / 38988434 |
| quickfix-native/fragmentation/tcp/1 / client | 1864 | 5813462 | 0 | 24216 | 1076466 | 147548612 | 828038 / 81984876 |
| quickfix-native/fragmentation/tcp/1 / server | 833 | 285246 | 0 | 172228 | 165233 | 38988658 | 165199 / 38988342 |
| quickfix-native/fragmentation/tcp/2 / client | 1864 | 5813462 | 0 | 24216 | 1076513 | 147549627 | 828089 / 81986501 |
| quickfix-native/fragmentation/tcp/2 / server | 833 | 285246 | 0 | 161617 | 165233 | 38988698 | 165199 / 38988382 |
| quickfix-native/fragmentation/tcp/3 / client | 1864 | 5813462 | 0 | 24216 | 1076448 | 147586470 | 828020 / 81984346 |
| quickfix-native/fragmentation/tcp/3 / server | 832 | 284734 | 0 | 153996 | 165233 | 38988657 | 165199 / 38988341 |
| quickfix-native/replay/tcp/1 / client | 1864 | 5813462 | 0 | 28620 | 976336 | 29421141 | 708895 / 8840305 |
| quickfix-native/replay/tcp/1 / server | 832 | 284990 | 0 | 54407 | 152873 | 1869274 | 152839 / 1868958 |
| quickfix-native/replay/tcp/2 / client | 1864 | 5813462 | 0 | 28620 | 974017 | 29346626 | 707204 / 8826233 |
| quickfix-native/replay/tcp/2 / server | 832 | 284990 | 0 | 54382 | 152549 | 1864674 | 152515 / 1864358 |
| quickfix-native/replay/tcp/3 / client | 1864 | 5813462 | 0 | 28620 | 976280 | 29410754 | 708843 / 8839946 |
| quickfix-native/replay/tcp/3 / server | 832 | 284990 | 0 | 54440 | 152873 | 1869206 | 152839 / 1868890 |
| quickfix-native/overload/tcp/1 / client | 1864 | 5813462 | 0 | 28614 | 970382 | 29349345 | 704510 / 8801190 |
| quickfix-native/overload/tcp/1 / server | 831 | 284734 | 0 | 54050 | 152026 | 1857223 | 151992 / 1856907 |
| quickfix-native/overload/tcp/2 / client | 1864 | 5813462 | 0 | 28614 | 970363 | 29339759 | 704493 / 8800809 |
| quickfix-native/overload/tcp/2 / server | 831 | 284734 | 0 | 54049 | 152026 | 1857245 | 151992 / 1856929 |
| quickfix-native/overload/tcp/3 / client | 1864 | 5813462 | 0 | 28614 | 970378 | 29334138 | 704507 / 8801237 |
| quickfix-native/overload/tcp/3 / server | 832 | 284990 | 0 | 54057 | 152030 | 1857385 | 151996 / 1857069 |
| quickfix-native/scalar/tls/1 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551849 | 742912 / 9930618 |
| quickfix-native/scalar/tls/1 / server | 11313 | 981951 | 0 | 64890 | 173073 | 3090083 | 152003 / 1857057 |
| quickfix-native/scalar/tls/2 / client | 59311 | 9949780 | 0 | 319054 | 1049351 | 15551525 | 742916 / 9930481 |
| quickfix-native/scalar/tls/2 / server | 11313 | 981951 | 0 | 64890 | 173079 | 3091731 | 152001 / 1857031 |
| quickfix-native/scalar/tls/3 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551680 | 742912 / 9930534 |
| quickfix-native/scalar/tls/3 / server | 11313 | 981951 | 0 | 64890 | 173055 | 3089493 | 152001 / 1857039 |
| quickfix-native/groups/tls/1 / client | 59317 | 9952084 | 0 | 387400 | 7570404 | 68967098 | 5805369 / 42395310 |
| quickfix-native/groups/tls/1 / server | 33322 | 209828639 | 0 | 210247 | 245665 | 455653874 | 224622 / 454423702 |
| quickfix-native/groups/tls/2 / client | 59317 | 9952084 | 0 | 387400 | 7572546 | 69029536 | 5807511 / 42457942 |
| quickfix-native/groups/tls/2 / server | 33321 | 209828383 | 0 | 210246 | 245715 | 455660876 | 224622 / 454423642 |
| quickfix-native/groups/tls/3 / client | 59317 | 9952084 | 0 | 387400 | 7572150 | 69018105 | 5807115 / 42446421 |
| quickfix-native/groups/tls/3 / server | 33322 | 209828639 | 0 | 210247 | 245713 | 455659915 | 224622 / 454423690 |
| quickfix-native/binary/tls/1 / client | 59311 | 9949780 | 0 | 314656 | 1130923 | 160379562 | 844112 / 82514047 |
| quickfix-native/binary/tls/1 / server | 11319 | 1019455 | 0 | 75905 | 186252 | 58305321 | 165207 / 38988282 |
| quickfix-native/binary/tls/2 / client | 59311 | 9949780 | 0 | 314752 | 1130950 | 160381176 | 844139 / 82515280 |
| quickfix-native/binary/tls/2 / server | 11320 | 1019711 | 0 | 75924 | 186280 | 58310267 | 165208 / 38988485 |
| quickfix-native/binary/tls/3 / client | 59311 | 9949780 | 0 | 314656 | 1130923 | 160379742 | 844112 / 82514123 |
| quickfix-native/binary/tls/3 / server | 11321 | 1028959 | 0 | 76006 | 186304 | 58310268 | 165207 / 38988291 |
| quickfix-native/fragmentation/tls/1 / client | 59339 | 9983887 | 0 | 314734 | 1130941 | 160380896 | 844112 / 82514338 |
| quickfix-native/fragmentation/tls/1 / server | 11475 | 1017807 | 0 | 223537 | 186263 | 58307462 | 165210 / 38988420 |
| quickfix-native/fragmentation/tls/2 / client | 59339 | 9983887 | 0 | 314734 | 1130941 | 160381018 | 844112 / 82514424 |
| quickfix-native/fragmentation/tls/2 / server | 11474 | 1017551 | 0 | 223536 | 186317 | 58315071 | 165210 / 38988481 |
| quickfix-native/fragmentation/tls/3 / client | 59339 | 9983887 | 0 | 314734 | 1130941 | 160380861 | 844112 / 82514329 |
| quickfix-native/fragmentation/tls/3 / server | 11475 | 1026799 | 0 | 223538 | 186278 | 58308501 | 165210 / 38988428 |
| quickfix-native/replay/tls/1 / client | 59377 | 9985407 | 0 | 320300 | 1056041 | 15629086 | 747783 / 9979059 |
| quickfix-native/replay/tls/1 / server | 11471 | 998703 | 0 | 65490 | 174138 | 3113173 | 152905 / 1869798 |
| quickfix-native/replay/tls/2 / client | 59363 | 9984847 | 0 | 319824 | 1053136 | 15596471 | 745662 / 9958502 |
| quickfix-native/replay/tls/2 / server | 11471 | 998703 | 0 | 65420 | 173709 | 3106622 | 152527 / 1864508 |
| quickfix-native/replay/tls/3 / client | 59361 | 9984767 | 0 | 319756 | 1052721 | 15591795 | 745359 / 9955559 |
| quickfix-native/replay/tls/3 / server | 11474 | 999471 | 0 | 65427 | 173613 | 3097198 | 152473 / 1863728 |
| quickfix-native/overload/tls/1 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551572 | 742912 / 9930480 |
| quickfix-native/overload/tls/1 / server | 11313 | 981951 | 0 | 64890 | 173102 | 3094481 | 152002 / 1857021 |
| quickfix-native/overload/tls/2 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551207 | 742912 / 9930297 |
| quickfix-native/overload/tls/2 / server | 11313 | 981951 | 0 | 64890 | 173062 | 3088126 | 152001 / 1856999 |
| quickfix-native/overload/tls/3 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551380 | 742912 / 9930384 |
| quickfix-native/overload/tls/3 / server | 11313 | 981951 | 0 | 64890 | 173074 | 3091123 | 152002 / 1857015 |
| quickfix-quickfix/scalar/tcp/1 / client | 1864 | 5813462 | 0 | 28611 | 829845 | 28676327 | 695572 / 8783957 |
| quickfix-quickfix/scalar/tcp/1 / server | 1863 | 5813374 | 0 | 55010 | 793594 | 10818421 | 615289 / 8325907 |
| quickfix-quickfix/scalar/tcp/2 / client | 1864 | 5813462 | 0 | 28611 | 829846 | 28623132 | 695575 / 8783966 |
| quickfix-quickfix/scalar/tcp/2 / server | 1863 | 5813374 | 0 | 55010 | 793593 | 10793116 | 615289 / 8325907 |
| quickfix-quickfix/scalar/tcp/3 / client | 1864 | 5813462 | 0 | 28611 | 831293 | 25771797 | 697050 / 8827770 |
| quickfix-quickfix/scalar/tcp/3 / server | 1863 | 5813374 | 0 | 55010 | 793604 | 11257237 | 615298 / 8326171 |
| quickfix-quickfix/groups/tcp/1 / client | 1867 | 5814230 | 0 | 96957 | 7378724 | 54969862 | 5785963 / 42070748 |
| quickfix-quickfix/groups/tcp/1 / server | 1866 | 5814142 | 0 | 347756 | 3133311 | 33687661 | 2952724 / 20599277 |
| quickfix-quickfix/groups/tcp/2 / client | 1867 | 5814230 | 0 | 96957 | 7387436 | 55060517 | 5794675 / 42326300 |
| quickfix-quickfix/groups/tcp/2 / server | 1866 | 5814142 | 0 | 347756 | 3132408 | 33643202 | 2951827 / 20573117 |
| quickfix-quickfix/groups/tcp/3 / client | 1867 | 5814230 | 0 | 96957 | 7381361 | 55033166 | 5788600 / 42148100 |
| quickfix-quickfix/groups/tcp/3 / server | 1866 | 5814142 | 0 | 347756 | 3134100 | 33666839 | 2953519 / 20622749 |
| quickfix-quickfix/binary/tcp/1 / client | 1864 | 5813462 | 0 | 24213 | 995906 | 146041421 | 820134 / 82037264 |
| quickfix-quickfix/binary/tcp/1 / server | 1863 | 5813374 | 0 | 52812 | 829355 | 111884474 | 637569 / 71550627 |
| quickfix-quickfix/binary/tcp/2 / client | 1864 | 5813462 | 0 | 24213 | 997799 | 144049914 | 822244 / 82104723 |
| quickfix-quickfix/binary/tcp/2 / server | 1863 | 5813374 | 0 | 52812 | 829241 | 111421256 | 637512 / 71550399 |
| quickfix-quickfix/binary/tcp/3 / client | 1864 | 5813462 | 0 | 24213 | 995181 | 147362074 | 819196 / 82004295 |
| quickfix-quickfix/binary/tcp/3 / server | 1863 | 5813374 | 0 | 52812 | 829161 | 111166495 | 637472 / 71550239 |
| quickfix-quickfix/fragmentation/tcp/1 / client | 1864 | 5813462 | 0 | 24213 | 995052 | 147385500 | 819115 / 82003059 |
| quickfix-quickfix/fragmentation/tcp/1 / server | 1863 | 5813374 | 0 | 52812 | 954264 | 110097247 | 700025 / 71800451 |
| quickfix-quickfix/fragmentation/tcp/2 / client | 1864 | 5813462 | 0 | 24213 | 995146 | 147215111 | 819216 / 82006199 |
| quickfix-quickfix/fragmentation/tcp/2 / server | 1863 | 5813374 | 0 | 52812 | 924518 | 110042489 | 685152 / 71740959 |
| quickfix-quickfix/fragmentation/tcp/3 / client | 1864 | 5813462 | 0 | 24213 | 995193 | 147341513 | 819252 / 82007027 |
| quickfix-quickfix/fragmentation/tcp/3 / server | 1863 | 5813374 | 0 | 52812 | 962804 | 110068602 | 704304 / 71818023 |
| quickfix-quickfix/replay/tcp/1 / client | 1864 | 5813462 | 0 | 28614 | 833943 | 28278385 | 699158 / 8816517 |
| quickfix-quickfix/replay/tcp/1 / server | 1865 | 5813886 | 0 | 55020 | 797600 | 11203485 | 618169 / 8355924 |
| quickfix-quickfix/replay/tcp/2 / client | 1864 | 5813462 | 0 | 28614 | 837097 | 28740350 | 701908 / 8839765 |
| quickfix-quickfix/replay/tcp/2 / server | 1866 | 5814142 | 0 | 55023 | 800634 | 11762033 | 620347 / 8378640 |
| quickfix-quickfix/replay/tcp/3 / client | 1864 | 5813462 | 0 | 28614 | 834157 | 26530328 | 699409 / 8827160 |
| quickfix-quickfix/replay/tcp/3 / server | 1865 | 5813886 | 0 | 55020 | 797454 | 11125385 | 618068 / 8355034 |
| quickfix-quickfix/overload/tcp/1 / client | 1864 | 5813462 | 0 | 28611 | 829850 | 28724170 | 695578 / 8784012 |
| quickfix-quickfix/overload/tcp/1 / server | 1863 | 5813374 | 0 | 55010 | 793593 | 10873716 | 615289 / 8325907 |
| quickfix-quickfix/overload/tcp/2 / client | 1864 | 5813462 | 0 | 28611 | 829846 | 28582906 | 695574 / 8783963 |
| quickfix-quickfix/overload/tcp/2 / server | 1863 | 5813374 | 0 | 55010 | 793594 | 10823586 | 615289 / 8325907 |
| quickfix-quickfix/overload/tcp/3 / client | 1864 | 5813462 | 0 | 28611 | 830143 | 26594883 | 695896 / 8793935 |
| quickfix-quickfix/overload/tcp/3 / server | 1863 | 5813374 | 0 | 55010 | 793595 | 10791308 | 615289 / 8325907 |
| quickfix-quickfix/scalar/tls/1 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935218 | 734006 / 9913910 |
| quickfix-quickfix/scalar/tls/1 / server | 31757 | 7539264 | 0 | 308963 | 824717 | 12233847 | 615326 / 8326978 |
| quickfix-quickfix/scalar/tls/2 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935218 | 734006 / 9913910 |
| quickfix-quickfix/scalar/tls/2 / server | 31757 | 7539263 | 0 | 308965 | 824742 | 12240542 | 615326 / 8326978 |
| quickfix-quickfix/scalar/tls/3 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935218 | 734006 / 9913910 |
| quickfix-quickfix/scalar/tls/3 / server | 31760 | 7540031 | 0 | 308968 | 824741 | 12237574 | 615326 / 8326978 |
| quickfix-quickfix/groups/tls/1 / client | 59341 | 9986031 | 0 | 387404 | 7430056 | 68354776 | 5796607 / 42382868 |
| quickfix-quickfix/groups/tls/1 / server | 31762 | 7541056 | 0 | 601711 | 3166256 | 45407721 | 2954651 / 20657840 |
| quickfix-quickfix/groups/tls/2 / client | 59341 | 9986031 | 0 | 387404 | 7431424 | 68394904 | 5797975 / 42422996 |
| quickfix-quickfix/groups/tls/2 / server | 31764 | 7541568 | 0 | 601713 | 3165802 | 45399569 | 2954201 / 20644640 |
| quickfix-quickfix/groups/tls/3 / client | 59341 | 9986031 | 0 | 387404 | 7429966 | 68352136 | 5796517 / 42380228 |
| quickfix-quickfix/groups/tls/3 / server | 31762 | 7541056 | 0 | 601711 | 3165512 | 45383721 | 2953958 / 20637512 |
| quickfix-quickfix/binary/tls/1 / client | 59335 | 9983727 | 0 | 314660 | 1049526 | 159957023 | 835206 / 82533275 |
| quickfix-quickfix/binary/tls/1 / server | 31758 | 7539520 | 0 | 306768 | 859907 | 138737065 | 637326 / 71550578 |
| quickfix-quickfix/binary/tls/2 / client | 59335 | 9983727 | 0 | 314660 | 1049526 | 159957023 | 835206 / 82533275 |
| quickfix-quickfix/binary/tls/2 / server | 31759 | 7539775 | 0 | 306767 | 859942 | 138741880 | 637326 / 71550578 |
| quickfix-quickfix/binary/tls/3 / client | 59335 | 9983727 | 0 | 314660 | 1049526 | 159957023 | 835206 / 82533275 |
| quickfix-quickfix/binary/tls/3 / server | 31757 | 7539263 | 0 | 306767 | 859949 | 138748328 | 637326 / 71550578 |
| quickfix-quickfix/fragmentation/tls/1 / client | 59335 | 9983727 | 0 | 314660 | 1050876 | 159996667 | 836556 / 82572875 |
| quickfix-quickfix/fragmentation/tls/1 / server | 177000 | 13355960 | 0 | 5243666 | 1731124 | 143975380 | 782535 / 72131642 |
| quickfix-quickfix/fragmentation/tls/2 / client | 59335 | 9983727 | 0 | 314660 | 1051830 | 160024651 | 837510 / 82600859 |
| quickfix-quickfix/fragmentation/tls/2 / server | 177000 | 13355961 | 0 | 5243666 | 1731141 | 143979781 | 782535 / 72131642 |
| quickfix-quickfix/fragmentation/tls/3 / client | 59335 | 9983727 | 0 | 314660 | 1049526 | 159957067 | 835206 / 82533275 |
| quickfix-quickfix/fragmentation/tls/3 / server | 177001 | 13356216 | 0 | 5243667 | 1731160 | 143981964 | 782526 / 72131378 |
| quickfix-quickfix/replay/tls/1 / client | 59377 | 9985407 | 0 | 320424 | 915645 | 15021847 | 739831 / 9971976 |
| quickfix-quickfix/replay/tls/1 / server | 31926 | 7554592 | 0 | 310591 | 831029 | 12315549 | 619728 / 8372730 |
| quickfix-quickfix/replay/tls/2 / client | 59353 | 9984447 | 0 | 319608 | 911529 | 14969507 | 736291 / 9936869 |
| quickfix-quickfix/replay/tls/2 / server | 31850 | 7550176 | 0 | 309697 | 827286 | 12270021 | 617127 / 8346011 |
| quickfix-quickfix/replay/tls/3 / client | 59355 | 9984527 | 0 | 319676 | 911872 | 14973882 | 736586 / 9939803 |
| quickfix-quickfix/replay/tls/3 / server | 31858 | 7551184 | 0 | 309774 | 827641 | 12273340 | 617338 / 8348039 |
| quickfix-quickfix/overload/tls/1 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935218 | 734006 / 9913910 |
| quickfix-quickfix/overload/tls/1 / server | 31758 | 7539520 | 0 | 308966 | 824698 | 12234407 | 615326 / 8326978 |
| quickfix-quickfix/overload/tls/2 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935218 | 734006 / 9913910 |
| quickfix-quickfix/overload/tls/2 / server | 31758 | 7539520 | 0 | 308966 | 824762 | 12243375 | 615326 / 8326978 |
| quickfix-quickfix/overload/tls/3 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935218 | 734006 / 9913910 |
| quickfix-quickfix/overload/tls/3 / server | 31757 | 7539263 | 0 | 308965 | 824703 | 12232830 | 615326 / 8326978 |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |
| native-native/scalar/tcp/1 / client | 26522 | 3124512 |
| native-native/scalar/tcp/1 / server | 39703 | 6218432 |
| native-native/scalar/tcp/1/audit-diagnostic / client | 26516 | 3124512 |
| native-native/scalar/tcp/1/audit-diagnostic / server | 39703 | 6218432 |
| native-native/scalar/tcp/2 / client | 26524 | 3124512 |
| native-native/scalar/tcp/2 / server | 39708 | 6218432 |
| native-native/scalar/tcp/2/audit-diagnostic / client | 26516 | 3124512 |
| native-native/scalar/tcp/2/audit-diagnostic / server | 39703 | 6218432 |
| native-native/scalar/tcp/3 / client | 26520 | 3124512 |
| native-native/scalar/tcp/3 / server | 39703 | 6218432 |
| native-native/scalar/tcp/3/audit-diagnostic / client | 26517 | 3124512 |
| native-native/scalar/tcp/3/audit-diagnostic / server | 39703 | 6218432 |
| native-native/groups/tcp/1 / client | 35456 | 39206176 |
| native-native/groups/tcp/1 / server | 176243 | 6255296 |
| native-native/groups/tcp/1/audit-diagnostic / client | 35456 | 39206176 |
| native-native/groups/tcp/1/audit-diagnostic / server | 176243 | 6255296 |
| native-native/groups/tcp/2 / client | 35458 | 39206176 |
| native-native/groups/tcp/2 / server | 176243 | 6255296 |
| native-native/groups/tcp/2/audit-diagnostic / client | 35456 | 39206176 |
| native-native/groups/tcp/2/audit-diagnostic / server | 176243 | 6255296 |
| native-native/groups/tcp/3 / client | 35456 | 39206176 |
| native-native/groups/tcp/3 / server | 176243 | 6255296 |
| native-native/groups/tcp/3/audit-diagnostic / client | 35456 | 39206176 |
| native-native/groups/tcp/3/audit-diagnostic / server | 176243 | 6255296 |
| native-native/binary/tcp/1 / client | 56554 | 39169312 |
| native-native/binary/tcp/1 / server | 61633 | 67544896 |
| native-native/binary/tcp/1/audit-diagnostic / client | 57120 | 39169312 |
| native-native/binary/tcp/1/audit-diagnostic / server | 61676 | 67544896 |
| native-native/binary/tcp/2 / client | 56891 | 39169312 |
| native-native/binary/tcp/2 / server | 61643 | 67544896 |
| native-native/binary/tcp/2/audit-diagnostic / client | 57013 | 39169312 |
| native-native/binary/tcp/2/audit-diagnostic / server | 61681 | 67544896 |
| native-native/binary/tcp/3 / client | 56410 | 39169312 |
| native-native/binary/tcp/3 / server | 61634 | 67544896 |
| native-native/binary/tcp/3/audit-diagnostic / client | 56973 | 39169312 |
| native-native/binary/tcp/3/audit-diagnostic / server | 61687 | 67544896 |
| native-native/fragmentation/tcp/1 / client | 53969 | 39169312 |
| native-native/fragmentation/tcp/1 / server | 141775 | 67544896 |
| native-native/fragmentation/tcp/1/audit-diagnostic / client | 54820 | 39169312 |
| native-native/fragmentation/tcp/1/audit-diagnostic / server | 153694 | 67544896 |
| native-native/fragmentation/tcp/2 / client | 54091 | 39169312 |
| native-native/fragmentation/tcp/2 / server | 156741 | 67544896 |
| native-native/fragmentation/tcp/2/audit-diagnostic / client | 54066 | 39169312 |
| native-native/fragmentation/tcp/2/audit-diagnostic / server | 153771 | 67544896 |
| native-native/fragmentation/tcp/3 / client | 55374 | 39169312 |
| native-native/fragmentation/tcp/3 / server | 145016 | 67544896 |
| native-native/fragmentation/tcp/3/audit-diagnostic / client | 54007 | 39169312 |
| native-native/fragmentation/tcp/3/audit-diagnostic / server | 152752 | 67544896 |
| native-native/replay/tcp/1 / client | 26613 | 3124512 |
| native-native/replay/tcp/1 / server | 39763 | 6220480 |
| native-native/replay/tcp/1/audit-diagnostic / client | 26630 | 3124512 |
| native-native/replay/tcp/1/audit-diagnostic / server | 39729 | 6218432 |
| native-native/replay/tcp/2 / client | 26631 | 3124512 |
| native-native/replay/tcp/2 / server | 39729 | 6218432 |
| native-native/replay/tcp/2/audit-diagnostic / client | 26620 | 3124512 |
| native-native/replay/tcp/2/audit-diagnostic / server | 39731 | 6218432 |
| native-native/replay/tcp/3 / client | 26621 | 3124512 |
| native-native/replay/tcp/3 / server | 39733 | 6218432 |
| native-native/replay/tcp/3/audit-diagnostic / client | 26631 | 3124512 |
| native-native/replay/tcp/3/audit-diagnostic / server | 39729 | 6218432 |
| native-native/overload/tcp/1 / client | 26518 | 3124512 |
| native-native/overload/tcp/1 / server | 39703 | 6218432 |
| native-native/overload/tcp/1/audit-diagnostic / client | 26517 | 3124512 |
| native-native/overload/tcp/1/audit-diagnostic / server | 39703 | 6218432 |
| native-native/overload/tcp/2 / client | 26519 | 3124512 |
| native-native/overload/tcp/2 / server | 39703 | 6218432 |
| native-native/overload/tcp/2/audit-diagnostic / client | 26516 | 3124512 |
| native-native/overload/tcp/2/audit-diagnostic / server | 39703 | 6218432 |
| native-native/overload/tcp/3 / client | 26516 | 3124512 |
| native-native/overload/tcp/3 / server | 39703 | 6218432 |
| native-native/overload/tcp/3/audit-diagnostic / client | 26520 | 3124512 |
| native-native/overload/tcp/3/audit-diagnostic / server | 39703 | 6218432 |
| native-native/scalar/tls/1 / client | 28752 | 3125152 |
| native-native/scalar/tls/1 / server | 44126 | 6219776 |
| native-native/scalar/tls/1/audit-diagnostic / client | 28752 | 3125152 |
| native-native/scalar/tls/1/audit-diagnostic / server | 44126 | 6219776 |
| native-native/scalar/tls/2 / client | 28752 | 3125152 |
| native-native/scalar/tls/2 / server | 44126 | 6219776 |
| native-native/scalar/tls/2/audit-diagnostic / client | 28752 | 3125152 |
| native-native/scalar/tls/2/audit-diagnostic / server | 44125 | 6219776 |
| native-native/scalar/tls/3 / client | 28752 | 3125152 |
| native-native/scalar/tls/3 / server | 44126 | 6219776 |
| native-native/scalar/tls/3/audit-diagnostic / client | 28752 | 3125152 |
| native-native/scalar/tls/3/audit-diagnostic / server | 44125 | 6219776 |
| native-native/groups/tls/1 / client | 37692 | 39206816 |
| native-native/groups/tls/1 / server | 169675 | 6256640 |
| native-native/groups/tls/1/audit-diagnostic / client | 37692 | 39206816 |
| native-native/groups/tls/1/audit-diagnostic / server | 169665 | 6256640 |
| native-native/groups/tls/2 / client | 37692 | 39206816 |
| native-native/groups/tls/2 / server | 169715 | 6256640 |
| native-native/groups/tls/2/audit-diagnostic / client | 37692 | 39206816 |
| native-native/groups/tls/2/audit-diagnostic / server | 169672 | 6256640 |
| native-native/groups/tls/3 / client | 37692 | 39206816 |
| native-native/groups/tls/3 / server | 169723 | 6256640 |
| native-native/groups/tls/3/audit-diagnostic / client | 37692 | 39206816 |
| native-native/groups/tls/3/audit-diagnostic / server | 169670 | 6256640 |
| native-native/binary/tls/1 / client | 37924 | 39169952 |
| native-native/binary/tls/1 / server | 55175 | 67546240 |
| native-native/binary/tls/1/audit-diagnostic / client | 38001 | 39169952 |
| native-native/binary/tls/1/audit-diagnostic / server | 55284 | 67546240 |
| native-native/binary/tls/2 / client | 37998 | 39169952 |
| native-native/binary/tls/2 / server | 55200 | 67546240 |
| native-native/binary/tls/2/audit-diagnostic / client | 37848 | 39169952 |
| native-native/binary/tls/2/audit-diagnostic / server | 55144 | 67546240 |
| native-native/binary/tls/3 / client | 38031 | 39169952 |
| native-native/binary/tls/3 / server | 55174 | 67546240 |
| native-native/binary/tls/3/audit-diagnostic / client | 37630 | 39169952 |
| native-native/binary/tls/3/audit-diagnostic / server | 55177 | 67546240 |
| native-native/fragmentation/tls/1 / client | 41794 | 39170208 |
| native-native/fragmentation/tls/1 / server | 202530 | 67546240 |
| native-native/fragmentation/tls/1/audit-diagnostic / client | 41814 | 39170208 |
| native-native/fragmentation/tls/1/audit-diagnostic / server | 202530 | 67546240 |
| native-native/fragmentation/tls/2 / client | 41890 | 39170208 |
| native-native/fragmentation/tls/2 / server | 202530 | 67546240 |
| native-native/fragmentation/tls/2/audit-diagnostic / client | 41874 | 39170208 |
| native-native/fragmentation/tls/2/audit-diagnostic / server | 202530 | 67546240 |
| native-native/fragmentation/tls/3 / client | 41806 | 39170208 |
| native-native/fragmentation/tls/3 / server | 202530 | 67546240 |
| native-native/fragmentation/tls/3/audit-diagnostic / client | 41869 | 39170208 |
| native-native/fragmentation/tls/3/audit-diagnostic / server | 202530 | 67546240 |
| native-native/replay/tls/1 / client | 28873 | 3125408 |
| native-native/replay/tls/1 / server | 44157 | 6219776 |
| native-native/replay/tls/1/audit-diagnostic / client | 28882 | 3125408 |
| native-native/replay/tls/1/audit-diagnostic / server | 44157 | 6219776 |
| native-native/replay/tls/2 / client | 28883 | 3125408 |
| native-native/replay/tls/2 / server | 44157 | 6219776 |
| native-native/replay/tls/2/audit-diagnostic / client | 28868 | 3125408 |
| native-native/replay/tls/2/audit-diagnostic / server | 44157 | 6219776 |
| native-native/replay/tls/3 / client | 28861 | 3125408 |
| native-native/replay/tls/3 / server | 44157 | 6219776 |
| native-native/replay/tls/3/audit-diagnostic / client | 28886 | 3125408 |
| native-native/replay/tls/3/audit-diagnostic / server | 44157 | 6219776 |
| native-native/overload/tls/1 / client | 28752 | 3125152 |
| native-native/overload/tls/1 / server | 44126 | 6219776 |
| native-native/overload/tls/1/audit-diagnostic / client | 28752 | 3125152 |
| native-native/overload/tls/1/audit-diagnostic / server | 44125 | 6219776 |
| native-native/overload/tls/2 / client | 28752 | 3125152 |
| native-native/overload/tls/2 / server | 44125 | 6219776 |
| native-native/overload/tls/2/audit-diagnostic / client | 28752 | 3125152 |
| native-native/overload/tls/2/audit-diagnostic / server | 44125 | 6219776 |
| native-native/overload/tls/3 / client | 28752 | 3125152 |
| native-native/overload/tls/3 / server | 44126 | 6219776 |
| native-native/overload/tls/3/audit-diagnostic / client | 28752 | 3125152 |
| native-native/overload/tls/3/audit-diagnostic / server | 44125 | 6219776 |
| native-quickfix/scalar/tcp/1 / client | 26509 | 3124512 |
| native-quickfix/scalar/tcp/1 / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/1/audit-diagnostic / client | 26523 | 3124512 |
| native-quickfix/scalar/tcp/1/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/2 / client | 26509 | 3124512 |
| native-quickfix/scalar/tcp/2 / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/2/audit-diagnostic / client | 26520 | 3124512 |
| native-quickfix/scalar/tcp/2/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/3 / client | 26521 | 3124512 |
| native-quickfix/scalar/tcp/3 / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/3/audit-diagnostic / client | 26514 | 3124512 |
| native-quickfix/scalar/tcp/3/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/groups/tcp/1 / client | 35448 | 39206176 |
| native-quickfix/groups/tcp/1 / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/1/audit-diagnostic / client | 35452 | 39206176 |
| native-quickfix/groups/tcp/1/audit-diagnostic / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/2 / client | 35448 | 39206176 |
| native-quickfix/groups/tcp/2 / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/2/audit-diagnostic / client | 35449 | 39206176 |
| native-quickfix/groups/tcp/2/audit-diagnostic / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/3 / client | 35451 | 39206176 |
| native-quickfix/groups/tcp/3 / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/3/audit-diagnostic / client | 35449 | 39206176 |
| native-quickfix/groups/tcp/3/audit-diagnostic / server | 345603 | 2297408 |
| native-quickfix/binary/tcp/1 / client | 57216 | 39169312 |
| native-quickfix/binary/tcp/1 / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/1/audit-diagnostic / client | 57284 | 39169312 |
| native-quickfix/binary/tcp/1/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/2 / client | 56791 | 39169312 |
| native-quickfix/binary/tcp/2 / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/2/audit-diagnostic / client | 57141 | 39169312 |
| native-quickfix/binary/tcp/2/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/3 / client | 57113 | 39169312 |
| native-quickfix/binary/tcp/3 / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/3/audit-diagnostic / client | 57013 | 39169312 |
| native-quickfix/binary/tcp/3/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/1 / client | 53716 | 39169312 |
| native-quickfix/fragmentation/tcp/1 / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/1/audit-diagnostic / client | 53708 | 39169312 |
| native-quickfix/fragmentation/tcp/1/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/2 / client | 53707 | 39169312 |
| native-quickfix/fragmentation/tcp/2 / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/2/audit-diagnostic / client | 54068 | 39169312 |
| native-quickfix/fragmentation/tcp/2/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/3 / client | 55438 | 39169312 |
| native-quickfix/fragmentation/tcp/3 / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/3/audit-diagnostic / client | 53880 | 39169312 |
| native-quickfix/fragmentation/tcp/3/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/replay/tcp/1 / client | 26636 | 3126560 |
| native-quickfix/replay/tcp/1 / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/1/audit-diagnostic / client | 26646 | 3124512 |
| native-quickfix/replay/tcp/1/audit-diagnostic / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/2 / client | 26618 | 3124512 |
| native-quickfix/replay/tcp/2 / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/2/audit-diagnostic / client | 26602 | 3124512 |
| native-quickfix/replay/tcp/2/audit-diagnostic / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/3 / client | 26595 | 3124512 |
| native-quickfix/replay/tcp/3 / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/3/audit-diagnostic / client | 26620 | 3124512 |
| native-quickfix/replay/tcp/3/audit-diagnostic / server | 52867 | 2260544 |
| native-quickfix/overload/tcp/1 / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/1 / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/1/audit-diagnostic / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/1/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/2 / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/2 / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/2/audit-diagnostic / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/2/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/3 / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/3 / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/3/audit-diagnostic / client | 26517 | 3124512 |
| native-quickfix/overload/tcp/3/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/scalar/tls/1 / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/1 / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/1/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/1/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/2 / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/2 / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/2/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/2/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/3 / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/3 / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/3/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/3/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/groups/tls/1 / client | 37688 | 39207072 |
| native-quickfix/groups/tls/1 / server | 345610 | 2297792 |
| native-quickfix/groups/tls/1/audit-diagnostic / client | 37688 | 39207072 |
| native-quickfix/groups/tls/1/audit-diagnostic / server | 345610 | 2297792 |
| native-quickfix/groups/tls/2 / client | 37688 | 39207072 |
| native-quickfix/groups/tls/2 / server | 345610 | 2297792 |
| native-quickfix/groups/tls/2/audit-diagnostic / client | 37688 | 39207072 |
| native-quickfix/groups/tls/2/audit-diagnostic / server | 345610 | 2297792 |
| native-quickfix/groups/tls/3 / client | 37688 | 39207072 |
| native-quickfix/groups/tls/3 / server | 345610 | 2297792 |
| native-quickfix/groups/tls/3/audit-diagnostic / client | 37688 | 39207072 |
| native-quickfix/groups/tls/3/audit-diagnostic / server | 345610 | 2297792 |
| native-quickfix/binary/tls/1 / client | 37646 | 39170208 |
| native-quickfix/binary/tls/1 / server | 50672 | 1212608 |
| native-quickfix/binary/tls/1/audit-diagnostic / client | 38108 | 39170208 |
| native-quickfix/binary/tls/1/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/binary/tls/2 / client | 37761 | 39170208 |
| native-quickfix/binary/tls/2 / server | 50672 | 1212608 |
| native-quickfix/binary/tls/2/audit-diagnostic / client | 38375 | 39170208 |
| native-quickfix/binary/tls/2/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/binary/tls/3 / client | 38025 | 39170208 |
| native-quickfix/binary/tls/3 / server | 50672 | 1212608 |
| native-quickfix/binary/tls/3/audit-diagnostic / client | 37600 | 39170208 |
| native-quickfix/binary/tls/3/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/1 / client | 41458 | 39170208 |
| native-quickfix/fragmentation/tls/1 / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/1/audit-diagnostic / client | 38150 | 39170208 |
| native-quickfix/fragmentation/tls/1/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/2 / client | 40528 | 39170208 |
| native-quickfix/fragmentation/tls/2 / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/2/audit-diagnostic / client | 38246 | 39170208 |
| native-quickfix/fragmentation/tls/2/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/3 / client | 40941 | 39170208 |
| native-quickfix/fragmentation/tls/3 / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/3/audit-diagnostic / client | 37827 | 39170208 |
| native-quickfix/fragmentation/tls/3/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/replay/tls/1 / client | 28840 | 3125408 |
| native-quickfix/replay/tls/1 / server | 52874 | 2260928 |
| native-quickfix/replay/tls/1/audit-diagnostic / client | 28872 | 3125408 |
| native-quickfix/replay/tls/1/audit-diagnostic / server | 52874 | 2260928 |
| native-quickfix/replay/tls/2 / client | 28858 | 3125408 |
| native-quickfix/replay/tls/2 / server | 52874 | 2260928 |
| native-quickfix/replay/tls/2/audit-diagnostic / client | 28873 | 3125408 |
| native-quickfix/replay/tls/2/audit-diagnostic / server | 52874 | 2260928 |
| native-quickfix/replay/tls/3 / client | 28853 | 3125408 |
| native-quickfix/replay/tls/3 / server | 52874 | 2260928 |
| native-quickfix/replay/tls/3/audit-diagnostic / client | 28844 | 3125408 |
| native-quickfix/replay/tls/3/audit-diagnostic / server | 52874 | 2260928 |
| native-quickfix/overload/tls/1 / client | 28748 | 3125408 |
| native-quickfix/overload/tls/1 / server | 52870 | 2260928 |
| native-quickfix/overload/tls/1/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/overload/tls/1/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/overload/tls/2 / client | 28748 | 3125408 |
| native-quickfix/overload/tls/2 / server | 52870 | 2260928 |
| native-quickfix/overload/tls/2/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/overload/tls/2/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/overload/tls/3 / client | 28748 | 3125408 |
| native-quickfix/overload/tls/3 / server | 52870 | 2260928 |
| native-quickfix/overload/tls/3/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/overload/tls/3/audit-diagnostic / server | 52870 | 2260928 |
| quickfix-native/scalar/tcp/1 / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/1 / server | 39695 | 6218432 |
| quickfix-native/scalar/tcp/1/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/1/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/scalar/tcp/2 / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/2 / server | 39695 | 6218432 |
| quickfix-native/scalar/tcp/2/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/2/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/scalar/tcp/3 / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/3 / server | 39740 | 6218432 |
| quickfix-native/scalar/tcp/3/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/3/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/groups/tcp/1 / client | 94804 | 463872 |
| quickfix-native/groups/tcp/1 / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/1/audit-diagnostic / client | 94804 | 463872 |
| quickfix-native/groups/tcp/1/audit-diagnostic / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/2 / client | 94804 | 463872 |
| quickfix-native/groups/tcp/2 / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/2/audit-diagnostic / client | 94804 | 463872 |
| quickfix-native/groups/tcp/2/audit-diagnostic / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/3 / client | 94804 | 463872 |
| quickfix-native/groups/tcp/3 / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/3/audit-diagnostic / client | 94804 | 463872 |
| quickfix-native/groups/tcp/3/audit-diagnostic / server | 176235 | 6255296 |
| quickfix-native/binary/tcp/1 / client | 22066 | 427008 |
| quickfix-native/binary/tcp/1 / server | 61694 | 67544896 |
| quickfix-native/binary/tcp/1/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/binary/tcp/1/audit-diagnostic / server | 61453 | 67544896 |
| quickfix-native/binary/tcp/2 / client | 22066 | 427008 |
| quickfix-native/binary/tcp/2 / server | 61668 | 67544896 |
| quickfix-native/binary/tcp/2/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/binary/tcp/2/audit-diagnostic / server | 61691 | 67544896 |
| quickfix-native/binary/tcp/3 / client | 22066 | 427008 |
| quickfix-native/binary/tcp/3 / server | 61374 | 67544896 |
| quickfix-native/binary/tcp/3/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/binary/tcp/3/audit-diagnostic / server | 61492 | 67544896 |
| quickfix-native/fragmentation/tcp/1 / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/1 / server | 146868 | 67544896 |
| quickfix-native/fragmentation/tcp/1/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/1/audit-diagnostic / server | 157865 | 67544896 |
| quickfix-native/fragmentation/tcp/2 / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/2 / server | 146142 | 67544896 |
| quickfix-native/fragmentation/tcp/2/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/2/audit-diagnostic / server | 147256 | 67544896 |
| quickfix-native/fragmentation/tcp/3 / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/3 / server | 143086 | 67544896 |
| quickfix-native/fragmentation/tcp/3/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/3/audit-diagnostic / server | 139635 | 67544896 |
| quickfix-native/replay/tcp/1 / client | 26470 | 990976 |
| quickfix-native/replay/tcp/1 / server | 40141 | 6218432 |
| quickfix-native/replay/tcp/1/audit-diagnostic / client | 26470 | 990976 |
| quickfix-native/replay/tcp/1/audit-diagnostic / server | 39987 | 6218432 |
| quickfix-native/replay/tcp/2 / client | 26470 | 990976 |
| quickfix-native/replay/tcp/2 / server | 40056 | 6218432 |
| quickfix-native/replay/tcp/2/audit-diagnostic / client | 26470 | 990976 |
| quickfix-native/replay/tcp/2/audit-diagnostic / server | 39987 | 6218432 |
| quickfix-native/replay/tcp/3 / client | 26470 | 990976 |
| quickfix-native/replay/tcp/3 / server | 40107 | 6218432 |
| quickfix-native/replay/tcp/3/audit-diagnostic / client | 26470 | 990976 |
| quickfix-native/replay/tcp/3/audit-diagnostic / server | 40020 | 6218432 |
| quickfix-native/overload/tcp/1 / client | 26464 | 990208 |
| quickfix-native/overload/tcp/1 / server | 39701 | 6218432 |
| quickfix-native/overload/tcp/1/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/overload/tcp/1/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/overload/tcp/2 / client | 26464 | 990208 |
| quickfix-native/overload/tcp/2 / server | 39695 | 6218432 |
| quickfix-native/overload/tcp/2/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/overload/tcp/2/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/overload/tcp/3 / client | 26464 | 990208 |
| quickfix-native/overload/tcp/3 / server | 39697 | 6218432 |
| quickfix-native/overload/tcp/3/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/overload/tcp/3/audit-diagnostic / server | 39701 | 6218432 |
| quickfix-native/scalar/tls/1 / client | 26471 | 990592 |
| quickfix-native/scalar/tls/1 / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/1/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/scalar/tls/1/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/2 / client | 26471 | 990592 |
| quickfix-native/scalar/tls/2 / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/2/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/scalar/tls/2/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/3 / client | 26471 | 990592 |
| quickfix-native/scalar/tls/3 / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/3/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/scalar/tls/3/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/groups/tls/1 / client | 94811 | 464256 |
| quickfix-native/groups/tls/1 / server | 169658 | 6256640 |
| quickfix-native/groups/tls/1/audit-diagnostic / client | 94811 | 464256 |
| quickfix-native/groups/tls/1/audit-diagnostic / server | 169658 | 6256640 |
| quickfix-native/groups/tls/2 / client | 94811 | 464256 |
| quickfix-native/groups/tls/2 / server | 169658 | 6256640 |
| quickfix-native/groups/tls/2/audit-diagnostic / client | 94811 | 464256 |
| quickfix-native/groups/tls/2/audit-diagnostic / server | 169658 | 6256640 |
| quickfix-native/groups/tls/3 / client | 94811 | 464256 |
| quickfix-native/groups/tls/3 / server | 169658 | 6256640 |
| quickfix-native/groups/tls/3/audit-diagnostic / client | 94811 | 464256 |
| quickfix-native/groups/tls/3/audit-diagnostic / server | 169658 | 6256640 |
| quickfix-native/binary/tls/1 / client | 22073 | 427392 |
| quickfix-native/binary/tls/1 / server | 55312 | 67546240 |
| quickfix-native/binary/tls/1/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/binary/tls/1/audit-diagnostic / server | 55122 | 67546240 |
| quickfix-native/binary/tls/2 / client | 22073 | 427392 |
| quickfix-native/binary/tls/2 / server | 55199 | 67546240 |
| quickfix-native/binary/tls/2/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/binary/tls/2/audit-diagnostic / server | 55140 | 67546240 |
| quickfix-native/binary/tls/3 / client | 22073 | 427392 |
| quickfix-native/binary/tls/3 / server | 55251 | 67546240 |
| quickfix-native/binary/tls/3/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/binary/tls/3/audit-diagnostic / server | 55221 | 67546240 |
| quickfix-native/fragmentation/tls/1 / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/1 / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/1/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/1/audit-diagnostic / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/2 / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/2 / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/2/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/2/audit-diagnostic / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/3 / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/3 / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/3/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/3/audit-diagnostic / server | 202522 | 67546240 |
| quickfix-native/replay/tls/1 / client | 26477 | 991360 |
| quickfix-native/replay/tls/1 / server | 44533 | 6219776 |
| quickfix-native/replay/tls/1/audit-diagnostic / client | 26477 | 991360 |
| quickfix-native/replay/tls/1/audit-diagnostic / server | 44448 | 6219776 |
| quickfix-native/replay/tls/2 / client | 26477 | 991360 |
| quickfix-native/replay/tls/2 / server | 44477 | 6219776 |
| quickfix-native/replay/tls/2/audit-diagnostic / client | 26477 | 991360 |
| quickfix-native/replay/tls/2/audit-diagnostic / server | 44392 | 6219776 |
| quickfix-native/replay/tls/3 / client | 26477 | 991360 |
| quickfix-native/replay/tls/3 / server | 44601 | 6219776 |
| quickfix-native/replay/tls/3/audit-diagnostic / client | 26477 | 991360 |
| quickfix-native/replay/tls/3/audit-diagnostic / server | 44398 | 6219776 |
| quickfix-native/overload/tls/1 / client | 26471 | 990592 |
| quickfix-native/overload/tls/1 / server | 44122 | 6219776 |
| quickfix-native/overload/tls/1/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/overload/tls/1/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/overload/tls/2 / client | 26471 | 990592 |
| quickfix-native/overload/tls/2 / server | 44118 | 6219776 |
| quickfix-native/overload/tls/2/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/overload/tls/2/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/overload/tls/3 / client | 26471 | 990592 |
| quickfix-native/overload/tls/3 / server | 44298 | 6219776 |
| quickfix-native/overload/tls/3/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/overload/tls/3/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-quickfix/scalar/tcp/1 / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/1 / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/1/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/1/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/2 / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/2 / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/2/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/2/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/3 / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/3 / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/3/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/3/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/groups/tcp/1 / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/1 / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/1/audit-diagnostic / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/1/audit-diagnostic / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/2 / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/2 / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/2/audit-diagnostic / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/2/audit-diagnostic / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/3 / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/3 / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/3/audit-diagnostic / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/3/audit-diagnostic / server | 345600 | 2297408 |
| quickfix-quickfix/binary/tcp/1 / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/1 / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/1/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/1/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/2 / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/2 / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/2/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/2/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/3 / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/3 / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/3/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/3/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/1 / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/1 / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/1/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/1/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/2 / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/2 / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/2/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/2/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/3 / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/3 / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/3/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/3/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/replay/tcp/1 / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/1 / server | 52866 | 2260544 |
| quickfix-quickfix/replay/tcp/1/audit-diagnostic / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/1/audit-diagnostic / server | 52866 | 2260544 |
| quickfix-quickfix/replay/tcp/2 / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/2 / server | 52867 | 2260544 |
| quickfix-quickfix/replay/tcp/2/audit-diagnostic / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/2/audit-diagnostic / server | 52867 | 2260544 |
| quickfix-quickfix/replay/tcp/3 / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/3 / server | 52866 | 2260544 |
| quickfix-quickfix/replay/tcp/3/audit-diagnostic / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/3/audit-diagnostic / server | 52866 | 2260544 |
| quickfix-quickfix/overload/tcp/1 / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/1 / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/1/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/1/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/2 / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/2 / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/2/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/2/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/3 / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/3 / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/3/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/3/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tls/1 / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/1 / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/1/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/1/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/2 / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/2 / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/2/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/2/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/3 / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/3 / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/3/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/3/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/groups/tls/1 / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/1 / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/1/audit-diagnostic / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/1/audit-diagnostic / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/2 / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/2 / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/2/audit-diagnostic / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/2/audit-diagnostic / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/3 / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/3 / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/3/audit-diagnostic / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/3/audit-diagnostic / server | 345607 | 2297792 |
| quickfix-quickfix/binary/tls/1 / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/1 / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/1/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/1/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/2 / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/2 / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/2/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/2/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/3 / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/3 / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/3/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/3/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/1 / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/1 / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/1/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/1/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/2 / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/2 / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/2/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/2/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/3 / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/3 / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/3/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/3/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/replay/tls/1 / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/1 / server | 52873 | 2260928 |
| quickfix-quickfix/replay/tls/1/audit-diagnostic / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/1/audit-diagnostic / server | 52874 | 2260928 |
| quickfix-quickfix/replay/tls/2 / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/2 / server | 52873 | 2260928 |
| quickfix-quickfix/replay/tls/2/audit-diagnostic / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/2/audit-diagnostic / server | 52872 | 2260928 |
| quickfix-quickfix/replay/tls/3 / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/3 / server | 52874 | 2260928 |
| quickfix-quickfix/replay/tls/3/audit-diagnostic / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/3/audit-diagnostic / server | 52873 | 2260928 |
| quickfix-quickfix/overload/tls/1 / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/1 / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/1/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/1/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/2 / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/2 / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/2/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/2/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/3 / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/3 / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/3/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/3/audit-diagnostic / server | 52867 | 2260928 |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: native replayable bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
