# FIX measured baseline

This is an optimized **instrumented** baseline. Zfix was compiled by Clang 21.1.8
with `-O3 -DNDEBUG`, retaining `-DZDEBUG` and ASan to match the unchanged existing
Clang 21 dependency DSOs (`-O1 -g -DZDEBUG`, ASan). The pinned QuickFIX SDK uses
Clang 21, `-O2 -g -DNDEBUG`, GNU C++17 and ASan. System crypto and other external
libraries are uninstrumented. These results do not establish ordinary release
or production throughput. No dependency was rebuilt for this baseline.

All 144 timing cases and 144 separate allocation/copy cases passed. Each case
uses one session, 200 warmup orders, 2,000 measured orders, 64 in flight and seed 1;
all four pairings, TCP/TLS and six profiles have three repetitions. Group loads
use 32 parties with eight subparties each; binary data is 4,096 bytes. Relay
fragmentation uses 64-byte writes. Ordinary profiles saturate the bounded client; overload
schedules at 1,000,000 orders/s. Both peers use 4,096 retained messages, 64 MiB history
and 16 MiB queue bounds. The archive preserves exact arguments, counts, resources,
heap observations, diagnostic counters and stderr. Native history retains
replayable bodies; QuickFIX retains serialized frames. Matching limits cover
different stored representations. No QA or compilation ran
concurrently with measurement; the host is shared and not a controlled lab.

Process quantiles have 2,000 samples per run, so p99.9 has only about two tail
observations. Codec quantiles have 10,000 samples per shape/run (1,000 warmup),
about ten at that tail. The standalone group shape uses eight parties,
four subparties each and 32 text bytes. Repetitions are reported separately
or summarized as specified below, without claiming statistical confidence bounds. Latencies
include queueing at the declared in-flight window. CPU/RSS include startup,
warmup and shutdown; fork/exec RSS can include the inherited parent high-water
floor. Retained-byte peaks describe application history, not total process heap.

Allocation diagnostics are separate runs. Framework allocation/live-byte
snapshots cover framework heaps at logical drain, excluding SDK/STL/libc.
LD_AUDIT counts selected main-namespace PLT allocation attempts and copy entries:
free includes null pointers, requested bytes include full realloc requests,
ASan copy counts are a subset, and nested calls can be counted. Direct/inlined
and custom allocator internal calls are excluded. No diagnostic counts are
combined with timing distributions.

Verification is scoped to Linux x64, exercised with GCC 15.2 and Clang 21.1.8.
ARM and Windows are outside this task's scope.

Build label: `clang21-O3-ZDEBUG-ASAN-existing-Clang-ASAN-dependencies`. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
CPU: Intel(R) Xeon(R) Platinum 8488C. Affinity: [0, 1, 2, 3, 4, 5, 6, 7].
Compiler: `clang++`. Flags: `-march=x86-64-v2 -g -DZDEBUG -O3 -DNDEBUG -fsanitize=address -fno-omit-frame-pointer`.

These are local process measurements on the recorded host. The table uses median per-session completion rate and median p50 across repeats; worst p99 is the largest individual-run p99. Quantiles are never added or merged. Full p50/p95/p99/p99.9/max, wire counts, resources, retained bytes, errors, diagnostic allocation/copy counts, exact commands and hashes are in the archived `process/report.md`, `process/manifest.json` and individual `case.json` files.

The regression envelope is 1.25 times the worst observed intended-terminal p99, rounded up. It is a measured baseline for equivalent runs on this host, not a production service-level promise or a portable CI threshold. Startup, TLS relay and shared-host effects are described in the archived `process/report.md`. Overload intended latency includes the delay before the bounded client can submit.

| Pair / transport / shape / session | Runs | Orders/s median | Ack p50 median ns | Ack p99 worst ns | Terminal p99 worst ns | Intended terminal p99 worst ns | Regression envelope ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / tcp / binary / 1 | 3 | 11526.3 | 5498491 | 6602044 | 6650280 | 6650280 | 8312850 |
| native-native / tcp / fragmentation / 1 | 3 | 2733.1 | 21829285 | 31564570 | 31640191 | 31640191 | 39550239 |
| native-native / tcp / groups / 1 | 3 | 4468.5 | 11405744 | 21967368 | 21978195 | 21978195 | 27472744 |
| native-native / tcp / overload / 1 | 3 | 29743.3 | 2113196 | 2473568 | 2490050 | 66304437 | 82880547 |
| native-native / tcp / replay / 1 | 3 | 22114.8 | 2824088 | 3942698 | 3956822 | 3956822 | 4946028 |
| native-native / tcp / scalar / 1 | 3 | 31668.9 | 1978709 | 2313683 | 2327464 | 2327464 | 2909330 |
| native-native / tls / binary / 1 | 3 | 10855.7 | 5875402 | 6937007 | 6987387 | 6987387 | 8734234 |
| native-native / tls / fragmentation / 1 | 3 | 1766.7 | 33409549 | 44436204 | 44455762 | 44455762 | 55569703 |
| native-native / tls / groups / 1 | 3 | 4612.4 | 11241418 | 22256809 | 22266352 | 22266352 | 27832940 |
| native-native / tls / overload / 1 | 3 | 17971.1 | 3497491 | 4221765 | 4244247 | 118013057 | 147516322 |
| native-native / tls / replay / 1 | 3 | 16218.2 | 3823805 | 5567571 | 5599430 | 5599430 | 6999288 |
| native-native / tls / scalar / 1 | 3 | 16863.9 | 3768694 | 4477836 | 4522097 | 4522097 | 5652622 |
| native-quickfix / tcp / binary / 1 | 3 | 7843.4 | 7458001 | 10028283 | 10104739 | 10104739 | 12630924 |
| native-quickfix / tcp / fragmentation / 1 | 3 | 3224.3 | 19886711 | 22606786 | 22640939 | 22640939 | 28301174 |
| native-quickfix / tcp / groups / 1 | 3 | 1695.2 | 36289490 | 51277325 | 51305194 | 51305194 | 64131493 |
| native-quickfix / tcp / overload / 1 | 3 | 20159.4 | 3132959 | 5152559 | 5184796 | 113041659 | 141302074 |
| native-quickfix / tcp / replay / 1 | 3 | 15047.5 | 4191005 | 4610432 | 4629480 | 4629480 | 5786850 |
| native-quickfix / tcp / scalar / 1 | 3 | 20344.3 | 3014955 | 4728103 | 4761676 | 4761676 | 5952095 |
| native-quickfix / tls / binary / 1 | 3 | 7311.2 | 8621831 | 10397381 | 10480001 | 10480001 | 13100002 |
| native-quickfix / tls / fragmentation / 1 | 3 | 2068.0 | 30342718 | 48546192 | 48574384 | 48574384 | 60717980 |
| native-quickfix / tls / groups / 1 | 3 | 1683.8 | 35599810 | 59967738 | 59985622 | 59985622 | 74982028 |
| native-quickfix / tls / overload / 1 | 3 | 14399.5 | 4301478 | 5169440 | 5205675 | 146807110 | 183508888 |
| native-quickfix / tls / replay / 1 | 3 | 13920.6 | 4444690 | 6171033 | 6209999 | 6209999 | 7762499 |
| native-quickfix / tls / scalar / 1 | 3 | 14155.3 | 4290982 | 6194276 | 6228944 | 6228944 | 7786180 |
| quickfix-native / tcp / binary / 1 | 3 | 7606.6 | 8147378 | 10377744 | 10461316 | 10461316 | 13076645 |
| quickfix-native / tcp / fragmentation / 1 | 3 | 2800.1 | 23188016 | 35906917 | 35936399 | 35936399 | 44920499 |
| quickfix-native / tcp / groups / 1 | 3 | 889.9 | 71193583 | 86060214 | 86063850 | 86063850 | 107579813 |
| quickfix-native / tcp / overload / 1 | 3 | 14709.7 | 3890989 | 5542207 | 5583792 | 148560674 | 185700843 |
| quickfix-native / tcp / replay / 1 | 3 | 13585.7 | 4416125 | 7149609 | 7205692 | 7205692 | 9007115 |
| quickfix-native / tcp / scalar / 1 | 3 | 14512.9 | 4354153 | 5674620 | 5718818 | 5718818 | 7148523 |
| quickfix-native / tls / binary / 1 | 3 | 6851.9 | 9050161 | 10902450 | 10980242 | 10980242 | 13725303 |
| quickfix-native / tls / fragmentation / 1 | 3 | 1829.0 | 34875695 | 55314557 | 55358134 | 55358134 | 69197668 |
| quickfix-native / tls / groups / 1 | 3 | 872.1 | 74049808 | 81866616 | 81868848 | 81868848 | 102336060 |
| quickfix-native / tls / overload / 1 | 3 | 11431.5 | 5620996 | 6875246 | 6926940 | 178789791 | 223487239 |
| quickfix-native / tls / replay / 1 | 3 | 11128.2 | 5876579 | 6691180 | 6739090 | 6739090 | 8423863 |
| quickfix-native / tls / scalar / 1 | 3 | 11443.2 | 5263308 | 7273928 | 7336368 | 7336368 | 9170460 |
| quickfix-quickfix / tcp / binary / 1 | 3 | 7853.1 | 7457730 | 9912283 | 9984957 | 9984957 | 12481197 |
| quickfix-quickfix / tcp / fragmentation / 1 | 3 | 3372.1 | 19334824 | 37966468 | 38033296 | 38033296 | 47541620 |
| quickfix-quickfix / tcp / groups / 1 | 3 | 907.3 | 70592118 | 81097038 | 81099423 | 81099423 | 101374279 |
| quickfix-quickfix / tcp / overload / 1 | 3 | 15580.3 | 3801476 | 6403821 | 6454379 | 136540387 | 170675484 |
| quickfix-quickfix / tcp / replay / 1 | 3 | 14945.2 | 3824074 | 5262789 | 5302530 | 5302530 | 6628163 |
| quickfix-quickfix / tcp / scalar / 1 | 3 | 14940.6 | 3713578 | 6062319 | 6113268 | 6113268 | 7641585 |
| quickfix-quickfix / tls / binary / 1 | 3 | 7707.7 | 8197344 | 10983169 | 11042380 | 11042380 | 13802975 |
| quickfix-quickfix / tls / fragmentation / 1 | 3 | 2059.9 | 30958650 | 44896726 | 44912247 | 44912247 | 56140309 |
| quickfix-quickfix / tls / groups / 1 | 3 | 900.1 | 71323044 | 78909111 | 78911094 | 78911094 | 98638868 |
| quickfix-quickfix / tls / overload / 1 | 3 | 13020.8 | 4761988 | 6948255 | 7011371 | 162844032 | 203555040 |
| quickfix-quickfix / tls / replay / 1 | 3 | 12915.5 | 4750150 | 9014451 | 9052865 | 9052865 | 11316082 |
| quickfix-quickfix / tls / scalar / 1 | 3 | 13631.8 | 4498389 | 5362351 | 5393962 | 5393962 | 6742453 |

## Standalone codec

Per-call encode includes typed body and full FIX framing; decode includes framing/checksum, typed construction and validation. QuickFIX also applies its canonical dictionary validation. Native reuses its output backing; QuickFIX constructs its SDK message and returns its SDK string. QuickFIX decode includes its input string and selected-field arena copies; Native decoded spans borrow input. These ownership costs are included. Clock-pair overhead is reported separately without subtraction.

| Engine / shape | Runs | Frame bytes | Encode p50 median ns | Encode p99 worst ns | Decode p50 median ns | Decode p99 worst ns | Clock p50 median ns |
| --- | --- | --- | --- | --- | --- | --- | --- |
| quickfix / binary | 3 | 4281 | 16286 | 44047 | 20026 | 46315 | 41 |
| quickfix / groups | 3 | 910 | 121509 | 215857 | 78467 | 113338 | 42 |
| quickfix / scalar | 3 | 170 | 10981 | 28533 | 14356 | 33787 | 41 |
| zfix / binary | 3 | 4281 | 5053 | 9219 | 2624 | 4709 | 40 |
| zfix / groups | 3 | 910 | 16866 | 32134 | 29987 | 60272 | 41 |
| zfix / scalar | 3 | 170 | 3940 | 5359 | 1726 | 2146 | 40 |

Raw artifacts: the `process/` subtree in the dated archive.

## Executable and library size

`.text` measures that ELF section; file bytes include debug/symbol data.
Shared libraries are listed separately and must not be attributed to only one
peer. All other loaded libraries, section sizes and hashes remain in the
manifests. These rows do not sum to a whole-process code footprint.

| Program | ELF file bytes | .text bytes |
| --- | --- | --- |
| native_client | 17324344 | 7144256 |
| native_codec | 3337624 | 1684848 |
| native_server | 17324128 | 7144256 |
| quickfix_client | 6101744 | 2428944 |
| quickfix_codec | 3132192 | 1501984 |
| quickfix_server | 6102520 | 2428944 |

| Framework/SDK library | ELF file bytes | .text bytes |
| --- | --- | --- |
| libZdbus-10.0.0.so | 2963992 | 740014 |
| libZe-10.0.0.so | 246760 | 51855 |
| libZf-10.0.0.so | 3249504 | 981553 |
| libZfix-10.0.0.so | 2701088 | 1073521 |
| libZfixFmt-10.0.0.so | 650232 | 199510 |
| libZi-10.0.0.so | 7767512 | 1921995 |
| libZm-10.0.0.so | 1734448 | 410546 |
| libZt-10.0.0.so | 865424 | 229369 |
| libZtcp-10.0.0.so | 49992 | 5232 |
| libZtls-10.0.0.so | 5865224 | 1794611 |
| libZu-10.0.0.so | 384512 | 97579 |
| libquickfix.so.17.0.0 | 15246632 | 1985394 |
