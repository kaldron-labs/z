# FIX process load measurements

Build label: clang21-O3-ZDEBUG-ASAN-existing-Clang-ASAN-dependencies. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Orders/s is the sum of per-session rates, rather than a shared global interval. Session quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Mode | Status | Complete / unfinished | Errors / bad exits / timeouts | Orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 31668.894 | 0.292206 / 71753728 | 0.321278 / 72368128 |
| native-native / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13588.488 | 0.443538 / 75317248 | 0.492339 / 75816960 |
| native-native / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 32398.669 | 0.292942 / 71872512 | 0.317282 / 72318976 |
| native-native / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 16148.122 | 0.414602 / 75411456 | 0.452335 / 75726848 |
| native-native / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 30857.308 | 0.293467 / 71856128 | 0.317248 / 72413184 |
| native-native / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 14681.972 | 0.420130 / 75309056 | 0.487593 / 75907072 |
| native-native / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4468.547 | 0.631689 / 152825856 | 0.861544 / 424198144 |
| native-native / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2258.643 | 0.976132 / 156229632 | 1.407702 / 427503616 |
| native-native / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4503.338 | 0.632829 / 152752128 | 0.844133 / 424325120 |
| native-native / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2253.461 | 0.967715 / 156663808 | 1.405805 / 427540480 |
| native-native / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4424.662 | 0.633827 / 152924160 | 0.863041 / 424472576 |
| native-native / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2215.452 | 0.964454 / 156082176 | 1.459691 / 427462656 |
| native-native / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11526.266 | 0.556121 / 198877184 | 0.617390 / 209440768 |
| native-native / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7507.450 | 0.682531 / 203603968 | 0.746110 / 212754432 |
| native-native / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11700.023 | 0.551255 / 199069696 | 0.613198 / 209268736 |
| native-native / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8371.280 | 0.675697 / 203100160 | 0.746350 / 212459520 |
| native-native / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10385.657 | 0.578821 / 200085504 | 0.634654 / 209256448 |
| native-native / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8546.365 | 0.659606 / 203272192 | 0.734573 / 212762624 |
| native-native / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2844.909 | 0.504748 / 194961408 | 1.503558 / 355483648 |
| native-native / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2795.964 | 0.629768 / 198631424 | 1.669024 / 366485504 |
| native-native / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2733.144 | 0.511991 / 194613248 | 1.570329 / 366288896 |
| native-native / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2761.861 | 0.620177 / 197652480 | 1.651656 / 364322816 |
| native-native / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2732.282 | 0.504079 / 194740224 | 1.562734 / 369623040 |
| native-native / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2653.334 | 0.597230 / 197865472 | 1.761002 / 375640064 |
| native-native / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 22114.823 | 0.298066 / 72007680 | 0.324074 / 72507392 |
| native-native / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 14795.553 | 0.426082 / 75227136 | 0.485589 / 76107776 |
| native-native / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 22773.459 | 0.294385 / 71999488 | 0.308422 / 72781824 |
| native-native / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13810.451 | 0.434150 / 75374592 | 0.491955 / 76185600 |
| native-native / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 20366.753 | 0.294215 / 72032256 | 0.329194 / 72617984 |
| native-native / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12731.165 | 0.454329 / 75575296 | 0.465096 / 75931648 |
| native-native / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 29743.296 | 0.302058 / 72028160 | 0.323376 / 72572928 |
| native-native / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 14266.715 | 0.432243 / 75051008 | 0.488024 / 75829248 |
| native-native / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 29128.764 | 0.300176 / 72261632 | 0.333867 / 72642560 |
| native-native / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 15680.564 | 0.405426 / 75296768 | 0.472506 / 75808768 |
| native-native / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 31520.975 | 0.294764 / 71757824 | 0.320604 / 72749056 |
| native-native / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 15438.003 | 0.404479 / 75718656 | 0.473530 / 75419648 |
| native-native / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17301.117 | 0.402560 / 111181824 | 0.452730 / 146518016 |
| native-native / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13067.714 | 0.502143 / 114466816 | 0.554559 / 149737472 |
| native-native / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16584.021 | 0.401933 / 111124480 | 0.462883 / 146370560 |
| native-native / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12904.845 | 0.513474 / 114212864 | 0.590307 / 149946368 |
| native-native / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16863.864 | 0.411259 / 111071232 | 0.461577 / 146505728 |
| native-native / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13145.628 | 0.516376 / 114208768 | 0.587654 / 149671936 |
| native-native / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4683.856 | 0.723253 / 192741376 | 0.875409 / 383516672 |
| native-native / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2298.287 | 1.053475 / 195600384 | 1.462800 / 385527808 |
| native-native / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4603.429 | 0.712327 / 192237568 | 0.921231 / 383520768 |
| native-native / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2287.028 | 1.058865 / 195645440 | 1.451515 / 385617920 |
| native-native / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4612.432 | 0.709908 / 192503808 | 0.899954 / 383508480 |
| native-native / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2328.901 | 1.030913 / 195534848 | 1.444319 / 385568768 |
| native-native / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10855.683 | 0.585925 / 214605824 | 0.671125 / 261386240 |
| native-native / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9034.000 | 0.695003 / 211087360 | 0.783471 / 263782400 |
| native-native / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10961.392 | 0.587492 / 213487616 | 0.664310 / 261201920 |
| native-native / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8894.059 | 0.677742 / 212320256 | 0.807836 / 264388608 |
| native-native / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10536.081 | 0.594749 / 212336640 | 0.690059 / 261316608 |
| native-native / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9281.552 | 0.670632 / 213524480 | 0.773252 / 263229440 |
| native-native / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1764.694 | 0.627249 / 262451200 | 2.148658 / 364888064 |
| native-native / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1751.559 | 0.736665 / 269258752 | 2.394903 / 368218112 |
| native-native / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1766.709 | 0.651068 / 266244096 | 2.126187 / 364871680 |
| native-native / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1769.725 | 0.741028 / 268910592 | 2.379047 / 367644672 |
| native-native / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1796.828 | 0.647090 / 266588160 | 2.109656 / 365039616 |
| native-native / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1699.555 | 0.737446 / 269197312 | 2.460424 / 368037888 |
| native-native / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16481.517 | 0.394311 / 111394816 | 0.412944 / 146857984 |
| native-native / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12389.289 | 0.518606 / 114524160 | 0.564716 / 149671936 |
| native-native / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16218.223 | 0.376320 / 111398912 | 0.416519 / 146833408 |
| native-native / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11104.272 | 0.554926 / 114245632 | 0.560959 / 149667840 |
| native-native / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15667.598 | 0.397225 / 111026176 | 0.409578 / 146526208 |
| native-native / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11012.332 | 0.501746 / 114298880 | 0.616398 / 150061056 |
| native-native / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16552.437 | 0.405545 / 110673920 | 0.463919 / 146374656 |
| native-native / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13003.284 | 0.505248 / 113844224 | 0.573323 / 149680128 |
| native-native / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17971.059 | 0.397882 / 111263744 | 0.434806 / 146563072 |
| native-native / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12782.681 | 0.510979 / 114774016 | 0.576090 / 149643264 |
| native-native / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 18426.381 | 0.401388 / 111198208 | 0.446187 / 146436096 |
| native-native / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12832.433 | 0.508316 / 114298880 | 0.571244 / 150024192 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 20344.283 | 0.325709 / 71970816 | 0.394492 / 115363840 |
| native-quickfix / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10707.261 | 0.423869 / 75350016 | 0.630388 / 118931456 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 20465.591 | 0.331794 / 71868416 | 0.396573 / 115720192 |
| native-quickfix / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11793.572 | 0.438806 / 75407360 | 0.585467 / 119001088 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16551.495 | 0.346361 / 71991296 | 0.410068 / 115884032 |
| native-quickfix / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11168.588 | 0.418209 / 75407360 | 0.607766 / 118755328 |
| native-quickfix / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1695.236 | 0.663650 / 152854528 | 1.764948 / 427630592 |
| native-quickfix / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 964.374 | 0.999700 / 156930048 | 2.901928 / 430718976 |
| native-quickfix / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1745.370 | 0.653684 / 153272320 | 1.741735 / 427638784 |
| native-quickfix / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 907.821 | 1.045255 / 156610560 | 3.083022 / 430788608 |
| native-quickfix / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1689.637 | 0.656329 / 153063424 | 1.763643 / 427769856 |
| native-quickfix / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 935.929 | 1.022705 / 155963392 | 2.978431 / 430772224 |
| native-quickfix / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 8442.703 | 0.561054 / 200396800 | 0.633202 / 378892288 |
| native-quickfix / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6536.005 | 0.674489 / 202907648 | 0.844443 / 382058496 |
| native-quickfix / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7843.400 | 0.583891 / 200794112 | 0.662059 / 378474496 |
| native-quickfix / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6495.450 | 0.645918 / 201805824 | 0.842758 / 381804544 |
| native-quickfix / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7812.331 | 0.565707 / 199200768 | 0.661522 / 378839040 |
| native-quickfix / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6929.593 | 0.675002 / 203939840 | 0.824552 / 382095360 |
| native-quickfix / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2973.046 | 0.552921 / 195776512 | 1.108815 / 398651392 |
| native-quickfix / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3335.645 | 0.585576 / 197591040 | 1.274702 / 392667136 |
| native-quickfix / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3224.270 | 0.509956 / 194670592 | 1.067199 / 395792384 |
| native-quickfix / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3349.447 | 0.608740 / 197963776 | 1.246335 / 392880128 |
| native-quickfix / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3304.423 | 0.479156 / 194109440 | 1.130836 / 393904128 |
| native-quickfix / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3307.359 | 0.624585 / 198017024 | 1.230749 / 391282688 |
| native-quickfix / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15047.470 | 0.338372 / 71983104 | 0.430802 / 115777536 |
| native-quickfix / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11197.775 | 0.453277 / 75382784 | 0.597222 / 119144448 |
| native-quickfix / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16480.721 | 0.325618 / 72245248 | 0.418335 / 115343360 |
| native-quickfix / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10769.634 | 0.447055 / 75399168 | 0.628235 / 118833152 |
| native-quickfix / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15008.755 | 0.341313 / 71901184 | 0.430327 / 115261440 |
| native-quickfix / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10449.877 | 0.465364 / 75685888 | 0.620460 / 118747136 |
| native-quickfix / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17260.435 | 0.328867 / 72167424 | 0.413786 / 115855360 |
| native-quickfix / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11042.677 | 0.422554 / 75157504 | 0.597730 / 118665216 |
| native-quickfix / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 20598.415 | 0.318185 / 72163328 | 0.386707 / 115589120 |
| native-quickfix / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11425.325 | 0.421506 / 75132928 | 0.599613 / 118829056 |
| native-quickfix / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 20159.376 | 0.330825 / 72237056 | 0.380435 / 115535872 |
| native-quickfix / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10325.522 | 0.422627 / 75292672 | 0.637614 / 118935552 |
| native-quickfix / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14155.328 | 0.394009 / 111308800 | 0.484648 / 124964864 |
| native-quickfix / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9655.415 | 0.506203 / 114470912 | 0.683964 / 128155648 |
| native-quickfix / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13039.641 | 0.424816 / 111775744 | 0.504534 / 125046784 |
| native-quickfix / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9239.750 | 0.521894 / 114626560 | 0.711525 / 128270336 |
| native-quickfix / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14756.730 | 0.395705 / 111390720 | 0.460952 / 124731392 |
| native-quickfix / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10451.013 | 0.508770 / 114614272 | 0.686650 / 128270336 |
| native-quickfix / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1703.665 | 0.756888 / 192839680 | 1.829596 / 436060160 |
| native-quickfix / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 939.294 | 1.119883 / 195842048 | 3.088923 / 439037952 |
| native-quickfix / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1683.789 | 0.756555 / 192843776 | 1.846133 / 435785728 |
| native-quickfix / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 951.269 | 1.082997 / 195735552 | 3.026064 / 438898688 |
| native-quickfix / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1475.721 | 0.858053 / 192524288 | 1.999987 / 436264960 |
| native-quickfix / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 925.595 | 1.100575 / 195739648 | 3.079212 / 439250944 |
| native-quickfix / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7311.232 | 0.578767 / 208859136 | 0.750167 / 389369856 |
| native-quickfix / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5163.166 | 0.685703 / 217264128 | 1.022762 / 392384512 |
| native-quickfix / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 6858.510 | 0.581515 / 209895424 | 0.752588 / 389627904 |
| native-quickfix / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5168.727 | 0.680429 / 212021248 | 0.994483 / 392609792 |
| native-quickfix / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7511.994 | 0.565962 / 209469440 | 0.710925 / 389255168 |
| native-quickfix / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6204.960 | 0.677135 / 211197952 | 0.916527 / 392896512 |
| native-quickfix / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2068.034 | 0.653107 / 258940928 | 1.614151 / 436498432 |
| native-quickfix / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1251.413 | 0.749989 / 218595328 | 2.442601 / 439808000 |
| native-quickfix / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2066.253 | 0.644642 / 265666560 | 1.622225 / 436310016 |
| native-quickfix / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1270.961 | 0.689897 / 213565440 | 2.521159 / 439529472 |
| native-quickfix / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2081.725 | 0.624569 / 254930944 | 1.635804 / 436441088 |
| native-quickfix / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1264.370 | 0.704680 / 214929408 | 2.462813 / 439586816 |
| native-quickfix / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12118.407 | 0.385292 / 111190016 | 0.498748 / 124948480 |
| native-quickfix / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8850.543 | 0.514422 / 114143232 | 0.753859 / 128049152 |
| native-quickfix / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16294.631 | 0.391003 / 111124480 | 0.465520 / 124715008 |
| native-quickfix / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8829.224 | 0.514518 / 114208768 | 0.726194 / 128188416 |
| native-quickfix / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13920.557 | 0.402237 / 111276032 | 0.484656 / 125300736 |
| native-quickfix / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8629.723 | 0.501006 / 114454528 | 0.766884 / 128212992 |
| native-quickfix / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14399.463 | 0.410681 / 111480832 | 0.457016 / 125181952 |
| native-quickfix / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10580.646 | 0.505111 / 114376704 | 0.666209 / 128253952 |
| native-quickfix / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13336.415 | 0.407478 / 111345664 | 0.490624 / 124997632 |
| native-quickfix / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9525.394 | 0.499335 / 114503680 | 0.679253 / 128155648 |
| native-quickfix / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14790.230 | 0.404966 / 111378432 | 0.479422 / 125243392 |
| native-quickfix / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9011.475 | 0.509763 / 114806784 | 0.719427 / 128012288 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14512.941 | 0.437423 / 123297792 | 0.367186 / 72400896 |
| quickfix-native / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7104.716 | 0.734128 / 126849024 | 0.499123 / 75542528 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14681.842 | 0.446809 / 123482112 | 0.388527 / 72753152 |
| quickfix-native / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7184.250 | 0.697950 / 126689280 | 0.510168 / 75661312 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12069.625 | 0.473365 / 123494400 | 0.388622 / 72605696 |
| quickfix-native / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8043.906 | 0.682221 / 126992384 | 0.493497 / 75456512 |
| quickfix-native / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 878.000 | 3.171452 / 437383168 | 0.999862 / 423981056 |
| quickfix-native / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 530.529 | 4.989171 / 440487936 | 1.640093 / 427085824 |
| quickfix-native / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 911.099 | 2.953590 / 437551104 | 0.956965 / 424050688 |
| quickfix-native / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 538.783 | 4.908518 / 440451072 | 1.627107 / 427466752 |
| quickfix-native / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 889.902 | 3.085929 / 437428224 | 0.962969 / 423882752 |
| quickfix-native / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 517.949 | 5.086193 / 440897536 | 1.667932 / 427323392 |
| quickfix-native / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7358.583 | 0.735920 / 361689088 | 0.601133 / 209244160 |
| quickfix-native / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4795.339 | 0.999870 / 365162496 | 0.695863 / 212680704 |
| quickfix-native / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7942.863 | 0.697942 / 361660416 | 0.579175 / 209424384 |
| quickfix-native / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5047.187 | 0.965792 / 365142016 | 0.704790 / 212496384 |
| quickfix-native / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7606.571 | 0.734677 / 361512960 | 0.604459 / 208629760 |
| quickfix-native / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4968.815 | 0.998319 / 364720128 | 0.685157 / 212512768 |
| quickfix-native / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2800.057 | 0.803384 / 361611264 | 1.507917 / 363192320 |
| quickfix-native / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2783.002 | 1.064157 / 364879872 | 1.723766 / 368369664 |
| quickfix-native / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2724.940 | 0.752998 / 361017344 | 1.576337 / 364191744 |
| quickfix-native / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2680.508 | 1.025767 / 364830720 | 1.752521 / 363843584 |
| quickfix-native / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2828.980 | 0.756264 / 361463808 | 1.507067 / 359026688 |
| quickfix-native / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2759.298 | 1.068046 / 365002752 | 1.726411 / 358494208 |
| quickfix-native / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13014.725 | 0.469304 / 124203008 | 0.383908 / 72810496 |
| quickfix-native / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7654.511 | 0.689846 / 127062016 | 0.528773 / 75968512 |
| quickfix-native / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13585.692 | 0.454297 / 124243968 | 0.386226 / 72736768 |
| quickfix-native / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6428.260 | 0.777673 / 127107072 | 0.503687 / 75898880 |
| quickfix-native / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15337.621 | 0.441209 / 124395520 | 0.396991 / 72802304 |
| quickfix-native / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6559.827 | 0.762700 / 127184896 | 0.519144 / 76058624 |
| quickfix-native / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13187.991 | 0.466890 / 123191296 | 0.377990 / 72302592 |
| quickfix-native / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7712.945 | 0.713284 / 126595072 | 0.488289 / 75636736 |
| quickfix-native / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14709.737 | 0.451224 / 123588608 | 0.375744 / 72626176 |
| quickfix-native / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7832.839 | 0.684359 / 126943232 | 0.464153 / 75919360 |
| quickfix-native / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16269.152 | 0.421125 / 123727872 | 0.382248 / 72675328 |
| quickfix-native / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7298.220 | 0.694809 / 126812160 | 0.508723 / 75558912 |
| quickfix-native / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11443.150 | 0.547013 / 137744384 | 0.475415 / 146587648 |
| quickfix-native / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6360.159 | 0.838855 / 140886016 | 0.590050 / 149999616 |
| quickfix-native / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11364.514 | 0.552489 / 137854976 | 0.482210 / 146337792 |
| quickfix-native / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5753.612 | 0.872972 / 140976128 | 0.609970 / 149581824 |
| quickfix-native / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12014.013 | 0.533527 / 137891840 | 0.480287 / 146272256 |
| quickfix-native / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6305.723 | 0.847994 / 141246464 | 0.571784 / 149372928 |
| quickfix-native / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 865.387 | 3.311267 / 448172032 | 1.028019 / 381685760 |
| quickfix-native / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 531.211 | 5.179648 / 451629056 | 1.706680 / 384606208 |
| quickfix-native / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 872.135 | 3.181974 / 448344064 | 1.013765 / 381763584 |
| quickfix-native / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 507.846 | 5.358482 / 451485696 | 1.735057 / 384720896 |
| quickfix-native / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 892.905 | 3.143201 / 448405504 | 0.980575 / 381657088 |
| quickfix-native / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 514.967 | 5.224801 / 451391488 | 1.710151 / 384708608 |
| quickfix-native / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 6732.141 | 0.808690 / 376741888 | 0.646881 / 259850240 |
| quickfix-native / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4674.811 | 1.084118 / 379924480 | 0.745164 / 261521408 |
| quickfix-native / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 6914.634 | 0.798807 / 376627200 | 0.632924 / 260120576 |
| quickfix-native / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4246.712 | 1.153895 / 380006400 | 0.776247 / 263053312 |
| quickfix-native / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 6851.933 | 0.791385 / 376791040 | 0.619701 / 258994176 |
| quickfix-native / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4444.123 | 1.112200 / 380268544 | 0.784565 / 262201344 |
| quickfix-native / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1663.057 | 0.871906 / 376999936 | 2.244461 / 364732416 |
| quickfix-native / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1814.846 | 1.221617 / 380100608 | 2.359146 / 368078848 |
| quickfix-native / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1829.006 | 0.906929 / 376926208 | 2.077100 / 364838912 |
| quickfix-native / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1771.577 | 1.204932 / 379969536 | 2.366132 / 367980544 |
| quickfix-native / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1885.302 | 0.866564 / 377024512 | 2.132695 / 364883968 |
| quickfix-native / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1679.990 | 1.182368 / 379899904 | 2.432844 / 368013312 |
| quickfix-native / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11137.593 | 0.559957 / 138133504 | 0.488565 / 147165184 |
| quickfix-native / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5745.957 | 0.885554 / 141398016 | 0.613503 / 150364160 |
| quickfix-native / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10255.215 | 0.583538 / 137932800 | 0.490190 / 146960384 |
| quickfix-native / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6306.771 | 0.842517 / 141139968 | 0.615461 / 150081536 |
| quickfix-native / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11128.221 | 0.566697 / 138223616 | 0.457717 / 147095552 |
| quickfix-native / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6179.041 | 0.863348 / 141340672 | 0.607367 / 150163456 |
| quickfix-native / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11431.544 | 0.545735 / 138039296 | 0.475396 / 146468864 |
| quickfix-native / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5977.441 | 0.843491 / 141008896 | 0.580481 / 149471232 |
| quickfix-native / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10980.756 | 0.546151 / 137728000 | 0.475356 / 146673664 |
| quickfix-native / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5934.678 | 0.864035 / 141242368 | 0.602546 / 149245952 |
| quickfix-native / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12619.479 | 0.533311 / 137662464 | 0.461790 / 146587648 |
| quickfix-native / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5987.048 | 0.844347 / 141058048 | 0.571967 / 149704704 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14940.586 | 0.439985 / 124043264 | 0.418422 / 115163136 |
| quickfix-quickfix / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9049.284 | 0.624082 / 126062592 | 0.593300 / 118407168 |
| quickfix-quickfix / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17314.871 | 0.413833 / 122716160 | 0.389162 / 115286016 |
| quickfix-quickfix / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8441.984 | 0.677928 / 125906944 | 0.623080 / 118415360 |
| quickfix-quickfix / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14389.279 | 0.434174 / 122773504 | 0.411139 / 115200000 |
| quickfix-quickfix / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8327.450 | 0.641249 / 125681664 | 0.589679 / 117944320 |
| quickfix-quickfix / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 911.557 | 3.074267 / 436920320 | 1.975620 / 427671552 |
| quickfix-quickfix / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 535.824 | 5.012294 / 440041472 | 3.293481 / 431120384 |
| quickfix-quickfix / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 907.313 | 3.033874 / 436625408 | 2.011080 / 427671552 |
| quickfix-quickfix / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 519.686 | 5.086175 / 439537664 | 3.257658 / 431108096 |
| quickfix-quickfix / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 876.335 | 3.160947 / 436498432 | 1.947795 / 427950080 |
| quickfix-quickfix / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 533.479 | 4.978785 / 439627776 | 3.281125 / 431198208 |
| quickfix-quickfix / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7808.314 | 0.673933 / 362622976 | 0.680107 / 366014464 |
| quickfix-quickfix / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4895.593 | 0.956918 / 364298240 | 0.850973 / 368828416 |
| quickfix-quickfix / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7853.060 | 0.695559 / 361304064 | 0.632733 / 365539328 |
| quickfix-quickfix / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5286.665 | 0.944882 / 364695552 | 0.830051 / 368902144 |
| quickfix-quickfix / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 8101.586 | 0.689268 / 362369024 | 0.646631 / 365600768 |
| quickfix-quickfix / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5570.442 | 0.960018 / 364277760 | 0.872469 / 368619520 |
| quickfix-quickfix / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3372.138 | 0.771333 / 360828928 | 1.071796 / 379727872 |
| quickfix-quickfix / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3466.034 | 1.045392 / 364359680 | 1.268710 / 380170240 |
| quickfix-quickfix / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3400.389 | 0.742516 / 360943616 | 1.085986 / 383037440 |
| quickfix-quickfix / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3259.017 | 0.986140 / 364154880 | 1.246030 / 379564032 |
| quickfix-quickfix / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2700.899 | 0.697380 / 360570880 | 1.259707 / 387846144 |
| quickfix-quickfix / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3017.470 | 1.047500 / 364163072 | 1.313644 / 381952000 |
| quickfix-quickfix / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14402.146 | 0.456658 / 123551744 | 0.448183 / 115044352 |
| quickfix-quickfix / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8714.628 | 0.660357 / 126537728 | 0.657212 / 118480896 |
| quickfix-quickfix / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15524.236 | 0.438702 / 123695104 | 0.441033 / 115015680 |
| quickfix-quickfix / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8142.844 | 0.709004 / 126177280 | 0.604661 / 118640640 |
| quickfix-quickfix / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14945.150 | 0.448436 / 122789888 | 0.411488 / 115056640 |
| quickfix-quickfix / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8199.095 | 0.679524 / 126316544 | 0.662516 / 118611968 |
| quickfix-quickfix / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14322.201 | 0.449148 / 122667008 | 0.420808 / 114688000 |
| quickfix-quickfix / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8981.606 | 0.647974 / 126279680 | 0.641912 / 118337536 |
| quickfix-quickfix / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15952.662 | 0.429235 / 122531840 | 0.408591 / 115249152 |
| quickfix-quickfix / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8127.330 | 0.694655 / 126042112 | 0.609342 / 118226944 |
| quickfix-quickfix / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15580.256 | 0.441581 / 123318272 | 0.409086 / 114753536 |
| quickfix-quickfix / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9128.878 | 0.660837 / 125935616 | 0.613208 / 118108160 |
| quickfix-quickfix / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13981.644 | 0.493839 / 137306112 | 0.460346 / 123981824 |
| quickfix-quickfix / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5878.106 | 0.845069 / 140349440 | 0.734344 / 127328256 |
| quickfix-quickfix / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13631.775 | 0.505818 / 137105408 | 0.456010 / 124518400 |
| quickfix-quickfix / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7285.985 | 0.783055 / 140234752 | 0.714743 / 127700992 |
| quickfix-quickfix / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13549.944 | 0.523200 / 136982528 | 0.468198 / 124366848 |
| quickfix-quickfix / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7342.099 | 0.774368 / 140189696 | 0.703312 / 127602688 |
| quickfix-quickfix / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 901.357 | 3.187159 / 448622592 | 2.062145 / 435781632 |
| quickfix-quickfix / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 530.332 | 5.163249 / 451469312 | 3.354411 / 438603776 |
| quickfix-quickfix / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 898.076 | 3.212581 / 448503808 | 2.017673 / 435748864 |
| quickfix-quickfix / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 528.539 | 5.178508 / 451620864 | 3.351829 / 438767616 |
| quickfix-quickfix / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 900.119 | 3.211660 / 448774144 | 2.059537 / 435548160 |
| quickfix-quickfix / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 528.740 | 5.181921 / 451858432 | 3.357994 / 438743040 |
| quickfix-quickfix / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7165.422 | 0.776889 / 376139776 | 0.676389 / 376279040 |
| quickfix-quickfix / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5095.408 | 1.032437 / 379416576 | 0.919137 / 379039744 |
| quickfix-quickfix / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7726.498 | 0.737097 / 376135680 | 0.661084 / 376229888 |
| quickfix-quickfix / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4686.460 | 1.087505 / 379596800 | 0.955588 / 378966016 |
| quickfix-quickfix / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7707.674 | 0.800173 / 376406016 | 0.709469 / 375754752 |
| quickfix-quickfix / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5067.075 | 1.025269 / 379387904 | 0.934426 / 378630144 |
| quickfix-quickfix / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2059.893 | 0.845978 / 376209408 | 1.565805 / 423247872 |
| quickfix-quickfix / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1261.994 | 1.249559 / 379760640 | 2.554417 / 426344448 |
| quickfix-quickfix / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1981.884 | 0.873526 / 376692736 | 1.695423 / 422969344 |
| quickfix-quickfix / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1323.281 | 1.176153 / 379555840 | 2.401521 / 426795008 |
| quickfix-quickfix / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2219.981 | 0.850992 / 376504320 | 1.536694 / 423706624 |
| quickfix-quickfix / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1252.149 | 1.161820 / 379490304 | 2.540164 / 426463232 |
| quickfix-quickfix / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12915.515 | 0.508212 / 137715712 | 0.493435 / 125042688 |
| quickfix-quickfix / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7019.420 | 0.804053 / 140845056 | 0.773960 / 127598592 |
| quickfix-quickfix / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12964.067 | 0.541064 / 137351168 | 0.461545 / 124723200 |
| quickfix-quickfix / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6163.399 | 0.851002 / 140787712 | 0.759969 / 127791104 |
| quickfix-quickfix / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12384.378 | 0.528709 / 137474048 | 0.527925 / 124964864 |
| quickfix-quickfix / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6751.357 | 0.819427 / 140464128 | 0.764732 / 127455232 |
| quickfix-quickfix / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13020.774 | 0.518821 / 137007104 | 0.461865 / 124583936 |
| quickfix-quickfix / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7395.151 | 0.769614 / 140492800 | 0.688139 / 127619072 |
| quickfix-quickfix / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13231.615 | 0.528520 / 136998912 | 0.486691 / 124342272 |
| quickfix-quickfix / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7241.862 | 0.777497 / 140271616 | 0.735155 / 127344640 |
| quickfix-quickfix / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12035.027 | 0.541403 / 137334784 | 0.484142 / 124088320 |
| quickfix-quickfix / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7332.086 | 0.768754 / 140406784 | 0.722044 / 127459328 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972619 / 380309 | 3097600 |
| native-native/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380309 / 972619 | 5767168 |
| native-native/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972616 / 380283 | 3097600 |
| native-native/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380283 / 972616 | 5767168 |
| native-native/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972551 / 380237 | 3097600 |
| native-native/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380237 / 972551 | 5767168 |
| native-native/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972692 / 10803904 | 39142400 |
| native-native/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803904 / 972692 | 5767168 |
| native-native/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972665 / 10803884 | 39142400 |
| native-native/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803884 / 972665 | 5767168 |
| native-native/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972642 / 10803887 | 39142400 |
| native-native/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803887 / 972642 | 5767168 |
| native-native/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061023 / 9424483 | 39142400 |
| native-native/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424483 / 19061023 | 67093632 |
| native-native/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061010 / 9424476 | 39142400 |
| native-native/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424476 / 19061010 | 67093632 |
| native-native/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061065 / 9424478 | 39142400 |
| native-native/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424478 / 19061065 | 67093632 |
| native-native/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19060987 / 9424454 | 39142400 |
| native-native/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424454 / 19060987 | 67093632 |
| native-native/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19060952 / 9424461 | 39142400 |
| native-native/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424461 / 19060952 | 67093632 |
| native-native/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19060968 / 9424478 | 39142400 |
| native-native/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424478 / 19060968 | 67093632 |
| native-native/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972912 / 380671 | 3097600 |
| native-native/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380671 / 973125 | 5767168 |
| native-native/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972921 / 380670 | 3097600 |
| native-native/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380670 / 973134 | 5767168 |
| native-native/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972951 / 380658 | 3097600 |
| native-native/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380658 / 973164 | 5767168 |
| native-native/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972665 / 380323 | 3097600 |
| native-native/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380323 / 972665 | 5767168 |
| native-native/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972593 / 380262 | 3097600 |
| native-native/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380262 / 972593 | 5767168 |
| native-native/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972678 / 380329 | 3097600 |
| native-native/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380329 / 972678 | 5767168 |
| native-native/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972665 / 380293 | 3097600 |
| native-native/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380293 / 972665 | 5767168 |
| native-native/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972618 / 380267 | 3097600 |
| native-native/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380267 / 972618 | 5767168 |
| native-native/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972633 / 380256 | 3097600 |
| native-native/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380256 / 972633 | 5767168 |
| native-native/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972660 / 10803925 | 39142400 |
| native-native/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803925 / 972660 | 5767168 |
| native-native/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972609 / 10803866 | 39142400 |
| native-native/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803866 / 972609 | 5767168 |
| native-native/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972734 / 10803924 | 39142400 |
| native-native/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803924 / 972734 | 5767168 |
| native-native/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061042 / 9424464 | 39142400 |
| native-native/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424464 / 19061042 | 67093632 |
| native-native/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061003 / 9424492 | 39142400 |
| native-native/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424492 / 19061003 | 67093632 |
| native-native/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061088 / 9424504 | 39142400 |
| native-native/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424504 / 19061088 | 67093632 |
| native-native/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061120 / 9424512 | 39142400 |
| native-native/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424512 / 19061120 | 67093632 |
| native-native/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061066 / 9424485 | 39142400 |
| native-native/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424485 / 19061066 | 67093632 |
| native-native/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061068 / 9424523 | 39142400 |
| native-native/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424523 / 19061068 | 67093632 |
| native-native/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972946 / 380689 | 3097600 |
| native-native/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380689 / 973159 | 5767168 |
| native-native/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972965 / 380666 | 3097600 |
| native-native/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380666 / 973178 | 5767168 |
| native-native/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972956 / 380668 | 3097600 |
| native-native/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380668 / 973169 | 5767168 |
| native-native/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972583 / 380289 | 3097600 |
| native-native/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380289 / 972583 | 5767168 |
| native-native/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972565 / 380254 | 3097600 |
| native-native/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380254 / 972565 | 5767168 |
| native-native/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972613 / 380298 | 3097600 |
| native-native/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380298 / 972613 | 5767168 |
| native-quickfix/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380165 | 3097600 |
| native-quickfix/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380165 / 951453 | 1673273 |
| native-quickfix/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380095 | 3097600 |
| native-quickfix/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380095 / 951453 | 1673273 |
| native-quickfix/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380147 | 3097600 |
| native-quickfix/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380147 / 951453 | 1673273 |
| native-quickfix/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803798 | 39142400 |
| native-quickfix/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803798 / 951453 | 1673273 |
| native-quickfix/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 10803685 | 39142400 |
| native-quickfix/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803685 / 951452 | 1673273 |
| native-quickfix/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 10803793 | 39142400 |
| native-quickfix/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803793 / 951452 | 1673273 |
| native-quickfix/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424320 | 39142400 |
| native-quickfix/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424320 / 19039853 | 18511929 |
| native-quickfix/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424311 | 39142400 |
| native-quickfix/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424311 / 19039853 | 18511929 |
| native-quickfix/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424307 | 39142400 |
| native-quickfix/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424307 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424370 | 39142400 |
| native-quickfix/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424370 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424345 | 39142400 |
| native-quickfix/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424345 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039852 / 9424311 | 39142400 |
| native-quickfix/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424311 / 19039852 | 18511929 |
| native-quickfix/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380419 | 3097600 |
| native-quickfix/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380419 / 951842 | 1673209 |
| native-quickfix/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380376 | 3097600 |
| native-quickfix/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380376 / 951842 | 1673209 |
| native-quickfix/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951632 / 380355 | 3097600 |
| native-quickfix/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380355 / 951840 | 1673208 |
| native-quickfix/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380144 | 3097600 |
| native-quickfix/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380144 / 951453 | 1673273 |
| native-quickfix/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 380196 | 3097600 |
| native-quickfix/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380196 / 951452 | 1673273 |
| native-quickfix/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380153 | 3097600 |
| native-quickfix/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380153 / 951453 | 1673273 |
| native-quickfix/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380144 | 3097600 |
| native-quickfix/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380144 / 951453 | 1673273 |
| native-quickfix/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380130 | 3097600 |
| native-quickfix/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380130 / 951453 | 1673273 |
| native-quickfix/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380149 | 3097600 |
| native-quickfix/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380149 / 951453 | 1673273 |
| native-quickfix/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803744 | 39142400 |
| native-quickfix/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803744 / 951453 | 1673273 |
| native-quickfix/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803761 | 39142400 |
| native-quickfix/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803761 / 951453 | 1673273 |
| native-quickfix/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803757 | 39142400 |
| native-quickfix/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803757 / 951453 | 1673273 |
| native-quickfix/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424362 | 39142400 |
| native-quickfix/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424362 / 19039853 | 18511929 |
| native-quickfix/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424378 | 39142400 |
| native-quickfix/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424378 / 19039853 | 18511929 |
| native-quickfix/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039852 / 9424347 | 39142400 |
| native-quickfix/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424347 / 19039852 | 18511929 |
| native-quickfix/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424364 | 39142400 |
| native-quickfix/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424364 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039852 / 9424344 | 39142400 |
| native-quickfix/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424344 / 19039852 | 18511929 |
| native-quickfix/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424346 | 39142400 |
| native-quickfix/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424346 / 19039853 | 18511929 |
| native-quickfix/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380389 | 3097600 |
| native-quickfix/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380389 / 951842 | 1673209 |
| native-quickfix/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380393 | 3097600 |
| native-quickfix/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380393 / 951842 | 1673209 |
| native-quickfix/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380414 | 3097600 |
| native-quickfix/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380414 / 951842 | 1673209 |
| native-quickfix/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380149 | 3097600 |
| native-quickfix/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380149 / 951453 | 1673273 |
| native-quickfix/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380170 | 3097600 |
| native-quickfix/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380170 / 951453 | 1673273 |
| native-quickfix/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380128 | 3097600 |
| native-quickfix/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380128 / 951453 | 1673273 |
| quickfix-native/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972545 / 380618 | 803594 |
| quickfix-native/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972545 | 5767168 |
| quickfix-native/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972408 / 380617 | 803593 |
| quickfix-native/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972408 | 5767168 |
| quickfix-native/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972449 / 380618 | 803594 |
| quickfix-native/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972449 | 5767168 |
| quickfix-native/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972495 / 10804218 | 11227194 |
| quickfix-native/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972495 | 5767168 |
| quickfix-native/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972547 / 10804218 | 11227194 |
| quickfix-native/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972547 | 5767168 |
| quickfix-native/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972429 / 10804218 | 11227194 |
| quickfix-native/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972429 | 5767168 |
| quickfix-native/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060912 / 9424818 | 9847794 |
| quickfix-native/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060912 | 67093632 |
| quickfix-native/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060989 / 9424818 | 9847794 |
| quickfix-native/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060989 | 67093632 |
| quickfix-native/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060910 / 9424818 | 9847794 |
| quickfix-native/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060910 | 67093632 |
| quickfix-native/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060943 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060943 | 67093632 |
| quickfix-native/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060910 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060910 | 67093632 |
| quickfix-native/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060922 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060922 | 67093632 |
| quickfix-native/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4441 / 2205 | 982114 / 380861 | 804221 |
| quickfix-native/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4442 | 380861 / 982327 | 5767168 |
| quickfix-native/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4501 / 2205 | 997491 / 380861 | 804221 |
| quickfix-native/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4502 | 380861 / 997702 | 5767168 |
| quickfix-native/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4487 / 2205 | 993800 / 380859 | 804219 |
| quickfix-native/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4488 | 380859 / 994013 | 5767168 |
| quickfix-native/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972544 / 380618 | 803594 |
| quickfix-native/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972544 | 5767168 |
| quickfix-native/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972380 / 380618 | 803594 |
| quickfix-native/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972380 | 5767168 |
| quickfix-native/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972447 / 380618 | 803594 |
| quickfix-native/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972447 | 5767168 |
| quickfix-native/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972443 / 380617 | 803593 |
| quickfix-native/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972443 | 5767168 |
| quickfix-native/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972553 / 380618 | 803594 |
| quickfix-native/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972553 | 5767168 |
| quickfix-native/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972463 / 380618 | 803594 |
| quickfix-native/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972463 | 5767168 |
| quickfix-native/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972496 / 10804218 | 11227194 |
| quickfix-native/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972496 | 5767168 |
| quickfix-native/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972530 / 10804218 | 11227194 |
| quickfix-native/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972530 | 5767168 |
| quickfix-native/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972487 / 10804218 | 11227194 |
| quickfix-native/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972487 | 5767168 |
| quickfix-native/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060873 / 9424818 | 9847794 |
| quickfix-native/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060873 | 67093632 |
| quickfix-native/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060846 / 9424817 | 9847793 |
| quickfix-native/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424817 / 19060846 | 67093632 |
| quickfix-native/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060904 / 9424818 | 9847794 |
| quickfix-native/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060904 | 67093632 |
| quickfix-native/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060915 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060915 | 67093632 |
| quickfix-native/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060889 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060889 | 67093632 |
| quickfix-native/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060815 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060815 | 67093632 |
| quickfix-native/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4437 / 2205 | 981082 / 380861 | 804221 |
| quickfix-native/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4438 | 380861 / 981295 | 5767168 |
| quickfix-native/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4433 / 2205 | 980040 / 380861 | 804221 |
| quickfix-native/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4434 | 380861 / 980253 | 5767168 |
| quickfix-native/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4429 / 2205 | 979020 / 380861 | 804221 |
| quickfix-native/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4430 | 380861 / 979233 | 5767168 |
| quickfix-native/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972479 / 380618 | 803594 |
| quickfix-native/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972479 | 5767168 |
| quickfix-native/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972480 / 380617 | 803593 |
| quickfix-native/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972480 | 5767168 |
| quickfix-native/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972564 / 380617 | 803593 |
| quickfix-native/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972564 | 5767168 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4418 / 2203 | 955361 / 380573 | 803549 |
| quickfix-quickfix/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4419 | 380573 / 955569 | 1673272 |
| quickfix-quickfix/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4419 / 2203 | 955618 / 380573 | 803549 |
| quickfix-quickfix/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4420 | 380573 / 955826 | 1673272 |
| quickfix-quickfix/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4425 / 2203 | 957115 / 380573 | 803549 |
| quickfix-quickfix/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4426 | 380573 / 957323 | 1673272 |
| quickfix-quickfix/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4489 / 2203 | 973129 / 380573 | 803549 |
| quickfix-quickfix/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4490 | 380573 / 973337 | 1673272 |
| quickfix-quickfix/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4437 / 2203 | 960127 / 380573 | 803549 |
| quickfix-quickfix/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4438 | 380573 / 960335 | 1673272 |
| quickfix-quickfix/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4465 / 2203 | 967132 / 380573 | 803549 |
| quickfix-quickfix/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4466 | 380573 / 967340 | 1673272 |
| quickfix-quickfix/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 1978709 / 2144538 / 2180303 / 2203579 / 2210061 | 1992019 / 2156716 / 2194366 / 2215369 / 2224750 | 0 / 0 / 0 / 0 / 0 | 1978709 / 2144538 / 2180303 / 2203579 / 2210061 | 1992019 / 2156716 / 2194366 / 2215369 / 2224750 | 3097600 | 5547524.430 |
| native-native/scalar/tcp/2 / 1 | 1930855 / 2173068 / 2313683 / 2352425 / 2368399 | 1941392 / 2185052 / 2327464 / 2361714 / 2377213 | 0 / 0 / 0 / 0 / 0 | 1930855 / 2173068 / 2313683 / 2352425 / 2368399 | 1941392 / 2185052 / 2327464 / 2361714 / 2377213 | 3097600 | 5498356.659 |
| native-native/scalar/tcp/3 / 1 | 2073231 / 2178186 / 2202544 / 2257304 / 2277895 | 2085464 / 2190094 / 2216659 / 2268057 / 2290689 | 0 / 0 / 0 / 0 / 0 | 2073231 / 2178186 / 2202544 / 2257304 / 2277895 | 2085464 / 2190094 / 2216659 / 2268057 / 2290689 | 3097600 | 5456710.645 |
| native-native/groups/tcp/1 / 1 | 11535659 / 20660326 / 20771327 / 20861540 / 20989982 | 11545621 / 20671892 / 20782567 / 20869487 / 20997572 | 0 / 0 / 0 / 0 / 0 | 11535659 / 20660326 / 20771327 / 20861540 / 20989982 | 11545621 / 20671892 / 20782567 / 20869487 / 20997572 | 39142400 | 16060150.643 |
| native-native/groups/tcp/2 / 1 | 11284958 / 20860586 / 21053617 / 21239179 / 21262915 | 11296241 / 20873240 / 21062010 / 21246956 / 21271014 | 0 / 0 / 0 / 0 / 0 | 11284958 / 20860586 / 21053617 / 21239179 / 21262915 | 11296241 / 20873240 / 21062010 / 21246956 / 21271014 | 39142400 | 16089858.841 |
| native-native/groups/tcp/3 / 1 | 11405744 / 21670974 / 21967368 / 22323957 / 22455049 | 11416201 / 21679787 / 21978195 / 22331672 / 22463087 | 0 / 0 / 0 / 0 / 0 | 11405744 / 21670974 / 21967368 / 22323957 / 22455049 | 11416201 / 21679787 / 21978195 / 22331672 / 22463087 | 39142400 | 15801580.682 |
| native-native/binary/tcp/1 / 1 | 5498491 / 5886115 / 6102594 / 6165413 / 6170288 | 5533832 / 5917515 / 6128069 / 6191953 / 6198368 | 0 / 0 / 0 / 0 / 0 | 5498491 / 5886115 / 6102594 / 6165413 / 6170288 | 5533832 / 5917515 / 6128069 / 6191953 / 6198368 | 39142400 | 71467241.263 |
| native-native/binary/tcp/2 / 1 | 5365407 / 6101789 / 6602044 / 7074864 / 7117301 | 5397413 / 6131264 / 6650280 / 7120767 / 7156427 | 0 / 0 / 0 / 0 / 0 | 5365407 / 6101789 / 6602044 / 7074864 / 7117301 | 5397413 / 6131264 / 6650280 / 7120767 / 7156427 | 39142400 | 72217740.007 |
| native-native/binary/tcp/3 / 1 | 6157037 / 6402667 / 6463039 / 6501387 / 6524330 | 6194354 / 6439515 / 6499577 / 6538051 / 6567060 | 0 / 0 / 0 / 0 / 0 | 6157037 / 6402667 / 6463039 / 6501387 / 6524330 | 6194354 / 6439515 / 6499577 / 6538051 / 6567060 | 39142400 | 67786416.801 |
| native-native/fragmentation/tcp/1 / 1 | 21509149 / 27915378 / 28965507 / 36297989 / 36334284 | 21545027 / 27946276 / 28992215 / 36335019 / 36371012 | 0 / 0 / 0 / 0 / 0 | 21509149 / 27915378 / 28965507 / 36297989 / 36334284 | 21545027 / 27946276 / 28992215 / 36335019 / 36371012 | 39142400 | 27050291.953 |
| native-native/fragmentation/tcp/2 / 1 | 21829285 / 28212247 / 29288578 / 29595186 / 29611000 | 21860416 / 28243222 / 29319859 / 29630260 / 29645508 | 0 / 0 / 0 / 0 / 0 | 21829285 / 28212247 / 29288578 / 29595186 / 29611000 | 21860416 / 28243222 / 29319859 / 29630260 / 29645508 | 39142400 | 26096800.129 |
| native-native/fragmentation/tcp/3 / 1 | 22514995 / 28919626 / 31564570 / 32097828 / 32138241 | 22545760 / 28950909 / 31640191 / 32127026 / 32168060 | 0 / 0 / 0 / 0 / 0 | 22514995 / 28919626 / 31564570 / 32097828 / 32138241 | 22545760 / 28950909 / 31640191 / 32127026 / 32168060 | 39142400 | 26415821.661 |
| native-native/replay/tcp/1 / 1 | 2824088 / 3581731 / 3942698 / 4026131 / 4057787 | 2837741 / 3585652 / 3956822 / 4039244 / 4066943 | 0 / 0 / 0 / 0 / 0 | 2824088 / 3581731 / 3942698 / 4026131 / 4057787 | 2837741 / 3585652 / 3956822 / 4039244 / 4066943 | 3097600 | 4040524.800 |
| native-native/replay/tcp/2 / 1 | 2724539 / 3265904 / 3544145 / 4076414 / 4092073 | 2734660 / 3273298 / 3548911 / 4086388 / 4098332 | 0 / 0 / 0 / 0 / 0 | 2724539 / 3265904 / 3544145 / 4076414 / 4092073 | 2734660 / 3273298 / 3548911 / 4086388 / 4098332 | 3097600 | 4032849.998 |
| native-native/replay/tcp/3 / 1 | 3127479 / 3686098 / 3861733 / 4681248 / 4739661 | 3142450 / 3696526 / 3865850 / 4720725 / 4755542 | 0 / 0 / 0 / 0 / 0 | 3127479 / 3686098 / 3861733 / 4681248 / 4739661 | 3142450 / 3696526 / 3865850 / 4720725 / 4755542 | 3097600 | 3936976.361 |
| native-native/overload/tcp/1 / 1 | 2113196 / 2250358 / 2473568 / 2539081 / 2544706 | 2126176 / 2264915 / 2490050 / 2557419 / 2561747 | 31153241 / 59984059 / 62773564 / 63286797 / 63344663 | 33248365 / 62234417 / 64654803 / 65173259 / 65236107 | 33256084 / 62243325 / 64660590 / 65199947 / 65243043 | 3097600 | 5315806.664 |
| native-native/overload/tcp/2 / 1 | 2182266 / 2316431 / 2423189 / 2444832 / 2457084 | 2195489 / 2329804 / 2440497 / 2461341 / 2467701 | 31826703 / 61626923 / 64489656 / 65102817 / 65168719 | 34064469 / 63915456 / 66294466 / 66626580 / 66656250 | 34071300 / 63929211 / 66304437 / 66633740 / 66661654 | 3097600 | 5374383.639 |
| native-native/overload/tcp/3 / 1 | 1991935 / 2141375 / 2350564 / 2363958 / 2373580 | 2003090 / 2158942 / 2362101 / 2375205 / 2384372 | 28951576 / 56125807 / 58771656 / 59336717 / 59389664 | 30935415 / 58306315 / 60849408 / 61409757 / 61444400 | 30946460 / 58320215 / 60873235 / 61416244 / 61450813 | 3097600 | 5417623.951 |
| native-native/scalar/tls/1 / 1 | 3654792 / 4077449 / 4477836 / 4675536 / 4688226 | 3680399 / 4103929 / 4522097 / 4707390 / 4720724 | 0 / 0 / 0 / 0 / 0 | 3654792 / 4077449 / 4477836 / 4675536 / 4688226 | 3680399 / 4103929 / 4522097 / 4707390 / 4720724 | 3097600 | 3854975.667 |
| native-native/scalar/tls/2 / 1 | 3889147 / 4201980 / 4281966 / 4382586 / 4407258 | 3920156 / 4233345 / 4310726 / 4396699 / 4419746 | 0 / 0 / 0 / 0 / 0 | 3889147 / 4201980 / 4281966 / 4382586 / 4407258 | 3920156 / 4233345 / 4310726 / 4396699 / 4419746 | 3097600 | 3776897.147 |
| native-native/scalar/tls/3 / 1 | 3768694 / 4088162 / 4194767 / 4241174 / 4252607 | 3797391 / 4118887 / 4213394 / 4278983 / 4288581 | 0 / 0 / 0 / 0 / 0 | 3768694 / 4088162 / 4194767 / 4241174 / 4252607 | 3797391 / 4118887 / 4213394 / 4278983 / 4288581 | 3097600 | 3808576.265 |
| native-native/groups/tls/1 / 1 | 11221443 / 21291272 / 21409775 / 21845667 / 22222370 | 11233780 / 21312896 / 21437951 / 21854995 / 22231193 | 0 / 0 / 0 / 0 / 0 | 11221443 / 21291272 / 21409775 / 21845667 / 22222370 | 11233780 / 21312896 / 21437951 / 21854995 / 22231193 | 39142400 | 15547894.740 |
| native-native/groups/tls/2 / 1 | 11760064 / 22032204 / 22176799 / 22599688 / 22858359 | 11777501 / 22068908 / 22200996 / 22609495 / 22868075 | 0 / 0 / 0 / 0 / 0 | 11760064 / 22032204 / 22176799 / 22599688 / 22858359 | 11777501 / 22068908 / 22200996 / 22609495 / 22868075 | 39142400 | 15370296.510 |
| native-native/groups/tls/3 / 1 | 11241418 / 22035834 / 22256809 / 22729507 / 23023712 | 11251665 / 22057529 / 22266352 / 22740707 / 23032999 | 0 / 0 / 0 / 0 / 0 | 11241418 / 22035834 / 22256809 / 22729507 / 23023712 | 11251665 / 22057529 / 22266352 / 22740707 / 23032999 | 39142400 | 15417258.231 |
| native-native/binary/tls/1 / 1 | 5849089 / 6443454 / 6937007 / 7206621 / 7256281 | 5889923 / 6469656 / 6987387 / 7230838 / 7278770 | 0 / 0 / 0 / 0 / 0 | 5849089 / 6443454 / 6937007 / 7206621 / 7256281 | 5889923 / 6469656 / 6987387 / 7230838 / 7278770 | 39142400 | 63726071.123 |
| native-native/binary/tls/2 / 1 | 5875402 / 6207627 / 6341663 / 6645237 / 6687668 | 5912860 / 6246388 / 6364929 / 6671519 / 6705367 | 0 / 0 / 0 / 0 / 0 | 5875402 / 6207627 / 6341663 / 6645237 / 6687668 | 5912860 / 6246388 / 6364929 / 6671519 / 6705367 | 39142400 | 65257160.323 |
| native-native/binary/tls/3 / 1 | 6048243 / 6524691 / 6637674 / 6833748 / 6844411 | 6089617 / 6568637 / 6670012 / 6861075 / 6870133 | 0 / 0 / 0 / 0 / 0 | 6048243 / 6524691 / 6637674 / 6833748 / 6844411 | 6089617 / 6568637 / 6670012 / 6861075 / 6870133 | 39142400 | 62375113.734 |
| native-native/fragmentation/tls/1 / 1 | 34380961 / 42970027 / 43336069 / 43375412 / 43397026 | 34408511 / 42991827 / 43367054 / 43393346 / 43424044 | 0 / 0 / 0 / 0 / 0 | 34380961 / 42970027 / 43336069 / 43375412 / 43397026 | 34408511 / 42991827 / 43367054 / 43393346 / 43424044 | 39142400 | 18044439.683 |
| native-native/fragmentation/tls/2 / 1 | 33356676 / 43395063 / 43768037 / 43834442 / 43853806 | 33381859 / 43421835 / 43796126 / 43854654 / 43871025 | 0 / 0 / 0 / 0 / 0 | 33356676 / 43395063 / 43768037 / 43834442 / 43853806 | 33381859 / 43421835 / 43796126 / 43854654 / 43871025 | 39142400 | 18165640.648 |
| native-native/fragmentation/tls/3 / 1 | 33409549 / 43729287 / 44436204 / 44517051 / 44523371 | 33432695 / 43753892 / 44455762 / 44540316 / 44552084 | 0 / 0 / 0 / 0 / 0 | 33409549 / 43729287 / 44436204 / 44517051 / 44523371 | 33432695 / 43753892 / 44455762 / 44540316 / 44552084 | 39142400 | 18288818.100 |
| native-native/replay/tls/1 / 1 | 3823805 / 4362140 / 5047493 / 5521860 / 5562551 | 3847311 / 4379833 / 5058981 / 5532163 / 5572899 | 0 / 0 / 0 / 0 / 0 | 3823805 / 4362140 / 5047493 / 5521860 / 5562551 | 3847311 / 4379833 / 5058981 / 5532163 / 5572899 | 3097600 | 3163848.790 |
| native-native/replay/tls/2 / 1 | 3785372 / 4881030 / 5567571 / 6565926 / 6610303 | 3824646 / 4911647 / 5599430 / 6580031 / 6630014 | 0 / 0 / 0 / 0 / 0 | 3785372 / 4881030 / 5567571 / 6565926 / 6610303 | 3824646 / 4911647 / 5599430 / 6580031 / 6630014 | 3097600 | 3170599.260 |
| native-native/replay/tls/3 / 1 | 4034307 / 4617929 / 5115587 / 5593735 / 5675070 | 4066581 / 4640501 / 5127216 / 5626135 / 5687012 | 0 / 0 / 0 / 0 / 0 | 4034307 / 4617929 / 5115587 / 5593735 / 5675070 | 4066581 / 4640501 / 5127216 / 5626135 / 5687012 | 3097600 | 3187261.750 |
| native-native/overload/tls/1 / 1 | 3825553 / 4110619 / 4221765 / 4414945 / 4470139 | 3854227 / 4137378 / 4244247 / 4457716 / 4511162 | 56956190 / 109979686 / 114644974 / 115671008 / 115778044 | 60411778 / 113761606 / 117993442 / 118740506 / 118800892 | 60451365 / 113773792 / 118013057 / 118758507 / 118829129 | 3097600 | 3732815.583 |
| native-native/overload/tls/2 / 1 | 3497491 / 3901706 / 4081785 / 4126456 / 4159778 | 3524525 / 3925066 / 4112527 / 4156079 / 4192669 | 50058598 / 100474381 / 105169276 / 106572728 / 106623482 | 53425852 / 104292421 / 108502774 / 109214315 / 109278717 | 53472023 / 104314757 / 108510507 / 109220599 / 109291045 | 3097600 | 3933902.777 |
| native-native/overload/tls/3 / 1 | 3434688 / 3655390 / 3751426 / 3788501 / 3816136 | 3457882 / 3682772 / 3776275 / 3807823 / 3833107 | 48715952 / 97918211 / 102520348 / 103567481 / 103622786 | 52000455 / 101624348 / 105681749 / 106462840 / 106515886 | 52027324 / 101650236 / 105692691 / 106473389 / 106541032 | 3097600 | 3879998.120 |
| native-quickfix/scalar/tcp/1 / 1 | 3005485 / 3878549 / 4026600 / 4076933 / 4078247 | 3029891 / 3910333 / 4054392 / 4109326 / 4112189 | 0 / 0 / 0 / 0 / 0 | 3005485 / 3878549 / 4026600 / 4076933 / 4078247 | 3029891 / 3910333 / 4054392 / 4109326 / 4112189 | 3097600 | 3560600.833 |
| native-quickfix/scalar/tcp/2 / 1 | 3014955 / 3676884 / 4314661 / 4552728 / 4597022 | 3037601 / 3688294 / 4343611 / 4590302 / 4618476 | 0 / 0 / 0 / 0 / 0 | 3014955 / 3676884 / 4314661 / 4552728 / 4597022 | 3037601 / 3688294 / 4343611 / 4590302 / 4618476 | 3097600 | 3504800.884 |
| native-quickfix/scalar/tcp/3 / 1 | 4029594 / 4664665 / 4728103 / 4914439 / 4978543 | 4057150 / 4690962 / 4761676 / 4920982 / 4999444 | 0 / 0 / 0 / 0 / 0 | 4029594 / 4664665 / 4728103 / 4914439 / 4978543 | 4057150 / 4690962 / 4761676 / 4920982 / 4999444 | 3097600 | 3328337.453 |
| native-quickfix/groups/tcp/1 / 1 | 36559666 / 49642174 / 50069718 / 53858056 / 54461381 | 36574967 / 49662983 / 50090081 / 53868074 / 54470592 | 0 / 0 / 0 / 0 / 0 | 36559666 / 49642174 / 50069718 / 53858056 / 54461381 | 36574967 / 49662983 / 50090081 / 53868074 / 54470592 | 39142400 | 7015071.836 |
| native-quickfix/groups/tcp/2 / 1 | 35050898 / 49807988 / 50896133 / 54824239 / 55556570 | 35063401 / 49817902 / 50905684 / 54832911 / 55565696 | 0 / 0 / 0 / 0 / 0 | 35050898 / 49807988 / 50896133 / 54824239 / 55556570 | 35063401 / 49817902 / 50905684 / 54832911 / 55565696 | 39142400 | 7156687.218 |
| native-quickfix/groups/tcp/3 / 1 | 36289490 / 50495202 / 51277325 / 54617358 / 55241406 | 36302264 / 50503065 / 51305194 / 54627747 / 55250553 | 0 / 0 / 0 / 0 / 0 | 36289490 / 50495202 / 51277325 / 54617358 / 55241406 | 36302264 / 50503065 / 51305194 / 54627747 / 55250553 | 39142400 | 6966850.321 |
| native-quickfix/binary/tcp/1 / 1 | 7458001 / 8061309 / 8196004 / 8486461 / 8510848 | 7501586 / 8106209 / 8246142 / 8515516 / 8539759 | 0 / 0 / 0 / 0 / 0 | 7458001 / 8061309 / 8196004 / 8486461 / 8510848 | 7501586 / 8106209 / 8246142 / 8515516 / 8539759 | 39142400 | 50612919.638 |
| native-quickfix/binary/tcp/2 / 1 | 7739459 / 9780295 / 10028283 / 10131920 / 10243321 | 7781265 / 9838618 / 10104739 / 10183053 / 10282744 | 0 / 0 / 0 / 0 / 0 | 7739459 / 9780295 / 10028283 / 10131920 / 10243321 | 7781265 / 9838618 / 10104739 / 10183053 / 10282744 | 39142400 | 48728159.816 |
| native-quickfix/binary/tcp/3 / 1 | 7408592 / 9692175 / 9803744 / 9995727 / 10051092 | 7451845 / 9753395 / 9863601 / 10064629 / 10115849 | 0 / 0 / 0 / 0 / 0 | 7408592 / 9692175 / 9803744 / 9995727 / 10051092 | 7451845 / 9753395 / 9863601 / 10064629 / 10115849 | 39142400 | 48960255.502 |
| native-quickfix/fragmentation/tcp/1 / 1 | 21443290 / 22186899 / 22606786 / 35422222 / 35486109 | 21481862 / 22227742 / 22640939 / 35486534 / 35534128 | 0 / 0 / 0 / 0 / 0 | 21443290 / 22186899 / 22606786 / 35422222 / 35486109 | 21481862 / 22227742 / 22640939 / 35486534 / 35534128 | 39142400 | 25637853.844 |
| native-quickfix/fragmentation/tcp/2 / 1 | 19886711 / 20469814 / 20782576 / 21799830 / 21928296 | 19916137 / 20503513 / 20818653 / 21833709 / 21961180 | 0 / 0 / 0 / 0 / 0 | 19886711 / 20469814 / 20782576 / 21799830 / 21928296 | 19916137 / 20503513 / 20818653 / 21833709 / 21961180 | 39142400 | 27119972.042 |
| native-quickfix/fragmentation/tcp/3 / 1 | 19367899 / 20076219 / 20838562 / 21703951 / 21789385 | 19394090 / 20105193 / 20859615 / 21726771 / 21816221 | 0 / 0 / 0 / 0 / 0 | 19367899 / 20076219 / 20838562 / 21703951 / 21789385 | 19394090 / 20105193 / 20859615 / 21726771 / 21816221 | 39142400 | 27476359.121 |
| native-quickfix/replay/tcp/1 / 1 | 4281222 / 4516899 / 4610432 / 4661419 / 4685717 | 4308711 / 4547574 / 4629480 / 4689740 / 4697277 | 0 / 0 / 0 / 0 / 0 | 4281222 / 4516899 / 4610432 / 4661419 / 4685717 | 4308711 / 4547574 / 4629480 / 4689740 / 4697277 | 3097600 | 2869390.210 |
| native-quickfix/replay/tcp/2 / 1 | 3763924 / 4396797 / 4590371 / 4630845 / 4634591 | 3788886 / 4429115 / 4626715 / 4674376 / 4678310 | 0 / 0 / 0 / 0 / 0 | 3763924 / 4396797 / 4590371 / 4630845 / 4634591 | 3788886 / 4429115 / 4626715 / 4674376 / 4678310 | 3097600 | 2904604.885 |
| native-quickfix/replay/tcp/3 / 1 | 4191005 / 4434827 / 4509426 / 4803376 / 4966255 | 4215585 / 4468132 / 4533360 / 4815026 / 4977493 | 0 / 0 / 0 / 0 / 0 | 4191005 / 4434827 / 4509426 / 4803376 / 4966255 | 4215585 / 4468132 / 4533360 / 4815026 / 4977493 | 3097600 | 2775063.794 |
| native-quickfix/overload/tcp/1 / 1 | 3814211 / 4489533 / 5152559 / 5245523 / 5249409 | 3835496 / 4512171 / 5184796 / 5282664 / 5285415 | 63460775 / 106116510 / 110093615 / 110961635 / 111060179 | 67557355 / 109391282 / 113031449 / 113768406 / 113853536 | 67572269 / 109401236 / 113041659 / 113797441 / 113872936 | 3097600 | 3380984.931 |
| native-quickfix/overload/tcp/2 / 1 | 3054266 / 3293182 / 3361912 / 3434100 / 3441275 | 3075391 / 3319038 / 3382759 / 3451912 / 3472559 | 45065904 / 87203975 / 91223936 / 92248945 / 92361062 | 48062018 / 90517418 / 94247188 / 94990761 / 95077524 | 48088420 / 90526478 / 94271969 / 95018352 / 95095849 | 3097600 | 3576023.187 |
| native-quickfix/overload/tcp/3 / 1 | 3132959 / 3279522 / 3316856 / 3353562 / 3374227 | 3156247 / 3303654 / 3343522 / 3385960 / 3405365 | 46153599 / 89118184 / 93191496 / 94145711 / 94226540 | 49138916 / 92426547 / 96235688 / 97095130 / 97185165 | 49168440 / 92461234 / 96256049 / 97120051 / 97210420 | 3097600 | 3511460.886 |
| native-quickfix/scalar/tls/1 / 1 | 4290982 / 5151603 / 6194276 / 6363329 / 6382288 | 4323948 / 5187180 / 6228944 / 6369421 / 6388541 | 0 / 0 / 0 / 0 / 0 | 4290982 / 5151603 / 6194276 / 6363329 / 6382288 | 4323948 / 5187180 / 6228944 / 6369421 / 6388541 | 3097600 | 2618358.733 |
| native-quickfix/scalar/tls/2 / 1 | 4826752 / 5215377 / 5895073 / 5924909 / 5932326 | 4863731 / 5240353 / 5931471 / 5967075 / 5973407 | 0 / 0 / 0 / 0 / 0 | 4826752 / 5215377 / 5895073 / 5924909 / 5932326 | 4863731 / 5240353 / 5931471 / 5967075 / 5973407 | 3097600 | 2594222.185 |
| native-quickfix/scalar/tls/3 / 1 | 4278246 / 4504662 / 4611452 / 4638138 / 4713138 | 4311608 / 4532840 / 4639074 / 4668454 / 4740847 | 0 / 0 / 0 / 0 / 0 | 4278246 / 4504662 / 4611452 / 4638138 / 4713138 | 4311608 / 4532840 / 4639074 / 4668454 / 4740847 | 3097600 | 2692564.406 |
| native-quickfix/groups/tls/1 / 1 | 35470357 / 49997354 / 57372761 / 59327715 / 59358368 | 35487995 / 50019070 / 57407401 / 59351565 / 59379017 | 0 / 0 / 0 / 0 / 0 | 35470357 / 49997354 / 57372761 / 59327715 / 59358368 | 35487995 / 50019070 / 57407401 / 59351565 / 59379017 | 39142400 | 6660699.422 |
| native-quickfix/groups/tls/2 / 1 | 35599810 / 57326400 / 59967738 / 60331023 / 60381700 | 35620586 / 57345173 / 59985622 / 60367390 / 60485607 | 0 / 0 / 0 / 0 / 0 | 35599810 / 57326400 / 59967738 / 60331023 / 60381700 | 35620586 / 57345173 / 59985622 / 60367390 / 60485607 | 39142400 | 6612469.643 |
| native-quickfix/groups/tls/3 / 1 | 44293510 / 50701805 / 51337623 / 55290086 / 56136348 | 44307641 / 50719146 / 51346662 / 55369317 / 56166293 | 0 / 0 / 0 / 0 / 0 | 44293510 / 50701805 / 51337623 / 55290086 / 56136348 | 44307641 / 50719146 / 51346662 / 55369317 / 56166293 | 39142400 | 5278846.840 |
| native-quickfix/binary/tls/1 / 1 | 8621831 / 9476934 / 9932020 / 10492708 / 10556465 | 8680234 / 9542177 / 9973586 / 10562452 / 10607834 | 0 / 0 / 0 / 0 / 0 | 8621831 / 9476934 / 9932020 / 10492708 / 10556465 | 8680234 / 9542177 / 9973586 / 10562452 / 10607834 | 39142400 | 23886382.246 |
| native-quickfix/binary/tls/2 / 1 | 9370586 / 10146524 / 10397381 / 10782671 / 10834897 | 9436748 / 10207035 / 10480001 / 10868644 / 10879690 | 0 / 0 / 0 / 0 / 0 | 9370586 / 10146524 / 10397381 / 10782671 / 10834897 | 9436748 / 10207035 / 10480001 / 10868644 / 10879690 | 39142400 | 40683602.232 |
| native-quickfix/binary/tls/3 / 1 | 8442271 / 8724599 / 8897059 / 9213087 / 9239242 | 8496996 / 8779262 / 8959918 / 9253112 / 9280219 | 0 / 0 / 0 / 0 / 0 | 8442271 / 8724599 / 8897059 / 9213087 / 9239242 | 8496996 / 8779262 / 8959918 / 9253112 / 9280219 | 39142400 | 42485325.126 |
| native-quickfix/fragmentation/tls/1 / 1 | 30070056 / 43386555 / 47284597 / 55073165 / 55172795 | 30098173 / 43430472 / 47305927 / 55098169 / 55195620 | 0 / 0 / 0 / 0 / 0 | 30070056 / 43386555 / 47284597 / 55073165 / 55172795 | 30098173 / 43430472 / 47305927 / 55098169 / 55195620 | 39142400 | 18439210.231 |
| native-quickfix/fragmentation/tls/2 / 1 | 30368034 / 39783568 / 45973257 / 50541852 / 55970240 | 30393615 / 39818303 / 45986302 / 50564686 / 56010190 | 0 / 0 / 0 / 0 / 0 | 30368034 / 39783568 / 45973257 / 50541852 / 55970240 | 30393615 / 39818303 / 45986302 / 50564686 / 56010190 | 39142400 | 18429191.254 |
| native-quickfix/fragmentation/tls/3 / 1 | 30342718 / 40661230 / 48546192 / 52605586 / 56753539 | 30382160 / 40681947 / 48574384 / 52629036 / 56769073 | 0 / 0 / 0 / 0 / 0 | 30342718 / 40661230 / 48546192 / 52605586 / 56753539 | 30382160 / 40681947 / 48574384 / 52629036 / 56769073 | 39142400 | 18577735.300 |
| native-quickfix/replay/tls/1 / 1 | 5658497 / 5974184 / 6114912 / 6550110 / 7097205 | 5697661 / 6007813 / 6163688 / 6571590 / 7130432 | 0 / 0 / 0 / 0 / 0 | 5658497 / 5974184 / 6114912 / 6550110 / 7097205 | 5697661 / 6007813 / 6163688 / 6571590 / 7130432 | 3097600 | 2256018.654 |
| native-quickfix/replay/tls/2 / 1 | 3571097 / 4770267 / 4918841 / 5266015 / 5326123 | 3589971 / 4792735 / 4927708 / 5278644 / 5339228 | 0 / 0 / 0 / 0 / 0 | 3571097 / 4770267 / 4918841 / 5266015 / 5326123 | 3589971 / 4792735 / 4927708 / 5278644 / 5339228 | 3097600 | 2418216.711 |
| native-quickfix/replay/tls/3 / 1 | 4444690 / 5683314 / 6171033 / 6438919 / 6815279 | 4474485 / 5726171 / 6209999 / 6470217 / 6855357 | 0 / 0 / 0 / 0 / 0 | 4444690 / 5683314 / 6171033 / 6438919 / 6815279 | 4474485 / 5726171 / 6209999 / 6470217 / 6855357 | 3097600 | 2320894.024 |
| native-quickfix/overload/tls/1 / 1 | 4260464 / 5008579 / 5088899 / 5116572 / 5123921 | 4295413 / 5042931 / 5128239 / 5154368 / 5156529 | 62151409 / 125541300 / 131862811 / 133389147 / 133525242 | 66387626 / 130628990 / 135833524 / 136764143 / 136871048 | 66414310 / 130662215 / 135852554 / 136794233 / 136895070 | 3097600 | 2696134.964 |
| native-quickfix/overload/tls/2 / 1 | 4824145 / 5090263 / 5169440 / 5220625 / 5231271 | 4858978 / 5120499 / 5205675 / 5261655 / 5267076 | 68084904 / 136532052 / 142991599 / 144429948 / 144562335 | 72845607 / 141653384 / 146798539 / 147816494 / 147942789 | 72878857 / 141689101 / 146807110 / 147839828 / 147966343 | 3097600 | 2612578.545 |
| native-quickfix/overload/tls/3 / 1 | 4301478 / 4545008 / 4680307 / 4767554 / 4839775 | 4331410 / 4572481 / 4715999 / 4816378 / 4892127 | 62290771 / 122231336 / 128006709 / 129175870 / 129306961 | 66502791 / 126886292 / 131988506 / 133087071 / 133201063 | 66526522 / 126919020 / 132016641 / 133116440 / 133225403 | 3097600 | 2699496.084 |
| quickfix-native/scalar/tcp/1 / 1 | 4354153 / 4496913 / 4548205 / 4577776 / 4599130 | 4390674 / 4532928 / 4586320 / 4618121 / 4637564 | 0 / 0 / 0 / 0 / 0 | 4354153 / 4496913 / 4548205 / 4577776 / 4599130 | 4390674 / 4532928 / 4586320 / 4618121 / 4637564 | 803594 | 685594.685 |
| quickfix-native/scalar/tcp/2 / 1 | 4315556 / 4464030 / 4504005 / 4568399 / 4587349 | 4347654 / 4494010 / 4535095 / 4588732 / 4614731 | 0 / 0 / 0 / 0 / 0 | 4315556 / 4464030 / 4504005 / 4568399 / 4587349 | 4347654 / 4494010 / 4535095 / 4588732 / 4614731 | 803593 | 706114.783 |
| quickfix-native/scalar/tcp/3 / 1 | 5263476 / 5581155 / 5674620 / 5695644 / 5719811 | 5308041 / 5622025 / 5718818 / 5740293 / 5752237 | 0 / 0 / 0 / 0 / 0 | 5263476 / 5581155 / 5674620 / 5695644 / 5719811 | 5308041 / 5622025 / 5718818 / 5740293 / 5752237 | 803594 | 701736.699 |
| quickfix-native/groups/tcp/1 / 1 | 72604529 / 79152066 / 80801731 / 81150462 / 81413949 | 72606344 / 79153965 / 80803694 / 81152378 / 81416034 | 0 / 0 / 0 / 0 / 0 | 72604529 / 79152066 / 80801731 / 81150462 / 81413949 | 72606344 / 79153965 / 80803694 / 81152378 / 81416034 | 11227194 | 3900322.575 |
| quickfix-native/groups/tcp/2 / 1 | 70238217 / 75892373 / 77678972 / 78080838 / 78103823 | 70239886 / 75894581 / 77680963 / 78083067 / 78106098 | 0 / 0 / 0 / 0 / 0 | 70238217 / 75892373 / 77678972 / 78080838 / 78103823 | 70239886 / 75894581 / 77680963 / 78083067 / 78106098 | 11227194 | 3425589.380 |
| quickfix-native/groups/tcp/3 / 1 | 71193583 / 83208626 / 86060214 / 86718724 / 86803692 | 71195417 / 83212006 / 86063850 / 86721474 / 86806018 | 0 / 0 / 0 / 0 / 0 | 71193583 / 83208626 / 86060214 / 86718724 / 86803692 | 71195417 / 83212006 / 86063850 / 86721474 / 86806018 | 11227194 | 3657386.719 |
| quickfix-native/binary/tcp/1 / 1 | 8194242 / 10211461 / 10377744 / 10681855 / 10726690 | 8231674 / 10278816 / 10461316 / 10764820 / 10806784 | 0 / 0 / 0 / 0 / 0 | 8194242 / 10211461 / 10377744 / 10681855 / 10726690 | 8231674 / 10278816 / 10461316 / 10764820 / 10806784 | 9847794 | 17453543.818 |
| quickfix-native/binary/tcp/2 / 1 | 8147378 / 8445872 / 8718840 / 8907849 / 8957879 | 8202854 / 8498225 / 8763009 / 8963988 / 8967639 | 0 / 0 / 0 / 0 / 0 | 8147378 / 8445872 / 8718840 / 8907849 / 8957879 | 8202854 / 8498225 / 8763009 / 8963988 / 8967639 | 9847794 | 17416873.834 |
| quickfix-native/binary/tcp/3 / 1 | 7587444 / 9425112 / 9533045 / 9624501 / 9651068 | 7641002 / 9483849 / 9589061 / 9688550 / 9700438 | 0 / 0 / 0 / 0 / 0 | 7587444 / 9425112 / 9533045 / 9624501 / 9651068 | 7641002 / 9483849 / 9589061 / 9688550 / 9700438 | 9847794 | 17567735.132 |
| quickfix-native/fragmentation/tcp/1 / 1 | 23244563 / 27653213 / 34835522 / 36250190 / 36327606 | 23301291 / 27742840 / 34981864 / 36260769 / 36340258 | 0 / 0 / 0 / 0 / 0 | 23244563 / 27653213 / 34835522 / 36250190 / 36327606 | 23301291 / 27742840 / 34981864 / 36260769 / 36340258 | 9847794 | 14079196.160 |
| quickfix-native/fragmentation/tcp/2 / 1 | 23188016 / 29875279 / 35906917 / 36517634 / 36580490 | 23261012 / 29914590 / 35936399 / 36564864 / 36586856 | 0 / 0 / 0 / 0 / 0 | 23188016 / 29875279 / 35906917 / 36517634 / 36580490 | 23261012 / 29914590 / 35936399 / 36564864 / 36586856 | 9847794 | 13509157.021 |
| quickfix-native/fragmentation/tcp/3 / 1 | 22608500 / 29224949 / 33068263 / 39288120 / 39366875 | 22642659 / 29265772 / 33082000 / 39358290 / 39374235 | 0 / 0 / 0 / 0 / 0 | 22608500 / 29224949 / 33068263 / 39288120 / 39366875 | 22642659 / 29265772 / 33082000 / 39358290 / 39374235 | 9847794 | 13895880.525 |
| quickfix-native/replay/tcp/1 / 1 | 4416125 / 7042797 / 7149609 / 7185066 / 7199545 | 4445135 / 7095951 / 7205692 / 7240357 / 7254953 | 0 / 0 / 0 / 0 / 0 | 4416125 / 7042797 / 7149609 / 7185066 / 7199545 | 4445135 / 7095951 / 7205692 / 7240357 / 7254953 | 804221 | 1100940.310 |
| quickfix-native/replay/tcp/2 / 1 | 4453043 / 5319457 / 6801090 / 8738460 / 8793113 | 4475789 / 5352905 / 6832003 / 8760688 / 8834241 | 0 / 0 / 0 / 0 / 0 | 4453043 / 5319457 / 6801090 / 8738460 / 8793113 | 4475789 / 5352905 / 6832003 / 8760688 / 8834241 | 804221 | 696623.766 |
| quickfix-native/replay/tcp/3 / 1 | 3924143 / 4323820 / 6967879 / 7408856 / 7450944 | 3941100 / 4346993 / 6989370 / 7423241 / 7471716 | 0 / 0 / 0 / 0 / 0 | 3924143 / 4323820 / 6967879 / 7408856 / 7450944 | 3941100 / 4346993 / 6989370 / 7423241 / 7471716 | 804219 | 1120833.462 |
| quickfix-native/overload/tcp/1 / 1 | 5200629 / 5467144 / 5542207 / 5596083 / 5659576 | 5241900 / 5507516 / 5583792 / 5620393 / 5662969 | 74861670 / 139674464 / 144783567 / 145821888 / 145968632 | 79974694 / 143556162 / 148532683 / 149518604 / 149626702 | 79995945 / 143588205 / 148560674 / 149546258 / 149654122 | 803594 | 705119.669 |
| quickfix-native/overload/tcp/2 / 1 | 3890989 / 5464201 / 5522606 / 5608924 / 5640074 | 3916670 / 5511300 / 5568417 / 5650005 / 5695987 | 63988234 / 122174773 / 128693365 / 130040140 / 130213842 | 67739326 / 127431871 / 132847467 / 133820363 / 133931030 | 67759419 / 127477948 / 132875257 / 133848509 / 133965365 | 803594 | 704327.415 |
| quickfix-native/overload/tcp/3 / 1 | 3866753 / 4158373 / 4253576 / 4286388 / 4324211 | 3896358 / 4189134 / 4278539 / 4315768 / 4327152 | 57191059 / 111333945 / 116051467 / 117118918 / 117240078 | 60997547 / 115130964 / 119834203 / 120800263 / 120908432 | 61025594 / 115165258 / 119853361 / 120828824 / 120933035 | 803594 | 682637.777 |
| quickfix-native/scalar/tls/1 / 1 | 5268040 / 6829623 / 6905124 / 6936459 / 6946514 | 5311546 / 6883805 / 6957894 / 6996374 / 6999647 | 0 / 0 / 0 / 0 / 0 | 5268040 / 6829623 / 6905124 / 6936459 / 6946514 | 5311546 / 6883805 / 6957894 / 6996374 / 6999647 | 803593 | 711536.243 |
| quickfix-native/scalar/tls/2 / 1 | 5085214 / 6871875 / 7273928 / 7535578 / 7567721 | 5115700 / 6920123 / 7336368 / 7584068 / 7634455 | 0 / 0 / 0 / 0 / 0 | 5085214 / 6871875 / 7273928 / 7535578 / 7567721 | 5115700 / 6920123 / 7336368 / 7584068 / 7634455 | 803594 | 1122491.718 |
| quickfix-native/scalar/tls/3 / 1 | 5263308 / 5512584 / 5617294 / 5645865 / 5651771 | 5303291 / 5555736 / 5653436 / 5684233 / 5687176 | 0 / 0 / 0 / 0 / 0 | 5263308 / 5512584 / 5617294 / 5645865 / 5651771 | 5303291 / 5555736 / 5653436 / 5684233 / 5687176 | 803594 | 1138324.027 |
| quickfix-native/groups/tls/1 / 1 | 74479672 / 78288953 / 78964349 / 79206905 / 79370301 | 74481661 / 78290643 / 78966414 / 79208932 / 79372616 | 0 / 0 / 0 / 0 / 0 | 74479672 / 78288953 / 78964349 / 79206905 / 79370301 | 74481661 / 78290643 / 78966414 / 79208932 / 79372616 | 11227194 | 2368992.760 |
| quickfix-native/groups/tls/2 / 1 | 74049808 / 81046088 / 81866616 / 82426573 / 82488315 | 74051972 / 81048676 / 81868848 / 82431839 / 82490993 | 0 / 0 / 0 / 0 / 0 | 74049808 / 81046088 / 81866616 / 82426573 / 82488315 | 74051972 / 81048676 / 81868848 / 82431839 / 82490993 | 11227194 | 3674053.215 |
| quickfix-native/groups/tls/3 / 1 | 72102182 / 77141824 / 78319811 / 78567635 / 78653715 | 72104400 / 77143951 / 78322358 / 78569852 / 78655826 | 0 / 0 / 0 / 0 / 0 | 72102182 / 77141824 / 78319811 / 78567635 / 78653715 | 72104400 / 77143951 / 78322358 / 78569852 / 78655826 | 11227194 | 3809594.044 |
| quickfix-native/binary/tls/1 / 1 | 9177898 / 10459122 / 10649940 / 10807874 / 10898376 | 9233280 / 10540455 / 10725359 / 10908104 / 10976069 | 0 / 0 / 0 / 0 / 0 | 9177898 / 10459122 / 10649940 / 10807874 / 10898376 | 9233280 / 10540455 / 10725359 / 10908104 / 10976069 | 9847794 | 25428506.676 |
| quickfix-native/binary/tls/2 / 1 | 8765518 / 10784286 / 10902450 / 11124569 / 11151081 | 8812594 / 10860018 / 10980242 / 11172968 / 11212998 | 0 / 0 / 0 / 0 / 0 | 8765518 / 10784286 / 10902450 / 11124569 / 11151081 | 8812594 / 10860018 / 10980242 / 11172968 / 11212998 | 9847793 | 25437636.355 |
| quickfix-native/binary/tls/3 / 1 | 9050161 / 10645879 / 10775128 / 10917803 / 10931407 | 9119972 / 10695300 / 10832377 / 10964298 / 10992337 | 0 / 0 / 0 / 0 / 0 | 9050161 / 10645879 / 10775128 / 10917803 / 10931407 | 9119972 / 10695300 / 10832377 / 10964298 / 10992337 | 9847794 | 25104720.628 |
| quickfix-native/fragmentation/tls/1 / 1 | 39643991 / 48633622 / 55314557 / 55772459 / 55847172 | 39700867 / 48682215 / 55358134 / 55842913 / 55891327 | 0 / 0 / 0 / 0 / 0 | 39643991 / 48633622 / 55314557 / 55772459 / 55847172 | 39700867 / 48682215 / 55358134 / 55842913 / 55891327 | 9847794 | 13463942.062 |
| quickfix-native/fragmentation/tls/2 / 1 | 34875695 / 37178711 / 50099961 / 54748702 / 54795310 | 34943105 / 37273111 / 50113455 / 54849338 / 54890944 | 0 / 0 / 0 / 0 / 0 | 34875695 / 37178711 / 50099961 / 54748702 / 54795310 | 34943105 / 37273111 / 50113455 / 54849338 / 54890944 | 9847794 | 14553788.675 |
| quickfix-native/fragmentation/tls/3 / 1 | 34142631 / 39827140 / 45030986 / 48236739 / 48355505 | 34204401 / 39868478 / 45128187 / 48308278 / 48363961 | 0 / 0 / 0 / 0 / 0 | 34142631 / 39827140 / 45030986 / 48236739 / 48355505 | 34204401 / 39868478 / 45128187 / 48308278 / 48363961 | 9847794 | 14258782.736 |
| quickfix-native/replay/tls/1 / 1 | 5876579 / 6321257 / 6425909 / 6453041 / 6460413 | 5918662 / 6366696 / 6470147 / 6499575 / 6504316 | 0 / 0 / 0 / 0 / 0 | 5876579 / 6321257 / 6425909 / 6453041 / 6460413 | 5918662 / 6366696 / 6470147 / 6499575 / 6504316 | 804221 | 1090468.705 |
| quickfix-native/replay/tls/2 / 1 | 6132337 / 6441623 / 6576740 / 6737516 / 6867581 | 6177344 / 6482510 / 6605869 / 6795411 / 6907106 | 0 / 0 / 0 / 0 / 0 | 6132337 / 6441623 / 6576740 / 6737516 / 6867581 | 6177344 / 6482510 / 6605869 / 6795411 / 6907106 | 804221 | 1091516.268 |
| quickfix-native/replay/tls/3 / 1 | 5512838 / 6620779 / 6691180 / 6744324 / 6762829 | 5544005 / 6671370 / 6739090 / 6798023 / 6820963 | 0 / 0 / 0 / 0 / 0 | 5512838 / 6620779 / 6691180 / 6744324 / 6762829 | 5544005 / 6671370 / 6739090 / 6798023 / 6820963 | 804221 | 1095236.628 |
| quickfix-native/overload/tls/1 / 1 | 5805704 / 6130877 / 6213697 / 6250267 / 6286563 | 5853439 / 6178816 / 6258196 / 6288164 / 6308273 | 78763485 / 160998970 / 167120300 / 168413545 / 168536968 | 84595942 / 166045211 / 171490291 / 172768742 / 172904266 | 84634871 / 166083524 / 171528084 / 172802708 / 172955495 | 803594 | 714150.999 |
| quickfix-native/overload/tls/2 / 1 | 5620996 / 6789475 / 6875246 / 6899763 / 6910838 | 5660217 / 6843073 / 6926940 / 6949651 / 6957491 | 86441491 / 168208014 / 174202327 / 175636908 / 175768192 | 93060895 / 173095491 / 178758701 / 179982509 / 180111712 | 93110649 / 173125904 / 178789791 / 180013127 / 180137827 | 803593 | 1142753.354 |
| quickfix-native/overload/tls/3 / 1 | 4906765 / 5557941 / 5670278 / 5725057 / 5735481 | 4939859 / 5589304 / 5689688 / 5762878 / 5767602 | 74178150 / 144174027 / 150338306 / 151764834 / 151910316 | 79037844 / 149118250 / 154949271 / 156296822 / 156455021 | 79065089 / 149149112 / 154978110 / 156342922 / 156486150 | 803593 | 1125601.964 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 4337707 / 4601497 / 4723178 / 4851219 / 4869589 | 4360264 / 4624630 / 4759558 / 4876441 / 4887313 | 0 / 0 / 0 / 0 / 0 | 4337707 / 4601497 / 4723178 / 4851219 / 4869589 | 4360264 / 4624630 / 4759558 / 4876441 / 4887313 | 803258 | 1079863.837 |
| quickfix-quickfix/scalar/tcp/2 / 1 | 3649297 / 3765508 / 3816288 / 3883704 / 3884198 | 3677163 / 3792004 / 3836068 / 3906871 / 3909515 | 0 / 0 / 0 / 0 / 0 | 3649297 / 3765508 / 3816288 / 3883704 / 3884198 | 3677163 / 3792004 / 3836068 / 3906871 / 3909515 | 803258 | 641976.932 |
| quickfix-quickfix/scalar/tcp/3 / 1 | 3713578 / 5887023 / 6062319 / 6154930 / 6172924 | 3740823 / 5932407 / 6113268 / 6202860 / 6219154 | 0 / 0 / 0 / 0 / 0 | 3713578 / 5887023 / 6062319 / 6154930 / 6172924 | 3740823 / 5932407 / 6113268 / 6202860 / 6219154 | 803258 | 658376.077 |
| quickfix-quickfix/groups/tcp/1 / 1 | 70388294 / 75262145 / 76988468 / 78174010 / 78175201 | 70390047 / 75264518 / 76990419 / 78176225 / 78178860 | 0 / 0 / 0 / 0 / 0 | 70388294 / 75262145 / 76988468 / 78174010 / 78175201 | 70390047 / 75264518 / 76990419 / 78176225 / 78178860 | 11226858 | 3573652.689 |
| quickfix-quickfix/groups/tcp/2 / 1 | 70592118 / 74763197 / 75532759 / 75895430 / 75933373 | 70594604 / 74765197 / 75534584 / 75897282 / 75935348 | 0 / 0 / 0 / 0 / 0 | 70592118 / 74763197 / 75532759 / 75895430 / 75933373 | 70594604 / 74765197 / 75534584 / 75897282 / 75935348 | 11226858 | 3507721.797 |
| quickfix-quickfix/groups/tcp/3 / 1 | 73893011 / 79846990 / 81097038 / 81457087 / 81600329 | 73895276 / 79849253 / 81099423 / 81459399 / 81602555 | 0 / 0 / 0 / 0 / 0 | 73893011 / 79846990 / 81097038 / 81457087 / 81600329 | 73895276 / 79849253 / 81099423 / 81459399 / 81602555 | 11226858 | 3679888.001 |
| quickfix-quickfix/binary/tcp/1 / 1 | 8340877 / 8788298 / 9087455 / 9411324 / 9479653 | 8392307 / 8839567 / 9141648 / 9489727 / 9525425 | 0 / 0 / 0 / 0 / 0 | 8340877 / 8788298 / 9087455 / 9411324 / 9479653 | 8392307 / 8839567 / 9141648 / 9489727 / 9525425 | 9847458 | 15972599.151 |
| quickfix-quickfix/binary/tcp/2 / 1 | 7457730 / 9647743 / 9912283 / 10160196 / 10165021 | 7502266 / 9725101 / 9984957 / 10234668 / 10268907 | 0 / 0 / 0 / 0 / 0 | 7457730 / 9647743 / 9912283 / 10160196 / 10165021 | 7502266 / 9725101 / 9984957 / 10234668 / 10268907 | 9847458 | 16205778.881 |
| quickfix-quickfix/binary/tcp/3 / 1 | 7286354 / 9224363 / 9455831 / 9508970 / 9520024 | 7330323 / 9266432 / 9527655 / 9568451 / 9585559 | 0 / 0 / 0 / 0 / 0 | 7286354 / 9224363 / 9455831 / 9508970 / 9520024 | 7330323 / 9266432 / 9527655 / 9568451 / 9585559 | 9847458 | 16267194.646 |
| quickfix-quickfix/fragmentation/tcp/1 / 1 | 19233173 / 25351055 / 29235049 / 30004379 / 30112884 | 19287810 / 25387219 / 29294682 / 30047066 / 30123589 | 0 / 0 / 0 / 0 / 0 | 19233173 / 25351055 / 29235049 / 30004379 / 30112884 | 19287810 / 25387219 / 29294682 / 30047066 / 30123589 | 9847458 | 14152477.691 |
| quickfix-quickfix/fragmentation/tcp/2 / 1 | 19334824 / 25687905 / 29990796 / 30860616 / 30929120 | 19370533 / 25725269 / 30036509 / 30901517 / 30942060 | 0 / 0 / 0 / 0 / 0 | 19334824 / 25687905 / 29990796 / 30860616 / 30929120 | 19370533 / 25725269 / 30036509 / 30901517 / 30942060 | 9847458 | 17948700.600 |
| quickfix-quickfix/fragmentation/tcp/3 / 1 | 23684919 / 31504744 / 37966468 / 38183735 / 38220623 | 23713573 / 31546889 / 38033296 / 38214252 / 38230231 | 0 / 0 / 0 / 0 / 0 | 23684919 / 31504744 / 37966468 / 38183735 / 38220623 | 23713573 / 31546889 / 38033296 / 38214252 / 38230231 | 9847458 | 12368028.811 |
| quickfix-quickfix/replay/tcp/1 / 1 | 4348461 / 5077639 / 5262789 / 5342991 / 5351508 | 4370556 / 5110360 / 5302530 / 5374407 / 5384939 | 0 / 0 / 0 / 0 / 0 | 4348461 / 5077639 / 5262789 / 5342991 / 5351508 | 4370556 / 5110360 / 5302530 / 5374407 / 5384939 | 803549 | 1034024.217 |
| quickfix-quickfix/replay/tcp/2 / 1 | 3824074 / 5006530 / 5176378 / 5236631 / 5268555 | 3852719 / 5042071 / 5211411 / 5285247 / 5299320 | 0 / 0 / 0 / 0 / 0 | 3824074 / 5006530 / 5176378 / 5236631 / 5268555 | 3852719 / 5042071 / 5211411 / 5285247 / 5299320 | 803549 | 642039.882 |
| quickfix-quickfix/replay/tcp/3 / 1 | 3778662 / 5056834 / 5133089 / 5365045 / 5415320 | 3805726 / 5088059 / 5167655 / 5391694 / 5449359 | 0 / 0 / 0 / 0 / 0 | 3778662 / 5056834 / 5133089 / 5365045 / 5415320 | 3805726 / 5088059 / 5167655 / 5391694 / 5449359 | 803549 | 646612.241 |
| quickfix-quickfix/overload/tcp/1 / 1 | 3801476 / 5304964 / 5380786 / 5490636 / 5539226 | 3830826 / 5343357 / 5417325 / 5541596 / 5550575 | 76680950 / 128400460 / 132924144 / 133986172 / 134092360 | 80913385 / 132040803 / 136515110 / 137497943 / 137613509 | 80936926 / 132065168 / 136540387 / 137528799 / 137644342 | 803258 | 661861.337 |
| quickfix-quickfix/overload/tcp/2 / 1 | 3624847 / 6292588 / 6403821 / 6452724 / 6486070 | 3652435 / 6339865 / 6454379 / 6498933 / 6533833 | 64062287 / 114099701 / 118652792 / 119654814 / 119809403 | 67555438 / 117789476 / 122299087 / 123227988 / 123335464 | 67578461 / 117813876 / 122322542 / 123252838 / 123371927 | 803258 | 659200.299 |
| quickfix-quickfix/overload/tcp/3 / 1 | 4263488 / 4515050 / 4609842 / 4742364 / 4758246 | 4287551 / 4537701 / 4632833 / 4783249 / 4788667 | 58077009 / 117361098 / 121861104 / 122852270 / 122963051 | 62381382 / 120928096 / 125277301 / 126219253 / 126342355 | 62402080 / 120951688 / 125327472 / 126241446 / 126368593 | 803258 | 665661.747 |
| quickfix-quickfix/scalar/tls/1 / 1 | 4498389 / 4678367 / 4907891 / 4946260 / 4963174 | 4533671 / 4716400 / 4942000 / 4975149 / 4986039 | 0 / 0 / 0 / 0 / 0 | 4498389 / 4678367 / 4907891 / 4946260 / 4963174 | 4533671 / 4716400 / 4942000 / 4975149 / 4986039 | 803258 | 646915.080 |
| quickfix-quickfix/scalar/tls/2 / 1 | 4519492 / 5236067 / 5362351 / 5414559 / 5430665 | 4556060 / 5261309 / 5393962 / 5444118 / 5479355 | 0 / 0 / 0 / 0 / 0 | 4519492 / 5236067 / 5362351 / 5414559 / 5430665 | 4556060 / 5261309 / 5393962 / 5444118 / 5479355 | 803258 | 667484.251 |
| quickfix-quickfix/scalar/tls/3 / 1 | 4447218 / 5156820 / 5301018 / 5368168 / 5395200 | 4483926 / 5179456 / 5328565 / 5393888 / 5408772 | 0 / 0 / 0 / 0 / 0 | 4447218 / 5156820 / 5301018 / 5368168 / 5395200 | 4483926 / 5179456 / 5328565 / 5393888 / 5408772 | 803258 | 666310.379 |
| quickfix-quickfix/groups/tls/1 / 1 | 71125607 / 76965936 / 77576337 / 78161931 / 78179753 | 71127766 / 76968353 / 77578569 / 78164192 / 78182449 | 0 / 0 / 0 / 0 / 0 | 71125607 / 76965936 / 77576337 / 78161931 / 78179753 | 71127766 / 76968353 / 77578569 / 78164192 / 78182449 | 11226858 | 3542515.117 |
| quickfix-quickfix/groups/tls/2 / 1 | 71323044 / 77021858 / 78909111 / 82124023 / 82205523 | 71325007 / 77023603 / 78911094 / 82126080 / 82208173 | 0 / 0 / 0 / 0 / 0 | 71323044 / 77021858 / 78909111 / 82124023 / 82205523 | 71325007 / 77023603 / 78911094 / 82126080 / 82208173 | 11226858 | 3813837.765 |
| quickfix-quickfix/groups/tls/3 / 1 | 71582594 / 76206555 / 77418880 / 78020426 / 78132210 | 71584824 / 76209124 / 77421259 / 78022422 / 78134952 | 0 / 0 / 0 / 0 / 0 | 71582594 / 76206555 / 77418880 / 78020426 / 78132210 | 71584824 / 76209124 / 77421259 / 78022422 / 78134952 | 11226858 | 3559466.427 |
| quickfix-quickfix/binary/tls/1 / 1 | 8487234 / 10588286 / 10983169 / 11123481 / 11128150 | 8545715 / 10621626 / 11042380 / 11179733 / 11191105 | 0 / 0 / 0 / 0 / 0 | 8487234 / 10588286 / 10983169 / 11123481 / 11128150 | 8545715 / 10621626 / 11042380 / 11179733 / 11191105 | 9847458 | 23226957.625 |
| quickfix-quickfix/binary/tls/2 / 1 | 8197344 / 8541552 / 8774932 / 8988121 / 9008796 | 8250563 / 8599654 / 8840670 / 9037649 / 9055461 | 0 / 0 / 0 / 0 / 0 | 8197344 / 8541552 / 8774932 / 8988121 / 9008796 | 8250563 / 8599654 / 8840670 / 9037649 / 9055461 | 9847458 | 16337566.607 |
| quickfix-quickfix/binary/tls/3 / 1 | 8170156 / 8444170 / 8499091 / 8544811 / 8557840 | 8200466 / 8477265 / 8532606 / 8569456 / 8595077 | 0 / 0 / 0 / 0 / 0 | 8170156 / 8444170 / 8499091 / 8544811 / 8557840 | 8200466 / 8477265 / 8532606 / 8569456 / 8595077 | 9847458 | 17284342.643 |
| quickfix-quickfix/fragmentation/tls/1 / 1 | 30958650 / 39820601 / 44896726 / 47092726 / 54847627 | 30995509 / 39871963 / 44912247 / 47116216 / 54985233 | 0 / 0 / 0 / 0 / 0 | 30958650 / 39820601 / 44896726 / 47092726 / 54847627 | 30995509 / 39871963 / 44912247 / 47116216 / 54985233 | 9847458 | 14212169.225 |
| quickfix-quickfix/fragmentation/tls/2 / 1 | 32111554 / 34005279 / 34671089 / 37898692 / 37957146 | 32191103 / 34103457 / 34769767 / 37965499 / 38029470 | 0 / 0 / 0 / 0 / 0 | 32111554 / 34005279 / 34671089 / 37898692 / 37957146 | 32191103 / 34103457 / 34769767 / 37965499 / 38029470 | 9847458 | 10943386.356 |
| quickfix-quickfix/fragmentation/tls/3 / 1 | 28690752 / 31930827 / 34862383 / 43221628 / 43239927 | 28764062 / 31995837 / 34920931 / 43288137 / 43303865 | 0 / 0 / 0 / 0 / 0 | 28690752 / 31930827 / 34862383 / 43221628 / 43239927 | 28764062 / 31995837 / 34920931 / 43288137 / 43303865 | 9847458 | 10631405.497 |
| quickfix-quickfix/replay/tls/1 / 1 | 4586276 / 6326554 / 9014451 / 9628673 / 9708309 | 4623474 / 6358059 / 9052865 / 9692031 / 9764266 | 0 / 0 / 0 / 0 / 0 | 4586276 / 6326554 / 9014451 / 9628673 / 9708309 | 4623474 / 6358059 / 9052865 / 9692031 / 9764266 | 803549 | 990226.205 |
| quickfix-quickfix/replay/tls/2 / 1 | 4750150 / 5328648 / 5577029 / 6038178 / 6089332 | 4771652 / 5353370 / 5608648 / 6076932 / 6118232 | 0 / 0 / 0 / 0 / 0 | 4750150 / 5328648 / 5577029 / 6038178 / 6089332 | 4771652 / 5353370 / 5608648 / 6076932 / 6118232 | 803549 | 637771.039 |
| quickfix-quickfix/replay/tls/3 / 1 | 5061767 / 5399139 / 6712006 / 6907021 / 6947662 | 5089531 / 5426184 / 6744452 / 6910060 / 6975122 | 0 / 0 / 0 / 0 / 0 | 5061767 / 5399139 / 6712006 / 6907021 / 6947662 | 5089531 / 5426184 / 6744452 / 6910060 / 6975122 | 803549 | 989826.483 |
| quickfix-quickfix/overload/tls/1 / 1 | 4509044 / 6290868 / 6811948 / 7090191 / 7138821 | 4542214 / 6345426 / 6862079 / 7149823 / 7200365 | 77165994 / 140272709 / 145948424 / 147171128 / 147325768 | 81503378 / 144794028 / 150317884 / 151442065 / 151570253 | 81538144 / 144829391 / 150345300 / 151475031 / 151601698 | 803258 | 663583.810 |
| quickfix-quickfix/overload/tls/2 / 1 | 4761988 / 4967527 / 5020500 / 5074086 / 5089072 | 4791674 / 4995156 / 5045739 / 5110907 / 5120392 | 71467229 / 137354058 / 143396665 / 144728475 / 144878296 | 76380820 / 142236958 / 147770742 / 148979765 / 149121396 | 76412470 / 142265148 / 147791047 / 149011213 / 149154124 | 803258 | 1035512.843 |
| quickfix-quickfix/overload/tls/3 / 1 | 4944493 / 6422729 / 6948255 / 7258950 / 7290856 | 4975765 / 6477649 / 7011371 / 7313867 / 7365174 | 83839919 / 152528297 / 158231271 / 159476153 / 159651677 | 88797789 / 157130049 / 162804720 / 164012966 / 164145217 | 88831722 / 157161915 / 162844032 / 164053469 / 164182594 | 803258 | 667045.197 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client | 1185 | 307432 | 0 | 34740 | 77560 | 891265 | 77336 / 889323 |
| native-native/scalar/tcp/1 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857690 | 152019 / 1857374 |
| native-native/scalar/tcp/2 / client | 1185 | 307480 | 0 | 34743 | 77560 | 891242 | 77336 / 889300 |
| native-native/scalar/tcp/2 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857636 | 152019 / 1857320 |
| native-native/scalar/tcp/3 / client | 1186 | 307464 | 0 | 34740 | 77560 | 891274 | 77336 / 889332 |
| native-native/scalar/tcp/3 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857700 | 152019 / 1857384 |
| native-native/groups/tcp/1 / client | 1190 | 309416 | 0 | 43694 | 801464 | 30005221 | 801240 / 30003279 |
| native-native/groups/tcp/1 / server | 22837 | 209110270 | 0 | 210415 | 224673 | 454424334 | 224639 / 454424018 |
| native-native/groups/tcp/2 / client | 1192 | 309480 | 0 | 43696 | 801447 | 30005143 | 801223 / 30003201 |
| native-native/groups/tcp/2 / server | 22837 | 209110270 | 0 | 210415 | 224673 | 454424288 | 224639 / 454423972 |
| native-native/groups/tcp/3 / client | 1190 | 309416 | 0 | 43694 | 801422 | 30005116 | 801198 / 30003174 |
| native-native/groups/tcp/3 / server | 22836 | 209109758 | 0 | 210415 | 224673 | 454424318 | 224639 / 454424002 |
| native-native/binary/tcp/1 / client | 1187 | 307944 | 0 | 65378 | 84167 | 19350659 | 83943 / 19348717 |
| native-native/binary/tcp/1 / server | 833 | 285246 | 0 | 76024 | 165260 | 38988957 | 165226 / 38988641 |
| native-native/binary/tcp/2 / client | 1187 | 307960 | 0 | 65238 | 84167 | 19350773 | 83943 / 19348831 |
| native-native/binary/tcp/2 / server | 833 | 285246 | 0 | 76037 | 165260 | 38989171 | 165226 / 38988855 |
| native-native/binary/tcp/3 / client | 1188 | 307976 | 0 | 65287 | 84167 | 19350721 | 83943 / 19348779 |
| native-native/binary/tcp/3 / server | 833 | 285246 | 0 | 76004 | 165260 | 38989057 | 165226 / 38988741 |
| native-native/fragmentation/tcp/1 / client | 1188 | 307992 | 0 | 62831 | 84166 | 19350699 | 83942 / 19348757 |
| native-native/fragmentation/tcp/1 / server | 833 | 285246 | 0 | 164232 | 165260 | 38989080 | 165226 / 38988764 |
| native-native/fragmentation/tcp/2 / client | 1188 | 307976 | 0 | 62260 | 84166 | 19350741 | 83942 / 19348799 |
| native-native/fragmentation/tcp/2 / server | 833 | 285246 | 0 | 163022 | 165260 | 38989070 | 165226 / 38988754 |
| native-native/fragmentation/tcp/3 / client | 1188 | 307976 | 0 | 62361 | 84166 | 19350711 | 83942 / 19348769 |
| native-native/fragmentation/tcp/3 / server | 833 | 285246 | 0 | 169436 | 165260 | 38989095 | 165226 / 38988779 |
| native-native/replay/tcp/1 / client | 1187 | 307736 | 0 | 34868 | 77645 | 892394 | 77421 / 890452 |
| native-native/replay/tcp/1 / server | 831 | 284734 | 0 | 54095 | 152140 | 1858897 | 152106 / 1858581 |
| native-native/replay/tcp/2 / client | 1187 | 307720 | 0 | 34859 | 77645 | 892445 | 77421 / 890503 |
| native-native/replay/tcp/2 / server | 831 | 284734 | 0 | 54103 | 152140 | 1858982 | 152106 / 1858666 |
| native-native/replay/tcp/3 / client | 1184 | 307656 | 0 | 34872 | 77645 | 892426 | 77421 / 890484 |
| native-native/replay/tcp/3 / server | 831 | 284734 | 0 | 54094 | 152140 | 1858954 | 152106 / 1858638 |
| native-native/overload/tcp/1 / client | 1186 | 307512 | 0 | 34740 | 77560 | 891260 | 77336 / 889318 |
| native-native/overload/tcp/1 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857676 | 152019 / 1857360 |
| native-native/overload/tcp/2 / client | 1186 | 307480 | 0 | 34741 | 77560 | 891266 | 77336 / 889324 |
| native-native/overload/tcp/2 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857684 | 152019 / 1857368 |
| native-native/overload/tcp/3 / client | 1185 | 307448 | 0 | 34739 | 77560 | 891235 | 77336 / 889293 |
| native-native/overload/tcp/3 / server | 831 | 284734 | 0 | 54061 | 152053 | 1857622 | 152019 / 1857306 |
| native-native/scalar/tls/1 / client | 11711 | 972632 | 0 | 45837 | 88288 | 1356077 | 77354 / 889461 |
| native-native/scalar/tls/1 / server | 11470 | 998447 | 0 | 65134 | 173113 | 3093106 | 152031 / 1857469 |
| native-native/scalar/tls/2 / client | 11708 | 972536 | 0 | 45834 | 88289 | 1356088 | 77355 / 889456 |
| native-native/scalar/tls/2 / server | 11470 | 998447 | 0 | 65133 | 173117 | 3091897 | 152031 / 1857433 |
| native-native/scalar/tls/3 / client | 11708 | 972536 | 0 | 45834 | 88288 | 1356071 | 77354 / 889452 |
| native-native/scalar/tls/3 / server | 11470 | 998447 | 0 | 65134 | 173138 | 3096596 | 152031 / 1857451 |
| native-native/groups/tls/1 / client | 11721 | 996360 | 0 | 54793 | 812201 | 40893566 | 801267 / 30003358 |
| native-native/groups/tls/1 / server | 33479 | 209845135 | 0 | 210493 | 245771 | 455661527 | 224653 / 454424089 |
| native-native/groups/tls/2 / client | 11718 | 996264 | 0 | 54790 | 812183 | 40893522 | 801249 / 30003333 |
| native-native/groups/tls/2 / server | 33480 | 209845391 | 0 | 210493 | 245768 | 455663411 | 224653 / 454424067 |
| native-native/groups/tls/3 / client | 11720 | 996312 | 0 | 54792 | 812197 | 40893609 | 801263 / 30003378 |
| native-native/groups/tls/3 / server | 33480 | 209845391 | 0 | 210495 | 245724 | 455654402 | 224653 / 454424089 |
| native-native/binary/tls/1 / client | 11717 | 1010136 | 0 | 54750 | 94896 | 28859810 | 83962 / 19348978 |
| native-native/binary/tls/1 / server | 11476 | 1035951 | 0 | 76160 | 186320 | 58313475 | 165237 / 38989024 |
| native-native/binary/tls/2 / client | 11715 | 1019288 | 0 | 54827 | 94896 | 28859705 | 83962 / 19348904 |
| native-native/binary/tls/2 / server | 11478 | 1045455 | 0 | 76168 | 186327 | 58311384 | 165237 / 38988816 |
| native-native/binary/tls/3 / client | 11717 | 1010184 | 0 | 54905 | 94895 | 28859699 | 83961 / 19348894 |
| native-native/binary/tls/3 / server | 11476 | 1035951 | 0 | 76165 | 186386 | 58319043 | 165237 / 38988824 |
| native-native/fragmentation/tls/1 / client | 11722 | 1011976 | 0 | 58999 | 94917 | 28860262 | 83960 / 19348920 |
| native-native/fragmentation/tls/1 / server | 11474 | 1017551 | 0 | 223547 | 186300 | 58304012 | 165237 / 38988839 |
| native-native/fragmentation/tls/2 / client | 11721 | 1011944 | 0 | 58977 | 94917 | 28860210 | 83960 / 19348895 |
| native-native/fragmentation/tls/2 / server | 11474 | 1017551 | 0 | 223547 | 186334 | 58311249 | 165237 / 38988848 |
| native-native/fragmentation/tls/3 / client | 11722 | 1021192 | 0 | 58996 | 94917 | 28860222 | 83960 / 19348907 |
| native-native/fragmentation/tls/3 / server | 11475 | 1026799 | 0 | 223548 | 186346 | 58311605 | 165237 / 38988853 |
| native-native/replay/tls/1 / client | 11714 | 974664 | 0 | 45983 | 88409 | 1358183 | 77440 / 890647 |
| native-native/replay/tls/1 / server | 11470 | 998447 | 0 | 65170 | 173224 | 3096225 | 152118 / 1858748 |
| native-native/replay/tls/2 / client | 11717 | 974744 | 0 | 45981 | 88409 | 1358134 | 77440 / 890637 |
| native-native/replay/tls/2 / server | 11470 | 998447 | 0 | 65170 | 173230 | 3093903 | 152118 / 1858729 |
| native-native/replay/tls/3 / client | 11716 | 974696 | 0 | 45968 | 88409 | 1358111 | 77440 / 890608 |
| native-native/replay/tls/3 / server | 11470 | 998447 | 0 | 65170 | 173216 | 3092779 | 152118 / 1858669 |
| native-native/overload/tls/1 / client | 11710 | 972600 | 0 | 45836 | 88289 | 1356086 | 77355 / 889463 |
| native-native/overload/tls/1 / server | 11471 | 998703 | 0 | 65134 | 173106 | 3089621 | 152031 / 1857447 |
| native-native/overload/tls/2 / client | 11711 | 972648 | 0 | 45837 | 88289 | 1356100 | 77355 / 889474 |
| native-native/overload/tls/2 / server | 11471 | 998703 | 0 | 65134 | 173152 | 3098484 | 152031 / 1857469 |
| native-native/overload/tls/3 / client | 11708 | 972536 | 0 | 45834 | 88288 | 1356142 | 77354 / 889474 |
| native-native/overload/tls/3 / server | 11470 | 998447 | 0 | 65134 | 173106 | 3087594 | 152031 / 1857495 |
| native-quickfix/scalar/tcp/1 / client | 1186 | 307464 | 0 | 34738 | 77533 | 890864 | 77309 / 888922 |
| native-quickfix/scalar/tcp/1 / server | 1863 | 5813374 | 0 | 55013 | 815739 | 12208532 | 615388 / 8326246 |
| native-quickfix/scalar/tcp/2 / client | 1185 | 307448 | 0 | 34730 | 77533 | 890867 | 77309 / 888925 |
| native-quickfix/scalar/tcp/2 / server | 1863 | 5813374 | 0 | 55013 | 815736 | 11322906 | 615387 / 8326204 |
| native-quickfix/scalar/tcp/3 / client | 1186 | 307496 | 0 | 34733 | 77533 | 890848 | 77309 / 888906 |
| native-quickfix/scalar/tcp/3 / server | 1863 | 5813374 | 0 | 55013 | 815737 | 12079768 | 615388 / 8326079 |
| native-quickfix/groups/tcp/1 / client | 1193 | 309512 | 0 | 43686 | 801426 | 30004782 | 801202 / 30002840 |
| native-quickfix/groups/tcp/1 / server | 1866 | 5814142 | 0 | 347759 | 3157084 | 42086170 | 2953164 / 20576967 |
| native-quickfix/groups/tcp/2 / client | 1193 | 309512 | 0 | 43688 | 801430 | 30004764 | 801206 / 30002822 |
| native-quickfix/groups/tcp/2 / server | 1866 | 5814142 | 0 | 347759 | 3157088 | 42178667 | 2953167 / 20577021 |
| native-quickfix/groups/tcp/3 / client | 1192 | 309480 | 0 | 43691 | 801410 | 30004773 | 801186 / 30002831 |
| native-quickfix/groups/tcp/3 / server | 1866 | 5814142 | 0 | 347759 | 3157081 | 42125045 | 2953162 / 20577011 |
| native-quickfix/binary/tcp/1 / client | 1188 | 308024 | 0 | 64943 | 84140 | 19350331 | 83916 / 19348389 |
| native-quickfix/binary/tcp/1 / server | 1863 | 5813374 | 0 | 52815 | 851395 | 111829475 | 637616 / 71552892 |
| native-quickfix/binary/tcp/2 / client | 1187 | 307944 | 0 | 64375 | 84141 | 19350341 | 83917 / 19348399 |
| native-quickfix/binary/tcp/2 / server | 1863 | 5813374 | 0 | 52815 | 851556 | 112473456 | 637697 / 71553248 |
| native-quickfix/binary/tcp/3 / client | 1185 | 307880 | 0 | 65525 | 84140 | 19350377 | 83916 / 19348435 |
| native-quickfix/binary/tcp/3 / server | 1863 | 5813374 | 0 | 52815 | 851458 | 112095931 | 637648 / 71553121 |
| native-quickfix/fragmentation/tcp/1 / client | 1187 | 307960 | 0 | 61935 | 84139 | 19350289 | 83915 / 19348347 |
| native-quickfix/fragmentation/tcp/1 / server | 1863 | 5813374 | 0 | 52815 | 935105 | 110241753 | 679473 / 71720275 |
| native-quickfix/fragmentation/tcp/2 / client | 1185 | 307896 | 0 | 62189 | 84140 | 19350375 | 83916 / 19348433 |
| native-quickfix/fragmentation/tcp/2 / server | 1863 | 5813374 | 0 | 52815 | 933064 | 110225985 | 678452 / 71716317 |
| native-quickfix/fragmentation/tcp/3 / client | 1187 | 307960 | 0 | 62252 | 84140 | 19350368 | 83916 / 19348426 |
| native-quickfix/fragmentation/tcp/3 / server | 1863 | 5813374 | 0 | 52815 | 919770 | 110250214 | 671805 / 71689741 |
| native-quickfix/replay/tcp/1 / client | 1187 | 307752 | 0 | 34839 | 77591 | 891628 | 77367 / 889686 |
| native-quickfix/replay/tcp/1 / server | 1864 | 5813630 | 0 | 55019 | 816074 | 11332097 | 615642 / 8329833 |
| native-quickfix/replay/tcp/2 / client | 1184 | 307624 | 0 | 34849 | 77591 | 891631 | 77367 / 889689 |
| native-quickfix/replay/tcp/2 / server | 1864 | 5813630 | 0 | 55019 | 816092 | 13279238 | 615651 / 8329768 |
| native-quickfix/replay/tcp/3 / client | 1187 | 307720 | 0 | 34837 | 77591 | 891613 | 77367 / 889671 |
| native-quickfix/replay/tcp/3 / server | 1864 | 5813630 | 0 | 55019 | 816075 | 11410735 | 615642 / 8329770 |
| native-quickfix/overload/tcp/1 / client | 1185 | 307432 | 0 | 34728 | 77533 | 890845 | 77309 / 888903 |
| native-quickfix/overload/tcp/1 / server | 1863 | 5813374 | 0 | 55013 | 815739 | 12106795 | 615389 / 8326051 |
| native-quickfix/overload/tcp/2 / client | 1186 | 307496 | 0 | 34729 | 77533 | 890861 | 77309 / 888919 |
| native-quickfix/overload/tcp/2 / server | 1863 | 5813374 | 0 | 55013 | 815739 | 12030985 | 615389 / 8326210 |
| native-quickfix/overload/tcp/3 / client | 1183 | 307368 | 0 | 34733 | 77533 | 890876 | 77309 / 888934 |
| native-quickfix/overload/tcp/3 / server | 1863 | 5813374 | 0 | 55013 | 815733 | 11558684 | 615386 / 8326153 |
| native-quickfix/scalar/tls/1 / client | 11644 | 969824 | 0 | 45755 | 88341 | 1357070 | 77325 / 889028 |
| native-quickfix/scalar/tls/1 / server | 31794 | 7546235 | 0 | 309138 | 846879 | 12497655 | 615423 / 8327193 |
| native-quickfix/scalar/tls/2 / client | 11643 | 969792 | 0 | 45754 | 88341 | 1357037 | 77325 / 889034 |
| native-quickfix/scalar/tls/2 / server | 31794 | 7546237 | 0 | 309138 | 846914 | 12495593 | 615423 / 8327076 |
| native-quickfix/scalar/tls/3 / client | 11641 | 969728 | 0 | 45752 | 88341 | 1357050 | 77325 / 889021 |
| native-quickfix/scalar/tls/3 / server | 31794 | 7546236 | 0 | 309138 | 846904 | 12495219 | 615423 / 8327156 |
| native-quickfix/groups/tls/1 / client | 11654 | 993760 | 0 | 54711 | 812221 | 40894518 | 801210 / 30002913 |
| native-quickfix/groups/tls/1 / server | 31799 | 7548027 | 0 | 601916 | 3185452 | 45579394 | 2951832 / 20572438 |
| native-quickfix/groups/tls/2 / client | 11655 | 993824 | 0 | 54714 | 812249 | 40894643 | 801233 / 30002971 |
| native-quickfix/groups/tls/2 / server | 31799 | 7548028 | 0 | 601916 | 3185471 | 45582925 | 2951832 / 20572605 |
| native-quickfix/groups/tls/3 / client | 11652 | 993696 | 0 | 54711 | 812225 | 40894601 | 801209 / 30002940 |
| native-quickfix/groups/tls/3 / server | 31799 | 7548028 | 0 | 601884 | 3185475 | 45582017 | 2951832 / 20572578 |
| native-quickfix/binary/tls/1 / client | 11648 | 1016480 | 0 | 55094 | 94947 | 28860701 | 83931 / 19348468 |
| native-quickfix/binary/tls/1 / server | 31794 | 7546236 | 0 | 306940 | 882010 | 138993194 | 637423 / 71552968 |
| native-quickfix/binary/tls/2 / client | 11650 | 1016576 | 0 | 54719 | 94947 | 28860658 | 83931 / 19348440 |
| native-quickfix/binary/tls/2 / server | 31794 | 7546236 | 0 | 306972 | 882035 | 138996140 | 637423 / 71552917 |
| native-quickfix/binary/tls/3 / client | 11648 | 1016496 | 0 | 54656 | 94947 | 28860804 | 83931 / 19348518 |
| native-quickfix/binary/tls/3 / server | 31794 | 7546237 | 0 | 306940 | 882045 | 138997925 | 637423 / 71553127 |
| native-quickfix/fragmentation/tls/1 / client | 11722 | 1021192 | 0 | 55290 | 94886 | 28859814 | 83933 / 19348590 |
| native-quickfix/fragmentation/tls/1 / server | 177004 | 13356119 | 0 | 5243740 | 1753308 | 144244400 | 782623 / 72133978 |
| native-quickfix/fragmentation/tls/2 / client | 11722 | 1021208 | 0 | 54923 | 94886 | 28859690 | 83933 / 19348502 |
| native-quickfix/fragmentation/tls/2 / server | 177004 | 13356119 | 0 | 5243740 | 1753298 | 144239692 | 782623 / 72133870 |
| native-quickfix/fragmentation/tls/3 / client | 11722 | 1021192 | 0 | 55035 | 94886 | 28859782 | 83933 / 19348569 |
| native-quickfix/fragmentation/tls/3 / server | 177004 | 13356120 | 0 | 5243740 | 1753295 | 144243953 | 782623 / 72133945 |
| native-quickfix/replay/tls/1 / client | 11714 | 974632 | 0 | 45939 | 88347 | 1357086 | 77386 / 889837 |
| native-quickfix/replay/tls/1 / server | 31813 | 7548696 | 0 | 309286 | 847261 | 12503491 | 615679 / 8330860 |
| native-quickfix/replay/tls/2 / client | 11716 | 974712 | 0 | 45940 | 88347 | 1357104 | 77386 / 889857 |
| native-quickfix/replay/tls/2 / server | 31813 | 7548696 | 0 | 309286 | 847259 | 12503235 | 615679 / 8330858 |
| native-quickfix/replay/tls/3 / client | 11717 | 974728 | 0 | 45935 | 88347 | 1357075 | 77386 / 889841 |
| native-quickfix/replay/tls/3 / server | 31813 | 7548696 | 0 | 309286 | 847234 | 12496733 | 615679 / 8330815 |
| native-quickfix/overload/tls/1 / client | 11641 | 969744 | 0 | 45752 | 88341 | 1357076 | 77325 / 889044 |
| native-quickfix/overload/tls/1 / server | 31794 | 7546235 | 0 | 309138 | 846851 | 12489811 | 615423 / 8327163 |
| native-quickfix/overload/tls/2 / client | 11644 | 969824 | 0 | 45755 | 88341 | 1357085 | 77325 / 889051 |
| native-quickfix/overload/tls/2 / server | 31795 | 7546493 | 0 | 309139 | 846846 | 12487988 | 615423 / 8327171 |
| native-quickfix/overload/tls/3 / client | 11644 | 969824 | 0 | 45755 | 88341 | 1357093 | 77325 / 889051 |
| native-quickfix/overload/tls/3 / server | 31795 | 7546492 | 0 | 309107 | 846856 | 12492069 | 615423 / 8327193 |
| quickfix-native/scalar/tcp/1 / client | 1864 | 5813462 | 0 | 28614 | 970376 | 29319092 | 704505 / 8800968 |
| quickfix-native/scalar/tcp/1 / server | 831 | 284734 | 0 | 54049 | 152027 | 1857253 | 151993 / 1856937 |
| quickfix-native/scalar/tcp/2 / client | 1864 | 5813462 | 0 | 28614 | 970375 | 29320105 | 704503 / 8801178 |
| quickfix-native/scalar/tcp/2 / server | 831 | 284734 | 0 | 54049 | 152027 | 1857347 | 151993 / 1857031 |
| quickfix-native/scalar/tcp/3 / client | 1864 | 5813462 | 0 | 28614 | 970395 | 29271019 | 704524 / 8801730 |
| quickfix-native/scalar/tcp/3 / server | 832 | 284990 | 0 | 54290 | 152030 | 1857353 | 151996 / 1857037 |
| quickfix-native/groups/tcp/1 / client | 1867 | 5814230 | 0 | 96960 | 7514458 | 55580782 | 5790099 / 41947374 |
| quickfix-native/groups/tcp/1 / server | 22837 | 209110270 | 0 | 210404 | 224646 | 454423909 | 224612 / 454423593 |
| quickfix-native/groups/tcp/2 / client | 1867 | 5814230 | 0 | 96960 | 7515682 | 55629617 | 5791323 / 41983329 |
| quickfix-native/groups/tcp/2 / server | 22837 | 209110270 | 0 | 210404 | 224647 | 454423935 | 224613 / 454423619 |
| quickfix-native/groups/tcp/3 / client | 1867 | 5814230 | 0 | 96960 | 7520343 | 55628533 | 5795985 / 42120279 |
| quickfix-native/groups/tcp/3 / server | 22837 | 209110270 | 0 | 210404 | 224646 | 454423951 | 224612 / 454423635 |
| quickfix-native/binary/tcp/1 / client | 1864 | 5813462 | 0 | 24216 | 1076572 | 147729585 | 828081 / 81984705 |
| quickfix-native/binary/tcp/1 / server | 833 | 285246 | 0 | 75991 | 165233 | 38988683 | 165199 / 38988367 |
| quickfix-native/binary/tcp/2 / client | 1864 | 5813462 | 0 | 24216 | 1076692 | 147767908 | 828189 / 81987535 |
| quickfix-native/binary/tcp/2 / server | 833 | 285246 | 0 | 75959 | 165234 | 38988678 | 165200 / 38988362 |
| quickfix-native/binary/tcp/3 / client | 1864 | 5813462 | 0 | 24216 | 1076438 | 147731816 | 827960 / 81981627 |
| quickfix-native/binary/tcp/3 / server | 833 | 285246 | 0 | 76050 | 165234 | 38988701 | 165200 / 38988385 |
| quickfix-native/fragmentation/tcp/1 / client | 1864 | 5813462 | 0 | 24216 | 1076424 | 147649852 | 827979 / 81982915 |
| quickfix-native/fragmentation/tcp/1 / server | 833 | 285246 | 0 | 165378 | 165233 | 38988719 | 165199 / 38988403 |
| quickfix-native/fragmentation/tcp/2 / client | 1864 | 5813462 | 0 | 24216 | 1076376 | 147612684 | 827948 / 81982467 |
| quickfix-native/fragmentation/tcp/2 / server | 833 | 285246 | 0 | 162800 | 165233 | 38988762 | 165199 / 38988446 |
| quickfix-native/fragmentation/tcp/3 / client | 1864 | 5813462 | 0 | 24216 | 1076342 | 147638383 | 827907 / 81981046 |
| quickfix-native/fragmentation/tcp/3 / server | 833 | 285246 | 0 | 159639 | 165233 | 38988734 | 165199 / 38988418 |
| quickfix-native/replay/tcp/1 / client | 1864 | 5813462 | 0 | 28620 | 976677 | 29358677 | 709139 / 8842846 |
| quickfix-native/replay/tcp/1 / server | 832 | 284990 | 0 | 54458 | 152927 | 1869993 | 152893 / 1869677 |
| quickfix-native/replay/tcp/2 / client | 1864 | 5813462 | 0 | 28620 | 974965 | 29450879 | 707889 / 8831515 |
| quickfix-native/replay/tcp/2 / server | 831 | 284478 | 0 | 54386 | 152684 | 1866572 | 152650 / 1866256 |
| quickfix-native/replay/tcp/3 / client | 1864 | 5813462 | 0 | 28620 | 976687 | 29403534 | 709147 / 8842996 |
| quickfix-native/replay/tcp/3 / server | 832 | 284990 | 0 | 54469 | 152927 | 1870051 | 152893 / 1869735 |
| quickfix-native/overload/tcp/1 / client | 1864 | 5813462 | 0 | 28614 | 970383 | 29338592 | 704512 / 8801253 |
| quickfix-native/overload/tcp/1 / server | 832 | 284990 | 0 | 54241 | 152030 | 1857283 | 151996 / 1856967 |
| quickfix-native/overload/tcp/2 / client | 1864 | 5813462 | 0 | 28614 | 970375 | 29313156 | 704502 / 8800999 |
| quickfix-native/overload/tcp/2 / server | 831 | 284734 | 0 | 54054 | 152027 | 1857215 | 151993 / 1856899 |
| quickfix-native/overload/tcp/3 / client | 1864 | 5813462 | 0 | 28614 | 970383 | 29267212 | 704512 / 8801409 |
| quickfix-native/overload/tcp/3 / server | 831 | 284734 | 0 | 54049 | 152027 | 1857317 | 151993 / 1857001 |
| quickfix-native/scalar/tls/1 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551361 | 742912 / 9930374 |
| quickfix-native/scalar/tls/1 / server | 11313 | 981951 | 0 | 64890 | 173081 | 3094247 | 152003 / 1857043 |
| quickfix-native/scalar/tls/2 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551474 | 742912 / 9930431 |
| quickfix-native/scalar/tls/2 / server | 11313 | 981951 | 0 | 64890 | 173043 | 3088104 | 152002 / 1857033 |
| quickfix-native/scalar/tls/3 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551505 | 742912 / 9930446 |
| quickfix-native/scalar/tls/3 / server | 11313 | 981951 | 0 | 64890 | 173099 | 3095211 | 152002 / 1857023 |
| quickfix-native/groups/tls/1 / client | 59317 | 9952084 | 0 | 387400 | 7573536 | 69058804 | 5808501 / 42487098 |
| quickfix-native/groups/tls/1 / server | 33321 | 209828383 | 0 | 210246 | 245715 | 455657480 | 224621 / 454423620 |
| quickfix-native/groups/tls/2 / client | 59317 | 9952084 | 0 | 387400 | 7572888 | 69039390 | 5807853 / 42467888 |
| quickfix-native/groups/tls/2 / server | 33321 | 209828383 | 0 | 210246 | 245683 | 455654840 | 224621 / 454423632 |
| quickfix-native/groups/tls/3 / client | 59317 | 9952084 | 0 | 387400 | 7571466 | 68997816 | 5806431 / 42426245 |
| quickfix-native/groups/tls/3 / server | 33321 | 209828383 | 0 | 210246 | 245747 | 455658851 | 224620 / 454423580 |
| quickfix-native/binary/tls/1 / client | 59311 | 9949780 | 0 | 314752 | 1130950 | 160381073 | 844139 / 82515231 |
| quickfix-native/binary/tls/1 / server | 11319 | 1019455 | 0 | 75916 | 186305 | 58314579 | 165207 / 38988460 |
| quickfix-native/binary/tls/2 / client | 59311 | 9949780 | 0 | 314656 | 1130923 | 160380278 | 844112 / 82514450 |
| quickfix-native/binary/tls/2 / server | 11321 | 1028959 | 0 | 76046 | 186229 | 58301859 | 165207 / 38988481 |
| quickfix-native/binary/tls/3 / client | 59311 | 9949780 | 0 | 314752 | 1130950 | 160380982 | 844139 / 82515189 |
| quickfix-native/binary/tls/3 / server | 11320 | 1019711 | 0 | 75963 | 186304 | 58312685 | 165212 / 38988526 |
| quickfix-native/fragmentation/tls/1 / client | 59339 | 9983887 | 0 | 314734 | 1130941 | 160380647 | 844112 / 82514213 |
| quickfix-native/fragmentation/tls/1 / server | 11475 | 1026799 | 0 | 223537 | 186243 | 58303761 | 165210 / 38988382 |
| quickfix-native/fragmentation/tls/2 / client | 59339 | 9983887 | 0 | 314734 | 1130941 | 160380694 | 844112 / 82514248 |
| quickfix-native/fragmentation/tls/2 / server | 11474 | 1017551 | 0 | 223537 | 186317 | 58314024 | 165210 / 38988408 |
| quickfix-native/fragmentation/tls/3 / client | 59339 | 9983887 | 0 | 314734 | 1130941 | 160381240 | 844112 / 82514536 |
| quickfix-native/fragmentation/tls/3 / server | 11474 | 1017551 | 0 | 223536 | 186279 | 58309745 | 165210 / 38988523 |
| quickfix-native/replay/tls/1 / client | 59374 | 9985287 | 0 | 320198 | 1055476 | 15622061 | 747383 / 9974812 |
| quickfix-native/replay/tls/1 / server | 11471 | 998703 | 0 | 65649 | 174058 | 3113674 | 152824 / 1868590 |
| quickfix-native/replay/tls/2 / client | 59375 | 9985327 | 0 | 320232 | 1055685 | 15624636 | 747536 / 9976402 |
| quickfix-native/replay/tls/2 / server | 11471 | 998703 | 0 | 65832 | 174056 | 3106988 | 152851 / 1868995 |
| quickfix-native/replay/tls/3 / client | 59368 | 9985047 | 0 | 319994 | 1054231 | 15608691 | 746474 / 9966308 |
| quickfix-native/replay/tls/3 / server | 11471 | 998703 | 0 | 65580 | 173799 | 3100224 | 152662 / 1866393 |
| quickfix-native/overload/tls/1 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551553 | 742912 / 9930470 |
| quickfix-native/overload/tls/1 / server | 11313 | 981951 | 0 | 64890 | 173061 | 3090951 | 152002 / 1857051 |
| quickfix-native/overload/tls/2 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551678 | 742912 / 9930533 |
| quickfix-native/overload/tls/2 / server | 11314 | 982207 | 0 | 65144 | 173084 | 3091882 | 152006 / 1857129 |
| quickfix-native/overload/tls/3 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551501 | 742912 / 9930443 |
| quickfix-native/overload/tls/3 / server | 11313 | 981951 | 0 | 64890 | 173079 | 3088008 | 152001 / 1857037 |
| quickfix-quickfix/scalar/tcp/1 / client | 1864 | 5813462 | 0 | 28611 | 829844 | 28614317 | 695574 / 8783963 |
| quickfix-quickfix/scalar/tcp/1 / server | 1863 | 5813374 | 0 | 55010 | 793595 | 10814431 | 615289 / 8325907 |
| quickfix-quickfix/scalar/tcp/2 / client | 1864 | 5813462 | 0 | 28611 | 829848 | 28678014 | 695576 / 8784006 |
| quickfix-quickfix/scalar/tcp/2 / server | 1863 | 5813374 | 0 | 55010 | 793592 | 10910973 | 615289 / 8325907 |
| quickfix-quickfix/scalar/tcp/3 / client | 1864 | 5813462 | 0 | 28611 | 829885 | 28572627 | 695612 / 8785025 |
| quickfix-quickfix/scalar/tcp/3 / server | 1863 | 5813374 | 0 | 55010 | 793593 | 10834267 | 615289 / 8325907 |
| quickfix-quickfix/groups/tcp/1 / client | 1867 | 5814230 | 0 | 96957 | 7383580 | 55039115 | 5790818 / 42213093 |
| quickfix-quickfix/groups/tcp/1 / server | 1866 | 5814142 | 0 | 347756 | 3132462 | 33672497 | 2951872 / 20574209 |
| quickfix-quickfix/groups/tcp/2 / client | 1867 | 5814230 | 0 | 96957 | 7371435 | 54955439 | 5778673 / 41856908 |
| quickfix-quickfix/groups/tcp/2 / server | 1866 | 5814142 | 0 | 347756 | 3133382 | 33596752 | 2952809 / 20602125 |
| quickfix-quickfix/groups/tcp/3 / client | 1867 | 5814230 | 0 | 96957 | 7387168 | 55014494 | 5794405 / 42318380 |
| quickfix-quickfix/groups/tcp/3 / server | 1866 | 5814142 | 0 | 347756 | 3133432 | 33660246 | 2952852 / 20603209 |
| quickfix-quickfix/binary/tcp/1 / client | 1864 | 5813462 | 0 | 24213 | 996334 | 147293330 | 820241 / 82032187 |
| quickfix-quickfix/binary/tcp/1 / server | 1863 | 5813374 | 0 | 52812 | 829191 | 111259942 | 637487 / 71550299 |
| quickfix-quickfix/binary/tcp/2 / client | 1864 | 5813462 | 0 | 24213 | 994874 | 147370378 | 818913 / 81996584 |
| quickfix-quickfix/binary/tcp/2 / server | 1863 | 5813374 | 0 | 52812 | 829283 | 111668317 | 637533 / 71550483 |
| quickfix-quickfix/binary/tcp/3 / client | 1864 | 5813462 | 0 | 24213 | 995865 | 146104337 | 820079 / 82035187 |
| quickfix-quickfix/binary/tcp/3 / server | 1863 | 5813374 | 0 | 52812 | 829304 | 111688457 | 637543 / 71550523 |
| quickfix-quickfix/fragmentation/tcp/1 / client | 1864 | 5813462 | 0 | 24213 | 994918 | 147333626 | 818985 / 81999380 |
| quickfix-quickfix/fragmentation/tcp/1 / server | 1863 | 5813374 | 0 | 52812 | 915895 | 110035679 | 680875 / 71725675 |
| quickfix-quickfix/fragmentation/tcp/2 / client | 1864 | 5813462 | 0 | 24213 | 994960 | 147361853 | 819033 / 82000907 |
| quickfix-quickfix/fragmentation/tcp/2 / server | 1863 | 5813374 | 0 | 52812 | 910607 | 110091390 | 678228 / 71714859 |
| quickfix-quickfix/fragmentation/tcp/3 / client | 1864 | 5813462 | 0 | 24213 | 994958 | 147366270 | 819026 / 82000651 |
| quickfix-quickfix/fragmentation/tcp/3 / server | 1863 | 5813374 | 0 | 52812 | 929921 | 110075014 | 687885 / 71753487 |
| quickfix-quickfix/replay/tcp/1 / client | 1864 | 5813462 | 0 | 28614 | 839317 | 28915384 | 703849 / 8856813 |
| quickfix-quickfix/replay/tcp/1 / server | 1866 | 5814142 | 0 | 55023 | 802754 | 11622546 | 621866 / 8394390 |
| quickfix-quickfix/replay/tcp/2 / client | 1864 | 5813462 | 0 | 28614 | 834079 | 28839804 | 699262 / 8816444 |
| quickfix-quickfix/replay/tcp/2 / server | 1865 | 5813886 | 0 | 55020 | 797749 | 10696554 | 618276 / 8357020 |
| quickfix-quickfix/replay/tcp/3 / client | 1864 | 5813462 | 0 | 28614 | 837721 | 28841743 | 702449 / 8844320 |
| quickfix-quickfix/replay/tcp/3 / server | 1866 | 5814142 | 0 | 55023 | 801231 | 11501573 | 620772 / 8382895 |
| quickfix-quickfix/overload/tcp/1 / client | 1864 | 5813462 | 0 | 28611 | 832313 | 25153027 | 698073 / 8857857 |
| quickfix-quickfix/overload/tcp/1 / server | 1863 | 5813374 | 0 | 55010 | 793594 | 11157023 | 615289 / 8325907 |
| quickfix-quickfix/overload/tcp/2 / client | 1864 | 5813462 | 0 | 28611 | 831167 | 26896275 | 696911 / 8823524 |
| quickfix-quickfix/overload/tcp/2 / server | 1863 | 5813374 | 0 | 55010 | 793593 | 10638875 | 615289 / 8325907 |
| quickfix-quickfix/overload/tcp/3 / client | 1864 | 5813462 | 0 | 28611 | 829861 | 28599772 | 695589 / 8784282 |
| quickfix-quickfix/overload/tcp/3 / server | 1863 | 5813374 | 0 | 55010 | 793595 | 10920052 | 615289 / 8325907 |
| quickfix-quickfix/scalar/tls/1 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935198 | 734006 / 9913900 |
| quickfix-quickfix/scalar/tls/1 / server | 31757 | 7539264 | 0 | 308965 | 824750 | 12238703 | 615326 / 8326958 |
| quickfix-quickfix/scalar/tls/2 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935198 | 734006 / 9913900 |
| quickfix-quickfix/scalar/tls/2 / server | 31757 | 7539265 | 0 | 308965 | 824725 | 12234608 | 615326 / 8326958 |
| quickfix-quickfix/scalar/tls/3 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935198 | 734006 / 9913900 |
| quickfix-quickfix/scalar/tls/3 / server | 31757 | 7539263 | 0 | 308965 | 824691 | 12228318 | 615326 / 8326958 |
| quickfix-quickfix/groups/tls/1 / client | 59341 | 9986031 | 0 | 387404 | 7428274 | 68302484 | 5794825 / 42330586 |
| quickfix-quickfix/groups/tls/1 / server | 31762 | 7541055 | 0 | 601711 | 3164942 | 45373328 | 2953328 / 20619012 |
| quickfix-quickfix/groups/tls/2 / client | 59341 | 9986031 | 0 | 387404 | 7430218 | 68359508 | 5796769 / 42387610 |
| quickfix-quickfix/groups/tls/2 / server | 31762 | 7541057 | 0 | 601711 | 3164802 | 45368218 | 2953193 / 20615052 |
| quickfix-quickfix/groups/tls/3 / client | 59341 | 9986031 | 0 | 387404 | 7432234 | 68418644 | 5798785 / 42446746 |
| quickfix-quickfix/groups/tls/3 / server | 31762 | 7541055 | 0 | 601711 | 3167247 | 45436400 | 2955668 / 20687652 |
| quickfix-quickfix/binary/tls/1 / client | 59335 | 9983727 | 0 | 314788 | 1049562 | 159958059 | 835242 / 82534321 |
| quickfix-quickfix/binary/tls/1 / server | 31757 | 7539264 | 0 | 306767 | 859945 | 138746665 | 637326 / 71550558 |
| quickfix-quickfix/binary/tls/2 / client | 59335 | 9983727 | 0 | 314692 | 1049535 | 159957267 | 835215 / 82533529 |
| quickfix-quickfix/binary/tls/2 / server | 31757 | 7539264 | 0 | 306765 | 859941 | 138744449 | 637326 / 71550558 |
| quickfix-quickfix/binary/tls/3 / client | 59335 | 9983727 | 0 | 314756 | 1049553 | 159957795 | 835233 / 82534057 |
| quickfix-quickfix/binary/tls/3 / server | 31757 | 7539264 | 0 | 306767 | 859910 | 138739753 | 637326 / 71550558 |
| quickfix-quickfix/fragmentation/tls/1 / client | 59335 | 9983727 | 0 | 314660 | 1049526 | 159957047 | 835206 / 82533265 |
| quickfix-quickfix/fragmentation/tls/1 / server | 177000 | 13355959 | 0 | 5243666 | 1731107 | 143976075 | 782526 / 72131358 |
| quickfix-quickfix/fragmentation/tls/2 / client | 59335 | 9983727 | 0 | 314660 | 1049526 | 159957047 | 835206 / 82533265 |
| quickfix-quickfix/fragmentation/tls/2 / server | 177000 | 13355960 | 0 | 5243666 | 1731125 | 143979004 | 782526 / 72131358 |
| quickfix-quickfix/fragmentation/tls/3 / client | 59335 | 9983727 | 0 | 314660 | 1049526 | 159957047 | 835206 / 82533265 |
| quickfix-quickfix/fragmentation/tls/3 / server | 177000 | 13355960 | 0 | 5243666 | 1731182 | 143988676 | 782526 / 72131358 |
| quickfix-quickfix/replay/tls/1 / client | 59389 | 9985887 | 0 | 320832 | 917693 | 15048017 | 741596 / 9989534 |
| quickfix-quickfix/replay/tls/1 / server | 31962 | 7556032 | 0 | 311035 | 832855 | 12325719 | 621025 / 8386174 |
| quickfix-quickfix/replay/tls/2 / client | 59376 | 9985367 | 0 | 320390 | 915471 | 15019594 | 739682 / 9970470 |
| quickfix-quickfix/replay/tls/2 / server | 31923 | 7554472 | 0 | 310554 | 830839 | 12302017 | 619618 / 8371556 |
| quickfix-quickfix/replay/tls/3 / client | 59356 | 9984567 | 0 | 319710 | 912041 | 14976004 | 736732 / 9941231 |
| quickfix-quickfix/replay/tls/3 / server | 31861 | 7551304 | 0 | 309811 | 827753 | 12270893 | 617445 / 8349115 |
| quickfix-quickfix/overload/tls/1 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935198 | 734006 / 9913900 |
| quickfix-quickfix/overload/tls/1 / server | 31757 | 7539265 | 0 | 308963 | 824724 | 12235440 | 615326 / 8326958 |
| quickfix-quickfix/overload/tls/2 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935198 | 734006 / 9913900 |
| quickfix-quickfix/overload/tls/2 / server | 31757 | 7539265 | 0 | 308965 | 824704 | 12234400 | 615326 / 8326958 |
| quickfix-quickfix/overload/tls/3 / client | 59335 | 9983727 | 0 | 319058 | 908859 | 14935247 | 734010 / 9913949 |
| quickfix-quickfix/overload/tls/3 / server | 31757 | 7539263 | 0 | 308933 | 824697 | 12232046 | 615326 / 8326958 |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |
| native-native/scalar/tcp/1 / client | 26517 | 3124512 |
| native-native/scalar/tcp/1 / server | 39703 | 6218432 |
| native-native/scalar/tcp/1/audit-diagnostic / client | 26517 | 3124512 |
| native-native/scalar/tcp/1/audit-diagnostic / server | 39703 | 6218432 |
| native-native/scalar/tcp/2 / client | 26524 | 3124512 |
| native-native/scalar/tcp/2 / server | 39704 | 6218432 |
| native-native/scalar/tcp/2/audit-diagnostic / client | 26520 | 3124512 |
| native-native/scalar/tcp/2/audit-diagnostic / server | 39703 | 6218432 |
| native-native/scalar/tcp/3 / client | 26516 | 3124512 |
| native-native/scalar/tcp/3 / server | 39706 | 6218432 |
| native-native/scalar/tcp/3/audit-diagnostic / client | 26516 | 3124512 |
| native-native/scalar/tcp/3/audit-diagnostic / server | 39703 | 6218432 |
| native-native/groups/tcp/1 / client | 35457 | 39206176 |
| native-native/groups/tcp/1 / server | 176241 | 6255296 |
| native-native/groups/tcp/1/audit-diagnostic / client | 35456 | 39206176 |
| native-native/groups/tcp/1/audit-diagnostic / server | 176243 | 6255296 |
| native-native/groups/tcp/2 / client | 35456 | 39206176 |
| native-native/groups/tcp/2 / server | 176243 | 6255296 |
| native-native/groups/tcp/2/audit-diagnostic / client | 35456 | 39206176 |
| native-native/groups/tcp/2/audit-diagnostic / server | 176243 | 6255296 |
| native-native/groups/tcp/3 / client | 35456 | 39206176 |
| native-native/groups/tcp/3 / server | 176243 | 6255296 |
| native-native/groups/tcp/3/audit-diagnostic / client | 35456 | 39206176 |
| native-native/groups/tcp/3/audit-diagnostic / server | 176243 | 6255296 |
| native-native/binary/tcp/1 / client | 56568 | 39169312 |
| native-native/binary/tcp/1 / server | 61639 | 67544896 |
| native-native/binary/tcp/1/audit-diagnostic / client | 57146 | 39169312 |
| native-native/binary/tcp/1/audit-diagnostic / server | 61660 | 67544896 |
| native-native/binary/tcp/2 / client | 56554 | 39169312 |
| native-native/binary/tcp/2 / server | 61634 | 67544896 |
| native-native/binary/tcp/2/audit-diagnostic / client | 57008 | 39169312 |
| native-native/binary/tcp/2/audit-diagnostic / server | 61673 | 67544896 |
| native-native/binary/tcp/3 / client | 56981 | 39169312 |
| native-native/binary/tcp/3 / server | 61642 | 67544896 |
| native-native/binary/tcp/3/audit-diagnostic / client | 57056 | 39169312 |
| native-native/binary/tcp/3/audit-diagnostic / server | 61640 | 67544896 |
| native-native/fragmentation/tcp/1 / client | 54088 | 39169312 |
| native-native/fragmentation/tcp/1 / server | 145481 | 67544896 |
| native-native/fragmentation/tcp/1/audit-diagnostic / client | 54600 | 39169312 |
| native-native/fragmentation/tcp/1/audit-diagnostic / server | 149868 | 67544896 |
| native-native/fragmentation/tcp/2 / client | 54213 | 39169312 |
| native-native/fragmentation/tcp/2 / server | 151639 | 67544896 |
| native-native/fragmentation/tcp/2/audit-diagnostic / client | 54029 | 39169312 |
| native-native/fragmentation/tcp/2/audit-diagnostic / server | 148656 | 67544896 |
| native-native/fragmentation/tcp/3 / client | 54043 | 39169312 |
| native-native/fragmentation/tcp/3 / server | 153565 | 67544896 |
| native-native/fragmentation/tcp/3/audit-diagnostic / client | 54128 | 39169312 |
| native-native/fragmentation/tcp/3/audit-diagnostic / server | 155070 | 67544896 |
| native-native/replay/tcp/1 / client | 26641 | 3124512 |
| native-native/replay/tcp/1 / server | 39729 | 6218432 |
| native-native/replay/tcp/1/audit-diagnostic / client | 26632 | 3124512 |
| native-native/replay/tcp/1/audit-diagnostic / server | 39729 | 6218432 |
| native-native/replay/tcp/2 / client | 26634 | 3124512 |
| native-native/replay/tcp/2 / server | 39733 | 6218432 |
| native-native/replay/tcp/2/audit-diagnostic / client | 26624 | 3124512 |
| native-native/replay/tcp/2/audit-diagnostic / server | 39737 | 6218432 |
| native-native/replay/tcp/3 / client | 26616 | 3124512 |
| native-native/replay/tcp/3 / server | 39729 | 6218432 |
| native-native/replay/tcp/3/audit-diagnostic / client | 26640 | 3124512 |
| native-native/replay/tcp/3/audit-diagnostic / server | 39729 | 6218432 |
| native-native/overload/tcp/1 / client | 26520 | 3124512 |
| native-native/overload/tcp/1 / server | 39703 | 6218432 |
| native-native/overload/tcp/1/audit-diagnostic / client | 26516 | 3124512 |
| native-native/overload/tcp/1/audit-diagnostic / server | 39703 | 6218432 |
| native-native/overload/tcp/2 / client | 26516 | 3124512 |
| native-native/overload/tcp/2 / server | 39703 | 6218432 |
| native-native/overload/tcp/2/audit-diagnostic / client | 26517 | 3124512 |
| native-native/overload/tcp/2/audit-diagnostic / server | 39703 | 6218432 |
| native-native/overload/tcp/3 / client | 26522 | 3124512 |
| native-native/overload/tcp/3 / server | 39703 | 6218432 |
| native-native/overload/tcp/3/audit-diagnostic / client | 26516 | 3124512 |
| native-native/overload/tcp/3/audit-diagnostic / server | 39703 | 6218432 |
| native-native/scalar/tls/1 / client | 28752 | 3125152 |
| native-native/scalar/tls/1 / server | 44126 | 6219776 |
| native-native/scalar/tls/1/audit-diagnostic / client | 28752 | 3125152 |
| native-native/scalar/tls/1/audit-diagnostic / server | 44126 | 6219776 |
| native-native/scalar/tls/2 / client | 28752 | 3125152 |
| native-native/scalar/tls/2 / server | 44125 | 6219776 |
| native-native/scalar/tls/2/audit-diagnostic / client | 28752 | 3125152 |
| native-native/scalar/tls/2/audit-diagnostic / server | 44125 | 6219776 |
| native-native/scalar/tls/3 / client | 28752 | 3125152 |
| native-native/scalar/tls/3 / server | 44125 | 6219776 |
| native-native/scalar/tls/3/audit-diagnostic / client | 28752 | 3125152 |
| native-native/scalar/tls/3/audit-diagnostic / server | 44126 | 6219776 |
| native-native/groups/tls/1 / client | 37692 | 39206816 |
| native-native/groups/tls/1 / server | 169727 | 6256640 |
| native-native/groups/tls/1/audit-diagnostic / client | 37692 | 39206816 |
| native-native/groups/tls/1/audit-diagnostic / server | 169667 | 6256640 |
| native-native/groups/tls/2 / client | 37692 | 39206816 |
| native-native/groups/tls/2 / server | 169787 | 6256640 |
| native-native/groups/tls/2/audit-diagnostic / client | 37692 | 39206816 |
| native-native/groups/tls/2/audit-diagnostic / server | 169666 | 6256640 |
| native-native/groups/tls/3 / client | 37692 | 39206816 |
| native-native/groups/tls/3 / server | 169687 | 6256640 |
| native-native/groups/tls/3/audit-diagnostic / client | 37692 | 39206816 |
| native-native/groups/tls/3/audit-diagnostic / server | 169668 | 6256640 |
| native-native/binary/tls/1 / client | 38125 | 39169952 |
| native-native/binary/tls/1 / server | 55186 | 67546240 |
| native-native/binary/tls/1/audit-diagnostic / client | 37654 | 39169952 |
| native-native/binary/tls/1/audit-diagnostic / server | 55141 | 67546240 |
| native-native/binary/tls/2 / client | 38081 | 39169952 |
| native-native/binary/tls/2 / server | 55175 | 67546240 |
| native-native/binary/tls/2/audit-diagnostic / client | 37733 | 39169952 |
| native-native/binary/tls/2/audit-diagnostic / server | 55147 | 67546240 |
| native-native/binary/tls/3 / client | 37977 | 39169952 |
| native-native/binary/tls/3 / server | 55177 | 67546240 |
| native-native/binary/tls/3/audit-diagnostic / client | 37809 | 39169952 |
| native-native/binary/tls/3/audit-diagnostic / server | 55146 | 67546240 |
| native-native/fragmentation/tls/1 / client | 41611 | 39170208 |
| native-native/fragmentation/tls/1 / server | 202530 | 67546240 |
| native-native/fragmentation/tls/1/audit-diagnostic / client | 41898 | 39170208 |
| native-native/fragmentation/tls/1/audit-diagnostic / server | 202530 | 67546240 |
| native-native/fragmentation/tls/2 / client | 41917 | 39170208 |
| native-native/fragmentation/tls/2 / server | 202530 | 67546240 |
| native-native/fragmentation/tls/2/audit-diagnostic / client | 41877 | 39170208 |
| native-native/fragmentation/tls/2/audit-diagnostic / server | 202530 | 67546240 |
| native-native/fragmentation/tls/3 / client | 41918 | 39170208 |
| native-native/fragmentation/tls/3 / server | 202530 | 67546240 |
| native-native/fragmentation/tls/3/audit-diagnostic / client | 41895 | 39170208 |
| native-native/fragmentation/tls/3/audit-diagnostic / server | 202530 | 67546240 |
| native-native/replay/tls/1 / client | 28855 | 3125408 |
| native-native/replay/tls/1 / server | 44157 | 6219776 |
| native-native/replay/tls/1/audit-diagnostic / client | 28888 | 3125408 |
| native-native/replay/tls/1/audit-diagnostic / server | 44157 | 6219776 |
| native-native/replay/tls/2 / client | 28859 | 3125408 |
| native-native/replay/tls/2 / server | 44157 | 6219776 |
| native-native/replay/tls/2/audit-diagnostic / client | 28883 | 3125408 |
| native-native/replay/tls/2/audit-diagnostic / server | 44157 | 6219776 |
| native-native/replay/tls/3 / client | 28871 | 3125408 |
| native-native/replay/tls/3 / server | 44157 | 6219776 |
| native-native/replay/tls/3/audit-diagnostic / client | 28871 | 3125408 |
| native-native/replay/tls/3/audit-diagnostic / server | 44157 | 6219776 |
| native-native/overload/tls/1 / client | 28752 | 3125152 |
| native-native/overload/tls/1 / server | 44125 | 6219776 |
| native-native/overload/tls/1/audit-diagnostic / client | 28752 | 3125152 |
| native-native/overload/tls/1/audit-diagnostic / server | 44125 | 6219776 |
| native-native/overload/tls/2 / client | 28752 | 3125152 |
| native-native/overload/tls/2 / server | 44126 | 6219776 |
| native-native/overload/tls/2/audit-diagnostic / client | 28752 | 3125152 |
| native-native/overload/tls/2/audit-diagnostic / server | 44125 | 6219776 |
| native-native/overload/tls/3 / client | 28752 | 3125152 |
| native-native/overload/tls/3 / server | 44126 | 6219776 |
| native-native/overload/tls/3/audit-diagnostic / client | 28752 | 3125152 |
| native-native/overload/tls/3/audit-diagnostic / server | 44126 | 6219776 |
| native-quickfix/scalar/tcp/1 / client | 26510 | 3124512 |
| native-quickfix/scalar/tcp/1 / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/1/audit-diagnostic / client | 26517 | 3124512 |
| native-quickfix/scalar/tcp/1/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/2 / client | 26508 | 3124512 |
| native-quickfix/scalar/tcp/2 / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/2/audit-diagnostic / client | 26510 | 3124512 |
| native-quickfix/scalar/tcp/2/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/3 / client | 26509 | 3124512 |
| native-quickfix/scalar/tcp/3 / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/3/audit-diagnostic / client | 26512 | 3124512 |
| native-quickfix/scalar/tcp/3/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/groups/tcp/1 / client | 35449 | 39206176 |
| native-quickfix/groups/tcp/1 / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/1/audit-diagnostic / client | 35448 | 39206176 |
| native-quickfix/groups/tcp/1/audit-diagnostic / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/2 / client | 35449 | 39206176 |
| native-quickfix/groups/tcp/2 / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/2/audit-diagnostic / client | 35448 | 39206176 |
| native-quickfix/groups/tcp/2/audit-diagnostic / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/3 / client | 35451 | 39206176 |
| native-quickfix/groups/tcp/3 / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/3/audit-diagnostic / client | 35452 | 39206176 |
| native-quickfix/groups/tcp/3/audit-diagnostic / server | 345603 | 2297408 |
| native-quickfix/binary/tcp/1 / client | 57168 | 39169312 |
| native-quickfix/binary/tcp/1 / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/1/audit-diagnostic / client | 56715 | 39169312 |
| native-quickfix/binary/tcp/1/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/2 / client | 57246 | 39169312 |
| native-quickfix/binary/tcp/2 / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/2/audit-diagnostic / client | 56148 | 39169312 |
| native-quickfix/binary/tcp/2/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/3 / client | 56436 | 39169312 |
| native-quickfix/binary/tcp/3 / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/3/audit-diagnostic / client | 57300 | 39169312 |
| native-quickfix/binary/tcp/3/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/1 / client | 54515 | 39169312 |
| native-quickfix/fragmentation/tcp/1 / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/1/audit-diagnostic / client | 53708 | 39169312 |
| native-quickfix/fragmentation/tcp/1/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/2 / client | 54071 | 39169312 |
| native-quickfix/fragmentation/tcp/2 / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/2/audit-diagnostic / client | 53964 | 39169312 |
| native-quickfix/fragmentation/tcp/2/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/3 / client | 53727 | 39169312 |
| native-quickfix/fragmentation/tcp/3 / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/3/audit-diagnostic / client | 54025 | 39169312 |
| native-quickfix/fragmentation/tcp/3/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/replay/tcp/1 / client | 26606 | 3124512 |
| native-quickfix/replay/tcp/1 / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/1/audit-diagnostic / client | 26610 | 3124512 |
| native-quickfix/replay/tcp/1/audit-diagnostic / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/2 / client | 26615 | 3124512 |
| native-quickfix/replay/tcp/2 / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/2/audit-diagnostic / client | 26623 | 3124512 |
| native-quickfix/replay/tcp/2/audit-diagnostic / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/3 / client | 26594 | 3124512 |
| native-quickfix/replay/tcp/3 / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/3/audit-diagnostic / client | 26608 | 3124512 |
| native-quickfix/replay/tcp/3/audit-diagnostic / server | 52867 | 2260544 |
| native-quickfix/overload/tcp/1 / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/1 / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/1/audit-diagnostic / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/1/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/2 / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/2 / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/2/audit-diagnostic / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/2/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/3 / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/3 / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/3/audit-diagnostic / client | 26515 | 3124512 |
| native-quickfix/overload/tcp/3/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/scalar/tls/1 / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/1 / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/1/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/1/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/2 / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/2 / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/2/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/2/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/3 / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/3 / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/3/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/3/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/groups/tls/1 / client | 37688 | 39207072 |
| native-quickfix/groups/tls/1 / server | 345610 | 2297792 |
| native-quickfix/groups/tls/1/audit-diagnostic / client | 37686 | 39207072 |
| native-quickfix/groups/tls/1/audit-diagnostic / server | 345610 | 2297792 |
| native-quickfix/groups/tls/2 / client | 37688 | 39207072 |
| native-quickfix/groups/tls/2 / server | 345610 | 2297792 |
| native-quickfix/groups/tls/2/audit-diagnostic / client | 37688 | 39207072 |
| native-quickfix/groups/tls/2/audit-diagnostic / server | 345610 | 2297792 |
| native-quickfix/groups/tls/3 / client | 37688 | 39207072 |
| native-quickfix/groups/tls/3 / server | 345610 | 2297792 |
| native-quickfix/groups/tls/3/audit-diagnostic / client | 37688 | 39207072 |
| native-quickfix/groups/tls/3/audit-diagnostic / server | 345610 | 2297792 |
| native-quickfix/binary/tls/1 / client | 37724 | 39170208 |
| native-quickfix/binary/tls/1 / server | 50672 | 1212608 |
| native-quickfix/binary/tls/1/audit-diagnostic / client | 38078 | 39170208 |
| native-quickfix/binary/tls/1/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/binary/tls/2 / client | 37763 | 39170208 |
| native-quickfix/binary/tls/2 / server | 50672 | 1212608 |
| native-quickfix/binary/tls/2/audit-diagnostic / client | 37701 | 39170208 |
| native-quickfix/binary/tls/2/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/binary/tls/3 / client | 37761 | 39170208 |
| native-quickfix/binary/tls/3 / server | 50672 | 1212608 |
| native-quickfix/binary/tls/3/audit-diagnostic / client | 37640 | 39170208 |
| native-quickfix/binary/tls/3/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/1 / client | 41375 | 39170208 |
| native-quickfix/fragmentation/tls/1 / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/1/audit-diagnostic / client | 38191 | 39170208 |
| native-quickfix/fragmentation/tls/1/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/2 / client | 41894 | 39170208 |
| native-quickfix/fragmentation/tls/2 / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/2/audit-diagnostic / client | 37824 | 39170208 |
| native-quickfix/fragmentation/tls/2/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/3 / client | 41072 | 39170208 |
| native-quickfix/fragmentation/tls/3 / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/3/audit-diagnostic / client | 37936 | 39170208 |
| native-quickfix/fragmentation/tls/3/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/replay/tls/1 / client | 28823 | 3125408 |
| native-quickfix/replay/tls/1 / server | 52874 | 2260928 |
| native-quickfix/replay/tls/1/audit-diagnostic / client | 28848 | 3125408 |
| native-quickfix/replay/tls/1/audit-diagnostic / server | 52874 | 2260928 |
| native-quickfix/replay/tls/2 / client | 28863 | 3125408 |
| native-quickfix/replay/tls/2 / server | 52874 | 2260928 |
| native-quickfix/replay/tls/2/audit-diagnostic / client | 28847 | 3125408 |
| native-quickfix/replay/tls/2/audit-diagnostic / server | 52874 | 2260928 |
| native-quickfix/replay/tls/3 / client | 28812 | 3125408 |
| native-quickfix/replay/tls/3 / server | 52874 | 2260928 |
| native-quickfix/replay/tls/3/audit-diagnostic / client | 28841 | 3125408 |
| native-quickfix/replay/tls/3/audit-diagnostic / server | 52874 | 2260928 |
| native-quickfix/overload/tls/1 / client | 28748 | 3125408 |
| native-quickfix/overload/tls/1 / server | 52870 | 2260928 |
| native-quickfix/overload/tls/1/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/overload/tls/1/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/overload/tls/2 / client | 28748 | 3125408 |
| native-quickfix/overload/tls/2 / server | 52870 | 2260928 |
| native-quickfix/overload/tls/2/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/overload/tls/2/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/overload/tls/3 / client | 28748 | 3125408 |
| native-quickfix/overload/tls/3 / server | 52870 | 2260928 |
| native-quickfix/overload/tls/3/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/overload/tls/3/audit-diagnostic / server | 52870 | 2260928 |
| quickfix-native/scalar/tcp/1 / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/1 / server | 39695 | 6218432 |
| quickfix-native/scalar/tcp/1/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/1/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/scalar/tcp/2 / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/2 / server | 39696 | 6218432 |
| quickfix-native/scalar/tcp/2/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/2/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/scalar/tcp/3 / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/3 / server | 39701 | 6218432 |
| quickfix-native/scalar/tcp/3/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/3/audit-diagnostic / server | 39933 | 6218432 |
| quickfix-native/groups/tcp/1 / client | 94804 | 463872 |
| quickfix-native/groups/tcp/1 / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/1/audit-diagnostic / client | 94804 | 463872 |
| quickfix-native/groups/tcp/1/audit-diagnostic / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/2 / client | 94804 | 463872 |
| quickfix-native/groups/tcp/2 / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/2/audit-diagnostic / client | 94804 | 463872 |
| quickfix-native/groups/tcp/2/audit-diagnostic / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/3 / client | 94804 | 463872 |
| quickfix-native/groups/tcp/3 / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/3/audit-diagnostic / client | 94804 | 463872 |
| quickfix-native/groups/tcp/3/audit-diagnostic / server | 176235 | 6255296 |
| quickfix-native/binary/tcp/1 / client | 22066 | 427008 |
| quickfix-native/binary/tcp/1 / server | 61610 | 67544896 |
| quickfix-native/binary/tcp/1/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/binary/tcp/1/audit-diagnostic / server | 61628 | 67544896 |
| quickfix-native/binary/tcp/2 / client | 22066 | 427008 |
| quickfix-native/binary/tcp/2 / server | 61694 | 67544896 |
| quickfix-native/binary/tcp/2/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/binary/tcp/2/audit-diagnostic / server | 61596 | 67544896 |
| quickfix-native/binary/tcp/3 / client | 22066 | 427008 |
| quickfix-native/binary/tcp/3 / server | 61375 | 67544896 |
| quickfix-native/binary/tcp/3/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/binary/tcp/3/audit-diagnostic / server | 61687 | 67544896 |
| quickfix-native/fragmentation/tcp/1 / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/1 / server | 149884 | 67544896 |
| quickfix-native/fragmentation/tcp/1/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/1/audit-diagnostic / server | 151017 | 67544896 |
| quickfix-native/fragmentation/tcp/2 / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/2 / server | 150493 | 67544896 |
| quickfix-native/fragmentation/tcp/2/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/2/audit-diagnostic / server | 148439 | 67544896 |
| quickfix-native/fragmentation/tcp/3 / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/3 / server | 147551 | 67544896 |
| quickfix-native/fragmentation/tcp/3/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/3/audit-diagnostic / server | 145276 | 67544896 |
| quickfix-native/replay/tcp/1 / client | 26470 | 990976 |
| quickfix-native/replay/tcp/1 / server | 40056 | 6218432 |
| quickfix-native/replay/tcp/1/audit-diagnostic / client | 26470 | 990976 |
| quickfix-native/replay/tcp/1/audit-diagnostic / server | 40035 | 6218432 |
| quickfix-native/replay/tcp/2 / client | 26470 | 990976 |
| quickfix-native/replay/tcp/2 / server | 40287 | 6218432 |
| quickfix-native/replay/tcp/2/audit-diagnostic / client | 26470 | 990976 |
| quickfix-native/replay/tcp/2/audit-diagnostic / server | 39981 | 6218432 |
| quickfix-native/replay/tcp/3 / client | 26470 | 990976 |
| quickfix-native/replay/tcp/3 / server | 40293 | 6218432 |
| quickfix-native/replay/tcp/3/audit-diagnostic / client | 26470 | 990976 |
| quickfix-native/replay/tcp/3/audit-diagnostic / server | 40046 | 6218432 |
| quickfix-native/overload/tcp/1 / client | 26464 | 990208 |
| quickfix-native/overload/tcp/1 / server | 39706 | 6218432 |
| quickfix-native/overload/tcp/1/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/overload/tcp/1/audit-diagnostic / server | 39885 | 6218432 |
| quickfix-native/overload/tcp/2 / client | 26464 | 990208 |
| quickfix-native/overload/tcp/2 / server | 39695 | 6218432 |
| quickfix-native/overload/tcp/2/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/overload/tcp/2/audit-diagnostic / server | 39700 | 6218432 |
| quickfix-native/overload/tcp/3 / client | 26464 | 990208 |
| quickfix-native/overload/tcp/3 / server | 39695 | 6218432 |
| quickfix-native/overload/tcp/3/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/overload/tcp/3/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/scalar/tls/1 / client | 26471 | 990592 |
| quickfix-native/scalar/tls/1 / server | 44368 | 6219776 |
| quickfix-native/scalar/tls/1/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/scalar/tls/1/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/2 / client | 26471 | 990592 |
| quickfix-native/scalar/tls/2 / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/2/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/scalar/tls/2/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/3 / client | 26471 | 990592 |
| quickfix-native/scalar/tls/3 / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/3/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/scalar/tls/3/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/groups/tls/1 / client | 94811 | 464256 |
| quickfix-native/groups/tls/1 / server | 169660 | 6256640 |
| quickfix-native/groups/tls/1/audit-diagnostic / client | 94811 | 464256 |
| quickfix-native/groups/tls/1/audit-diagnostic / server | 169658 | 6256640 |
| quickfix-native/groups/tls/2 / client | 94811 | 464256 |
| quickfix-native/groups/tls/2 / server | 169658 | 6256640 |
| quickfix-native/groups/tls/2/audit-diagnostic / client | 94811 | 464256 |
| quickfix-native/groups/tls/2/audit-diagnostic / server | 169658 | 6256640 |
| quickfix-native/groups/tls/3 / client | 94811 | 464256 |
| quickfix-native/groups/tls/3 / server | 169658 | 6256640 |
| quickfix-native/groups/tls/3/audit-diagnostic / client | 94811 | 464256 |
| quickfix-native/groups/tls/3/audit-diagnostic / server | 169658 | 6256640 |
| quickfix-native/binary/tls/1 / client | 22073 | 427392 |
| quickfix-native/binary/tls/1 / server | 55255 | 67546240 |
| quickfix-native/binary/tls/1/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/binary/tls/1/audit-diagnostic / server | 55133 | 67546240 |
| quickfix-native/binary/tls/2 / client | 22073 | 427392 |
| quickfix-native/binary/tls/2 / server | 55267 | 67546240 |
| quickfix-native/binary/tls/2/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/binary/tls/2/audit-diagnostic / server | 55261 | 67546240 |
| quickfix-native/binary/tls/3 / client | 22073 | 427392 |
| quickfix-native/binary/tls/3 / server | 55147 | 67546240 |
| quickfix-native/binary/tls/3/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/binary/tls/3/audit-diagnostic / server | 55178 | 67546240 |
| quickfix-native/fragmentation/tls/1 / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/1 / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/1/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/1/audit-diagnostic / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/2 / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/2 / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/2/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/2/audit-diagnostic / server | 202522 | 67546240 |
| quickfix-native/fragmentation/tls/3 / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/3 / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/3/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/3/audit-diagnostic / server | 202521 | 67546240 |
| quickfix-native/replay/tls/1 / client | 26477 | 991360 |
| quickfix-native/replay/tls/1 / server | 44756 | 6219776 |
| quickfix-native/replay/tls/1/audit-diagnostic / client | 26477 | 991360 |
| quickfix-native/replay/tls/1/audit-diagnostic / server | 44610 | 6219776 |
| quickfix-native/replay/tls/2 / client | 26477 | 991360 |
| quickfix-native/replay/tls/2 / server | 44452 | 6219776 |
| quickfix-native/replay/tls/2/audit-diagnostic / client | 26477 | 991360 |
| quickfix-native/replay/tls/2/audit-diagnostic / server | 44792 | 6219776 |
| quickfix-native/replay/tls/3 / client | 26477 | 991360 |
| quickfix-native/replay/tls/3 / server | 44432 | 6219776 |
| quickfix-native/replay/tls/3/audit-diagnostic / client | 26477 | 991360 |
| quickfix-native/replay/tls/3/audit-diagnostic / server | 44547 | 6219776 |
| quickfix-native/overload/tls/1 / client | 26471 | 990592 |
| quickfix-native/overload/tls/1 / server | 44118 | 6219776 |
| quickfix-native/overload/tls/1/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/overload/tls/1/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/overload/tls/2 / client | 26471 | 990592 |
| quickfix-native/overload/tls/2 / server | 44118 | 6219776 |
| quickfix-native/overload/tls/2/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/overload/tls/2/audit-diagnostic / server | 44370 | 6219776 |
| quickfix-native/overload/tls/3 / client | 26471 | 990592 |
| quickfix-native/overload/tls/3 / server | 44118 | 6219776 |
| quickfix-native/overload/tls/3/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/overload/tls/3/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-quickfix/scalar/tcp/1 / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/1 / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/1/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/1/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/2 / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/2 / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/2/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/2/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/3 / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/3 / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/3/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/3/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/groups/tcp/1 / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/1 / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/1/audit-diagnostic / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/1/audit-diagnostic / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/2 / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/2 / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/2/audit-diagnostic / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/2/audit-diagnostic / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/3 / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/3 / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/3/audit-diagnostic / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/3/audit-diagnostic / server | 345600 | 2297408 |
| quickfix-quickfix/binary/tcp/1 / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/1 / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/1/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/1/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/2 / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/2 / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/2/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/2/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/3 / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/3 / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/3/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/3/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/1 / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/1 / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/1/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/1/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/2 / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/2 / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/2/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/2/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/3 / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/3 / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/3/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/3/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/replay/tcp/1 / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/1 / server | 52866 | 2260544 |
| quickfix-quickfix/replay/tcp/1/audit-diagnostic / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/1/audit-diagnostic / server | 52867 | 2260544 |
| quickfix-quickfix/replay/tcp/2 / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/2 / server | 52866 | 2260544 |
| quickfix-quickfix/replay/tcp/2/audit-diagnostic / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/2/audit-diagnostic / server | 52866 | 2260544 |
| quickfix-quickfix/replay/tcp/3 / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/3 / server | 52866 | 2260544 |
| quickfix-quickfix/replay/tcp/3/audit-diagnostic / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/3/audit-diagnostic / server | 52867 | 2260544 |
| quickfix-quickfix/overload/tcp/1 / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/1 / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/1/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/1/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/2 / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/2 / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/2/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/2/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/3 / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/3 / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/3/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/3/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tls/1 / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/1 / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/1/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/1/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/2 / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/2 / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/2/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/2/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/3 / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/3 / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/3/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/3/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/groups/tls/1 / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/1 / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/1/audit-diagnostic / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/1/audit-diagnostic / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/2 / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/2 / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/2/audit-diagnostic / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/2/audit-diagnostic / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/3 / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/3 / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/3/audit-diagnostic / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/3/audit-diagnostic / server | 345607 | 2297792 |
| quickfix-quickfix/binary/tls/1 / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/1 / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/1/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/1/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/2 / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/2 / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/2/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/2/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/3 / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/3 / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/3/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/3/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/1 / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/1 / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/1/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/1/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/2 / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/2 / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/2/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/2/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/3 / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/3 / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/3/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/3/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/replay/tls/1 / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/1 / server | 52875 | 2260928 |
| quickfix-quickfix/replay/tls/1/audit-diagnostic / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/1/audit-diagnostic / server | 52874 | 2260928 |
| quickfix-quickfix/replay/tls/2 / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/2 / server | 52874 | 2260928 |
| quickfix-quickfix/replay/tls/2/audit-diagnostic / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/2/audit-diagnostic / server | 52874 | 2260928 |
| quickfix-quickfix/replay/tls/3 / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/3 / server | 52874 | 2260928 |
| quickfix-quickfix/replay/tls/3/audit-diagnostic / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/3/audit-diagnostic / server | 52873 | 2260928 |
| quickfix-quickfix/overload/tls/1 / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/1 / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/1/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/1/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/2 / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/2 / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/2/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/2/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/3 / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/3 / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/3/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/3/audit-diagnostic / server | 52867 | 2260928 |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: native replayable bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
