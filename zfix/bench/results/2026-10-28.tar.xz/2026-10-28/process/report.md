# FIX process load measurements

Build label: clang21-O3-ZDEBUG-ASAN-existing-Clang-ASAN-dependencies. Platform: Linux-7.0.0-1014-aws-x86_64-with-glibc2.43.
No configured clean release or platform acceptance is inferred from a label.

CPU/RSS cover whole local processes; latency and orders/s use each client's measured phase. Wire bytes include warmup and controls, so wire B/s uses case wall duration including setup/teardown. Orders/s is the sum of per-session rates, rather than a shared global interval. Session quantiles are reported separately and are not averaged across sessions or repeats.

| Pair / profile / transport / repeat | Mode | Status | Complete / unfinished | Errors / bad exits / timeouts | Orders/s | Client CPU s / RSS bytes | Server CPU s / RSS bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 27220.762 | 0.313916 / 71614464 | 0.340428 / 72888320 |
| native-native / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 16511.860 | 0.411382 / 75325440 | 0.453405 / 75776000 |
| native-native / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 28589.568 | 0.299017 / 71725056 | 0.330114 / 72675328 |
| native-native / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 16959.012 | 0.408293 / 75231232 | 0.452154 / 75948032 |
| native-native / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 31253.374 | 0.299521 / 72073216 | 0.322667 / 72413184 |
| native-native / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 14293.899 | 0.434535 / 75546624 | 0.476173 / 75816960 |
| native-native / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4418.820 | 0.627600 / 152420352 | 0.844530 / 424357888 |
| native-native / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2309.617 | 0.950660 / 156037120 | 1.374875 / 427294720 |
| native-native / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4364.209 | 0.639371 / 152428544 | 0.853185 / 424595456 |
| native-native / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2289.625 | 0.947543 / 156205056 | 1.387070 / 427450368 |
| native-native / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4512.976 | 0.635497 / 152457216 | 0.838012 / 424247296 |
| native-native / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2263.585 | 0.964902 / 155910144 | 1.407789 / 428134400 |
| native-native / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11810.106 | 0.546696 / 199131136 | 0.585175 / 209412096 |
| native-native / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8143.249 | 0.671022 / 203558912 | 0.724807 / 212828160 |
| native-native / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10171.444 | 0.572055 / 199106560 | 0.612983 / 209018880 |
| native-native / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7901.172 | 0.663520 / 203603968 | 0.737010 / 212705280 |
| native-native / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11370.281 | 0.555821 / 199548928 | 0.609253 / 209424384 |
| native-native / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8559.705 | 0.651789 / 202993664 | 0.724728 / 212688896 |
| native-native / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2772.434 | 0.536401 / 195670016 | 1.519650 / 363745280 |
| native-native / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2830.364 | 0.635376 / 198111232 | 1.645329 / 360013824 |
| native-native / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2952.297 | 0.530727 / 195690496 | 1.473423 / 355000320 |
| native-native / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2777.103 | 0.675679 / 199884800 | 1.625628 / 363421696 |
| native-native / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2783.958 | 0.513278 / 195268608 | 1.536700 / 369655808 |
| native-native / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2695.687 | 0.610323 / 197722112 | 1.731936 / 371228672 |
| native-native / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 20068.607 | 0.293707 / 72241152 | 0.334285 / 72462336 |
| native-native / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 14290.297 | 0.419987 / 75173888 | 0.477224 / 76197888 |
| native-native / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 19965.568 | 0.320539 / 71835648 | 0.307258 / 72605696 |
| native-native / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13697.907 | 0.447286 / 75440128 | 0.503926 / 76107776 |
| native-native / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 19927.514 | 0.303391 / 72294400 | 0.339785 / 72724480 |
| native-native / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 14069.870 | 0.421205 / 75223040 | 0.484051 / 75956224 |
| native-native / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 27016.680 | 0.315650 / 72007680 | 0.340802 / 72601600 |
| native-native / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 16715.300 | 0.401553 / 75591680 | 0.436289 / 75956224 |
| native-native / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 31412.967 | 0.296940 / 71847936 | 0.310842 / 72409088 |
| native-native / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 14881.165 | 0.425471 / 75194368 | 0.469896 / 75644928 |
| native-native / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 27189.305 | 0.314503 / 71565312 | 0.341396 / 72794112 |
| native-native / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 15734.192 | 0.416827 / 75165696 | 0.457882 / 75743232 |
| native-native / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 18001.804 | 0.403672 / 111157248 | 0.446563 / 146448384 |
| native-native / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12956.581 | 0.516827 / 114397184 | 0.588076 / 149852160 |
| native-native / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16732.285 | 0.407039 / 111017984 | 0.460929 / 146509824 |
| native-native / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 14272.404 | 0.491596 / 114532352 | 0.554369 / 149417984 |
| native-native / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17721.232 | 0.403203 / 111075328 | 0.448568 / 146317312 |
| native-native / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13227.466 | 0.494693 / 114143232 | 0.555088 / 149741568 |
| native-native / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4600.146 | 0.717580 / 192303104 | 0.905684 / 382730240 |
| native-native / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2343.221 | 1.052654 / 195710976 | 1.441315 / 385826816 |
| native-native / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4822.488 | 0.701936 / 192389120 | 0.869297 / 383365120 |
| native-native / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2279.994 | 1.075847 / 196001792 | 1.478164 / 386072576 |
| native-native / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 4790.911 | 0.699564 / 192110592 | 0.874713 / 382672896 |
| native-native / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2229.270 | 1.037541 / 195657728 | 1.490610 / 385875968 |
| native-native / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10800.831 | 0.598070 / 214659072 | 0.671413 / 261763072 |
| native-native / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8897.035 | 0.691515 / 212238336 | 0.782561 / 262553600 |
| native-native / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10550.442 | 0.591351 / 212307968 | 0.680668 / 261275648 |
| native-native / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8583.920 | 0.699495 / 211034112 | 0.801768 / 264134656 |
| native-native / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11100.280 | 0.580802 / 211070976 | 0.667544 / 261103616 |
| native-native / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8607.221 | 0.700422 / 211320832 | 0.796788 / 262709248 |
| native-native / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1769.676 | 0.619310 / 263761920 | 2.155095 / 364699648 |
| native-native / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1819.330 | 0.745922 / 267612160 | 2.310027 / 368091136 |
| native-native / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1825.350 | 0.640191 / 266407936 | 2.120957 / 364535808 |
| native-native / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1767.094 | 0.730585 / 269205504 | 2.350457 / 367853568 |
| native-native / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1780.112 | 0.635077 / 265670656 | 2.130928 / 365129728 |
| native-native / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1839.692 | 0.729567 / 268861440 | 2.294567 / 367923200 |
| native-native / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16280.564 | 0.388608 / 111030272 | 0.417170 / 146812928 |
| native-native / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12962.957 | 0.519332 / 114401280 | 0.577537 / 150097920 |
| native-native / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16546.142 | 0.369433 / 111345664 | 0.416860 / 146673664 |
| native-native / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12318.030 | 0.521027 / 114405376 | 0.561081 / 149676032 |
| native-native / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15159.425 | 0.372156 / 111357952 | 0.434373 / 146694144 |
| native-native / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12048.213 | 0.535774 / 114667520 | 0.564445 / 149815296 |
| native-native / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17880.061 | 0.401899 / 110989312 | 0.444923 / 146407424 |
| native-native / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13236.421 | 0.503228 / 114335744 | 0.578513 / 149958656 |
| native-native / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17563.709 | 0.401164 / 111267840 | 0.442006 / 146722816 |
| native-native / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13847.452 | 0.493734 / 113963008 | 0.547829 / 149725184 |
| native-native / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 18017.249 | 0.396679 / 110755840 | 0.445848 / 146345984 |
| native-native / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 13591.967 | 0.495944 / 114176000 | 0.567326 / 149585920 |
| native-quickfix / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 21197.725 | 0.311546 / 71872512 | 0.381151 / 116019200 |
| native-quickfix / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12111.843 | 0.434814 / 75513856 | 0.591200 / 118542336 |
| native-quickfix / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15795.267 | 0.339056 / 72290304 | 0.423321 / 115625984 |
| native-quickfix / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11909.026 | 0.441171 / 75042816 | 0.597633 / 118587392 |
| native-quickfix / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 20717.570 | 0.316793 / 72028160 | 0.392722 / 115904512 |
| native-quickfix / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10683.655 | 0.430744 / 75423744 | 0.601973 / 118824960 |
| native-quickfix / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1746.352 | 0.665697 / 153305088 | 1.739713 / 427749376 |
| native-quickfix / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 964.759 | 1.031899 / 156270592 | 2.904075 / 430993408 |
| native-quickfix / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1725.812 | 0.654486 / 153432064 | 1.747191 / 427352064 |
| native-quickfix / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 931.279 | 1.015945 / 156844032 | 3.012561 / 430772224 |
| native-quickfix / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1606.236 | 0.733807 / 152850432 | 1.820930 / 427835392 |
| native-quickfix / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 937.995 | 1.045229 / 155815936 | 2.963496 / 430944256 |
| native-quickfix / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 8724.642 | 0.553623 / 200314880 | 0.642392 / 379133952 |
| native-quickfix / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6061.260 | 0.652194 / 202993664 | 0.886045 / 381968384 |
| native-quickfix / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7601.942 | 0.547558 / 199737344 | 0.690648 / 379121664 |
| native-quickfix / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6451.953 | 0.641189 / 201572352 | 0.855570 / 382144512 |
| native-quickfix / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7596.022 | 0.573049 / 200364032 | 0.682644 / 378920960 |
| native-quickfix / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6747.797 | 0.679181 / 202711040 | 0.867893 / 381960192 |
| native-quickfix / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3296.777 | 0.482546 / 194109440 | 1.062422 / 396840960 |
| native-quickfix / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2969.113 | 0.674108 / 199491584 | 1.272942 / 394543104 |
| native-quickfix / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2961.941 | 0.560405 / 196784128 | 1.102819 / 398458880 |
| native-quickfix / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3310.736 | 0.603514 / 197558272 | 1.324957 / 392318976 |
| native-quickfix / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2970.817 | 0.514078 / 195203072 | 1.125481 / 397926400 |
| native-quickfix / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3626.405 | 0.582337 / 197459968 | 1.176814 / 391348224 |
| native-quickfix / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16083.010 | 0.318204 / 72155136 | 0.410785 / 115412992 |
| native-quickfix / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 12873.148 | 0.426150 / 75288576 | 0.575201 / 118722560 |
| native-quickfix / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14839.725 | 0.338331 / 72294400 | 0.425742 / 115707904 |
| native-quickfix / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10312.918 | 0.425205 / 75259904 | 0.624663 / 118915072 |
| native-quickfix / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15406.329 | 0.308804 / 71942144 | 0.441804 / 115871744 |
| native-quickfix / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10552.264 | 0.429483 / 74948608 | 0.629963 / 119009280 |
| native-quickfix / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 18238.439 | 0.335740 / 71725056 | 0.405298 / 115904512 |
| native-quickfix / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11952.505 | 0.424447 / 75177984 | 0.594577 / 118886400 |
| native-quickfix / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17241.682 | 0.342758 / 71987200 | 0.409906 / 115572736 |
| native-quickfix / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9937.722 | 0.429877 / 75300864 | 0.628277 / 118972416 |
| native-quickfix / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 18296.812 | 0.328852 / 71974912 | 0.399524 / 115691520 |
| native-quickfix / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 11961.047 | 0.420918 / 75116544 | 0.594141 / 118915072 |
| native-quickfix / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14704.155 | 0.406141 / 111534080 | 0.461490 / 124948480 |
| native-quickfix / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9912.173 | 0.502803 / 114458624 | 0.668185 / 128020480 |
| native-quickfix / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16592.962 | 0.397437 / 111661056 | 0.456928 / 125083648 |
| native-quickfix / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 10557.958 | 0.489940 / 114212864 | 0.677489 / 128303104 |
| native-quickfix / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14665.058 | 0.417322 / 111427584 | 0.485347 / 124928000 |
| native-quickfix / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9383.219 | 0.494558 / 114601984 | 0.685277 / 128098304 |
| native-quickfix / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1517.784 | 0.785135 / 192647168 | 2.024108 / 435666944 |
| native-quickfix / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 930.683 | 1.094893 / 196038656 | 3.072731 / 438755328 |
| native-quickfix / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1723.603 | 0.709899 / 192192512 | 1.804315 / 436002816 |
| native-quickfix / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 901.346 | 1.149350 / 195743744 | 3.110767 / 439255040 |
| native-quickfix / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1529.408 | 0.775570 / 192864256 | 2.048126 / 435683328 |
| native-quickfix / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 885.770 | 1.159463 / 195911680 | 3.214624 / 439255040 |
| native-quickfix / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7167.201 | 0.571284 / 208596992 | 0.748125 / 389705728 |
| native-quickfix / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5351.318 | 0.675136 / 220897280 | 0.997101 / 392421376 |
| native-quickfix / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 6695.704 | 0.578747 / 214474752 | 0.752568 / 389345280 |
| native-quickfix / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5992.253 | 0.652597 / 214470656 | 0.934070 / 392663040 |
| native-quickfix / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7708.216 | 0.567076 / 207822848 | 0.731927 / 389615616 |
| native-quickfix / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5392.188 | 0.687842 / 216895488 | 0.992106 / 392695808 |
| native-quickfix / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2053.918 | 0.649317 / 262586368 | 1.586310 / 436572160 |
| native-quickfix / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1236.271 | 0.738052 / 223588352 | 2.530202 / 439996416 |
| native-quickfix / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2050.729 | 0.594952 / 232509440 | 1.667340 / 436572160 |
| native-quickfix / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1235.055 | 0.739767 / 222625792 | 2.566526 / 439504896 |
| native-quickfix / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2221.418 | 0.645278 / 265498624 | 1.513280 / 436690944 |
| native-quickfix / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1232.734 | 0.708313 / 220909568 | 2.530913 / 439574528 |
| native-quickfix / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15825.286 | 0.387745 / 111546368 | 0.439183 / 125210624 |
| native-quickfix / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8876.092 | 0.518572 / 114565120 | 0.707328 / 128212992 |
| native-quickfix / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 16012.787 | 0.383015 / 111452160 | 0.448604 / 125243392 |
| native-quickfix / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7763.067 | 0.510665 / 114622464 | 0.805861 / 128196608 |
| native-quickfix / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15406.762 | 0.402142 / 111403008 | 0.455753 / 124948480 |
| native-quickfix / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8276.096 | 0.540786 / 114401280 | 0.741975 / 128258048 |
| native-quickfix / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15198.472 | 0.392707 / 111419392 | 0.476408 / 124809216 |
| native-quickfix / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9373.498 | 0.493259 / 114241536 | 0.699215 / 128229376 |
| native-quickfix / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14173.125 | 0.417669 / 111161344 | 0.485274 / 124821504 |
| native-quickfix / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8012.188 | 0.510541 / 114556928 | 0.737372 / 128167936 |
| native-quickfix / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14771.497 | 0.397873 / 111046656 | 0.452549 / 124833792 |
| native-quickfix / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9517.654 | 0.494541 / 114573312 | 0.705827 / 128122880 |
| quickfix-native / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13848.127 | 0.459875 / 123240448 | 0.359320 / 72294400 |
| quickfix-native / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7825.714 | 0.697006 / 126644224 | 0.480877 / 75890688 |
| quickfix-native / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12432.992 | 0.465328 / 123469824 | 0.383714 / 71876608 |
| quickfix-native / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7736.447 | 0.702404 / 126627840 | 0.514655 / 75485184 |
| quickfix-native / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12835.918 | 0.461556 / 123301888 | 0.380603 / 72491008 |
| quickfix-native / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7220.581 | 0.698239 / 126713856 | 0.471540 / 75669504 |
| quickfix-native / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 889.042 | 3.096663 / 437198848 | 1.039274 / 423964672 |
| quickfix-native / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 528.483 | 5.036492 / 440635392 | 1.639074 / 427339776 |
| quickfix-native / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 891.742 | 3.018785 / 437600256 | 0.983905 / 423911424 |
| quickfix-native / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 526.144 | 5.103928 / 440700928 | 1.648889 / 427732992 |
| quickfix-native / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 907.974 | 3.009285 / 437477376 | 0.979878 / 424030208 |
| quickfix-native / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 510.714 | 5.210279 / 439996416 | 1.676366 / 427155456 |
| quickfix-native / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7789.772 | 0.692855 / 361635840 | 0.574886 / 209379328 |
| quickfix-native / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4381.667 | 1.038596 / 365162496 | 0.690953 / 212676608 |
| quickfix-native / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 8439.712 | 0.670730 / 362213376 | 0.575853 / 209256448 |
| quickfix-native / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5314.915 | 0.956915 / 365338624 | 0.690209 / 212480000 |
| quickfix-native / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7334.535 | 0.713559 / 361451520 | 0.594768 / 208973824 |
| quickfix-native / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4991.978 | 0.964351 / 364552192 | 0.706682 / 212566016 |
| quickfix-native / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2770.670 | 0.812536 / 361590784 | 1.523031 / 358883328 |
| quickfix-native / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2569.324 | 1.053633 / 364683264 | 1.836034 / 373731328 |
| quickfix-native / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3104.284 | 0.747870 / 361566208 | 1.451017 / 339202048 |
| quickfix-native / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2813.676 | 1.023385 / 364781568 | 1.684629 / 364109824 |
| quickfix-native / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2545.301 | 0.796853 / 361779200 | 1.658318 / 374001664 |
| quickfix-native / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2793.358 | 1.030820 / 364531712 | 1.723449 / 366419968 |
| quickfix-native / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14445.287 | 0.449383 / 123678720 | 0.378739 / 72642560 |
| quickfix-native / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6450.293 | 0.774484 / 126771200 | 0.510731 / 76038144 |
| quickfix-native / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14337.060 | 0.448377 / 123850752 | 0.365620 / 72876032 |
| quickfix-native / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7590.818 | 0.698612 / 127254528 | 0.545137 / 76075008 |
| quickfix-native / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13428.904 | 0.468602 / 123744256 | 0.407055 / 72622080 |
| quickfix-native / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6690.443 | 0.768618 / 126877696 | 0.515456 / 76120064 |
| quickfix-native / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15597.219 | 0.444941 / 123809792 | 0.374754 / 72474624 |
| quickfix-native / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6860.838 | 0.741382 / 126562304 | 0.475996 / 75358208 |
| quickfix-native / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13143.622 | 0.453175 / 123322368 | 0.384969 / 72167424 |
| quickfix-native / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7571.102 | 0.700834 / 126844928 | 0.478883 / 75976704 |
| quickfix-native / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14964.835 | 0.444476 / 123203584 | 0.376199 / 72175616 |
| quickfix-native / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7900.964 | 0.698470 / 126451712 | 0.496717 / 75587584 |
| quickfix-native / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13212.526 | 0.511802 / 137646080 | 0.457874 / 146120704 |
| quickfix-native / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6832.334 | 0.801187 / 141139968 | 0.605320 / 149536768 |
| quickfix-native / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11033.167 | 0.543119 / 137814016 | 0.446443 / 146563072 |
| quickfix-native / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5931.827 | 0.858050 / 141012992 | 0.583487 / 149815296 |
| quickfix-native / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12274.770 | 0.533412 / 137633792 | 0.488683 / 146472960 |
| quickfix-native / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5330.780 | 0.908516 / 140775424 | 0.581368 / 149450752 |
| quickfix-native / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 898.413 | 3.150181 / 448049152 | 0.988152 / 381743104 |
| quickfix-native / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 528.084 | 5.162233 / 451694592 | 1.686897 / 384802816 |
| quickfix-native / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 908.802 | 3.117964 / 448094208 | 0.989018 / 381698048 |
| quickfix-native / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 533.202 | 5.093286 / 451334144 | 1.662424 / 384696320 |
| quickfix-native / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 834.607 | 3.349515 / 448118784 | 1.005710 / 381693952 |
| quickfix-native / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 506.831 | 5.333452 / 451768320 | 1.726351 / 384802816 |
| quickfix-native / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7094.045 | 0.769882 / 376938496 | 0.594596 / 258830336 |
| quickfix-native / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4294.406 | 1.128423 / 379678720 | 0.765440 / 263110656 |
| quickfix-native / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 6558.238 | 0.819841 / 376893440 | 0.605899 / 259104768 |
| quickfix-native / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4640.248 | 1.094992 / 380280832 | 0.780900 / 264654848 |
| quickfix-native / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 6832.272 | 0.787543 / 376766464 | 0.599402 / 258260992 |
| quickfix-native / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4556.687 | 1.106392 / 380039168 | 0.760094 / 263753728 |
| quickfix-native / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1767.606 | 0.866844 / 376750080 | 2.212190 / 364703744 |
| quickfix-native / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1918.083 | 1.234123 / 380063744 | 2.308572 / 367820800 |
| quickfix-native / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1803.216 | 0.866017 / 376934400 | 2.131353 / 364785664 |
| quickfix-native / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1907.895 | 1.229487 / 380198912 | 2.290482 / 367919104 |
| quickfix-native / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1709.913 | 0.921987 / 376832000 | 2.128337 / 364601344 |
| quickfix-native / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1819.301 | 1.284805 / 380076032 | 2.317017 / 367955968 |
| quickfix-native / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11391.555 | 0.562641 / 138125312 | 0.472084 / 147075072 |
| quickfix-native / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6243.805 | 0.850643 / 141291520 | 0.622195 / 150540288 |
| quickfix-native / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12143.908 | 0.532710 / 138276864 | 0.477376 / 147210240 |
| quickfix-native / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5993.904 | 0.861353 / 141668352 | 0.609792 / 150802432 |
| quickfix-native / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 9706.814 | 0.584523 / 138166272 | 0.484924 / 147619840 |
| quickfix-native / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5336.237 | 0.908778 / 141033472 | 0.629189 / 150077440 |
| quickfix-native / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10484.477 | 0.583116 / 137625600 | 0.460605 / 146317312 |
| quickfix-native / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6690.861 | 0.810213 / 141275136 | 0.566415 / 149577728 |
| quickfix-native / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12561.072 | 0.540510 / 137588736 | 0.484250 / 146382848 |
| quickfix-native / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5980.502 | 0.840997 / 141021184 | 0.576271 / 149491712 |
| quickfix-native / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 10263.655 | 0.574681 / 137916416 | 0.456222 / 146849792 |
| quickfix-native / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6405.195 | 0.828112 / 141221888 | 0.590185 / 149602304 |
| quickfix-quickfix / scalar / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17405.501 | 0.416310 / 122400768 | 0.395047 / 115097600 |
| quickfix-quickfix / scalar / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9114.370 | 0.619659 / 125861888 | 0.604367 / 118444032 |
| quickfix-quickfix / scalar / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17277.034 | 0.407499 / 122810368 | 0.383815 / 115175424 |
| quickfix-quickfix / scalar / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9067.773 | 0.665677 / 125980672 | 0.636131 / 118202368 |
| quickfix-quickfix / scalar / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15269.471 | 0.427936 / 124194816 | 0.442653 / 114905088 |
| quickfix-quickfix / scalar / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9073.003 | 0.643030 / 126095360 | 0.607025 / 118448128 |
| quickfix-quickfix / groups / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 855.780 | 3.218947 / 436486144 | 2.028693 / 428142592 |
| quickfix-quickfix / groups / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 516.455 | 5.158947 / 440254464 | 3.384266 / 431120384 |
| quickfix-quickfix / groups / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 922.103 | 3.044103 / 436813824 | 1.970796 / 427716608 |
| quickfix-quickfix / groups / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 527.919 | 5.043555 / 439754752 | 3.428431 / 431009792 |
| quickfix-quickfix / groups / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 922.944 | 3.044503 / 436482048 | 1.955473 / 427663360 |
| quickfix-quickfix / groups / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 537.551 | 4.963066 / 439369728 | 3.204499 / 431435776 |
| quickfix-quickfix / binary / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7565.710 | 0.716915 / 361091072 | 0.637513 / 365400064 |
| quickfix-quickfix / binary / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5607.399 | 0.926141 / 364826624 | 0.848667 / 368812032 |
| quickfix-quickfix / binary / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7484.450 | 0.723038 / 361328640 | 0.633820 / 365678592 |
| quickfix-quickfix / binary / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5734.823 | 0.902270 / 364777472 | 0.841648 / 368394240 |
| quickfix-quickfix / binary / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7137.772 | 0.735665 / 361357312 | 0.634564 / 365514752 |
| quickfix-quickfix / binary / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5522.273 | 0.923257 / 364470272 | 0.824223 / 368517120 |
| quickfix-quickfix / fragmentation / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2919.509 | 0.743659 / 360173568 | 1.120812 / 385982464 |
| quickfix-quickfix / fragmentation / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3471.553 | 1.024381 / 363991040 | 1.216209 / 377917440 |
| quickfix-quickfix / fragmentation / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 2683.323 | 0.679116 / 360275968 | 1.253561 / 388366336 |
| quickfix-quickfix / fragmentation / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 3605.933 | 0.980086 / 364134400 | 1.225089 / 377044992 |
| quickfix-quickfix / fragmentation / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 3280.115 | 0.719550 / 361480192 | 1.109698 / 382328832 |
| quickfix-quickfix / fragmentation / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 2976.564 | 1.004431 / 364433408 | 1.367661 / 382365696 |
| quickfix-quickfix / replay / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15560.083 | 0.437006 / 123670528 | 0.448141 / 115068928 |
| quickfix-quickfix / replay / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8109.493 | 0.687537 / 126382080 | 0.693188 / 118312960 |
| quickfix-quickfix / replay / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17355.288 | 0.434388 / 123179008 | 0.418602 / 115212288 |
| quickfix-quickfix / replay / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8462.584 | 0.676092 / 126193664 | 0.647615 / 118607872 |
| quickfix-quickfix / replay / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15417.973 | 0.454226 / 123092992 | 0.417793 / 115335168 |
| quickfix-quickfix / replay / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6576.607 | 0.748149 / 126414848 | 0.631136 / 118452224 |
| quickfix-quickfix / overload / tcp / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17192.510 | 0.410697 / 122851328 | 0.389973 / 115220480 |
| quickfix-quickfix / overload / tcp / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8863.132 | 0.642135 / 126070784 | 0.671768 / 118325248 |
| quickfix-quickfix / overload / tcp / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 17950.948 | 0.432887 / 122437632 | 0.411463 / 114941952 |
| quickfix-quickfix / overload / tcp / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 8689.610 | 0.645742 / 125976576 | 0.596114 / 118173696 |
| quickfix-quickfix / overload / tcp / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 15209.521 | 0.422098 / 123363328 | 0.449340 / 115179520 |
| quickfix-quickfix / overload / tcp / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 9144.254 | 0.628441 / 126111744 | 0.578342 / 118374400 |
| quickfix-quickfix / scalar / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13508.914 | 0.509806 / 137138176 | 0.487329 / 124235776 |
| quickfix-quickfix / scalar / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6900.545 | 0.804777 / 140333056 | 0.724945 / 127434752 |
| quickfix-quickfix / scalar / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13353.694 | 0.504168 / 137080832 | 0.443560 / 124018688 |
| quickfix-quickfix / scalar / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6641.577 | 0.802019 / 140300288 | 0.706850 / 127455232 |
| quickfix-quickfix / scalar / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12625.612 | 0.519708 / 136900608 | 0.479427 / 124112896 |
| quickfix-quickfix / scalar / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7324.310 | 0.772144 / 140271616 | 0.682411 / 127516672 |
| quickfix-quickfix / groups / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 899.087 | 3.206643 / 448315392 | 2.044757 / 435638272 |
| quickfix-quickfix / groups / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 515.268 | 5.268799 / 451780608 | 3.438093 / 438616064 |
| quickfix-quickfix / groups / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 868.868 | 3.304191 / 448389120 | 2.118440 / 435720192 |
| quickfix-quickfix / groups / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 497.825 | 5.464863 / 451588096 | 3.530006 / 438390784 |
| quickfix-quickfix / groups / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 879.250 | 3.273297 / 448466944 | 2.115657 / 435826688 |
| quickfix-quickfix / groups / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 521.835 | 5.264990 / 451624960 | 3.599283 / 438824960 |
| quickfix-quickfix / binary / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7430.176 | 0.753473 / 376410112 | 0.669819 / 376238080 |
| quickfix-quickfix / binary / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4979.468 | 1.039252 / 379756544 | 0.898846 / 379392000 |
| quickfix-quickfix / binary / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7363.196 | 0.800171 / 376446976 | 0.707705 / 375812096 |
| quickfix-quickfix / binary / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 5053.295 | 1.042020 / 379670528 | 0.919807 / 379105280 |
| quickfix-quickfix / binary / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 7028.481 | 0.751525 / 376389632 | 0.754743 / 375963648 |
| quickfix-quickfix / binary / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 4805.287 | 1.065925 / 379498496 | 0.970023 / 379064320 |
| quickfix-quickfix / fragmentation / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1921.934 | 0.771998 / 376393728 | 1.692624 / 423632896 |
| quickfix-quickfix / fragmentation / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1324.898 | 1.292125 / 379817984 | 2.352082 / 426442752 |
| quickfix-quickfix / fragmentation / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1952.180 | 0.982264 / 376360960 | 1.630233 / 423161856 |
| quickfix-quickfix / fragmentation / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1262.121 | 1.289033 / 379596800 | 2.449467 / 426164224 |
| quickfix-quickfix / fragmentation / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 1939.500 | 0.942517 / 376487936 | 1.609225 / 423571456 |
| quickfix-quickfix / fragmentation / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 1336.277 | 1.274905 / 379408384 | 2.326492 / 426156032 |
| quickfix-quickfix / replay / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11159.002 | 0.557602 / 138170368 | 0.521575 / 125300736 |
| quickfix-quickfix / replay / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6985.197 | 0.795025 / 140615680 | 0.782557 / 127963136 |
| quickfix-quickfix / replay / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 12356.547 | 0.525799 / 137306112 | 0.538658 / 124391424 |
| quickfix-quickfix / replay / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 6576.147 | 0.845205 / 140361728 | 0.731930 / 127729664 |
| quickfix-quickfix / replay / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11993.729 | 0.550669 / 137572352 | 0.494954 / 124469248 |
| quickfix-quickfix / replay / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7024.538 | 0.823876 / 140595200 | 0.810235 / 127787008 |
| quickfix-quickfix / overload / tls / 1 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 14060.962 | 0.501194 / 136982528 | 0.471131 / 124186624 |
| quickfix-quickfix / overload / tls / 1 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7197.934 | 0.790004 / 140443648 | 0.705013 / 127475712 |
| quickfix-quickfix / overload / tls / 2 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 13860.400 | 0.499320 / 137121792 | 0.461403 / 124141568 |
| quickfix-quickfix / overload / tls / 2 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7348.165 | 0.761203 / 140210176 | 0.686752 / 127582208 |
| quickfix-quickfix / overload / tls / 3 | timing | passed | 2000 / 0 | 0 / 0 / 0 | 11689.167 | 0.532748 / 136908800 | 0.484082 / 124194816 |
| quickfix-quickfix / overload / tls / 3 | audit diagnostic | passed | 2000 / 0 | 0 / 0 / 0 | 7282.338 | 0.780817 / 140439552 | 0.706046 / 127373312 |

## Work and process counters

Wire counts include warmup, controls and any replay. Retention is the application history cache's observed high-water mark, not total heap usage.

| Case / role / session | Offered / admitted / complete | Ack / reports | In-flight / peak | Rx / Tx frames | Rx / Tx bytes | Retained bytes |
| --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972640 / 380317 | 3097600 |
| native-native/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380317 / 972640 | 5767168 |
| native-native/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972630 / 380274 | 3097600 |
| native-native/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380274 / 972630 | 5767168 |
| native-native/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972634 / 380290 | 3097600 |
| native-native/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380290 / 972634 | 5767168 |
| native-native/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972623 / 10803871 | 39142400 |
| native-native/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803871 / 972623 | 5767168 |
| native-native/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972623 / 10803856 | 39142400 |
| native-native/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803856 / 972623 | 5767168 |
| native-native/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972642 / 10803875 | 39142400 |
| native-native/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803875 / 972642 | 5767168 |
| native-native/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061052 / 9424491 | 39142400 |
| native-native/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424491 / 19061052 | 67093632 |
| native-native/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061057 / 9424513 | 39142400 |
| native-native/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424513 / 19061057 | 67093632 |
| native-native/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061006 / 9424462 | 39142400 |
| native-native/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424462 / 19061006 | 67093632 |
| native-native/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061030 / 9424459 | 39142400 |
| native-native/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424459 / 19061030 | 67093632 |
| native-native/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19060992 / 9424458 | 39142400 |
| native-native/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424458 / 19060992 | 67093632 |
| native-native/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061060 / 9424469 | 39142400 |
| native-native/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424469 / 19061060 | 67093632 |
| native-native/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972993 / 380683 | 3097600 |
| native-native/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380683 / 973206 | 5767168 |
| native-native/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972936 / 380681 | 3097600 |
| native-native/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380681 / 973147 | 5767168 |
| native-native/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972959 / 380680 | 3097600 |
| native-native/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380680 / 973172 | 5767168 |
| native-native/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972587 / 380269 | 3097600 |
| native-native/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380269 / 972587 | 5767168 |
| native-native/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972653 / 380319 | 3097600 |
| native-native/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380319 / 972653 | 5767168 |
| native-native/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972647 / 380302 | 3097600 |
| native-native/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380302 / 972647 | 5767168 |
| native-native/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972658 / 380291 | 3097600 |
| native-native/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380291 / 972658 | 5767168 |
| native-native/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972691 / 380297 | 3097600 |
| native-native/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380297 / 972691 | 5767168 |
| native-native/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972609 / 380276 | 3097600 |
| native-native/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380276 / 972609 | 5767168 |
| native-native/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972604 / 10803860 | 39142400 |
| native-native/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803860 / 972604 | 5767168 |
| native-native/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972717 / 10803923 | 39142400 |
| native-native/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803923 / 972717 | 5767168 |
| native-native/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972626 / 10803852 | 39142400 |
| native-native/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 10803852 / 972626 | 5767168 |
| native-native/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061108 / 9424515 | 39142400 |
| native-native/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424515 / 19061108 | 67093632 |
| native-native/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061094 / 9424478 | 39142400 |
| native-native/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424478 / 19061094 | 67093632 |
| native-native/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19060999 / 9424497 | 39142400 |
| native-native/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424497 / 19060999 | 67093632 |
| native-native/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19060962 / 9424457 | 39142400 |
| native-native/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424457 / 19060962 | 67093632 |
| native-native/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19060996 / 9424492 | 39142400 |
| native-native/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424492 / 19060996 | 67093632 |
| native-native/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 19061057 / 9424493 | 39142400 |
| native-native/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 9424493 / 19061057 | 67093632 |
| native-native/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972980 / 380690 | 3097600 |
| native-native/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380690 / 973192 | 5767168 |
| native-native/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972974 / 380687 | 3097600 |
| native-native/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380687 / 973187 | 5767168 |
| native-native/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4406 / 2207 | 972963 / 380676 | 3097600 |
| native-native/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2207 / 4407 | 380676 / 973176 | 5767168 |
| native-native/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972605 / 380285 | 3097600 |
| native-native/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380285 / 972605 | 5767168 |
| native-native/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972550 / 380247 | 3097600 |
| native-native/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380247 / 972550 | 5767168 |
| native-native/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2204 | 972626 / 380255 | 3097600 |
| native-native/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2204 / 4404 | 380255 / 972626 | 5767168 |
| native-quickfix/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380110 | 3097600 |
| native-quickfix/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380110 / 951453 | 1673273 |
| native-quickfix/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380153 | 3097600 |
| native-quickfix/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380153 / 951453 | 1673273 |
| native-quickfix/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380144 | 3097600 |
| native-quickfix/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380144 / 951453 | 1673273 |
| native-quickfix/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 10803759 | 39142400 |
| native-quickfix/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803759 / 951452 | 1673273 |
| native-quickfix/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803776 | 39142400 |
| native-quickfix/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803776 / 951453 | 1673273 |
| native-quickfix/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803773 | 39142400 |
| native-quickfix/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803773 / 951453 | 1673273 |
| native-quickfix/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424349 | 39142400 |
| native-quickfix/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424349 / 19039853 | 18511929 |
| native-quickfix/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424319 | 39142400 |
| native-quickfix/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424319 / 19039853 | 18511929 |
| native-quickfix/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039852 / 9424326 | 39142400 |
| native-quickfix/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424326 / 19039852 | 18511929 |
| native-quickfix/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039851 / 9424306 | 39142400 |
| native-quickfix/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424306 / 19039851 | 18511929 |
| native-quickfix/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424347 | 39142400 |
| native-quickfix/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424347 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039852 / 9424371 | 39142400 |
| native-quickfix/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424371 / 19039852 | 18511929 |
| native-quickfix/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951632 / 380381 | 3097600 |
| native-quickfix/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380381 / 951840 | 1673208 |
| native-quickfix/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951632 / 380378 | 3097600 |
| native-quickfix/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380378 / 951840 | 1673208 |
| native-quickfix/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951630 / 380374 | 3097600 |
| native-quickfix/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380374 / 951838 | 1673207 |
| native-quickfix/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380152 | 3097600 |
| native-quickfix/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380152 / 951453 | 1673273 |
| native-quickfix/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951452 / 380148 | 3097600 |
| native-quickfix/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380148 / 951452 | 1673273 |
| native-quickfix/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380129 | 3097600 |
| native-quickfix/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380129 / 951453 | 1673273 |
| native-quickfix/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380137 | 3097600 |
| native-quickfix/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380137 / 951453 | 1673273 |
| native-quickfix/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380119 | 3097600 |
| native-quickfix/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380119 / 951453 | 1673273 |
| native-quickfix/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380140 | 3097600 |
| native-quickfix/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380140 / 951453 | 1673273 |
| native-quickfix/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803716 | 39142400 |
| native-quickfix/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803716 / 951453 | 1673273 |
| native-quickfix/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803748 | 39142400 |
| native-quickfix/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803748 / 951453 | 1673273 |
| native-quickfix/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 10803710 | 39142400 |
| native-quickfix/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10803710 / 951453 | 1673273 |
| native-quickfix/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424351 | 39142400 |
| native-quickfix/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424351 / 19039853 | 18511929 |
| native-quickfix/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424358 | 39142400 |
| native-quickfix/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424358 / 19039853 | 18511929 |
| native-quickfix/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039852 / 9424369 | 39142400 |
| native-quickfix/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424369 / 19039852 | 18511929 |
| native-quickfix/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424332 | 39142400 |
| native-quickfix/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424332 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424343 | 39142400 |
| native-quickfix/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424343 / 19039853 | 18511929 |
| native-quickfix/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19039853 / 9424359 | 39142400 |
| native-quickfix/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424359 / 19039853 | 18511929 |
| native-quickfix/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380362 | 3097600 |
| native-quickfix/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380362 / 951842 | 1673209 |
| native-quickfix/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951634 / 380416 | 3097600 |
| native-quickfix/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380416 / 951842 | 1673209 |
| native-quickfix/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4404 / 2205 | 951632 / 380395 | 3097600 |
| native-quickfix/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4405 | 380395 / 951840 | 1673208 |
| native-quickfix/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380109 | 3097600 |
| native-quickfix/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380109 / 951453 | 1673273 |
| native-quickfix/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380124 | 3097600 |
| native-quickfix/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380124 / 951453 | 1673273 |
| native-quickfix/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 951453 / 380156 | 3097600 |
| native-quickfix/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380156 / 951453 | 1673273 |
| quickfix-native/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972494 / 380617 | 803593 |
| quickfix-native/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972494 | 5767168 |
| quickfix-native/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972556 / 380617 | 803593 |
| quickfix-native/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972556 | 5767168 |
| quickfix-native/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972496 / 380617 | 803593 |
| quickfix-native/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972496 | 5767168 |
| quickfix-native/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972498 / 10804218 | 11227194 |
| quickfix-native/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972498 | 5767168 |
| quickfix-native/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972486 / 10804218 | 11227194 |
| quickfix-native/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972486 | 5767168 |
| quickfix-native/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972559 / 10804217 | 11227193 |
| quickfix-native/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804217 / 972559 | 5767168 |
| quickfix-native/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060892 / 9424818 | 9847794 |
| quickfix-native/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060892 | 67093632 |
| quickfix-native/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060890 / 9424818 | 9847794 |
| quickfix-native/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060890 | 67093632 |
| quickfix-native/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060897 / 9424818 | 9847794 |
| quickfix-native/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060897 | 67093632 |
| quickfix-native/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060905 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060905 | 67093632 |
| quickfix-native/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060975 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060975 | 67093632 |
| quickfix-native/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060836 / 9424817 | 9847793 |
| quickfix-native/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424817 / 19060836 | 67093632 |
| quickfix-native/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4433 / 2205 | 980116 / 380859 | 804219 |
| quickfix-native/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4434 | 380859 / 980329 | 5767168 |
| quickfix-native/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4439 / 2205 | 981618 / 380859 | 804219 |
| quickfix-native/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4440 | 380859 / 981831 | 5767168 |
| quickfix-native/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4439 / 2205 | 981624 / 380859 | 804219 |
| quickfix-native/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4440 | 380859 / 981837 | 5767168 |
| quickfix-native/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972486 / 380618 | 803594 |
| quickfix-native/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972486 | 5767168 |
| quickfix-native/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972500 / 380618 | 803594 |
| quickfix-native/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972500 | 5767168 |
| quickfix-native/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972493 / 380617 | 803593 |
| quickfix-native/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972493 | 5767168 |
| quickfix-native/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972466 / 380618 | 803594 |
| quickfix-native/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972466 | 5767168 |
| quickfix-native/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972457 / 380617 | 803593 |
| quickfix-native/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972457 | 5767168 |
| quickfix-native/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972541 / 380617 | 803593 |
| quickfix-native/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972541 | 5767168 |
| quickfix-native/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972492 / 10804218 | 11227194 |
| quickfix-native/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972492 | 5767168 |
| quickfix-native/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972554 / 10804218 | 11227194 |
| quickfix-native/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804218 / 972554 | 5767168 |
| quickfix-native/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972486 / 10804217 | 11227193 |
| quickfix-native/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 10804217 / 972486 | 5767168 |
| quickfix-native/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060860 / 9424818 | 9847794 |
| quickfix-native/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060860 | 67093632 |
| quickfix-native/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060949 / 9424818 | 9847794 |
| quickfix-native/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060949 | 67093632 |
| quickfix-native/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060878 / 9424815 | 9847791 |
| quickfix-native/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424815 / 19060878 | 67093632 |
| quickfix-native/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060866 / 9424817 | 9847793 |
| quickfix-native/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424817 / 19060866 | 67093632 |
| quickfix-native/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060920 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060920 | 67093632 |
| quickfix-native/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 19060868 / 9424818 | 9847794 |
| quickfix-native/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 9424818 / 19060868 | 67093632 |
| quickfix-native/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4429 / 2205 | 979119 / 380859 | 804219 |
| quickfix-native/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4430 | 380859 / 979331 | 5767168 |
| quickfix-native/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4434 / 2205 | 980307 / 380861 | 804221 |
| quickfix-native/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4435 | 380861 / 980520 | 5767168 |
| quickfix-native/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4444 / 2205 | 982808 / 380861 | 804221 |
| quickfix-native/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2205 / 4445 | 380861 / 983021 | 5767168 |
| quickfix-native/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972452 / 380618 | 803594 |
| quickfix-native/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380618 / 972452 | 5767168 |
| quickfix-native/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972396 / 380617 | 803593 |
| quickfix-native/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972396 | 5767168 |
| quickfix-native/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4403 / 2203 | 972469 / 380617 | 803593 |
| quickfix-native/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4403 | 380617 / 972469 | 5767168 |
| quickfix-quickfix/scalar/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/groups/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/binary/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/replay/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4411 / 2203 | 953615 / 380573 | 803549 |
| quickfix-quickfix/replay/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4412 | 380573 / 953823 | 1673272 |
| quickfix-quickfix/replay/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4433 / 2203 | 959123 / 380573 | 803549 |
| quickfix-quickfix/replay/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4434 | 380573 / 959331 | 1673272 |
| quickfix-quickfix/replay/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4440 / 2203 | 960862 / 380573 | 803549 |
| quickfix-quickfix/replay/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4441 | 380573 / 961070 | 1673272 |
| quickfix-quickfix/overload/tcp/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tcp/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tcp/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tcp/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tcp/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tcp/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/scalar/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/scalar/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/groups/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/groups/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 10804074 | 11226858 |
| quickfix-quickfix/groups/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 10804074 / 951309 | 1673272 |
| quickfix-quickfix/binary/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/binary/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/binary/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/fragmentation/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 19039709 / 9424674 | 9847458 |
| quickfix-quickfix/fragmentation/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 9424674 / 19039709 | 18511928 |
| quickfix-quickfix/replay/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4529 / 2203 | 983164 / 380573 | 803549 |
| quickfix-quickfix/replay/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4530 | 380573 / 983372 | 1673272 |
| quickfix-quickfix/replay/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4421 / 2203 | 956120 / 380573 | 803549 |
| quickfix-quickfix/replay/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4422 | 380573 / 956328 | 1673272 |
| quickfix-quickfix/replay/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4431 / 2203 | 958621 / 380573 | 803549 |
| quickfix-quickfix/replay/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2203 / 4432 | 380573 / 958829 | 1673272 |
| quickfix-quickfix/overload/tls/1 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tls/1 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tls/2 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tls/2 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |
| quickfix-quickfix/overload/tls/3 / client / 1 | 2000 / 2000 / 2000 | 2000 / 4000 | 0 / 64 | 4402 / 2202 | 951309 / 380474 | 803258 |
| quickfix-quickfix/overload/tls/3 / server / 1 | 2200 / 2200 / 2200 | 2200 / 4400 | 0 / 0 | 2202 / 4402 | 380474 / 951309 | 1673272 |

## Per-session latency and retention

All latency entries are ns, in p50 / p95 / p99 / p99.9 / max order.

| Case / session | Ack | Terminal | Scheduling delay | Intended ack | Intended terminal | Client retained bytes | Client wire B/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / 1 | 2326842 / 2440505 / 2499569 / 2509601 / 2511970 | 2340079 / 2456995 / 2512219 / 2523409 / 2524294 | 0 / 0 / 0 / 0 / 0 | 2326842 / 2440505 / 2499569 / 2509601 / 2511970 | 2340079 / 2456995 / 2512219 / 2523409 / 2524294 | 3097600 | 5183930.096 |
| native-native/scalar/tcp/2 / 1 | 2221584 / 2376300 / 2494464 / 2537291 / 2545213 | 2235249 / 2391746 / 2514318 / 2554644 / 2572842 | 0 / 0 / 0 / 0 / 0 | 2221584 / 2376300 / 2494464 / 2537291 / 2545213 | 2235249 / 2391746 / 2514318 / 2554644 / 2572842 | 3097600 | 5378787.175 |
| native-native/scalar/tcp/3 / 1 | 2024475 / 2223870 / 2287241 / 2341439 / 2350891 | 2036681 / 2240138 / 2297572 / 2357779 / 2364398 | 0 / 0 / 0 / 0 / 0 | 2024475 / 2223870 / 2287241 / 2341439 / 2350891 | 2036681 / 2240138 / 2297572 / 2357779 / 2364398 | 3097600 | 5390977.976 |
| native-native/groups/tcp/1 / 1 | 11701925 / 20794269 / 20918290 / 21276395 / 21572917 | 11712446 / 20803127 / 20927971 / 21285845 / 21580159 | 0 / 0 / 0 / 0 / 0 | 11701925 / 20794269 / 20918290 / 21276395 / 21572917 | 11712446 / 20803127 / 20927971 / 21285845 / 21580159 | 39142400 | 15874056.658 |
| native-native/groups/tcp/2 / 1 | 11412583 / 21279037 / 21445749 / 21603387 / 21705761 | 11422155 / 21291097 / 21467020 / 21611345 / 21733676 | 0 / 0 / 0 / 0 / 0 | 11412583 / 21279037 / 21445749 / 21603387 / 21705761 | 11422155 / 21291097 / 21467020 / 21611345 / 21733676 | 39142400 | 15674549.147 |
| native-native/groups/tcp/3 / 1 | 11356008 / 20662856 / 20907012 / 21360530 / 21692626 | 11367547 / 20674145 / 20915770 / 21369147 / 21702470 | 0 / 0 / 0 / 0 / 0 | 11356008 / 20662856 / 20907012 / 21360530 / 21692626 | 11367547 / 20674145 / 20915770 / 21369147 / 21702470 | 39142400 | 16064741.153 |
| native-native/binary/tcp/1 / 1 | 5397734 / 5752667 / 5845102 / 6130612 / 6198202 | 5429712 / 5786721 / 5875914 / 6161135 / 6235630 | 0 / 0 / 0 / 0 / 0 | 5397734 / 5752667 / 5845102 / 6130612 / 6198202 | 5429712 / 5786721 / 5875914 / 6161135 / 6235630 | 39142400 | 75187212.194 |
| native-native/binary/tcp/2 / 1 | 6407212 / 6780655 / 6871878 / 7014168 / 7023728 | 6446378 / 6818618 / 6909120 / 7054352 / 7062145 | 0 / 0 / 0 / 0 / 0 | 6407212 / 6780655 / 6871878 / 7014168 / 7023728 | 6446378 / 6818618 / 6909120 / 7054352 / 7062145 | 39142400 | 68960841.057 |
| native-native/binary/tcp/3 / 1 | 5489735 / 6290068 / 6365497 / 6415595 / 6420750 | 5525556 / 6327667 / 6401268 / 6455924 / 6456801 | 0 / 0 / 0 / 0 / 0 | 5489735 / 6290068 / 6365497 / 6415595 / 6420750 | 5525556 / 6327667 / 6401268 / 6455924 / 6456801 | 39142400 | 72278418.384 |
| native-native/fragmentation/tcp/1 / 1 | 23124444 / 27827904 / 35785343 / 37210212 / 37220188 | 23161481 / 27860920 / 35829496 / 37238341 / 37250666 | 0 / 0 / 0 / 0 / 0 | 23124444 / 27827904 / 35785343 / 37210212 / 37220188 | 23161481 / 27860920 / 35829496 / 37238341 / 37250666 | 39142400 | 26446581.201 |
| native-native/fragmentation/tcp/2 / 1 | 22133404 / 27664818 / 32663336 / 32937321 / 32967370 | 22159512 / 27702132 / 32705737 / 32982363 / 33007184 | 0 / 0 / 0 / 0 / 0 | 22133404 / 27664818 / 32663336 / 32937321 / 32967370 | 22159512 / 27702132 / 32705737 / 32982363 / 33007184 | 39142400 | 27284228.159 |
| native-native/fragmentation/tcp/3 / 1 | 23047423 / 28928040 / 41165260 / 41426471 / 41485151 | 23082796 / 28955207 / 41195972 / 41449951 / 41515538 | 0 / 0 / 0 / 0 / 0 | 23047423 / 28928040 / 41165260 / 41426471 / 41485151 | 23082796 / 28955207 / 41195972 / 41449951 / 41515538 | 39142400 | 26465123.931 |
| native-native/replay/tcp/1 / 1 | 3146293 / 3563885 / 3727983 / 4055048 / 4082901 | 3160244 / 3575234 / 3747145 / 4067033 / 4095641 | 0 / 0 / 0 / 0 / 0 | 3146293 / 3563885 / 3727983 / 4055048 / 4082901 | 3160244 / 3575234 / 3747145 / 4067033 / 4095641 | 3097600 | 3957080.308 |
| native-native/replay/tcp/2 / 1 | 3134500 / 3530337 / 3809221 / 4518883 / 4575822 | 3150352 / 3544155 / 3821023 / 4534603 / 4588571 | 0 / 0 / 0 / 0 / 0 | 3134500 / 3530337 / 3809221 / 4518883 / 4575822 | 3150352 / 3544155 / 3821023 / 4534603 / 4588571 | 3097600 | 3912854.109 |
| native-native/replay/tcp/3 / 1 | 3144417 / 3653088 / 4152439 / 4276058 / 4286568 | 3157312 / 3664243 / 4157823 / 4280253 / 4291968 | 0 / 0 / 0 / 0 / 0 | 3144417 / 3653088 / 4152439 / 4276058 / 4286568 | 3157312 / 3664243 / 4157823 / 4280253 / 4291968 | 3097600 | 3873785.638 |
| native-native/overload/tcp/1 / 1 | 2335323 / 2475517 / 2683289 / 2725242 / 2726968 | 2348168 / 2491042 / 2696964 / 2737295 / 2742546 | 34236421 / 66113835 / 69333130 / 69889708 / 69951966 | 36522363 / 68828193 / 71353201 / 71948551 / 72018204 | 36533308 / 68839277 / 71365586 / 71972227 / 72029341 | 3097600 | 5219315.526 |
| native-native/overload/tcp/2 / 1 | 2031893 / 2157102 / 2402706 / 2437455 / 2441903 | 2043376 / 2169226 / 2416670 / 2448167 / 2452367 | 30326520 / 57640369 / 60051222 / 60567195 / 60617620 | 32459895 / 59667684 / 61424563 / 61639670 / 61663052 | 32471039 / 59679893 / 61433000 / 61645545 / 61668976 | 3097600 | 5549083.359 |
| native-native/overload/tcp/3 / 1 | 2295759 / 2583901 / 2755801 / 2763833 / 2766727 | 2309521 / 2595227 / 2768762 / 2777516 / 2780348 | 33672374 / 66061825 / 68778773 / 69443428 / 69521101 | 35983233 / 68279239 / 70893019 / 71454696 / 71549308 | 35994200 / 68289820 / 70909298 / 71472448 / 71559336 | 3097600 | 5168136.870 |
| native-native/scalar/tls/1 / 1 | 3495039 / 3862020 / 4177417 / 4381949 / 4402674 | 3521714 / 3889201 / 4216154 / 4399580 / 4415599 | 0 / 0 / 0 / 0 / 0 | 3495039 / 3862020 / 4177417 / 4381949 / 4402674 | 3521714 / 3889201 / 4216154 / 4399580 / 4415599 | 3097600 | 3859686.189 |
| native-native/scalar/tls/2 / 1 | 3755286 / 4262787 / 4443015 / 4543520 / 4595916 | 3781723 / 4289076 / 4477813 / 4570672 / 4629950 | 0 / 0 / 0 / 0 / 0 | 3755286 / 4262787 / 4443015 / 4543520 / 4595916 | 3781723 / 4289076 / 4477813 / 4570672 / 4629950 | 3097600 | 3772175.602 |
| native-native/scalar/tls/3 / 1 | 3511724 / 4025623 / 4105863 / 4236563 / 4303530 | 3539478 / 4052183 / 4136662 / 4287454 / 4324763 | 0 / 0 / 0 / 0 / 0 | 3511724 / 4025623 / 4105863 / 4236563 / 4303530 | 3539478 / 4052183 / 4136662 / 4287454 / 4324763 | 3097600 | 3914151.139 |
| native-native/groups/tls/1 / 1 | 11411520 / 21780492 / 22012284 / 22202437 / 22699556 | 11425349 / 21801820 / 22025637 / 22212466 / 22708143 | 0 / 0 / 0 / 0 / 0 | 11411520 / 21780492 / 22012284 / 22202437 / 22699556 | 11425349 / 21801820 / 22025637 / 22212466 / 22708143 | 39142400 | 15541757.552 |
| native-native/groups/tls/2 / 1 | 10766142 / 21344958 / 21558252 / 21766964 / 21807762 | 10780406 / 21361929 / 21576223 / 21775644 / 21816040 | 0 / 0 / 0 / 0 / 0 | 10766142 / 21344958 / 21558252 / 21766964 / 21807762 | 10780406 / 21361929 / 21576223 / 21775644 / 21816040 | 39142400 | 15811622.172 |
| native-native/groups/tls/3 / 1 | 10871284 / 21222963 / 21635925 / 21969186 / 22326999 | 10881383 / 21242926 / 21657337 / 21980086 / 22336326 | 0 / 0 / 0 / 0 / 0 | 10871284 / 21222963 / 21635925 / 21969186 / 22326999 | 10881383 / 21242926 / 21657337 / 21980086 / 22336326 | 39142400 | 15771942.912 |
| native-native/binary/tls/1 / 1 | 5886390 / 6441984 / 6988113 / 7167103 / 7212195 | 5925107 / 6497993 / 7019069 / 7224292 / 7226459 | 0 / 0 / 0 / 0 / 0 | 5886390 / 6441984 / 6988113 / 7167103 / 7212195 | 5925107 / 6497993 / 7019069 / 7224292 / 7226459 | 39142400 | 64711433.647 |
| native-native/binary/tls/2 / 1 | 6158077 / 6548138 / 6667387 / 6770132 / 6799760 | 6196940 / 6590956 / 6709892 / 6783544 / 6821252 | 0 / 0 / 0 / 0 / 0 | 6158077 / 6548138 / 6667387 / 6770132 / 6799760 | 6196940 / 6590956 / 6709892 / 6783544 / 6821252 | 39142400 | 63884075.023 |
| native-native/binary/tls/3 / 1 | 5769193 / 6141792 / 6324519 / 6389563 / 6439841 | 5808109 / 6180499 / 6365961 / 6416592 / 6461862 | 0 / 0 / 0 / 0 / 0 | 5769193 / 6141792 / 6324519 / 6389563 / 6439841 | 5808109 / 6180499 / 6365961 / 6416592 / 6461862 | 39142400 | 64501637.660 |
| native-native/fragmentation/tls/1 / 1 | 34725889 / 42749817 / 44116658 / 44399096 / 44404425 | 34748699 / 42770484 / 44134588 / 44417241 / 44422713 | 0 / 0 / 0 / 0 / 0 | 34725889 / 42749817 / 44116658 / 44399096 / 44404425 | 34748699 / 42770484 / 44134588 / 44417241 / 44422713 | 39142400 | 18126107.630 |
| native-native/fragmentation/tls/2 / 1 | 32217631 / 43505097 / 50045350 / 56714069 / 56739340 | 32239600 / 43535618 / 50066342 / 56738795 / 56757846 | 0 / 0 / 0 / 0 / 0 | 32217631 / 43505097 / 50045350 / 56714069 / 56739340 | 32239600 / 43535618 / 50066342 / 56738795 / 56757846 | 39142400 | 18625612.546 |
| native-native/fragmentation/tls/3 / 1 | 34974923 / 43495309 / 59208112 / 59479011 / 59482940 | 34998188 / 43519233 / 59227751 / 59498226 / 59505881 | 0 / 0 / 0 / 0 / 0 | 34974923 / 43495309 / 59208112 / 59479011 / 59482940 | 34998188 / 43519233 / 59227751 / 59498226 / 59505881 | 39142400 | 18182109.637 |
| native-native/replay/tls/1 / 1 | 3820297 / 4549230 / 4901998 / 5620288 / 5699281 | 3838680 / 4571371 / 4921725 / 5636618 / 5711163 | 0 / 0 / 0 / 0 / 0 | 3820297 / 4549230 / 4901998 / 5620288 / 5699281 | 3838680 / 4571371 / 4921725 / 5636618 / 5711163 | 3097600 | 3185173.715 |
| native-native/replay/tls/2 / 1 | 3737208 / 4665842 / 5458363 / 5869335 / 6321109 | 3757870 / 4679756 / 5484619 / 5875931 / 6340577 | 0 / 0 / 0 / 0 / 0 | 3737208 / 4665842 / 5458363 / 5869335 / 6321109 | 3757870 / 4679756 / 5484619 / 5875931 / 6340577 | 3097600 | 3238792.776 |
| native-native/replay/tls/3 / 1 | 4055939 / 5099953 / 5410257 / 6401806 / 6460523 | 4076646 / 5118569 / 5422536 / 6429355 / 6477312 | 0 / 0 / 0 / 0 / 0 | 4055939 / 5099953 / 5410257 / 6401806 / 6460523 | 4076646 / 5118569 / 5422536 / 6429355 / 6477312 | 3097600 | 3098842.246 |
| native-native/overload/tls/1 / 1 | 3555310 / 3728526 / 3887144 / 3919822 / 3936268 | 3582560 / 3755269 / 3919603 / 3944898 / 3964912 | 52076822 / 101304477 / 105736576 / 106813234 / 107072724 | 55659102 / 104925166 / 108848113 / 109699607 / 109830764 | 55707221 / 104932397 / 108883306 / 109716980 / 109857442 | 3097600 | 3898032.300 |
| native-native/overload/tls/2 / 1 | 3549434 / 3929507 / 3999012 / 4092578 / 4096540 | 3575842 / 3962080 / 4026648 / 4118210 / 4124516 | 52182762 / 103126767 / 107723298 / 108781978 / 108879673 | 56006955 / 106828674 / 110910689 / 111773470 / 111861139 | 56019655 / 106844336 / 110930821 / 111793265 / 111872164 | 3097600 | 3892762.848 |
| native-native/overload/tls/3 / 1 | 3529951 / 3728036 / 3856002 / 3935221 / 3957643 | 3558505 / 3755560 / 3867641 / 3966324 / 3979355 | 52049418 / 100318204 / 104981016 / 106093123 / 106188710 | 55592141 / 104051649 / 108149284 / 108902282 / 108994347 | 55621479 / 104064321 / 108156758 / 108923798 / 109005740 | 3097600 | 3876937.973 |
| native-quickfix/scalar/tcp/1 / 1 | 2980693 / 3152034 / 3190104 / 3214470 / 3228700 | 3003204 / 3174141 / 3206454 / 3231190 / 3236585 | 0 / 0 / 0 / 0 / 0 | 2980693 / 3152034 / 3190104 / 3214470 / 3228700 | 3003204 / 3174141 / 3206454 / 3231190 / 3236585 | 3097600 | 3647621.652 |
| native-quickfix/scalar/tcp/2 / 1 | 4058142 / 4231134 / 4295904 / 4317631 / 4336642 | 4089138 / 4266661 / 4331730 / 4357964 / 4383976 | 0 / 0 / 0 / 0 / 0 | 4058142 / 4231134 / 4295904 / 4317631 / 4336642 | 4089138 / 4266661 / 4331730 / 4357964 / 4383976 | 3097600 | 3325870.231 |
| native-quickfix/scalar/tcp/3 / 1 | 3020938 / 3171868 / 4102227 / 4338528 / 4353947 | 3045820 / 3200211 / 4124658 / 4362962 / 4383358 | 0 / 0 / 0 / 0 / 0 | 3020938 / 3171868 / 4102227 / 4338528 / 4353947 | 3045820 / 3200211 / 4124658 / 4362962 / 4383358 | 3097600 | 3539770.224 |
| native-quickfix/groups/tcp/1 / 1 | 34861909 / 48490419 / 48943194 / 52963998 / 53715756 | 34883645 / 48509804 / 48951722 / 52979063 / 53743090 | 0 / 0 / 0 / 0 / 0 | 34861909 / 48490419 / 48943194 / 52963998 / 53715756 | 34883645 / 48509804 / 48951722 / 52979063 / 53743090 | 39142400 | 7131767.610 |
| native-quickfix/groups/tcp/2 / 1 | 36120203 / 49772085 / 50684271 / 53256541 / 53977251 | 36140015 / 49781703 / 50709374 / 53269755 / 53989460 | 0 / 0 / 0 / 0 / 0 | 36120203 / 49772085 / 50684271 / 53256541 / 53977251 | 36140015 / 49781703 / 50709374 / 53269755 / 53989460 | 39142400 | 7123825.278 |
| native-quickfix/groups/tcp/3 / 1 | 38521851 / 48159606 / 49209896 / 53461865 / 53702063 | 38537612 / 48169476 / 49247468 / 53478568 / 53712354 | 0 / 0 / 0 / 0 / 0 | 38521851 / 48159606 / 49209896 / 53461865 / 53702063 | 38537612 / 48169476 / 49247468 / 53478568 / 53712354 | 39142400 | 6769609.109 |
| native-quickfix/binary/tcp/1 / 1 | 7248157 / 7602422 / 7705441 / 7772420 / 7793096 | 7289726 / 7644455 / 7747311 / 7802365 / 7816997 | 0 / 0 / 0 / 0 / 0 | 7248157 / 7602422 / 7705441 / 7772420 / 7793096 | 7289726 / 7644455 / 7747311 / 7802365 / 7816997 | 39142400 | 51097895.865 |
| native-quickfix/binary/tcp/2 / 1 | 8353030 / 8935904 / 10013736 / 10465103 / 10639394 | 8406977 / 8990208 / 10038004 / 10489732 / 10662607 | 0 / 0 / 0 / 0 / 0 | 8353030 / 8935904 / 10013736 / 10465103 / 10639394 | 8406977 / 8990208 / 10038004 / 10489732 / 10662607 | 39142400 | 47362823.505 |
| native-quickfix/binary/tcp/3 / 1 | 8462107 / 8813533 / 9877639 / 10140859 / 10171431 | 8509964 / 8860096 / 9925817 / 10183253 / 10237726 | 0 / 0 / 0 / 0 / 0 | 8462107 / 8813533 / 9877639 / 10140859 / 10171431 | 8509964 / 8860096 / 9925817 / 10183253 / 10237726 | 39142400 | 48496700.867 |
| native-quickfix/fragmentation/tcp/1 / 1 | 19530401 / 20888845 / 27777241 / 30534710 / 30561973 | 19557780 / 20925304 / 27805691 / 30566592 / 30595251 | 0 / 0 / 0 / 0 / 0 | 19530401 / 20888845 / 27777241 / 30534710 / 30561973 | 19557780 / 20925304 / 27805691 / 30566592 / 30595251 | 39142400 | 27703479.109 |
| native-quickfix/fragmentation/tcp/2 / 1 | 21547057 / 22322041 / 29735427 / 29887947 / 29894908 | 21583923 / 22369446 / 29774403 / 29919858 / 29931252 | 0 / 0 / 0 / 0 / 0 | 21547057 / 22322041 / 29735427 / 29887947 / 29894908 | 21583923 / 22369446 / 29774403 / 29919858 / 29931252 | 39142400 | 25462353.016 |
| native-quickfix/fragmentation/tcp/3 / 1 | 21741511 / 24743304 / 29831868 / 30098178 / 30114599 | 21783526 / 24766965 / 29870668 / 30129924 / 30147789 | 0 / 0 / 0 / 0 / 0 | 21741511 / 24743304 / 29831868 / 30098178 / 30114599 | 21783526 / 24766965 / 29870668 / 30129924 / 30147789 | 39142400 | 25715263.934 |
| native-quickfix/replay/tcp/1 / 1 | 3572713 / 5074615 / 5992216 / 6750069 / 6788930 | 3593599 / 5112156 / 6008656 / 6762523 / 6804562 | 0 / 0 / 0 / 0 / 0 | 3572713 / 5074615 / 5992216 / 6750069 / 6788930 | 3593599 / 5112156 / 6008656 / 6762523 / 6804562 | 3097600 | 2898506.901 |
| native-quickfix/replay/tcp/2 / 1 | 4330961 / 4508631 / 4566228 / 4612959 / 4618508 | 4358367 / 4538347 / 4597572 / 4640563 / 4653462 | 0 / 0 / 0 / 0 / 0 | 4330961 / 4508631 / 4566228 / 4612959 / 4618508 | 4358367 / 4538347 / 4597572 / 4640563 / 4653462 | 3097600 | 2850381.518 |
| native-quickfix/replay/tcp/3 / 1 | 4086781 / 4298823 / 4838395 / 5369002 / 5459553 | 4111555 / 4344501 / 4883720 / 5409970 / 5533928 | 0 / 0 / 0 / 0 / 0 | 4086781 / 4298823 / 4838395 / 5369002 / 5459553 | 4111555 / 4344501 / 4883720 / 5409970 / 5533928 | 3097600 | 2873205.451 |
| native-quickfix/overload/tcp/1 / 1 | 3251052 / 3949426 / 4139169 / 4185571 / 4193692 | 3275220 / 3975182 / 4163367 / 4209335 / 4245837 | 45833554 / 97719707 / 102864074 / 104046586 / 104150394 | 48889676 / 101888948 / 106526718 / 107507110 / 107629841 | 48912607 / 101901829 / 106553995 / 107542049 / 107659510 | 3097600 | 3420091.776 |
| native-quickfix/overload/tcp/2 / 1 | 3738035 / 3881488 / 3915181 / 3936602 / 3950341 | 3765882 / 3908471 / 3944996 / 3965305 / 3970701 | 55290428 / 106349114 / 110198385 / 111071672 / 111180733 | 59035531 / 109488091 / 113128743 / 113879568 / 113967268 | 59051874 / 109509356 / 113162758 / 113909215 / 113998966 | 3097600 | 3350986.020 |
| native-quickfix/overload/tcp/3 / 1 | 3067768 / 4666604 / 4718818 / 4746054 / 4764249 | 3090367 / 4697326 / 4752544 / 4782278 / 4798090 | 44101163 / 99481143 / 103444146 / 104298725 / 104392668 | 47056779 / 102742449 / 106453392 / 107200185 / 107289052 | 47077976 / 102749330 / 106474679 / 107227647 / 107309660 | 3097600 | 3433463.659 |
| native-quickfix/scalar/tls/1 / 1 | 4281701 / 4518090 / 4626381 / 5089470 / 5194225 | 4311118 / 4550091 / 4657480 / 5098040 / 5213498 | 0 / 0 / 0 / 0 / 0 | 4281701 / 4518090 / 4626381 / 5089470 / 5194225 | 4311118 / 4550091 / 4657480 / 5098040 / 5213498 | 3097600 | 2701862.506 |
| native-quickfix/scalar/tls/2 / 1 | 3639174 / 4519689 / 4614902 / 4703828 / 4740521 | 3667432 / 4549156 / 4648953 / 4726656 / 4762059 | 0 / 0 / 0 / 0 / 0 | 3639174 / 4519689 / 4614902 / 4703828 / 4740521 | 3667432 / 4549156 / 4648953 / 4726656 / 4762059 | 3097600 | 2809830.439 |
| native-quickfix/scalar/tls/3 / 1 | 4392057 / 4620617 / 4866511 / 5002910 / 5009468 | 4423784 / 4653373 / 4902724 / 5034854 / 5044814 | 0 / 0 / 0 / 0 / 0 | 4392057 / 4620617 / 4866511 / 5002910 / 5009468 | 4423784 / 4653373 / 4902724 / 5034854 / 5044814 | 3097600 | 2699848.435 |
| native-quickfix/groups/tls/1 / 1 | 41730354 / 50051101 / 51804875 / 55495363 / 56482824 | 41766730 / 50076294 / 51864692 / 55572285 / 56557035 | 0 / 0 / 0 / 0 / 0 | 41730354 / 50051101 / 51804875 / 55495363 / 56482824 | 41766730 / 50076294 / 51864692 / 55572285 / 56557035 | 39142400 | 6225199.348 |
| native-quickfix/groups/tls/2 / 1 | 35684226 / 49256847 / 49704733 / 54055297 / 54915595 | 35707968 / 49279094 / 49714354 / 54078167 / 54935467 | 0 / 0 / 0 / 0 / 0 | 35684226 / 49256847 / 49704733 / 54055297 / 54915595 | 35707968 / 49279094 / 49714354 / 54078167 / 54935467 | 39142400 | 6774307.889 |
| native-quickfix/groups/tls/3 / 1 | 39857001 / 56561192 / 57475636 / 61166244 / 61639230 | 39898013 / 56619942 / 57516096 / 61271131 / 61690045 | 0 / 0 / 0 / 0 / 0 | 39857001 / 56561192 / 57475636 / 61166244 / 61639230 | 39898013 / 56619942 / 57516096 / 61271131 / 61690045 | 39142400 | 6158653.374 |
| native-quickfix/binary/tls/1 / 1 | 9054057 / 9732183 / 11439549 / 11848658 / 11959662 | 9120393 / 9806580 / 11508431 / 11912629 / 12003754 | 0 / 0 / 0 / 0 / 0 | 9054057 / 9732183 / 11439549 / 11848658 / 11959662 | 9120393 / 9806580 / 11508431 / 11912629 / 12003754 | 39142400 | 41731951.053 |
| native-quickfix/binary/tls/2 / 1 | 9684599 / 10093507 / 10416096 / 10470447 / 10591418 | 9740841 / 10154271 / 10474009 / 10525393 / 10625017 | 0 / 0 / 0 / 0 / 0 | 9684599 / 10093507 / 10416096 / 10470447 / 10591418 | 9740841 / 10154271 / 10474009 / 10525393 / 10625017 | 39142400 | 23587203.368 |
| native-quickfix/binary/tls/3 / 1 | 7886549 / 9700272 / 10002186 / 10329926 / 10408458 | 7936137 / 9764737 / 10055769 / 10414833 / 10462702 | 0 / 0 / 0 / 0 / 0 | 7886549 / 9700272 / 10002186 / 10329926 / 10408458 | 7936137 / 9764737 / 10055769 / 10414833 / 10462702 | 39142400 | 24176933.301 |
| native-quickfix/fragmentation/tls/1 / 1 | 30924424 / 42396037 / 44689052 / 50407587 / 50433227 | 30975243 / 42434482 / 44721270 / 50439586 / 50468410 | 0 / 0 / 0 / 0 / 0 | 30924424 / 42396037 / 44689052 / 50407587 / 50433227 | 30975243 / 42434482 / 44721270 / 50439586 / 50468410 | 39142400 | 18448871.510 |
| native-quickfix/fragmentation/tls/2 / 1 | 30880478 / 32953866 / 35508790 / 47054060 / 47149997 | 30930646 / 33000642 / 35531609 / 47072769 / 47167164 | 0 / 0 / 0 / 0 / 0 | 30880478 / 32953866 / 35508790 / 47054060 / 47149997 | 30930646 / 33000642 / 35531609 / 47072769 / 47167164 | 39142400 | 18445187.184 |
| native-quickfix/fragmentation/tls/3 / 1 | 28304676 / 37055804 / 44119493 / 51190049 / 51218486 | 28328712 / 37086224 / 44682817 / 51209336 / 51235272 | 0 / 0 / 0 / 0 / 0 | 28304676 / 37055804 / 44119493 / 51190049 / 51218486 | 28328712 / 37086224 / 44682817 / 51209336 / 51235272 | 39142400 | 19472115.736 |
| native-quickfix/replay/tls/1 / 1 | 3965299 / 4276842 / 5029617 / 5800701 / 5826250 | 3994124 / 4295130 / 5044519 / 5809718 / 5841817 | 0 / 0 / 0 / 0 / 0 | 3965299 / 4276842 / 5029617 / 5800701 / 5826250 | 3994124 / 4295130 / 5044519 / 5809718 / 5841817 | 3097600 | 2467961.411 |
| native-quickfix/replay/tls/2 / 1 | 3599738 / 5569165 / 5935881 / 6144059 / 6197044 | 3624910 / 5606654 / 6004838 / 6173047 / 6208056 | 0 / 0 / 0 / 0 / 0 | 3599738 / 5569165 / 5935881 / 6144059 / 6197044 | 3624910 / 5606654 / 6004838 / 6173047 / 6208056 | 3097600 | 2460545.798 |
| native-quickfix/replay/tls/3 / 1 | 4055762 / 4399807 / 4868241 / 5558938 / 5629131 | 4079444 / 4423591 / 4872552 / 5574240 / 5641844 | 0 / 0 / 0 / 0 / 0 | 4055762 / 4399807 / 4868241 / 5558938 / 5629131 | 4079444 / 4423591 / 4872552 / 5574240 / 5641844 | 3097600 | 2402388.679 |
| native-quickfix/overload/tls/1 / 1 | 3755264 / 5022938 / 5121931 / 5147623 / 5157703 | 3779458 / 5055459 / 5157653 / 5175684 / 5195696 | 50515765 / 118290028 / 124606750 / 126125748 / 126260877 | 54467136 / 123414992 / 128550198 / 129463569 / 129553678 | 54510685 / 123451565 / 128556820 / 129480315 / 129593175 | 3097600 | 2760875.148 |
| native-quickfix/overload/tls/2 / 1 | 4881168 / 5464025 / 5551912 / 5579210 / 5602554 | 4919645 / 5499958 / 5584847 / 5616473 / 5619811 | 77681839 / 129882690 / 134532425 / 135590258 / 135706925 | 83022564 / 133680319 / 138048881 / 138988539 / 139089809 | 83051587 / 133701278 / 138086478 / 139014733 / 139113142 | 3097600 | 2639125.868 |
| native-quickfix/overload/tls/3 / 1 | 4266766 / 5065015 / 5171418 / 5260872 / 5348464 | 4295673 / 5097177 / 5204293 / 5301963 / 5370249 | 62833172 / 124401681 / 129168976 / 130156022 / 130260562 | 67028120 / 128308986 / 132365750 / 133277023 / 133363036 | 67059174 / 128336405 / 132392517 / 133294009 / 133396893 | 3097600 | 2754392.456 |
| quickfix-native/scalar/tcp/1 / 1 | 4568484 / 5333510 / 5650466 / 5777236 / 5799534 | 4599436 / 5365739 / 5701074 / 5801070 / 5805864 | 0 / 0 / 0 / 0 / 0 | 4568484 / 5333510 / 5650466 / 5777236 / 5799534 | 4599436 / 5365739 / 5701074 / 5801070 / 5805864 | 803593 | 708784.491 |
| quickfix-native/scalar/tcp/2 / 1 | 5083962 / 5296757 / 5561294 / 5655692 / 5678429 | 5123878 / 5337109 / 5605053 / 5694446 / 5717241 | 0 / 0 / 0 / 0 / 0 | 5083962 / 5296757 / 5561294 / 5655692 / 5678429 | 5123878 / 5337109 / 5605053 / 5694446 / 5717241 | 803593 | 1163395.225 |
| quickfix-native/scalar/tcp/3 / 1 | 5035851 / 5299127 / 5415789 / 5483388 / 5497476 | 5077997 / 5340592 / 5456866 / 5518732 / 5539155 | 0 / 0 / 0 / 0 / 0 | 5035851 / 5299127 / 5415789 / 5483388 / 5497476 | 5077997 / 5340592 / 5456866 / 5518732 / 5539155 | 803593 | 702624.335 |
| quickfix-native/groups/tcp/1 / 1 | 71539569 / 81729362 / 85601102 / 85948255 / 86218963 | 71541451 / 81731393 / 85603482 / 85950005 / 86221340 | 0 / 0 / 0 / 0 / 0 | 71539569 / 81729362 / 85601102 / 85948255 / 86218963 | 71541451 / 81731393 / 85603482 / 85950005 / 86221340 | 11227194 | 3840856.704 |
| quickfix-native/groups/tcp/2 / 1 | 71552394 / 76577682 / 78675153 / 79070341 / 79154778 | 71554448 / 76579908 / 78677616 / 79072627 / 79157507 | 0 / 0 / 0 / 0 / 0 | 71552394 / 76577682 / 78675153 / 79070341 / 79154778 | 71554448 / 76579908 / 78677616 / 79072627 / 79157507 | 11227194 | 3549673.288 |
| quickfix-native/groups/tcp/3 / 1 | 70895128 / 76154790 / 78630334 / 79107450 / 79240845 | 70897415 / 76157110 / 78633047 / 79109451 / 79243002 | 0 / 0 / 0 / 0 / 0 | 70895128 / 76154790 / 78630334 / 79107450 / 79240845 | 70897415 / 76157110 / 78633047 / 79109451 / 79243002 | 11227193 | 3788930.051 |
| quickfix-native/binary/tcp/1 / 1 | 8323917 / 8643379 / 8722533 / 8783731 / 8797418 | 8381525 / 8709022 / 8785467 / 8845095 / 8863031 | 0 / 0 / 0 / 0 / 0 | 8323917 / 8643379 / 8722533 / 8783731 / 8797418 | 8381525 / 8709022 / 8785467 / 8845095 / 8863031 | 9847794 | 17357722.361 |
| quickfix-native/binary/tcp/2 / 1 | 7509894 / 7839361 / 8052389 / 8220387 / 8222045 | 7550287 / 7884764 / 8116365 / 8252394 / 8268892 | 0 / 0 / 0 / 0 / 0 | 7509894 / 7839361 / 8052389 / 8220387 / 8222045 | 7550287 / 7884764 / 8116365 / 8252394 / 8268892 | 9847794 | 16816230.931 |
| quickfix-native/binary/tcp/3 / 1 | 8358301 / 10048303 / 10185209 / 10267935 / 10290456 | 8408978 / 10118470 / 10267626 / 10327831 / 10384255 | 0 / 0 / 0 / 0 / 0 | 8358301 / 10048303 / 10185209 / 10267935 / 10290456 | 8408978 / 10118470 / 10267626 / 10327831 / 10384255 | 9847794 | 18102354.610 |
| quickfix-native/fragmentation/tcp/1 / 1 | 23217294 / 28108659 / 33019615 / 33822645 / 33832229 | 23298952 / 28202686 / 33107401 / 33911971 / 33915826 | 0 / 0 / 0 / 0 / 0 | 23217294 / 28108659 / 33019615 / 33822645 / 33832229 | 23298952 / 28202686 / 33107401 / 33911971 / 33915826 | 9847794 | 14365804.109 |
| quickfix-native/fragmentation/tcp/2 / 1 | 21077002 / 30158332 / 31174155 / 31254526 / 31328820 | 21139021 / 30208218 / 31231635 / 31310239 / 31336415 | 0 / 0 / 0 / 0 / 0 | 21077002 / 30158332 / 31174155 / 31254526 / 31328820 | 21139021 / 30208218 / 31231635 / 31310239 / 31336415 | 9847794 | 18200409.725 |
| quickfix-native/fragmentation/tcp/3 / 1 | 26055722 / 31912827 / 40791252 / 41642100 / 41778126 | 26137234 / 31963109 / 40875627 / 41702663 / 41784824 | 0 / 0 / 0 / 0 / 0 | 26055722 / 31912827 / 40791252 / 41642100 / 41778126 | 26137234 / 31963109 / 40875627 / 41702663 / 41784824 | 9847793 | 13958678.476 |
| quickfix-native/replay/tcp/1 / 1 | 4232794 / 4935486 / 5044253 / 5280837 / 5299998 | 4262751 / 4971257 / 5078051 / 5310108 / 5328594 | 0 / 0 / 0 / 0 / 0 | 4232794 / 4935486 / 5044253 / 5280837 / 5299998 | 4262751 / 4971257 / 5078051 / 5310108 / 5328594 | 804219 | 1116944.146 |
| quickfix-native/replay/tcp/2 / 1 | 3954172 / 5490311 / 6576573 / 6921857 / 6976067 | 3981047 / 5524539 / 6607213 / 6955094 / 7014758 | 0 / 0 / 0 / 0 / 0 | 3954172 / 5490311 / 6576573 / 6921857 / 6976067 | 3981047 / 5524539 / 6607213 / 6955094 / 7014758 | 804219 | 1102556.381 |
| quickfix-native/replay/tcp/3 / 1 | 4392338 / 5229202 / 7103625 / 7561111 / 7607234 | 4415099 / 5271459 / 7166139 / 7598360 / 7662832 | 0 / 0 / 0 / 0 / 0 | 4392338 / 5229202 / 7103625 / 7561111 / 7607234 | 4415099 / 5271459 / 7166139 / 7598360 / 7662832 | 804219 | 691417.883 |
| quickfix-native/overload/tcp/1 / 1 | 3836249 / 5089607 / 5229689 / 5358107 / 5360274 | 3857888 / 5125844 / 5276853 / 5381110 / 5394288 | 62873605 / 116558363 / 121401835 / 122447901 / 122589256 | 66671613 / 120484389 / 125047064 / 126087224 / 126205521 | 66698391 / 120518206 / 125070982 / 126118260 / 126228984 | 803594 | 706134.249 |
| quickfix-native/overload/tcp/2 / 1 | 5122865 / 5411095 / 5558982 / 5624061 / 5647800 | 5158780 / 5444523 / 5593620 / 5669109 / 5675663 | 77142840 / 140449578 / 145274535 / 146300958 / 146444923 | 82212770 / 144388646 / 148992667 / 150010852 / 150136725 | 82249555 / 144421199 / 149011498 / 150038036 / 150166061 | 803594 | 1151445.164 |
| quickfix-native/overload/tcp/3 / 1 | 3857605 / 5293103 / 5387761 / 5492839 / 5523159 | 3884396 / 5337804 / 5434361 / 5533136 / 5564854 | 68423235 / 121958371 / 126692475 / 127710261 / 127843296 | 72487465 / 125807230 / 130510398 / 131511150 / 131617681 | 72508619 / 125852739 / 130534955 / 131532791 / 131647650 | 803593 | 684255.067 |
| quickfix-native/scalar/tls/1 / 1 | 4773024 / 4975304 / 5041861 / 5081099 / 5104720 | 4807153 / 5009320 / 5073019 / 5118286 / 5132880 | 0 / 0 / 0 / 0 / 0 | 4773024 / 4975304 / 5041861 / 5081099 / 5104720 | 4807153 / 5009320 / 5073019 / 5118286 / 5132880 | 803594 | 1137449.316 |
| quickfix-native/scalar/tls/2 / 1 | 5737154 / 6019090 / 6131354 / 6210899 / 6219505 | 5779816 / 6058892 / 6172197 / 6251102 / 6263755 | 0 / 0 / 0 / 0 / 0 | 5737154 / 6019090 / 6131354 / 6210899 / 6219505 | 5779816 / 6058892 / 6172197 / 6251102 / 6263755 | 803593 | 1131828.954 |
| quickfix-native/scalar/tls/3 / 1 | 4707570 / 6667082 / 7230140 / 7486612 / 7528733 | 4746118 / 6716374 / 7286848 / 7536910 / 7578599 | 0 / 0 / 0 / 0 / 0 | 4707570 / 6667082 / 7230140 / 7486612 / 7528733 | 4746118 / 6716374 / 7286848 / 7536910 / 7578599 | 803593 | 712371.196 |
| quickfix-native/groups/tls/1 / 1 | 70685441 / 82040688 / 86800670 / 87207577 / 87423322 | 70687656 / 82043192 / 86803981 / 87211026 / 87426685 | 0 / 0 / 0 / 0 / 0 | 70685441 / 82040688 / 86800670 / 87207577 / 87423322 | 70687656 / 82043192 / 86803981 / 87211026 / 87426685 | 11227194 | 3723000.736 |
| quickfix-native/groups/tls/2 / 1 | 70924139 / 75812477 / 76497125 / 76773129 / 76821987 | 70926270 / 75814474 / 76499251 / 76775143 / 76823853 | 0 / 0 / 0 / 0 / 0 | 70924139 / 75812477 / 76497125 / 76773129 / 76821987 | 70926270 / 75814474 / 76499251 / 76775143 / 76823853 | 11227194 | 3833413.009 |
| quickfix-native/groups/tls/3 / 1 | 76796088 / 82624913 / 83680923 / 84201311 / 84211814 | 76798366 / 82627101 / 83683148 / 84203377 / 84214136 | 0 / 0 / 0 / 0 / 0 | 76796088 / 82624913 / 83680923 / 84201311 / 84211814 | 76798366 / 82627101 / 83683148 / 84203377 / 84214136 | 11227193 | 2911673.526 |
| quickfix-native/binary/tls/1 / 1 | 8983653 / 9202480 / 9273591 / 9358211 / 9367924 | 9047069 / 9266304 / 9340166 / 9394490 / 9396562 | 0 / 0 / 0 / 0 / 0 | 8983653 / 9202480 / 9273591 / 9358211 / 9367924 | 9047069 / 9266304 / 9340166 / 9394490 / 9396562 | 9847794 | 24332809.828 |
| quickfix-native/binary/tls/2 / 1 | 9708245 / 10719614 / 10882046 / 11062331 / 11103900 | 9762847 / 10773703 / 10934673 / 11109977 / 11149855 | 0 / 0 / 0 / 0 / 0 | 9708245 / 10719614 / 10882046 / 11062331 / 11103900 | 9762847 / 10773703 / 10934673 / 11109977 / 11149855 | 9847794 | 25372544.545 |
| quickfix-native/binary/tls/3 / 1 | 9090068 / 10389211 / 10470197 / 10526492 / 10548759 | 9156198 / 10445305 / 10523586 / 10586604 / 10653073 | 0 / 0 / 0 / 0 / 0 | 9090068 / 10389211 / 10470197 / 10526492 / 10548759 | 9156198 / 10445305 / 10523586 / 10586604 / 10653073 | 9847791 | 25133558.562 |
| quickfix-native/fragmentation/tls/1 / 1 | 36801534 / 45910240 / 47756034 / 48531942 / 48589664 | 36877199 / 45985170 / 47764394 / 48548748 / 48648431 | 0 / 0 / 0 / 0 / 0 | 36801534 / 45910240 / 47756034 / 48531942 / 48589664 | 36877199 / 45985170 / 47764394 / 48548748 / 48648431 | 9847793 | 13675193.936 |
| quickfix-native/fragmentation/tls/2 / 1 | 34671613 / 44516619 / 48966628 / 49426640 / 49507951 | 34711736 / 44575828 / 49021960 / 49476356 / 49531155 | 0 / 0 / 0 / 0 / 0 | 34671613 / 44516619 / 48966628 / 49426640 / 49507951 | 34711736 / 44575828 / 49021960 / 49476356 / 49531155 | 9847794 | 14121757.552 |
| quickfix-native/fragmentation/tls/3 / 1 | 36670935 / 46678783 / 50203956 / 53954696 / 54007106 | 36745614 / 46757163 / 50210474 / 54043701 / 54103670 | 0 / 0 / 0 / 0 / 0 | 36670935 / 46678783 / 50203956 / 53954696 / 54007106 | 36745614 / 46757163 / 50210474 / 54043701 / 54103670 | 9847794 | 14006942.452 |
| quickfix-native/replay/tls/1 / 1 | 5400629 / 6270835 / 6464755 / 6498510 / 6518485 | 5430288 / 6313271 / 6503658 / 6546972 / 6552491 | 0 / 0 / 0 / 0 / 0 | 5400629 / 6270835 / 6464755 / 6498510 / 6518485 | 5430288 / 6313271 / 6503658 / 6546972 / 6552491 | 804219 | 718369.388 |
| quickfix-native/replay/tls/2 / 1 | 5152242 / 5354321 / 6604544 / 7098116 / 7175029 | 5191479 / 5393784 / 6635587 / 7134435 / 7208468 | 0 / 0 / 0 / 0 / 0 | 5152242 / 5354321 / 6604544 / 7098116 / 7175029 | 5191479 / 5393784 / 6635587 / 7134435 / 7208468 | 804221 | 1072032.288 |
| quickfix-native/replay/tls/3 / 1 | 6219213 / 8372608 / 8557317 / 8596525 / 8641683 | 6260472 / 8439986 / 8620516 / 8660356 / 8727227 | 0 / 0 / 0 / 0 / 0 | 6219213 / 8372608 / 8557317 / 8596525 / 8641683 | 6260472 / 8439986 / 8620516 / 8660356 / 8727227 | 804221 | 1092547.662 |
| quickfix-native/overload/tls/1 / 1 | 6116889 / 6738446 / 6819421 / 6851541 / 6864700 | 6159138 / 6789232 / 6869234 / 6906150 / 6923134 | 91645658 / 175215604 / 182384159 / 184018291 / 184199933 | 97547584 / 180971797 / 187344299 / 188535193 / 188685951 | 97586016 / 181017270 / 187374323 / 188565891 / 188759206 | 803594 | 741015.208 |
| quickfix-native/overload/tls/2 / 1 | 4996023 / 5183195 / 5289454 / 5330528 / 5343623 | 5027136 / 5218337 / 5320876 / 5357678 / 5366478 | 74924343 / 145046346 / 151218496 / 152607809 / 152745357 | 79926019 / 149990576 / 155883482 / 157060372 / 157192666 | 79957375 / 150026586 / 155916701 / 157093734 / 157223085 | 803593 | 1126631.475 |
| quickfix-native/overload/tls/3 / 1 | 6184003 / 6350975 / 6449609 / 6512322 / 6518557 | 6229911 / 6400385 / 6505113 / 6567329 / 6577311 | 91425720 / 178651198 / 186407796 / 188144778 / 188316650 | 97609085 / 184904241 / 191434370 / 192697821 / 192832351 | 97649095 / 184959367 / 191464012 / 192736485 / 192863365 | 803593 | 1151188.214 |
| quickfix-quickfix/scalar/tcp/1 / 1 | 3596983 / 3864284 / 3940577 / 3972546 / 4012842 | 3619788 / 3891910 / 3971955 / 4001720 / 4039224 | 0 / 0 / 0 / 0 / 0 | 3596983 / 3864284 / 3940577 / 3972546 / 4012842 | 3619788 / 3891910 / 3971955 / 4001720 / 4039224 | 803258 | 644061.251 |
| quickfix-quickfix/scalar/tcp/2 / 1 | 3614635 / 3937163 / 4020797 / 4046133 / 4054855 | 3641319 / 3962826 / 4047651 / 4074260 / 4081561 | 0 / 0 / 0 / 0 / 0 | 3614635 / 3937163 / 4020797 / 4046133 / 4054855 | 3641319 / 3962826 / 4047651 / 4074260 / 4081561 | 803258 | 643465.737 |
| quickfix-quickfix/scalar/tcp/3 / 1 | 4142906 / 4377154 / 4907877 / 5066886 / 5070612 | 4177012 / 4394239 / 4934201 / 5091184 / 5102382 | 0 / 0 / 0 / 0 / 0 | 4142906 / 4377154 / 4907877 / 5066886 / 5070612 | 4177012 / 4394239 / 4934201 / 5091184 / 5102382 | 803258 | 660212.765 |
| quickfix-quickfix/groups/tcp/1 / 1 | 75725582 / 80796813 / 81664720 / 82049400 / 82131355 | 75728691 / 80800008 / 81667700 / 82052160 / 82134407 | 0 / 0 / 0 / 0 / 0 | 75725582 / 80796813 / 81664720 / 82049400 / 82131355 | 75728691 / 80800008 / 81667700 / 82052160 / 82134407 | 11226858 | 3777049.001 |
| quickfix-quickfix/groups/tcp/2 / 1 | 69421023 / 74868030 / 76281694 / 76651549 / 76681954 | 69422761 / 74870417 / 76283520 / 76653473 / 76684042 | 0 / 0 / 0 / 0 / 0 | 69421023 / 74868030 / 76281694 / 76651549 / 76681954 | 69422761 / 74870417 / 76283520 / 76653473 / 76684042 | 11226858 | 3566665.877 |
| quickfix-quickfix/groups/tcp/3 / 1 | 69511057 / 74110406 / 74816847 / 75111097 / 75158351 | 69513427 / 74112625 / 74818944 / 75113162 / 75160181 | 0 / 0 / 0 / 0 / 0 | 69511057 / 74110406 / 74816847 / 75111097 / 75158351 | 69513427 / 74112625 / 74818944 / 75113162 / 75160181 | 11226858 | 3563259.726 |
| quickfix-quickfix/binary/tcp/1 / 1 | 8367247 / 9637733 / 9850233 / 9909381 / 9980567 | 8431116 / 9710247 / 9921806 / 9987905 / 10010848 | 0 / 0 / 0 / 0 / 0 | 8367247 / 9637733 / 9850233 / 9909381 / 9980567 | 8431116 / 9710247 / 9921806 / 9987905 / 10010848 | 9847458 | 16459510.948 |
| quickfix-quickfix/binary/tcp/2 / 1 | 8384284 / 9649340 / 9767423 / 10123752 / 10164960 | 8407889 / 9710602 / 9821050 / 10196059 / 10259264 | 0 / 0 / 0 / 0 / 0 | 8384284 / 9649340 / 9767423 / 10123752 / 10164960 | 8407889 / 9710602 / 9821050 / 10196059 / 10259264 | 9847458 | 16924730.993 |
| quickfix-quickfix/binary/tcp/3 / 1 | 9195166 / 9642262 / 9861680 / 10139726 / 10169145 | 9248318 / 9701004 / 9934129 / 10219855 / 10233097 | 0 / 0 / 0 / 0 / 0 | 9195166 / 9642262 / 9861680 / 10139726 / 10169145 | 9248318 / 9701004 / 9934129 / 10219855 / 10233097 | 9847458 | 16890527.087 |
| quickfix-quickfix/fragmentation/tcp/1 / 1 | 22092654 / 25014894 / 27391037 / 32683977 / 32705018 | 22117833 / 25047146 / 27414500 / 32702067 / 32715624 | 0 / 0 / 0 / 0 / 0 | 22092654 / 25014894 / 27391037 / 32683977 / 32705018 | 22117833 / 25047146 / 27414500 / 32702067 / 32715624 | 9847458 | 13211009.650 |
| quickfix-quickfix/fragmentation/tcp/2 / 1 | 24571387 / 30860832 / 31439811 / 31619130 / 31711795 | 24618583 / 30892135 / 31480609 / 31644158 / 31809043 | 0 / 0 / 0 / 0 / 0 | 24571387 / 30860832 / 31439811 / 31619130 / 31711795 | 24618583 / 30892135 / 31480609 / 31644158 / 31809043 | 9847458 | 11999898.653 |
| quickfix-quickfix/fragmentation/tcp/3 / 1 | 19715669 / 27703014 / 30826015 / 31801345 / 31822690 | 19760417 / 27754412 / 30860559 / 31881060 / 31906829 | 0 / 0 / 0 / 0 / 0 | 19715669 / 27703014 / 30826015 / 31801345 / 31822690 | 19760417 / 27754412 / 30860559 / 31881060 / 31906829 | 9847458 | 17677094.765 |
| quickfix-quickfix/replay/tcp/1 / 1 | 4167721 / 4557136 / 4695236 / 5006509 / 5020392 | 4187354 / 4576764 / 4721891 / 5030602 / 5070956 | 0 / 0 / 0 / 0 / 0 | 4167721 / 4557136 / 4695236 / 5006509 / 5020392 | 4187354 / 4576764 / 4721891 / 5030602 / 5070956 | 803549 | 1029800.023 |
| quickfix-quickfix/replay/tcp/2 / 1 | 3576269 / 3728853 / 3805490 / 3845617 / 3854835 | 3590006 / 3737570 / 3820756 / 3855315 / 3858117 | 0 / 0 / 0 / 0 / 0 | 3576269 / 3728853 / 3805490 / 3845617 / 3854835 | 3590006 / 3737570 / 3820756 / 3855315 / 3858117 | 803549 | 652276.277 |
| quickfix-quickfix/replay/tcp/3 / 1 | 3606601 / 6362972 / 7671866 / 8558889 / 8668004 | 3621345 / 6413222 / 7733894 / 8605772 / 8732981 | 0 / 0 / 0 / 0 / 0 | 3606601 / 6362972 / 7671866 / 8558889 / 8668004 | 3621345 / 6413222 / 7733894 / 8605772 / 8732981 | 803549 | 1035137.655 |
| quickfix-quickfix/overload/tcp/1 / 1 | 3659302 / 3771542 / 3851911 / 3886570 / 3891152 | 3686202 / 3799017 / 3880077 / 3909100 / 3916078 | 54190290 / 105263803 / 109743743 / 110699433 / 110813059 | 57865594 / 108863473 / 113181652 / 114188665 / 114298803 | 57888544 / 108891325 / 113204848 / 114215364 / 114330729 | 803258 | 641311.388 |
| quickfix-quickfix/overload/tcp/2 / 1 | 3497570 / 3765783 / 3962512 / 3987422 / 4011461 | 3511874 / 3780310 / 3977675 / 4001313 / 4013300 | 51380999 / 100563870 / 104863245 / 105895434 / 106003229 | 55257860 / 104018858 / 108288062 / 109285654 / 109388055 | 55275844 / 104040525 / 108311537 / 109312527 / 109415726 | 803258 | 666117.449 |
| quickfix-quickfix/overload/tcp/3 / 1 | 4144657 / 5006859 / 5120927 / 5223015 / 5240142 | 4176535 / 5039128 / 5153721 / 5255124 / 5271917 | 64677385 / 119209814 / 124686906 / 125839605 / 125962027 | 68218714 / 123623501 / 128456232 / 129375483 / 129467838 | 68248513 / 123660010 / 128482755 / 129398933 / 129497580 | 803258 | 1063124.918 |
| quickfix-quickfix/scalar/tls/1 / 1 | 4686716 / 5166952 / 5576210 / 5813263 / 5866047 | 4723438 / 5196089 / 5611200 / 5854816 / 5898253 | 0 / 0 / 0 / 0 / 0 | 4686716 / 5166952 / 5576210 / 5813263 / 5866047 | 4723438 / 5196089 / 5611200 / 5854816 / 5898253 | 803258 | 661287.808 |
| quickfix-quickfix/scalar/tls/2 / 1 | 4404094 / 5973327 / 6078807 / 6108980 / 6133107 | 4439047 / 6011940 / 6114876 / 6144980 / 6154747 | 0 / 0 / 0 / 0 / 0 | 4404094 / 5973327 / 6078807 / 6108980 / 6133107 | 4439047 / 6011940 / 6114876 / 6144980 / 6154747 | 803258 | 1043871.617 |
| quickfix-quickfix/scalar/tls/3 / 1 | 4484110 / 6854362 / 7126910 / 7229560 / 7292214 | 4521370 / 6911436 / 7159786 / 7265315 / 7295620 | 0 / 0 / 0 / 0 / 0 | 4484110 / 6854362 / 7126910 / 7229560 / 7292214 | 4521370 / 6911436 / 7159786 / 7265315 / 7295620 | 803258 | 1029925.175 |
| quickfix-quickfix/groups/tls/1 / 1 | 71614341 / 76737532 / 78854577 / 79635573 / 79689699 | 71616325 / 76739452 / 78856344 / 79637536 / 79691885 | 0 / 0 / 0 / 0 / 0 | 71614341 / 76737532 / 78854577 / 79635573 / 79689699 | 71616325 / 76739452 / 78856344 / 79637536 / 79691885 | 11226858 | 3835411.301 |
| quickfix-quickfix/groups/tls/2 / 1 | 73020916 / 83602822 / 85445335 / 86604539 / 86675530 | 73022909 / 83604808 / 85447828 / 86607421 / 86677773 | 0 / 0 / 0 / 0 / 0 | 73020916 / 83602822 / 85445335 / 86604539 / 86675530 | 73022909 / 83604808 / 85447828 / 86607421 / 86677773 | 11226858 | 2769992.667 |
| quickfix-quickfix/groups/tls/3 / 1 | 73322606 / 78089787 / 78745592 / 79075559 / 79293433 | 73325031 / 78092176 / 78748011 / 79077709 / 79295850 | 0 / 0 / 0 / 0 / 0 | 73322606 / 78089787 / 78745592 / 79075559 / 79293433 | 73325031 / 78092176 / 78748011 / 79077709 / 79295850 | 11226858 | 3596933.307 |
| quickfix-quickfix/binary/tls/1 / 1 | 8535889 / 8894634 / 9045226 / 9107496 / 9127265 | 8588573 / 8952795 / 9109512 / 9155807 / 9183853 | 0 / 0 / 0 / 0 / 0 | 8535889 / 8894634 / 9045226 / 9107496 / 9127265 | 8588573 / 8952795 / 9109512 / 9155807 / 9183853 | 9847458 | 23133747.274 |
| quickfix-quickfix/binary/tls/2 / 1 | 8281763 / 10438464 / 10679994 / 10730950 / 10761207 | 8331460 / 10491613 / 10739844 / 10800347 / 10817690 | 0 / 0 / 0 / 0 / 0 | 8281763 / 10438464 / 10679994 / 10730950 / 10761207 | 8331460 / 10491613 / 10739844 / 10800347 / 10817690 | 9847458 | 23324561.726 |
| quickfix-quickfix/binary/tls/3 / 1 | 9133358 / 9652569 / 10215356 / 10603003 / 10689428 | 9193782 / 9711908 / 10265206 / 10658135 / 10741147 | 0 / 0 / 0 / 0 / 0 | 9133358 / 9652569 / 10215356 / 10603003 / 10689428 | 9193782 / 9711908 / 10265206 / 10658135 / 10741147 | 9847458 | 16244283.410 |
| quickfix-quickfix/fragmentation/tls/1 / 1 | 32799007 / 42305616 / 55506346 / 56093841 / 56441891 | 32859671 / 43681161 / 55543268 / 56100650 / 56455415 | 0 / 0 / 0 / 0 / 0 | 32799007 / 42305616 / 55506346 / 56093841 / 56441891 | 32859671 / 43681161 / 55543268 / 56100650 / 56455415 | 9847458 | 10381654.236 |
| quickfix-quickfix/fragmentation/tls/2 / 1 | 32909953 / 43110242 / 44170223 / 51507434 / 51771907 | 33039804 / 43225691 / 44542911 / 51532769 / 51796925 | 0 / 0 / 0 / 0 / 0 | 32909953 / 43110242 / 44170223 / 51507434 / 51771907 | 33039804 / 43225691 / 44542911 / 51532769 / 51796925 | 9847458 | 11087495.742 |
| quickfix-quickfix/fragmentation/tls/3 / 1 | 33382319 / 37735218 / 44250612 / 48426807 / 54965825 | 33480748 / 37829381 / 44344198 / 48511833 / 55090671 | 0 / 0 / 0 / 0 / 0 | 33382319 / 37735218 / 44250612 / 48426807 / 54965825 | 33480748 / 37829381 / 44344198 / 48511833 / 55090671 | 9847458 | 10712246.662 |
| quickfix-quickfix/replay/tls/1 / 1 | 5763796 / 8179671 / 9638381 / 10232727 / 10339924 | 5801138 / 8229410 / 9677661 / 10270771 / 10370012 | 0 / 0 / 0 / 0 / 0 | 5763796 / 8179671 / 9638381 / 10232727 / 10339924 | 5801138 / 8229410 / 9677661 / 10270771 / 10370012 | 803549 | 661733.270 |
| quickfix-quickfix/replay/tls/2 / 1 | 4745125 / 6281836 / 6428831 / 6477273 / 6490202 | 4783936 / 6328755 / 6468374 / 6515951 / 6516730 | 0 / 0 / 0 / 0 / 0 | 4745125 / 6281836 / 6428831 / 6477273 / 6490202 | 4783936 / 6328755 / 6468374 / 6515951 / 6516730 | 803549 | 647661.178 |
| quickfix-quickfix/replay/tls/3 / 1 | 4909106 / 7834171 / 8152930 / 9443104 / 9605170 | 4936790 / 7899112 / 8217034 / 9496126 / 9662308 | 0 / 0 / 0 / 0 / 0 | 4909106 / 7834171 / 8152930 / 9443104 / 9605170 | 4936790 / 7899112 / 8217034 / 9496126 / 9662308 | 803549 | 648646.264 |
| quickfix-quickfix/overload/tls/1 / 1 | 4466212 / 4752772 / 4829775 / 4863093 / 4866013 | 4502729 / 4788106 / 4864838 / 4900174 / 4902340 | 65844373 / 128979612 / 134435987 / 135680709 / 135854427 | 70177914 / 133352292 / 138928013 / 140076580 / 140208642 | 70214676 / 133387278 / 138963028 / 140110589 / 140238776 | 803258 | 664567.510 |
| quickfix-quickfix/overload/tls/2 / 1 | 4513454 / 4841617 / 5033024 / 5084290 / 5116037 | 4549043 / 4875127 / 5053002 / 5114747 / 5134164 | 66944781 / 130218151 / 136446356 / 137797450 / 137963283 | 71574530 / 135272900 / 140781952 / 142119478 / 142235282 | 71612049 / 135300903 / 140810552 / 142142486 / 142296983 | 803258 | 646145.220 |
| quickfix-quickfix/overload/tls/3 / 1 | 5149425 / 6381205 / 6492977 / 6536160 / 6567214 | 5173480 / 6433589 / 6544011 / 6588873 / 6607062 | 88181373 / 156882189 / 162995629 / 164450514 / 164616573 | 94699692 / 161736726 / 167707597 / 168926678 / 169051565 | 94754506 / 161768146 / 167762338 / 168957354 / 169099587 | 803258 | 1023608.194 |

## Diagnostic allocation/copy observations

These separate reruns change execution and are excluded from timing results. The glibc observer counts dynamic calls after initialization through its exit hook; it excludes inlined copies and custom allocator internals. Counts cover startup, warmup, measured work and shutdown. Allocation counts include only successful calls; realloc adds its full requested size, not a live-byte delta. Free counts exclude null pointers; copy counts cover dynamic memcpy/memmove.

| Case / role | Successful allocation calls | Requested bytes | Free calls | Copy calls | Copy bytes |
| --- | --- | --- | --- | --- | --- |

## Separate PLT audit observations

LD_AUDIT diagnostic reruns preserve sanitizer checks and do not replace the allocator. Observations cover main-namespace PLT entries from preinit through the audit exit hook. Selected entries are malloc/calloc/realloc/aligned_alloc/posix_memalign, free, memcpy/memmove and __asan_memcpy/__asan_memmove. Other APIs, direct/local/inlined/non-PLT calls and custom allocator internals are unobserved. Allocations count attempts, not successes or live bytes; calloc products that overflow are omitted from requested bytes and counted separately. Free includes null pointers. Copy sums can include nested calls; ASan copy counts/bytes are a subset of those sums, not additional totals. These rows are excluded from timing results.

| Case / role | Allocation attempts | Requested bytes | Request overflows | Free calls | Copy entries | Copy bytes | ASan subset entries / bytes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| native-native/scalar/tcp/1 / client | 1185 | 307432 | 0 | 34739 | 77560 | 891241 | 77336 / 889299 |
| native-native/scalar/tcp/1 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857640 | 152019 / 1857324 |
| native-native/scalar/tcp/2 / client | 1186 | 307512 | 0 | 34740 | 77560 | 891306 | 77336 / 889364 |
| native-native/scalar/tcp/2 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857764 | 152019 / 1857448 |
| native-native/scalar/tcp/3 / client | 1183 | 307368 | 0 | 34737 | 77560 | 891291 | 77336 / 889349 |
| native-native/scalar/tcp/3 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857740 | 152019 / 1857424 |
| native-native/groups/tcp/1 / client | 1193 | 309528 | 0 | 43697 | 801418 | 30005119 | 801194 / 30003177 |
| native-native/groups/tcp/1 / server | 22837 | 209110270 | 0 | 210414 | 224673 | 454424322 | 224639 / 454424006 |
| native-native/groups/tcp/2 / client | 1193 | 309528 | 0 | 43697 | 801438 | 30005113 | 801214 / 30003171 |
| native-native/groups/tcp/2 / server | 22837 | 209110270 | 0 | 210415 | 224673 | 454424276 | 224639 / 454423960 |
| native-native/groups/tcp/3 / client | 1193 | 309512 | 0 | 43697 | 801439 | 30005149 | 801215 / 30003207 |
| native-native/groups/tcp/3 / server | 22837 | 209110270 | 0 | 210414 | 224673 | 454424314 | 224639 / 454423998 |
| native-native/binary/tcp/1 / client | 1187 | 307976 | 0 | 65346 | 84167 | 19350652 | 83943 / 19348710 |
| native-native/binary/tcp/1 / server | 833 | 285246 | 0 | 76059 | 165260 | 38988933 | 165226 / 38988617 |
| native-native/binary/tcp/2 / client | 1188 | 307992 | 0 | 65403 | 84167 | 19350720 | 83943 / 19348778 |
| native-native/binary/tcp/2 / server | 833 | 285246 | 0 | 76037 | 165260 | 38989060 | 165226 / 38988744 |
| native-native/binary/tcp/3 / client | 1185 | 307880 | 0 | 65192 | 84167 | 19350663 | 83943 / 19348721 |
| native-native/binary/tcp/3 / server | 833 | 285246 | 0 | 76037 | 165260 | 38988996 | 165226 / 38988680 |
| native-native/fragmentation/tcp/1 / client | 1187 | 307944 | 0 | 62304 | 84166 | 19350774 | 83942 / 19348832 |
| native-native/fragmentation/tcp/1 / server | 833 | 285246 | 0 | 160570 | 165260 | 38989145 | 165226 / 38988829 |
| native-native/fragmentation/tcp/2 / client | 1185 | 307896 | 0 | 63379 | 84166 | 19350689 | 83942 / 19348747 |
| native-native/fragmentation/tcp/2 / server | 833 | 285246 | 0 | 162617 | 165260 | 38989075 | 165226 / 38988759 |
| native-native/fragmentation/tcp/3 / client | 1187 | 307960 | 0 | 62100 | 84166 | 19350715 | 83942 / 19348773 |
| native-native/fragmentation/tcp/3 / server | 833 | 285246 | 0 | 166922 | 165260 | 38989088 | 165226 / 38988772 |
| native-native/replay/tcp/1 / client | 1187 | 307720 | 0 | 34850 | 77645 | 892434 | 77421 / 890492 |
| native-native/replay/tcp/1 / server | 831 | 284734 | 0 | 54094 | 152140 | 1858959 | 152106 / 1858643 |
| native-native/replay/tcp/2 / client | 1184 | 307640 | 0 | 34878 | 77645 | 892437 | 77421 / 890495 |
| native-native/replay/tcp/2 / server | 831 | 284734 | 0 | 54095 | 152140 | 1858975 | 152106 / 1858659 |
| native-native/replay/tcp/3 / client | 1187 | 307752 | 0 | 34858 | 77645 | 892421 | 77421 / 890479 |
| native-native/replay/tcp/3 / server | 831 | 284734 | 0 | 54094 | 152140 | 1858933 | 152106 / 1858617 |
| native-native/overload/tcp/1 / client | 1186 | 307480 | 0 | 34740 | 77560 | 891250 | 77336 / 889308 |
| native-native/overload/tcp/1 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857652 | 152019 / 1857336 |
| native-native/overload/tcp/2 / client | 1185 | 307464 | 0 | 34740 | 77560 | 891261 | 77336 / 889319 |
| native-native/overload/tcp/2 / server | 831 | 284734 | 0 | 54060 | 152053 | 1857684 | 152019 / 1857368 |
| native-native/overload/tcp/3 / client | 1186 | 307512 | 0 | 34740 | 77559 | 891235 | 77335 / 889293 |
| native-native/overload/tcp/3 / server | 830 | 284222 | 0 | 54060 | 152053 | 1857660 | 152019 / 1857344 |
| native-native/scalar/tls/1 / client | 11711 | 972632 | 0 | 45837 | 88288 | 1356057 | 77354 / 889445 |
| native-native/scalar/tls/1 / server | 11470 | 998447 | 0 | 65134 | 173060 | 3080075 | 152031 / 1857437 |
| native-native/scalar/tls/2 / client | 11708 | 972536 | 0 | 45834 | 88288 | 1355971 | 77354 / 889426 |
| native-native/scalar/tls/2 / server | 11470 | 998447 | 0 | 65134 | 173093 | 3090751 | 152031 / 1857399 |
| native-native/scalar/tls/3 / client | 11711 | 972632 | 0 | 45837 | 88289 | 1356114 | 77355 / 889480 |
| native-native/scalar/tls/3 / server | 11470 | 998447 | 0 | 65133 | 173092 | 3087693 | 152031 / 1857475 |
| native-native/groups/tls/1 / client | 11720 | 996328 | 0 | 54792 | 812156 | 40893513 | 801222 / 30003328 |
| native-native/groups/tls/1 / server | 33478 | 209844879 | 0 | 210489 | 245744 | 455659178 | 224650 / 454423994 |
| native-native/groups/tls/2 / client | 11718 | 996296 | 0 | 54790 | 812183 | 40893581 | 801249 / 30003363 |
| native-native/groups/tls/2 / server | 33479 | 209845135 | 0 | 210500 | 245717 | 455656855 | 224653 / 454424095 |
| native-native/groups/tls/3 / client | 11720 | 996328 | 0 | 54792 | 812175 | 40893574 | 801241 / 30003355 |
| native-native/groups/tls/3 / server | 33478 | 209844879 | 0 | 210489 | 245722 | 455659345 | 224650 / 454424032 |
| native-native/binary/tls/1 / client | 11714 | 1010056 | 0 | 54828 | 94895 | 28859766 | 83961 / 19348938 |
| native-native/binary/tls/1 / server | 11477 | 1036207 | 0 | 76168 | 186294 | 58302266 | 165237 / 38988875 |
| native-native/binary/tls/2 / client | 11717 | 1010136 | 0 | 54733 | 94896 | 28859792 | 83962 / 19348956 |
| native-native/binary/tls/2 / server | 11476 | 1035951 | 0 | 76158 | 186304 | 58310914 | 165237 / 38988859 |
| native-native/binary/tls/3 / client | 11716 | 1010152 | 0 | 54775 | 94895 | 28859738 | 83961 / 19348913 |
| native-native/binary/tls/3 / server | 11476 | 1035951 | 0 | 76159 | 186284 | 58304661 | 165237 / 38988803 |
| native-native/fragmentation/tls/1 / client | 11719 | 1011912 | 0 | 58894 | 94917 | 28860210 | 83960 / 19348901 |
| native-native/fragmentation/tls/1 / server | 11474 | 1017551 | 0 | 223547 | 186316 | 58309122 | 165237 / 38988868 |
| native-native/fragmentation/tls/2 / client | 11722 | 1011976 | 0 | 59001 | 94917 | 28860221 | 83960 / 19348891 |
| native-native/fragmentation/tls/2 / server | 11474 | 1017551 | 0 | 223548 | 186342 | 58313164 | 165237 / 38988794 |
| native-native/fragmentation/tls/3 / client | 11721 | 1011960 | 0 | 58971 | 94917 | 28860241 | 83960 / 19348918 |
| native-native/fragmentation/tls/3 / server | 11475 | 1017807 | 0 | 223548 | 186310 | 58307678 | 165237 / 38988939 |
| native-native/replay/tls/1 / client | 11714 | 974632 | 0 | 45996 | 88409 | 1358193 | 77440 / 890654 |
| native-native/replay/tls/1 / server | 11470 | 998447 | 0 | 65170 | 173222 | 3094109 | 152118 / 1858763 |
| native-native/replay/tls/2 / client | 11717 | 974744 | 0 | 45988 | 88409 | 1358112 | 77440 / 890629 |
| native-native/replay/tls/2 / server | 11470 | 998447 | 0 | 65170 | 173193 | 3093431 | 152118 / 1858712 |
| native-native/replay/tls/3 / client | 11716 | 974696 | 0 | 46000 | 88409 | 1358223 | 77440 / 890672 |
| native-native/replay/tls/3 / server | 11471 | 998703 | 0 | 65171 | 173235 | 3094398 | 152118 / 1858808 |
| native-native/overload/tls/1 / client | 11711 | 972632 | 0 | 45837 | 88288 | 1356089 | 77354 / 889464 |
| native-native/overload/tls/1 / server | 11470 | 998447 | 0 | 65134 | 173087 | 3085768 | 152031 / 1857475 |
| native-native/overload/tls/2 / client | 11711 | 972664 | 0 | 45837 | 88289 | 1356057 | 77355 / 889458 |
| native-native/overload/tls/2 / server | 11471 | 998703 | 0 | 65134 | 173106 | 3091591 | 152031 / 1857431 |
| native-native/overload/tls/3 / client | 11708 | 972536 | 0 | 45834 | 88289 | 1356142 | 77355 / 889490 |
| native-native/overload/tls/3 / server | 11470 | 998447 | 0 | 65133 | 173140 | 3096193 | 152031 / 1857495 |
| native-quickfix/scalar/tcp/1 / client | 1186 | 307464 | 0 | 34729 | 77534 | 890897 | 77310 / 888955 |
| native-quickfix/scalar/tcp/1 / server | 1863 | 5813374 | 0 | 55013 | 815740 | 13028591 | 615389 / 8326234 |
| native-quickfix/scalar/tcp/2 / client | 1185 | 307448 | 0 | 34728 | 77533 | 890869 | 77309 / 888927 |
| native-quickfix/scalar/tcp/2 / server | 1863 | 5813374 | 0 | 55013 | 815760 | 14106403 | 615399 / 8326207 |
| native-quickfix/scalar/tcp/3 / client | 1186 | 307464 | 0 | 34730 | 77533 | 890866 | 77309 / 888924 |
| native-quickfix/scalar/tcp/3 / server | 1863 | 5813374 | 0 | 55013 | 815739 | 12266793 | 615389 / 8326219 |
| native-quickfix/groups/tcp/1 / client | 1193 | 309528 | 0 | 43687 | 801355 | 30004654 | 801131 / 30002712 |
| native-quickfix/groups/tcp/1 / server | 1866 | 5814142 | 0 | 347759 | 3157083 | 42124926 | 2953163 / 20576873 |
| native-quickfix/groups/tcp/2 / client | 1193 | 309560 | 0 | 43688 | 801440 | 30004781 | 801216 / 30002839 |
| native-quickfix/groups/tcp/2 / server | 1866 | 5814142 | 0 | 347759 | 3157085 | 42165367 | 2953164 / 20577042 |
| native-quickfix/groups/tcp/3 / client | 1192 | 309512 | 0 | 43686 | 801426 | 30004776 | 801202 / 30002834 |
| native-quickfix/groups/tcp/3 / server | 1866 | 5814142 | 0 | 347759 | 3157087 | 42138622 | 2953165 / 20576980 |
| native-quickfix/binary/tcp/1 / client | 1188 | 308008 | 0 | 65049 | 84140 | 19350311 | 83916 / 19348369 |
| native-quickfix/binary/tcp/1 / server | 1863 | 5813374 | 0 | 52815 | 851341 | 111651196 | 637589 / 71552795 |
| native-quickfix/binary/tcp/2 / client | 1187 | 307976 | 0 | 64165 | 84140 | 19350293 | 83916 / 19348351 |
| native-quickfix/binary/tcp/2 / server | 1863 | 5813374 | 0 | 52815 | 851459 | 112058146 | 637648 / 71552980 |
| native-quickfix/binary/tcp/3 / client | 1185 | 307928 | 0 | 64927 | 84140 | 19350315 | 83916 / 19348373 |
| native-quickfix/binary/tcp/3 / server | 1863 | 5813374 | 0 | 52815 | 851345 | 111645297 | 637591 / 71552813 |
| native-quickfix/fragmentation/tcp/1 / client | 1187 | 307944 | 0 | 63086 | 84139 | 19350304 | 83915 / 19348362 |
| native-quickfix/fragmentation/tcp/1 / server | 1863 | 5813374 | 0 | 52815 | 947068 | 110252077 | 685453 / 71744255 |
| native-quickfix/fragmentation/tcp/2 / client | 1185 | 307928 | 0 | 62028 | 84139 | 19350299 | 83915 / 19348357 |
| native-quickfix/fragmentation/tcp/2 / server | 1863 | 5813374 | 0 | 52815 | 928503 | 110230565 | 676176 / 71707392 |
| native-quickfix/fragmentation/tcp/3 / client | 1187 | 307944 | 0 | 61958 | 84139 | 19350326 | 83915 / 19348384 |
| native-quickfix/fragmentation/tcp/3 / server | 1863 | 5813374 | 0 | 52815 | 919362 | 110244638 | 671601 / 71688900 |
| native-quickfix/replay/tcp/1 / client | 1184 | 307624 | 0 | 34846 | 77591 | 891644 | 77367 / 889702 |
| native-quickfix/replay/tcp/1 / server | 1864 | 5813630 | 0 | 55019 | 816105 | 14663517 | 615657 / 8329812 |
| native-quickfix/replay/tcp/2 / client | 1187 | 307720 | 0 | 34834 | 77591 | 891608 | 77367 / 889666 |
| native-quickfix/replay/tcp/2 / server | 1864 | 5813630 | 0 | 55019 | 816076 | 11733573 | 615643 / 8329746 |
| native-quickfix/replay/tcp/3 / client | 1186 | 307736 | 0 | 34809 | 77591 | 891627 | 77367 / 889685 |
| native-quickfix/replay/tcp/3 / server | 1864 | 5813630 | 0 | 55019 | 816075 | 11482714 | 615642 / 8329833 |
| native-quickfix/overload/tcp/1 / client | 1186 | 307496 | 0 | 34734 | 77533 | 890847 | 77309 / 888905 |
| native-quickfix/overload/tcp/1 / server | 1863 | 5813374 | 0 | 55013 | 815738 | 11933757 | 615388 / 8326261 |
| native-quickfix/overload/tcp/2 / client | 1183 | 307400 | 0 | 34740 | 77533 | 890888 | 77309 / 888946 |
| native-quickfix/overload/tcp/2 / server | 1863 | 5813374 | 0 | 55013 | 815734 | 11280106 | 615386 / 8326309 |
| native-quickfix/overload/tcp/3 / client | 1183 | 307368 | 0 | 34727 | 77533 | 890865 | 77309 / 888923 |
| native-quickfix/overload/tcp/3 / server | 1863 | 5813374 | 0 | 55013 | 815735 | 11648433 | 615387 / 8326180 |
| native-quickfix/scalar/tls/1 / client | 11644 | 969840 | 0 | 45755 | 88341 | 1357085 | 77325 / 889029 |
| native-quickfix/scalar/tls/1 / server | 31794 | 7546236 | 0 | 309138 | 846865 | 12495135 | 615423 / 8327259 |
| native-quickfix/scalar/tls/2 / client | 11644 | 969824 | 0 | 45755 | 88341 | 1357182 | 77325 / 889076 |
| native-quickfix/scalar/tls/2 / server | 31795 | 7546491 | 0 | 309139 | 846839 | 12491077 | 615423 / 8327411 |
| native-quickfix/scalar/tls/3 / client | 11641 | 969728 | 0 | 45752 | 88341 | 1357106 | 77325 / 889046 |
| native-quickfix/scalar/tls/3 / server | 31794 | 7546236 | 0 | 309138 | 846847 | 12491321 | 615423 / 8327273 |
| native-quickfix/groups/tls/1 / client | 11654 | 993792 | 0 | 54713 | 812218 | 40894625 | 801202 / 30002954 |
| native-quickfix/groups/tls/1 / server | 31799 | 7548029 | 0 | 601884 | 3185493 | 45584884 | 2951832 / 20572626 |
| native-quickfix/groups/tls/2 / client | 11655 | 993824 | 0 | 54714 | 812195 | 40894554 | 801179 / 30002890 |
| native-quickfix/groups/tls/2 / server | 31799 | 7548028 | 0 | 601948 | 3185458 | 45579912 | 2951832 / 20572611 |
| native-quickfix/groups/tls/3 / client | 11652 | 993744 | 0 | 54711 | 812208 | 40894617 | 801192 / 30002927 |
| native-quickfix/groups/tls/3 / server | 31799 | 7548027 | 0 | 601948 | 3185505 | 45586041 | 2951832 / 20572689 |
| native-quickfix/binary/tls/1 / client | 11648 | 1016512 | 0 | 55387 | 94947 | 28860869 | 83931 / 19348577 |
| native-quickfix/binary/tls/1 / server | 31794 | 7546236 | 0 | 306940 | 882061 | 139001095 | 637423 / 71553169 |
| native-quickfix/binary/tls/2 / client | 11650 | 1016576 | 0 | 54915 | 94947 | 28860788 | 83931 / 19348516 |
| native-quickfix/binary/tls/2 / server | 31795 | 7546493 | 0 | 306973 | 882080 | 139005947 | 637423 / 71553109 |
| native-quickfix/binary/tls/3 / client | 11648 | 1016480 | 0 | 55054 | 94947 | 28860669 | 83931 / 19348446 |
| native-quickfix/binary/tls/3 / server | 31794 | 7546235 | 0 | 306972 | 882065 | 139000752 | 637423 / 71552962 |
| native-quickfix/fragmentation/tls/1 / client | 11723 | 1021240 | 0 | 55648 | 94886 | 28859622 | 83933 / 19348466 |
| native-quickfix/fragmentation/tls/1 / server | 177004 | 13356119 | 0 | 5243740 | 1753252 | 144233663 | 782623 / 72133796 |
| native-quickfix/fragmentation/tls/2 / client | 11722 | 1021224 | 0 | 55564 | 94887 | 28859689 | 83934 / 19348516 |
| native-quickfix/fragmentation/tls/2 / server | 177006 | 13356632 | 0 | 5243742 | 1753273 | 144240098 | 782623 / 72133849 |
| native-quickfix/fragmentation/tls/3 / client | 11722 | 1021240 | 0 | 55445 | 94887 | 28859698 | 83934 / 19348521 |
| native-quickfix/fragmentation/tls/3 / server | 177004 | 13356120 | 0 | 5243740 | 1753208 | 144229237 | 782623 / 72133861 |
| native-quickfix/replay/tls/1 / client | 11717 | 974728 | 0 | 45953 | 88347 | 1357069 | 77386 / 889835 |
| native-quickfix/replay/tls/1 / server | 31814 | 7548952 | 0 | 309287 | 847234 | 12502507 | 615679 / 8330843 |
| native-quickfix/replay/tls/2 / client | 11716 | 974744 | 0 | 45942 | 88347 | 1357060 | 77386 / 889820 |
| native-quickfix/replay/tls/2 / server | 31813 | 7548695 | 0 | 309286 | 847215 | 12497233 | 615679 / 8330857 |
| native-quickfix/replay/tls/3 / client | 11714 | 974632 | 0 | 45943 | 88347 | 1357047 | 77386 / 889842 |
| native-quickfix/replay/tls/3 / server | 31813 | 7548695 | 0 | 309286 | 847194 | 12491400 | 615679 / 8330748 |
| native-quickfix/overload/tls/1 / client | 11644 | 969840 | 0 | 45755 | 88341 | 1357061 | 77325 / 889031 |
| native-quickfix/overload/tls/1 / server | 31794 | 7546235 | 0 | 309138 | 846843 | 12492646 | 615423 / 8327183 |
| native-quickfix/overload/tls/2 / client | 11643 | 969792 | 0 | 45754 | 88341 | 1357054 | 77325 / 889026 |
| native-quickfix/overload/tls/2 / server | 31794 | 7546236 | 0 | 309138 | 846871 | 12493590 | 615423 / 8327175 |
| native-quickfix/overload/tls/3 / client | 11644 | 969824 | 0 | 45755 | 88341 | 1357124 | 77325 / 889061 |
| native-quickfix/overload/tls/3 / server | 31794 | 7546235 | 0 | 309138 | 846819 | 12489286 | 615423 / 8327282 |
| quickfix-native/scalar/tcp/1 / client | 1864 | 5813462 | 0 | 28614 | 970373 | 29324560 | 704501 / 8801211 |
| quickfix-native/scalar/tcp/1 / server | 831 | 284734 | 0 | 54049 | 152026 | 1857315 | 151992 / 1856999 |
| quickfix-native/scalar/tcp/2 / client | 1864 | 5813462 | 0 | 28614 | 970376 | 29323154 | 704504 / 8801013 |
| quickfix-native/scalar/tcp/2 / server | 831 | 284734 | 0 | 54049 | 152026 | 1857237 | 151992 / 1856921 |
| quickfix-native/scalar/tcp/3 / client | 1864 | 5813462 | 0 | 28614 | 970375 | 29308962 | 704504 / 8801286 |
| quickfix-native/scalar/tcp/3 / server | 831 | 284734 | 0 | 54049 | 152027 | 1857341 | 151993 / 1857025 |
| quickfix-native/groups/tcp/1 / client | 1867 | 5814230 | 0 | 96960 | 7516365 | 55705473 | 5792007 / 42003168 |
| quickfix-native/groups/tcp/1 / server | 22837 | 209110270 | 0 | 210404 | 224647 | 454423871 | 224613 / 454423555 |
| quickfix-native/groups/tcp/2 / client | 1867 | 5814230 | 0 | 96960 | 7517004 | 55686061 | 5792646 / 42022078 |
| quickfix-native/groups/tcp/2 / server | 22837 | 209110270 | 0 | 210403 | 224646 | 454423879 | 224612 / 454423563 |
| quickfix-native/groups/tcp/3 / client | 1867 | 5814230 | 0 | 96960 | 7516466 | 55603663 | 5792106 / 42006333 |
| quickfix-native/groups/tcp/3 / server | 22837 | 209110270 | 0 | 210403 | 224646 | 454423905 | 224612 / 454423589 |
| quickfix-native/binary/tcp/1 / client | 1864 | 5813462 | 0 | 24216 | 1076525 | 147784994 | 828039 / 81983673 |
| quickfix-native/binary/tcp/1 / server | 833 | 285246 | 0 | 75987 | 165234 | 38988660 | 165200 / 38988344 |
| quickfix-native/binary/tcp/2 / client | 1864 | 5813462 | 0 | 24216 | 1076570 | 147707950 | 828078 / 81984640 |
| quickfix-native/binary/tcp/2 / server | 834 | 285502 | 0 | 75986 | 165238 | 38988760 | 165204 / 38988444 |
| quickfix-native/binary/tcp/3 / client | 1864 | 5813462 | 0 | 24216 | 1076494 | 147773021 | 828010 / 81982631 |
| quickfix-native/binary/tcp/3 / server | 834 | 285502 | 0 | 75874 | 165237 | 38988673 | 165203 / 38988357 |
| quickfix-native/fragmentation/tcp/1 / client | 1864 | 5813462 | 0 | 24216 | 1076474 | 147566517 | 828041 / 81985232 |
| quickfix-native/fragmentation/tcp/1 / server | 833 | 285246 | 0 | 168469 | 165233 | 38988813 | 165199 / 38988497 |
| quickfix-native/fragmentation/tcp/2 / client | 1864 | 5813462 | 0 | 24216 | 1076507 | 147589276 | 828061 / 81985267 |
| quickfix-native/fragmentation/tcp/2 / server | 833 | 285246 | 0 | 162877 | 165233 | 38988689 | 165199 / 38988373 |
| quickfix-native/fragmentation/tcp/3 / client | 1864 | 5813462 | 0 | 24216 | 1076483 | 147613191 | 828050 / 81985038 |
| quickfix-native/fragmentation/tcp/3 / server | 834 | 285502 | 0 | 164130 | 165237 | 38988663 | 165203 / 38988347 |
| quickfix-native/replay/tcp/1 / client | 1864 | 5813462 | 0 | 28620 | 977062 | 29484003 | 709419 / 8845004 |
| quickfix-native/replay/tcp/1 / server | 832 | 284990 | 0 | 54444 | 152981 | 1870772 | 152947 / 1870456 |
| quickfix-native/replay/tcp/2 / client | 1864 | 5813462 | 0 | 28620 | 981307 | 29544047 | 712539 / 8871267 |
| quickfix-native/replay/tcp/2 / server | 832 | 284990 | 0 | 54598 | 153575 | 1879122 | 153541 / 1878806 |
| quickfix-native/replay/tcp/3 / client | 1864 | 5813462 | 0 | 28620 | 975106 | 29364840 | 707983 / 8832274 |
| quickfix-native/replay/tcp/3 / server | 831 | 284478 | 0 | 54376 | 152711 | 1866882 | 152677 / 1866566 |
| quickfix-native/overload/tcp/1 / client | 1864 | 5813462 | 0 | 28614 | 970379 | 29334187 | 704508 / 8801135 |
| quickfix-native/overload/tcp/1 / server | 831 | 284734 | 0 | 54053 | 152027 | 1857279 | 151993 / 1856963 |
| quickfix-native/overload/tcp/2 / client | 1864 | 5813462 | 0 | 28614 | 970375 | 29297568 | 704505 / 8801275 |
| quickfix-native/overload/tcp/2 / server | 832 | 284990 | 0 | 54088 | 152031 | 1857369 | 151997 / 1857053 |
| quickfix-native/overload/tcp/3 / client | 1864 | 5813462 | 0 | 28614 | 970391 | 29275970 | 704521 / 8801688 |
| quickfix-native/overload/tcp/3 / server | 831 | 284734 | 0 | 54049 | 152026 | 1857321 | 151992 / 1857005 |
| quickfix-native/scalar/tls/1 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551421 | 742912 / 9930404 |
| quickfix-native/scalar/tls/1 / server | 11313 | 981951 | 0 | 64890 | 173072 | 3088263 | 152002 / 1857045 |
| quickfix-native/scalar/tls/2 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551846 | 742912 / 9930617 |
| quickfix-native/scalar/tls/2 / server | 11315 | 982463 | 0 | 64892 | 173041 | 3089422 | 152002 / 1857045 |
| quickfix-native/scalar/tls/3 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551730 | 742912 / 9930558 |
| quickfix-native/scalar/tls/3 / server | 11315 | 982463 | 0 | 64895 | 173084 | 3095043 | 152006 / 1857109 |
| quickfix-native/groups/tls/1 / client | 59317 | 9952084 | 0 | 387400 | 7570080 | 68957740 | 5805045 / 42385878 |
| quickfix-native/groups/tls/1 / server | 33321 | 209828383 | 0 | 210246 | 245710 | 455660428 | 224621 / 454423672 |
| quickfix-native/groups/tls/2 / client | 59317 | 9952084 | 0 | 387400 | 7571484 | 68998830 | 5806449 / 42427016 |
| quickfix-native/groups/tls/2 / server | 33321 | 209828383 | 0 | 210246 | 245655 | 455653536 | 224621 / 454423692 |
| quickfix-native/groups/tls/3 / client | 59317 | 9952084 | 0 | 387400 | 7571760 | 69011984 | 5806725 / 42440359 |
| quickfix-native/groups/tls/3 / server | 33322 | 209828639 | 0 | 210247 | 245703 | 455656225 | 224621 / 454423636 |
| quickfix-native/binary/tls/1 / client | 59311 | 9949780 | 0 | 314656 | 1130927 | 160379607 | 844116 / 82514093 |
| quickfix-native/binary/tls/1 / server | 11319 | 1019455 | 0 | 76047 | 186291 | 58310652 | 165209 / 38988310 |
| quickfix-native/binary/tls/2 / client | 59311 | 9949780 | 0 | 314656 | 1130923 | 160380205 | 844112 / 82514402 |
| quickfix-native/binary/tls/2 / server | 11320 | 1019711 | 0 | 76145 | 186263 | 58309467 | 165208 / 38988461 |
| quickfix-native/binary/tls/3 / client | 59311 | 9949780 | 0 | 314784 | 1130959 | 160381286 | 844148 / 82515475 |
| quickfix-native/binary/tls/3 / server | 11320 | 1019711 | 0 | 76088 | 186239 | 58306273 | 165209 / 38988488 |
| quickfix-native/fragmentation/tls/1 / client | 59339 | 9983887 | 0 | 314734 | 1130941 | 160380352 | 844112 / 82514056 |
| quickfix-native/fragmentation/tls/1 / server | 11474 | 1017551 | 0 | 223536 | 186285 | 58309626 | 165210 / 38988312 |
| quickfix-native/fragmentation/tls/2 / client | 59339 | 9983887 | 0 | 314766 | 1130950 | 160381166 | 844121 / 82514603 |
| quickfix-native/fragmentation/tls/2 / server | 11474 | 1017551 | 0 | 223536 | 186313 | 58312956 | 165210 / 38988417 |
| quickfix-native/fragmentation/tls/3 / client | 59339 | 9983887 | 0 | 314766 | 1130950 | 160381076 | 844121 / 82514575 |
| quickfix-native/fragmentation/tls/3 / server | 11475 | 1026799 | 0 | 223537 | 186237 | 58302662 | 165210 / 38988433 |
| quickfix-native/replay/tls/1 / client | 59376 | 9985367 | 0 | 320266 | 1055891 | 15627391 | 747686 / 9978085 |
| quickfix-native/replay/tls/1 / server | 11471 | 998703 | 0 | 65482 | 174085 | 3112524 | 152878 / 1869406 |
| quickfix-native/replay/tls/2 / client | 59401 | 9986367 | 0 | 321116 | 1061055 | 15685191 | 751470 / 10014581 |
| quickfix-native/replay/tls/2 / server | 11472 | 998959 | 0 | 65687 | 174879 | 3129469 | 153553 / 1878863 |
| quickfix-native/replay/tls/3 / client | 59378 | 9985447 | 0 | 320334 | 1056306 | 15631924 | 747989 / 9980961 |
| quickfix-native/replay/tls/3 / server | 11472 | 998959 | 0 | 65591 | 174129 | 3108488 | 152932 / 1870194 |
| quickfix-native/overload/tls/1 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551364 | 742912 / 9930374 |
| quickfix-native/overload/tls/1 / server | 11313 | 981951 | 0 | 64890 | 173095 | 3093063 | 152003 / 1857055 |
| quickfix-native/overload/tls/2 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551741 | 742912 / 9930563 |
| quickfix-native/overload/tls/2 / server | 11313 | 981951 | 0 | 64890 | 173075 | 3091480 | 152002 / 1857073 |
| quickfix-native/overload/tls/3 / client | 59311 | 9949780 | 0 | 319054 | 1049347 | 15551891 | 742912 / 9930638 |
| quickfix-native/overload/tls/3 / server | 11313 | 981951 | 0 | 64890 | 173085 | 3093327 | 152002 / 1857063 |
| quickfix-quickfix/scalar/tcp/1 / client | 1864 | 5813462 | 0 | 28611 | 830616 | 25939727 | 696369 / 8807915 |
| quickfix-quickfix/scalar/tcp/1 / server | 1863 | 5813374 | 0 | 55010 | 793595 | 11231205 | 615289 / 8325907 |
| quickfix-quickfix/scalar/tcp/2 / client | 1864 | 5813462 | 0 | 28611 | 831289 | 26642680 | 697041 / 8827469 |
| quickfix-quickfix/scalar/tcp/2 / server | 1863 | 5813374 | 0 | 55010 | 793595 | 10702616 | 615289 / 8325907 |
| quickfix-quickfix/scalar/tcp/3 / client | 1864 | 5813462 | 0 | 28611 | 831822 | 24946121 | 697594 / 8844296 |
| quickfix-quickfix/scalar/tcp/3 / server | 1863 | 5813374 | 0 | 55010 | 793595 | 10601637 | 615289 / 8325907 |
| quickfix-quickfix/groups/tcp/1 / client | 1867 | 5814230 | 0 | 96957 | 7382199 | 55015588 | 5789437 / 42172652 |
| quickfix-quickfix/groups/tcp/1 / server | 1866 | 5814142 | 0 | 347756 | 3133798 | 33679222 | 2953215 / 20613781 |
| quickfix-quickfix/groups/tcp/2 / client | 1867 | 5814230 | 0 | 96957 | 7374000 | 55032917 | 5781238 / 41932148 |
| quickfix-quickfix/groups/tcp/2 / server | 1866 | 5814142 | 0 | 347756 | 3135104 | 33738576 | 2954516 / 20651817 |
| quickfix-quickfix/groups/tcp/3 / client | 1867 | 5814230 | 0 | 96957 | 7371241 | 54953704 | 5778479 / 41851149 |
| quickfix-quickfix/groups/tcp/3 / server | 1866 | 5814142 | 0 | 347756 | 3133461 | 33664308 | 2952880 / 20604005 |
| quickfix-quickfix/binary/tcp/1 / client | 1864 | 5813462 | 0 | 24213 | 997048 | 145038295 | 821373 / 82076159 |
| quickfix-quickfix/binary/tcp/1 / server | 1863 | 5813374 | 0 | 52812 | 829223 | 111389969 | 637503 / 71550363 |
| quickfix-quickfix/binary/tcp/2 / client | 1864 | 5813462 | 0 | 24213 | 996343 | 145495306 | 820645 / 82054095 |
| quickfix-quickfix/binary/tcp/2 / server | 1863 | 5813374 | 0 | 52812 | 829370 | 111986238 | 637576 / 71550655 |
| quickfix-quickfix/binary/tcp/3 / client | 1864 | 5813462 | 0 | 24213 | 994821 | 147385101 | 818863 / 81995211 |
| quickfix-quickfix/binary/tcp/3 / server | 1863 | 5813374 | 0 | 52812 | 829171 | 111236642 | 637477 / 71550259 |
| quickfix-quickfix/fragmentation/tcp/1 / client | 1864 | 5813462 | 0 | 24213 | 995023 | 147301792 | 819086 / 82002259 |
| quickfix-quickfix/fragmentation/tcp/1 / server | 1863 | 5813374 | 0 | 52812 | 897454 | 110013013 | 671638 / 71687815 |
| quickfix-quickfix/fragmentation/tcp/2 / client | 1864 | 5813462 | 0 | 24213 | 995044 | 147288103 | 819115 / 82003287 |
| quickfix-quickfix/fragmentation/tcp/2 / server | 1863 | 5813374 | 0 | 52812 | 889056 | 109952716 | 667442 / 71671259 |
| quickfix-quickfix/fragmentation/tcp/3 / client | 1864 | 5813462 | 0 | 24213 | 995524 | 147215377 | 819539 / 82014364 |
| quickfix-quickfix/fragmentation/tcp/3 / server | 1863 | 5813374 | 0 | 52812 | 934944 | 110046598 | 690422 / 71765003 |
| quickfix-quickfix/replay/tcp/1 / client | 1864 | 5813462 | 0 | 28614 | 841470 | 22727649 | 706982 / 9084124 |
| quickfix-quickfix/replay/tcp/1 / server | 1864 | 5813630 | 0 | 55017 | 795633 | 10614573 | 616763 / 8341551 |
| quickfix-quickfix/replay/tcp/2 / client | 1864 | 5813462 | 0 | 28614 | 835349 | 28949405 | 700372 / 8826074 |
| quickfix-quickfix/replay/tcp/2 / server | 1866 | 5814142 | 0 | 55023 | 798964 | 10801817 | 619147 / 8366062 |
| quickfix-quickfix/replay/tcp/3 / client | 1864 | 5813462 | 0 | 28614 | 833756 | 28835211 | 698980 / 8813986 |
| quickfix-quickfix/replay/tcp/3 / server | 1865 | 5813886 | 0 | 55020 | 797446 | 10686070 | 618059 / 8354770 |
| quickfix-quickfix/overload/tcp/1 / client | 1864 | 5813462 | 0 | 28611 | 830591 | 26965038 | 696333 / 8806622 |
| quickfix-quickfix/overload/tcp/1 / server | 1863 | 5813374 | 0 | 55010 | 793602 | 11062379 | 615298 / 8326171 |
| quickfix-quickfix/overload/tcp/2 / client | 1864 | 5813462 | 0 | 28611 | 829852 | 28699673 | 695580 / 8784218 |
| quickfix-quickfix/overload/tcp/2 / server | 1863 | 5813374 | 0 | 55010 | 793593 | 10857405 | 615289 / 8325907 |
| quickfix-quickfix/overload/tcp/3 / client | 1864 | 5813462 | 0 | 28611 | 829866 | 28560354 | 695596 / 8784540 |
| quickfix-quickfix/overload/tcp/3 / server | 1863 | 5813374 | 0 | 55010 | 793594 | 10896368 | 615289 / 8325907 |
| quickfix-quickfix/scalar/tls/1 / client | 59335 | 9983727 | 0 | 319058 | 908859 | 14935271 | 734010 / 9913961 |
| quickfix-quickfix/scalar/tls/1 / server | 31757 | 7539265 | 0 | 308933 | 824708 | 12233432 | 615326 / 8326982 |
| quickfix-quickfix/scalar/tls/2 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935222 | 734006 / 9913912 |
| quickfix-quickfix/scalar/tls/2 / server | 31757 | 7539263 | 0 | 308933 | 824670 | 12227990 | 615326 / 8326982 |
| quickfix-quickfix/scalar/tls/3 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935222 | 734006 / 9913912 |
| quickfix-quickfix/scalar/tls/3 / server | 31757 | 7539263 | 0 | 308933 | 824721 | 12236318 | 615326 / 8326982 |
| quickfix-quickfix/groups/tls/1 / client | 59341 | 9986031 | 0 | 387404 | 7430794 | 68376428 | 5797345 / 42404518 |
| quickfix-quickfix/groups/tls/1 / server | 31763 | 7541311 | 0 | 601680 | 3165145 | 45372088 | 2953598 / 20626956 |
| quickfix-quickfix/groups/tls/2 / client | 59341 | 9986031 | 0 | 387404 | 7428818 | 68318397 | 5795369 / 42346487 |
| quickfix-quickfix/groups/tls/2 / server | 31763 | 7541312 | 0 | 601680 | 3165320 | 45386089 | 2953706 / 20630124 |
| quickfix-quickfix/groups/tls/3 / client | 59341 | 9986031 | 0 | 387404 | 7431442 | 68395436 | 5797993 / 42423526 |
| quickfix-quickfix/groups/tls/3 / server | 31762 | 7541056 | 0 | 601679 | 3165095 | 45377593 | 2953499 / 20624052 |
| quickfix-quickfix/binary/tls/1 / client | 59335 | 9983727 | 0 | 314820 | 1049571 | 159958347 | 835251 / 82534597 |
| quickfix-quickfix/binary/tls/1 / server | 31757 | 7539265 | 0 | 306765 | 859928 | 138743066 | 637326 / 71550582 |
| quickfix-quickfix/binary/tls/2 / client | 59335 | 9983727 | 0 | 314724 | 1049544 | 159957555 | 835224 / 82533805 |
| quickfix-quickfix/binary/tls/2 / server | 31759 | 7539777 | 0 | 306769 | 859912 | 138742802 | 637326 / 71550582 |
| quickfix-quickfix/binary/tls/3 / client | 59335 | 9983727 | 0 | 314692 | 1049535 | 159957291 | 835215 / 82533541 |
| quickfix-quickfix/binary/tls/3 / server | 31757 | 7539263 | 0 | 306765 | 859921 | 138743128 | 637326 / 71550582 |
| quickfix-quickfix/fragmentation/tls/1 / client | 59335 | 9983727 | 0 | 314660 | 1049526 | 159957071 | 835206 / 82533277 |
| quickfix-quickfix/fragmentation/tls/1 / server | 177000 | 13355959 | 0 | 5243666 | 1731121 | 143979987 | 782526 / 72131382 |
| quickfix-quickfix/fragmentation/tls/2 / client | 59335 | 9983727 | 0 | 314660 | 1049526 | 159957071 | 835206 / 82533277 |
| quickfix-quickfix/fragmentation/tls/2 / server | 177000 | 13355960 | 0 | 5243666 | 1731091 | 143974068 | 782526 / 72131382 |
| quickfix-quickfix/fragmentation/tls/3 / client | 59335 | 9983727 | 0 | 314660 | 1049526 | 159957071 | 835206 / 82533277 |
| quickfix-quickfix/fragmentation/tls/3 / server | 177000 | 13355960 | 0 | 5243666 | 1731098 | 143972948 | 782544 / 72131910 |
| quickfix-quickfix/replay/tls/1 / client | 59373 | 9985247 | 0 | 320288 | 914967 | 15013289 | 739249 / 9966265 |
| quickfix-quickfix/replay/tls/1 / server | 31914 | 7554113 | 0 | 310443 | 830383 | 12304870 | 619294 / 8368291 |
| quickfix-quickfix/replay/tls/2 / client | 59363 | 9984847 | 0 | 319948 | 913244 | 14991316 | 737766 / 9951497 |
| quickfix-quickfix/replay/tls/2 / server | 31882 | 7552144 | 0 | 310070 | 828825 | 12284266 | 618206 / 8356999 |
| quickfix-quickfix/replay/tls/3 / client | 59366 | 9984967 | 0 | 320050 | 913756 | 14997833 | 738207 / 9955869 |
| quickfix-quickfix/replay/tls/3 / server | 31892 | 7552760 | 0 | 310182 | 829301 | 12286192 | 618530 / 8360345 |
| quickfix-quickfix/overload/tls/1 / client | 59335 | 9983727 | 0 | 319058 | 908859 | 14935271 | 734010 / 9913961 |
| quickfix-quickfix/overload/tls/1 / server | 31757 | 7539264 | 0 | 308965 | 824709 | 12235807 | 615326 / 8326982 |
| quickfix-quickfix/overload/tls/2 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935222 | 734006 / 9913912 |
| quickfix-quickfix/overload/tls/2 / server | 31757 | 7539264 | 0 | 308965 | 824742 | 12239351 | 615326 / 8326982 |
| quickfix-quickfix/overload/tls/3 / client | 59335 | 9983727 | 0 | 319058 | 908855 | 14935222 | 734006 / 9913912 |
| quickfix-quickfix/overload/tls/3 / server | 31758 | 7539520 | 0 | 308934 | 824709 | 12233287 | 615326 / 8326982 |

## Framework heap observations

Cold logical-drain samples cover Ztc::HeapMgr arenas only. They exclude SDK, STL and libc allocation paths; live bytes are a drain-time sample, not peak resident memory or total process heap usage.

| Case / role | Framework allocation calls | Framework live bytes |
| --- | --- | --- |
| native-native/scalar/tcp/1 / client | 26516 | 3124512 |
| native-native/scalar/tcp/1 / server | 39703 | 6218432 |
| native-native/scalar/tcp/1/audit-diagnostic / client | 26516 | 3124512 |
| native-native/scalar/tcp/1/audit-diagnostic / server | 39703 | 6218432 |
| native-native/scalar/tcp/2 / client | 26517 | 3124512 |
| native-native/scalar/tcp/2 / server | 39703 | 6218432 |
| native-native/scalar/tcp/2/audit-diagnostic / client | 26516 | 3124512 |
| native-native/scalar/tcp/2/audit-diagnostic / server | 39703 | 6218432 |
| native-native/scalar/tcp/3 / client | 26523 | 3124512 |
| native-native/scalar/tcp/3 / server | 39703 | 6218432 |
| native-native/scalar/tcp/3/audit-diagnostic / client | 26516 | 3124512 |
| native-native/scalar/tcp/3/audit-diagnostic / server | 39703 | 6218432 |
| native-native/groups/tcp/1 / client | 35456 | 39206176 |
| native-native/groups/tcp/1 / server | 176243 | 6255296 |
| native-native/groups/tcp/1/audit-diagnostic / client | 35456 | 39206176 |
| native-native/groups/tcp/1/audit-diagnostic / server | 176243 | 6255296 |
| native-native/groups/tcp/2 / client | 35456 | 39206176 |
| native-native/groups/tcp/2 / server | 176243 | 6255296 |
| native-native/groups/tcp/2/audit-diagnostic / client | 35456 | 39206176 |
| native-native/groups/tcp/2/audit-diagnostic / server | 176243 | 6255296 |
| native-native/groups/tcp/3 / client | 35456 | 39206176 |
| native-native/groups/tcp/3 / server | 176243 | 6255296 |
| native-native/groups/tcp/3/audit-diagnostic / client | 35456 | 39206176 |
| native-native/groups/tcp/3/audit-diagnostic / server | 176243 | 6255296 |
| native-native/binary/tcp/1 / client | 56441 | 39169312 |
| native-native/binary/tcp/1 / server | 61656 | 67544896 |
| native-native/binary/tcp/1/audit-diagnostic / client | 57114 | 39169312 |
| native-native/binary/tcp/1/audit-diagnostic / server | 61695 | 67544896 |
| native-native/binary/tcp/2 / client | 56490 | 39169312 |
| native-native/binary/tcp/2 / server | 61658 | 67544896 |
| native-native/binary/tcp/2/audit-diagnostic / client | 57172 | 39169312 |
| native-native/binary/tcp/2/audit-diagnostic / server | 61673 | 67544896 |
| native-native/binary/tcp/3 / client | 56719 | 39169312 |
| native-native/binary/tcp/3 / server | 61670 | 67544896 |
| native-native/binary/tcp/3/audit-diagnostic / client | 56964 | 39169312 |
| native-native/binary/tcp/3/audit-diagnostic / server | 61673 | 67544896 |
| native-native/fragmentation/tcp/1 / client | 54633 | 39169312 |
| native-native/fragmentation/tcp/1 / server | 150180 | 67544896 |
| native-native/fragmentation/tcp/1/audit-diagnostic / client | 54074 | 39169312 |
| native-native/fragmentation/tcp/1/audit-diagnostic / server | 146204 | 67544896 |
| native-native/fragmentation/tcp/2 / client | 54638 | 39169312 |
| native-native/fragmentation/tcp/2 / server | 145128 | 67544896 |
| native-native/fragmentation/tcp/2/audit-diagnostic / client | 55149 | 39169312 |
| native-native/fragmentation/tcp/2/audit-diagnostic / server | 148251 | 67544896 |
| native-native/fragmentation/tcp/3 / client | 54328 | 39169312 |
| native-native/fragmentation/tcp/3 / server | 153586 | 67544896 |
| native-native/fragmentation/tcp/3/audit-diagnostic / client | 53868 | 39169312 |
| native-native/fragmentation/tcp/3/audit-diagnostic / server | 152558 | 67544896 |
| native-native/replay/tcp/1 / client | 26641 | 3124512 |
| native-native/replay/tcp/1 / server | 39732 | 6218432 |
| native-native/replay/tcp/1/audit-diagnostic / client | 26615 | 3124512 |
| native-native/replay/tcp/1/audit-diagnostic / server | 39729 | 6218432 |
| native-native/replay/tcp/2 / client | 26622 | 3124512 |
| native-native/replay/tcp/2 / server | 39730 | 6218432 |
| native-native/replay/tcp/2/audit-diagnostic / client | 26646 | 3124512 |
| native-native/replay/tcp/2/audit-diagnostic / server | 39729 | 6218432 |
| native-native/replay/tcp/3 / client | 26609 | 3124512 |
| native-native/replay/tcp/3 / server | 39732 | 6218432 |
| native-native/replay/tcp/3/audit-diagnostic / client | 26623 | 3124512 |
| native-native/replay/tcp/3/audit-diagnostic / server | 39729 | 6218432 |
| native-native/overload/tcp/1 / client | 26525 | 3124512 |
| native-native/overload/tcp/1 / server | 39703 | 6218432 |
| native-native/overload/tcp/1/audit-diagnostic / client | 26516 | 3124512 |
| native-native/overload/tcp/1/audit-diagnostic / server | 39703 | 6218432 |
| native-native/overload/tcp/2 / client | 26520 | 3124512 |
| native-native/overload/tcp/2 / server | 39703 | 6218432 |
| native-native/overload/tcp/2/audit-diagnostic / client | 26516 | 3124512 |
| native-native/overload/tcp/2/audit-diagnostic / server | 39703 | 6218432 |
| native-native/overload/tcp/3 / client | 26521 | 3124512 |
| native-native/overload/tcp/3 / server | 39703 | 6218432 |
| native-native/overload/tcp/3/audit-diagnostic / client | 26516 | 3124512 |
| native-native/overload/tcp/3/audit-diagnostic / server | 39703 | 6218432 |
| native-native/scalar/tls/1 / client | 28752 | 3125152 |
| native-native/scalar/tls/1 / server | 44126 | 6219776 |
| native-native/scalar/tls/1/audit-diagnostic / client | 28752 | 3125152 |
| native-native/scalar/tls/1/audit-diagnostic / server | 44126 | 6219776 |
| native-native/scalar/tls/2 / client | 28752 | 3125152 |
| native-native/scalar/tls/2 / server | 44126 | 6219776 |
| native-native/scalar/tls/2/audit-diagnostic / client | 28752 | 3125152 |
| native-native/scalar/tls/2/audit-diagnostic / server | 44126 | 6219776 |
| native-native/scalar/tls/3 / client | 28752 | 3125152 |
| native-native/scalar/tls/3 / server | 44125 | 6219776 |
| native-native/scalar/tls/3/audit-diagnostic / client | 28752 | 3125152 |
| native-native/scalar/tls/3/audit-diagnostic / server | 44125 | 6219776 |
| native-native/groups/tls/1 / client | 37692 | 39206816 |
| native-native/groups/tls/1 / server | 169693 | 6256640 |
| native-native/groups/tls/1/audit-diagnostic / client | 37692 | 39206816 |
| native-native/groups/tls/1/audit-diagnostic / server | 169665 | 6256640 |
| native-native/groups/tls/2 / client | 37692 | 39206816 |
| native-native/groups/tls/2 / server | 169693 | 6256640 |
| native-native/groups/tls/2/audit-diagnostic / client | 37692 | 39206816 |
| native-native/groups/tls/2/audit-diagnostic / server | 169674 | 6256640 |
| native-native/groups/tls/3 / client | 37692 | 39206816 |
| native-native/groups/tls/3 / server | 169670 | 6256640 |
| native-native/groups/tls/3/audit-diagnostic / client | 37692 | 39206816 |
| native-native/groups/tls/3/audit-diagnostic / server | 169665 | 6256640 |
| native-native/binary/tls/1 / client | 38157 | 39169952 |
| native-native/binary/tls/1 / server | 55186 | 67546240 |
| native-native/binary/tls/1/audit-diagnostic / client | 37735 | 39169952 |
| native-native/binary/tls/1/audit-diagnostic / server | 55148 | 67546240 |
| native-native/binary/tls/2 / client | 37970 | 39169952 |
| native-native/binary/tls/2 / server | 55181 | 67546240 |
| native-native/binary/tls/2/audit-diagnostic / client | 37637 | 39169952 |
| native-native/binary/tls/2/audit-diagnostic / server | 55139 | 67546240 |
| native-native/binary/tls/3 / client | 37905 | 39169952 |
| native-native/binary/tls/3 / server | 55174 | 67546240 |
| native-native/binary/tls/3/audit-diagnostic / client | 37680 | 39169952 |
| native-native/binary/tls/3/audit-diagnostic / server | 55140 | 67546240 |
| native-native/fragmentation/tls/1 / client | 41739 | 39170208 |
| native-native/fragmentation/tls/1 / server | 202530 | 67546240 |
| native-native/fragmentation/tls/1/audit-diagnostic / client | 41796 | 39170208 |
| native-native/fragmentation/tls/1/audit-diagnostic / server | 202530 | 67546240 |
| native-native/fragmentation/tls/2 / client | 41909 | 39170208 |
| native-native/fragmentation/tls/2 / server | 202530 | 67546240 |
| native-native/fragmentation/tls/2/audit-diagnostic / client | 41900 | 39170208 |
| native-native/fragmentation/tls/2/audit-diagnostic / server | 202531 | 67546240 |
| native-native/fragmentation/tls/3 / client | 41852 | 39170208 |
| native-native/fragmentation/tls/3 / server | 202530 | 67546240 |
| native-native/fragmentation/tls/3/audit-diagnostic / client | 41871 | 39170208 |
| native-native/fragmentation/tls/3/audit-diagnostic / server | 202530 | 67546240 |
| native-native/replay/tls/1 / client | 28858 | 3125408 |
| native-native/replay/tls/1 / server | 44157 | 6219776 |
| native-native/replay/tls/1/audit-diagnostic / client | 28901 | 3125408 |
| native-native/replay/tls/1/audit-diagnostic / server | 44157 | 6219776 |
| native-native/replay/tls/2 / client | 28865 | 3125408 |
| native-native/replay/tls/2 / server | 44157 | 6219776 |
| native-native/replay/tls/2/audit-diagnostic / client | 28890 | 3125408 |
| native-native/replay/tls/2/audit-diagnostic / server | 44157 | 6219776 |
| native-native/replay/tls/3 / client | 28857 | 3125408 |
| native-native/replay/tls/3 / server | 44157 | 6219776 |
| native-native/replay/tls/3/audit-diagnostic / client | 28903 | 3125408 |
| native-native/replay/tls/3/audit-diagnostic / server | 44157 | 6219776 |
| native-native/overload/tls/1 / client | 28752 | 3125152 |
| native-native/overload/tls/1 / server | 44125 | 6219776 |
| native-native/overload/tls/1/audit-diagnostic / client | 28752 | 3125152 |
| native-native/overload/tls/1/audit-diagnostic / server | 44126 | 6219776 |
| native-native/overload/tls/2 / client | 28752 | 3125152 |
| native-native/overload/tls/2 / server | 44125 | 6219776 |
| native-native/overload/tls/2/audit-diagnostic / client | 28752 | 3125152 |
| native-native/overload/tls/2/audit-diagnostic / server | 44125 | 6219776 |
| native-native/overload/tls/3 / client | 28752 | 3125152 |
| native-native/overload/tls/3 / server | 44126 | 6219776 |
| native-native/overload/tls/3/audit-diagnostic / client | 28752 | 3125152 |
| native-native/overload/tls/3/audit-diagnostic / server | 44125 | 6219776 |
| native-quickfix/scalar/tcp/1 / client | 26508 | 3124512 |
| native-quickfix/scalar/tcp/1 / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/1/audit-diagnostic / client | 26508 | 3124512 |
| native-quickfix/scalar/tcp/1/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/2 / client | 26510 | 3124512 |
| native-quickfix/scalar/tcp/2 / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/2/audit-diagnostic / client | 26508 | 3124512 |
| native-quickfix/scalar/tcp/2/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/3 / client | 26523 | 3124512 |
| native-quickfix/scalar/tcp/3 / server | 52863 | 2260544 |
| native-quickfix/scalar/tcp/3/audit-diagnostic / client | 26509 | 3124512 |
| native-quickfix/scalar/tcp/3/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/groups/tcp/1 / client | 35449 | 39206176 |
| native-quickfix/groups/tcp/1 / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/1/audit-diagnostic / client | 35449 | 39206176 |
| native-quickfix/groups/tcp/1/audit-diagnostic / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/2 / client | 35449 | 39206176 |
| native-quickfix/groups/tcp/2 / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/2/audit-diagnostic / client | 35450 | 39206176 |
| native-quickfix/groups/tcp/2/audit-diagnostic / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/3 / client | 35450 | 39206176 |
| native-quickfix/groups/tcp/3 / server | 345603 | 2297408 |
| native-quickfix/groups/tcp/3/audit-diagnostic / client | 35449 | 39206176 |
| native-quickfix/groups/tcp/3/audit-diagnostic / server | 345603 | 2297408 |
| native-quickfix/binary/tcp/1 / client | 57206 | 39169312 |
| native-quickfix/binary/tcp/1 / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/1/audit-diagnostic / client | 56821 | 39169312 |
| native-quickfix/binary/tcp/1/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/2 / client | 56851 | 39169312 |
| native-quickfix/binary/tcp/2 / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/2/audit-diagnostic / client | 55938 | 39169312 |
| native-quickfix/binary/tcp/2/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/3 / client | 57182 | 39169312 |
| native-quickfix/binary/tcp/3 / server | 50665 | 1212224 |
| native-quickfix/binary/tcp/3/audit-diagnostic / client | 56702 | 39169312 |
| native-quickfix/binary/tcp/3/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/1 / client | 53754 | 39169312 |
| native-quickfix/fragmentation/tcp/1 / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/1/audit-diagnostic / client | 54859 | 39169312 |
| native-quickfix/fragmentation/tcp/1/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/2 / client | 55205 | 39169312 |
| native-quickfix/fragmentation/tcp/2 / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/2/audit-diagnostic / client | 53801 | 39169312 |
| native-quickfix/fragmentation/tcp/2/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/3 / client | 54345 | 39169312 |
| native-quickfix/fragmentation/tcp/3 / server | 50665 | 1212224 |
| native-quickfix/fragmentation/tcp/3/audit-diagnostic / client | 53731 | 39169312 |
| native-quickfix/fragmentation/tcp/3/audit-diagnostic / server | 50665 | 1212224 |
| native-quickfix/replay/tcp/1 / client | 26576 | 3124512 |
| native-quickfix/replay/tcp/1 / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/1/audit-diagnostic / client | 26620 | 3124512 |
| native-quickfix/replay/tcp/1/audit-diagnostic / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/2 / client | 26593 | 3124512 |
| native-quickfix/replay/tcp/2 / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/2/audit-diagnostic / client | 26605 | 3124512 |
| native-quickfix/replay/tcp/2/audit-diagnostic / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/3 / client | 26596 | 3124512 |
| native-quickfix/replay/tcp/3 / server | 52867 | 2260544 |
| native-quickfix/replay/tcp/3/audit-diagnostic / client | 26581 | 3124512 |
| native-quickfix/replay/tcp/3/audit-diagnostic / server | 52867 | 2260544 |
| native-quickfix/overload/tcp/1 / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/1 / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/1/audit-diagnostic / client | 26513 | 3124512 |
| native-quickfix/overload/tcp/1/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/2 / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/2 / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/2/audit-diagnostic / client | 26522 | 3124512 |
| native-quickfix/overload/tcp/2/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/3 / client | 26508 | 3124512 |
| native-quickfix/overload/tcp/3 / server | 52863 | 2260544 |
| native-quickfix/overload/tcp/3/audit-diagnostic / client | 26509 | 3124512 |
| native-quickfix/overload/tcp/3/audit-diagnostic / server | 52863 | 2260544 |
| native-quickfix/scalar/tls/1 / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/1 / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/1/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/1/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/2 / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/2 / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/2/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/2/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/3 / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/3 / server | 52870 | 2260928 |
| native-quickfix/scalar/tls/3/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/scalar/tls/3/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/groups/tls/1 / client | 37688 | 39207072 |
| native-quickfix/groups/tls/1 / server | 345610 | 2297792 |
| native-quickfix/groups/tls/1/audit-diagnostic / client | 37688 | 39207072 |
| native-quickfix/groups/tls/1/audit-diagnostic / server | 345610 | 2297792 |
| native-quickfix/groups/tls/2 / client | 37688 | 39207072 |
| native-quickfix/groups/tls/2 / server | 345610 | 2297792 |
| native-quickfix/groups/tls/2/audit-diagnostic / client | 37688 | 39207072 |
| native-quickfix/groups/tls/2/audit-diagnostic / server | 345610 | 2297792 |
| native-quickfix/groups/tls/3 / client | 37688 | 39207072 |
| native-quickfix/groups/tls/3 / server | 345610 | 2297792 |
| native-quickfix/groups/tls/3/audit-diagnostic / client | 37688 | 39207072 |
| native-quickfix/groups/tls/3/audit-diagnostic / server | 345610 | 2297792 |
| native-quickfix/binary/tls/1 / client | 37678 | 39170208 |
| native-quickfix/binary/tls/1 / server | 50672 | 1212608 |
| native-quickfix/binary/tls/1/audit-diagnostic / client | 38371 | 39170208 |
| native-quickfix/binary/tls/1/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/binary/tls/2 / client | 38099 | 39170208 |
| native-quickfix/binary/tls/2 / server | 50672 | 1212608 |
| native-quickfix/binary/tls/2/audit-diagnostic / client | 37897 | 39170208 |
| native-quickfix/binary/tls/2/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/binary/tls/3 / client | 37639 | 39170208 |
| native-quickfix/binary/tls/3 / server | 50672 | 1212608 |
| native-quickfix/binary/tls/3/audit-diagnostic / client | 38038 | 39170208 |
| native-quickfix/binary/tls/3/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/1 / client | 41629 | 39170208 |
| native-quickfix/fragmentation/tls/1 / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/1/audit-diagnostic / client | 38548 | 39170208 |
| native-quickfix/fragmentation/tls/1/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/2 / client | 39427 | 39170208 |
| native-quickfix/fragmentation/tls/2 / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/2/audit-diagnostic / client | 38465 | 39170208 |
| native-quickfix/fragmentation/tls/2/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/3 / client | 41859 | 39170208 |
| native-quickfix/fragmentation/tls/3 / server | 50672 | 1212608 |
| native-quickfix/fragmentation/tls/3/audit-diagnostic / client | 38346 | 39170208 |
| native-quickfix/fragmentation/tls/3/audit-diagnostic / server | 50672 | 1212608 |
| native-quickfix/replay/tls/1 / client | 28857 | 3125408 |
| native-quickfix/replay/tls/1 / server | 52874 | 2260928 |
| native-quickfix/replay/tls/1/audit-diagnostic / client | 28859 | 3125408 |
| native-quickfix/replay/tls/1/audit-diagnostic / server | 52874 | 2260928 |
| native-quickfix/replay/tls/2 / client | 28840 | 3125408 |
| native-quickfix/replay/tls/2 / server | 52874 | 2260928 |
| native-quickfix/replay/tls/2/audit-diagnostic / client | 28849 | 3125408 |
| native-quickfix/replay/tls/2/audit-diagnostic / server | 52874 | 2260928 |
| native-quickfix/replay/tls/3 / client | 28848 | 3125408 |
| native-quickfix/replay/tls/3 / server | 52874 | 2260928 |
| native-quickfix/replay/tls/3/audit-diagnostic / client | 28852 | 3125408 |
| native-quickfix/replay/tls/3/audit-diagnostic / server | 52874 | 2260928 |
| native-quickfix/overload/tls/1 / client | 28748 | 3125408 |
| native-quickfix/overload/tls/1 / server | 52870 | 2260928 |
| native-quickfix/overload/tls/1/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/overload/tls/1/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/overload/tls/2 / client | 28748 | 3125408 |
| native-quickfix/overload/tls/2 / server | 52870 | 2260928 |
| native-quickfix/overload/tls/2/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/overload/tls/2/audit-diagnostic / server | 52870 | 2260928 |
| native-quickfix/overload/tls/3 / client | 28748 | 3125408 |
| native-quickfix/overload/tls/3 / server | 52870 | 2260928 |
| native-quickfix/overload/tls/3/audit-diagnostic / client | 28748 | 3125408 |
| native-quickfix/overload/tls/3/audit-diagnostic / server | 52870 | 2260928 |
| quickfix-native/scalar/tcp/1 / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/1 / server | 39704 | 6218432 |
| quickfix-native/scalar/tcp/1/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/1/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/scalar/tcp/2 / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/2 / server | 39719 | 6218432 |
| quickfix-native/scalar/tcp/2/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/2/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/scalar/tcp/3 / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/3 / server | 39697 | 6218432 |
| quickfix-native/scalar/tcp/3/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/scalar/tcp/3/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/groups/tcp/1 / client | 94804 | 463872 |
| quickfix-native/groups/tcp/1 / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/1/audit-diagnostic / client | 94804 | 463872 |
| quickfix-native/groups/tcp/1/audit-diagnostic / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/2 / client | 94804 | 463872 |
| quickfix-native/groups/tcp/2 / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/2/audit-diagnostic / client | 94804 | 463872 |
| quickfix-native/groups/tcp/2/audit-diagnostic / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/3 / client | 94804 | 463872 |
| quickfix-native/groups/tcp/3 / server | 176235 | 6255296 |
| quickfix-native/groups/tcp/3/audit-diagnostic / client | 94804 | 463872 |
| quickfix-native/groups/tcp/3/audit-diagnostic / server | 176235 | 6255296 |
| quickfix-native/binary/tcp/1 / client | 22066 | 427008 |
| quickfix-native/binary/tcp/1 / server | 61694 | 67544896 |
| quickfix-native/binary/tcp/1/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/binary/tcp/1/audit-diagnostic / server | 61624 | 67544896 |
| quickfix-native/binary/tcp/2 / client | 22066 | 427008 |
| quickfix-native/binary/tcp/2 / server | 61662 | 67544896 |
| quickfix-native/binary/tcp/2/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/binary/tcp/2/audit-diagnostic / server | 61621 | 67544896 |
| quickfix-native/binary/tcp/3 / client | 22066 | 427008 |
| quickfix-native/binary/tcp/3 / server | 61452 | 67546944 |
| quickfix-native/binary/tcp/3/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/binary/tcp/3/audit-diagnostic / server | 61511 | 67544896 |
| quickfix-native/fragmentation/tcp/1 / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/1 / server | 147432 | 67544896 |
| quickfix-native/fragmentation/tcp/1/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/1/audit-diagnostic / server | 154108 | 67544896 |
| quickfix-native/fragmentation/tcp/2 / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/2 / server | 136148 | 67544896 |
| quickfix-native/fragmentation/tcp/2/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/2/audit-diagnostic / server | 148516 | 67544896 |
| quickfix-native/fragmentation/tcp/3 / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/3 / server | 156034 | 67544896 |
| quickfix-native/fragmentation/tcp/3/audit-diagnostic / client | 22066 | 427008 |
| quickfix-native/fragmentation/tcp/3/audit-diagnostic / server | 149767 | 67544896 |
| quickfix-native/replay/tcp/1 / client | 26470 | 990976 |
| quickfix-native/replay/tcp/1 / server | 39979 | 6218432 |
| quickfix-native/replay/tcp/1/audit-diagnostic / client | 26470 | 990976 |
| quickfix-native/replay/tcp/1/audit-diagnostic / server | 40017 | 6218432 |
| quickfix-native/replay/tcp/2 / client | 26470 | 990976 |
| quickfix-native/replay/tcp/2 / server | 39993 | 6218432 |
| quickfix-native/replay/tcp/2/audit-diagnostic / client | 26470 | 990976 |
| quickfix-native/replay/tcp/2/audit-diagnostic / server | 40127 | 6218432 |
| quickfix-native/replay/tcp/3 / client | 26470 | 990976 |
| quickfix-native/replay/tcp/3 / server | 40056 | 6218432 |
| quickfix-native/replay/tcp/3/audit-diagnostic / client | 26470 | 990976 |
| quickfix-native/replay/tcp/3/audit-diagnostic / server | 39969 | 6218432 |
| quickfix-native/overload/tcp/1 / client | 26464 | 990208 |
| quickfix-native/overload/tcp/1 / server | 39715 | 6218432 |
| quickfix-native/overload/tcp/1/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/overload/tcp/1/audit-diagnostic / server | 39699 | 6218432 |
| quickfix-native/overload/tcp/2 / client | 26464 | 990208 |
| quickfix-native/overload/tcp/2 / server | 39706 | 6218432 |
| quickfix-native/overload/tcp/2/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/overload/tcp/2/audit-diagnostic / server | 39731 | 6218432 |
| quickfix-native/overload/tcp/3 / client | 26464 | 990208 |
| quickfix-native/overload/tcp/3 / server | 39695 | 6218432 |
| quickfix-native/overload/tcp/3/audit-diagnostic / client | 26464 | 990208 |
| quickfix-native/overload/tcp/3/audit-diagnostic / server | 39695 | 6218432 |
| quickfix-native/scalar/tls/1 / client | 26471 | 990592 |
| quickfix-native/scalar/tls/1 / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/1/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/scalar/tls/1/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/2 / client | 26471 | 990592 |
| quickfix-native/scalar/tls/2 / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/2/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/scalar/tls/2/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/3 / client | 26471 | 990592 |
| quickfix-native/scalar/tls/3 / server | 44118 | 6219776 |
| quickfix-native/scalar/tls/3/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/scalar/tls/3/audit-diagnostic / server | 44120 | 6219776 |
| quickfix-native/groups/tls/1 / client | 94811 | 464256 |
| quickfix-native/groups/tls/1 / server | 169658 | 6256640 |
| quickfix-native/groups/tls/1/audit-diagnostic / client | 94811 | 464256 |
| quickfix-native/groups/tls/1/audit-diagnostic / server | 169658 | 6256640 |
| quickfix-native/groups/tls/2 / client | 94811 | 464256 |
| quickfix-native/groups/tls/2 / server | 169658 | 6256640 |
| quickfix-native/groups/tls/2/audit-diagnostic / client | 94811 | 464256 |
| quickfix-native/groups/tls/2/audit-diagnostic / server | 169658 | 6256640 |
| quickfix-native/groups/tls/3 / client | 94811 | 464256 |
| quickfix-native/groups/tls/3 / server | 169658 | 6256640 |
| quickfix-native/groups/tls/3/audit-diagnostic / client | 94811 | 464256 |
| quickfix-native/groups/tls/3/audit-diagnostic / server | 169658 | 6256640 |
| quickfix-native/binary/tls/1 / client | 22073 | 427392 |
| quickfix-native/binary/tls/1 / server | 55138 | 67546240 |
| quickfix-native/binary/tls/1/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/binary/tls/1/audit-diagnostic / server | 55264 | 67546240 |
| quickfix-native/binary/tls/2 / client | 22073 | 427392 |
| quickfix-native/binary/tls/2 / server | 55175 | 67546240 |
| quickfix-native/binary/tls/2/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/binary/tls/2/audit-diagnostic / server | 55361 | 67546240 |
| quickfix-native/binary/tls/3 / client | 22073 | 427392 |
| quickfix-native/binary/tls/3 / server | 55133 | 67546240 |
| quickfix-native/binary/tls/3/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/binary/tls/3/audit-diagnostic / server | 55304 | 67546240 |
| quickfix-native/fragmentation/tls/1 / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/1 / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/1/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/1/audit-diagnostic / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/2 / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/2 / server | 202526 | 67546240 |
| quickfix-native/fragmentation/tls/2/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/2/audit-diagnostic / server | 202521 | 67546240 |
| quickfix-native/fragmentation/tls/3 / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/3 / server | 202522 | 67546240 |
| quickfix-native/fragmentation/tls/3/audit-diagnostic / client | 22073 | 427392 |
| quickfix-native/fragmentation/tls/3/audit-diagnostic / server | 202521 | 67546240 |
| quickfix-native/replay/tls/1 / client | 26477 | 991360 |
| quickfix-native/replay/tls/1 / server | 44506 | 6219776 |
| quickfix-native/replay/tls/1/audit-diagnostic / client | 26477 | 991360 |
| quickfix-native/replay/tls/1/audit-diagnostic / server | 44441 | 6219776 |
| quickfix-native/replay/tls/2 / client | 26477 | 991360 |
| quickfix-native/replay/tls/2 / server | 44539 | 6219776 |
| quickfix-native/replay/tls/2/audit-diagnostic / client | 26477 | 991360 |
| quickfix-native/replay/tls/2/audit-diagnostic / server | 44620 | 6219776 |
| quickfix-native/replay/tls/3 / client | 26477 | 991360 |
| quickfix-native/replay/tls/3 / server | 44591 | 6219776 |
| quickfix-native/replay/tls/3/audit-diagnostic / client | 26477 | 991360 |
| quickfix-native/replay/tls/3/audit-diagnostic / server | 44547 | 6219776 |
| quickfix-native/overload/tls/1 / client | 26471 | 990592 |
| quickfix-native/overload/tls/1 / server | 44118 | 6219776 |
| quickfix-native/overload/tls/1/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/overload/tls/1/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/overload/tls/2 / client | 26471 | 990592 |
| quickfix-native/overload/tls/2 / server | 44122 | 6219776 |
| quickfix-native/overload/tls/2/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/overload/tls/2/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-native/overload/tls/3 / client | 26471 | 990592 |
| quickfix-native/overload/tls/3 / server | 44118 | 6219776 |
| quickfix-native/overload/tls/3/audit-diagnostic / client | 26471 | 990592 |
| quickfix-native/overload/tls/3/audit-diagnostic / server | 44118 | 6219776 |
| quickfix-quickfix/scalar/tcp/1 / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/1 / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/1/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/1/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/2 / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/2 / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/2/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/2/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/3 / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/3 / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tcp/3/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/scalar/tcp/3/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/groups/tcp/1 / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/1 / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/1/audit-diagnostic / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/1/audit-diagnostic / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/2 / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/2 / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/2/audit-diagnostic / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/2/audit-diagnostic / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/3 / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/3 / server | 345600 | 2297408 |
| quickfix-quickfix/groups/tcp/3/audit-diagnostic / client | 94801 | 463424 |
| quickfix-quickfix/groups/tcp/3/audit-diagnostic / server | 345600 | 2297408 |
| quickfix-quickfix/binary/tcp/1 / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/1 / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/1/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/1/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/2 / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/2 / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/2/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/2/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/3 / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/3 / server | 50662 | 1212224 |
| quickfix-quickfix/binary/tcp/3/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/binary/tcp/3/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/1 / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/1 / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/1/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/1/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/2 / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/2 / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/2/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/2/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/3 / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/3 / server | 50662 | 1212224 |
| quickfix-quickfix/fragmentation/tcp/3/audit-diagnostic / client | 22063 | 426560 |
| quickfix-quickfix/fragmentation/tcp/3/audit-diagnostic / server | 50662 | 1212224 |
| quickfix-quickfix/replay/tcp/1 / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/1 / server | 52865 | 2260544 |
| quickfix-quickfix/replay/tcp/1/audit-diagnostic / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/1/audit-diagnostic / server | 52865 | 2260544 |
| quickfix-quickfix/replay/tcp/2 / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/2 / server | 52866 | 2260544 |
| quickfix-quickfix/replay/tcp/2/audit-diagnostic / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/2/audit-diagnostic / server | 52867 | 2260544 |
| quickfix-quickfix/replay/tcp/3 / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/3 / server | 52867 | 2260544 |
| quickfix-quickfix/replay/tcp/3/audit-diagnostic / client | 26464 | 990080 |
| quickfix-quickfix/replay/tcp/3/audit-diagnostic / server | 52866 | 2260544 |
| quickfix-quickfix/overload/tcp/1 / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/1 / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/1/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/1/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/2 / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/2 / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/2/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/2/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/3 / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/3 / server | 52860 | 2260544 |
| quickfix-quickfix/overload/tcp/3/audit-diagnostic / client | 26461 | 989760 |
| quickfix-quickfix/overload/tcp/3/audit-diagnostic / server | 52860 | 2260544 |
| quickfix-quickfix/scalar/tls/1 / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/1 / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/1/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/1/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/2 / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/2 / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/2/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/2/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/3 / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/3 / server | 52867 | 2260928 |
| quickfix-quickfix/scalar/tls/3/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/scalar/tls/3/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/groups/tls/1 / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/1 / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/1/audit-diagnostic / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/1/audit-diagnostic / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/2 / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/2 / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/2/audit-diagnostic / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/2/audit-diagnostic / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/3 / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/3 / server | 345607 | 2297792 |
| quickfix-quickfix/groups/tls/3/audit-diagnostic / client | 94808 | 463808 |
| quickfix-quickfix/groups/tls/3/audit-diagnostic / server | 345607 | 2297792 |
| quickfix-quickfix/binary/tls/1 / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/1 / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/1/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/1/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/2 / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/2 / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/2/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/2/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/3 / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/3 / server | 50669 | 1212608 |
| quickfix-quickfix/binary/tls/3/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/binary/tls/3/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/1 / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/1 / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/1/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/1/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/2 / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/2 / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/2/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/2/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/3 / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/3 / server | 50669 | 1212608 |
| quickfix-quickfix/fragmentation/tls/3/audit-diagnostic / client | 22070 | 426944 |
| quickfix-quickfix/fragmentation/tls/3/audit-diagnostic / server | 50669 | 1212608 |
| quickfix-quickfix/replay/tls/1 / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/1 / server | 52875 | 2260928 |
| quickfix-quickfix/replay/tls/1/audit-diagnostic / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/1/audit-diagnostic / server | 52874 | 2260928 |
| quickfix-quickfix/replay/tls/2 / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/2 / server | 52873 | 2260928 |
| quickfix-quickfix/replay/tls/2/audit-diagnostic / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/2/audit-diagnostic / server | 52873 | 2260928 |
| quickfix-quickfix/replay/tls/3 / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/3 / server | 52873 | 2260928 |
| quickfix-quickfix/replay/tls/3/audit-diagnostic / client | 26471 | 990464 |
| quickfix-quickfix/replay/tls/3/audit-diagnostic / server | 52873 | 2260928 |
| quickfix-quickfix/overload/tls/1 / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/1 / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/1/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/1/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/2 / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/2 / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/2/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/2/audit-diagnostic / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/3 / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/3 / server | 52867 | 2260928 |
| quickfix-quickfix/overload/tls/3/audit-diagnostic / client | 26468 | 990144 |
| quickfix-quickfix/overload/tls/3/audit-diagnostic / server | 52867 | 2260928 |

## Comparability and evidence

- bind: native loopback; QuickFIX wildcard IPv4; local clients use localhost.
- validation: native declared typed dictionary; QuickFIX canonical dictionary and default validation; directional interop expectations are recorded separately.
- archive: native replayable bodies; QuickFIX serialized FIX messages; same configured count/byte bounds, different stored representation.
- logging: peer wire/event logging disabled; timing relay aggregate summary.
- wireCounters: native socket-completed; QuickFIX SDK wire attempts.
- resources: wait4 whole process including startup/warmup/shutdown and libtool wrapper/fork-exec highwater; inherited pre-exec RSS can dominate small cases; latency/throughput cover measured workload.
- relay: fragmentation/replay traverse Python and, for TLS, verified termination/re-encryption; compare to same relay profile only.
- remote: remote server resources and binary identity unmeasured unless provided separately; remote service lifecycle externally managed.

Actual ELF hashes, file bytes, section sizes, linked-library lists, compiler flags, SDK/dictionary pins and CPU metadata are in manifest.json. All commands, exits, raw session quantiles, wire counts, resource observations and failures are in each case.json. The independent correctness gate supplies detailed replay/OriginalSendingTime proof; aggregate timing relay counters do not.
