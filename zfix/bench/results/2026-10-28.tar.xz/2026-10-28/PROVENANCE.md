# Snapshot and verification boundaries

`RESULTS.md`, `build-manifest.json`, codec rows and the `process/` tree are the
fresh post-Link, fixed-codec-input optimized/instrumented measurement snapshot. Their recorded
source paths and binary hashes describe that run. The complete original
pre-Link measurement snapshot remains separately under `prior/pre-Link/`. Raw
measurement files and manifests are copied without rewriting their contents.
`prior/pre-codec-input-fix/` preserves the rejected post-Link run, including its
failed independent verification. Its native and QuickFIX codec fixtures sampled
different wall-clock timestamps with different fractional precision. A single
shared fixed nine-digit timestamp repairs only the fixture input. The fresh
snapshot reruns every process and codec case; no accepted/rejected samples are
combined and the failed verification is not relabelled as passing.

`verification/pre-layout/` contains the earlier delivery checks.
`verification/layout/` records the later fixture/role moves and Link refactor.
`verification/current/` contains separately pinned post-Link checks. These are
correctness and provenance evidence, not additional timing samples. They do not
retroactively measure rebuilt binaries or replace the snapshot's executable and
loaded-library hashes. The current index states its applicability assessment.

The Link owner body's identifier-only comparison establishes source behavior
preservation; it alone does not establish generated-code, object-layout or
performance identity. The post-Link measurement is a fresh run; no pre-Link
samples are substituted, combined or used to label rebuilt binaries as measured.
